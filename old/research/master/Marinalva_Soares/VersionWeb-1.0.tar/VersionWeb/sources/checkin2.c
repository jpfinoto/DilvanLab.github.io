/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */                                                                                  
/******************************************************************************************************************/

// Este CGI efetua o commit de um arquivo do qual foi feito checkout local
// de uma versao especifica e gera branches

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void AlteraDiretorio(char *Caminho);

int main (void)
{
 unsigned char *String,*Texto;
 char Arquivo[100],NomeArquivo[100],Login[30],CaminhoRepositorio[100],Caminho[100],Comando[100],Linha[255];
 char ModuloCheckout[100],*Resultado,buf[10000],ModuloCheckoutAux[100],ListaConteudoDiretorio[100],StringAux[100],LinhaControle[100],LinhaAux[30];
 char LogMensagem[200],Revisao[50],CaminhoRepositorioAux[100];
 int Tamanho,Tamanho2,buffer,BytesLidos,Cont=0,cont2,i=0,Contador,indice=0;
 FILE *ArquivoDados,*ArquivoCheckout,*ConteudoDiretorio,*RevisaoCheckout,*ArquivoCommit,*ArquivoCaminhoRepositorio;

 // obtem o tamnaho do arquivo + caracteres de ccontrole
 const char *TamanhoInformacao = getenv("CONTENT_LENGTH");
 Tamanho=atoi(TamanhoInformacao);

 //aloca o tamanho lido do arquivo
 String = malloc(Tamanho+1);
 Texto = malloc(Tamanho+1);

 // obtem o conteudo do arquivo + caracteres de controle em stdin
 fread(String,Tamanho,1,stdin);

 //guarda a linha de controle inicial pra compara-la no final (ate onde o arquivo deve ser lido)
 while (String[Cont] != '\n')
 {
  LinhaControle[Cont] = String[Cont];
  Cont++;
 }
 LinhaControle[Cont-1] = '\0';

 while (String[Cont] != '"') //primeira aspa (antes do nome do formulario para upload)
  Cont++;
 Cont++;

 //o nome do usuario e o caminho do repositorio vem no valor do campo name do arquivo de upload
 while (String[Cont] != '_') // obtem o nome do usuario para fazer o commit no nome dele
 {
  Login[i] = String[Cont];
  Cont++; i++;
 }
 Login[i] = '\0';
 i=0; Cont++;

 while (String[Cont] != '"') // obtem o valor do caminho do repositorio cvs
 {
  if (String[Cont] == '%') //%2F (/)
  {
   CaminhoRepositorio[i] = '/';
   Cont+=2;
  }
  else
   CaminhoRepositorio[i] = String[Cont];
  Cont++; i++;
 }
 CaminhoRepositorio[i] = '\0';
 i=0;

 while (String[Cont] != '=') //le ate o nome do campo do arquivo
  Cont++;
 Cont+=2; //elimina a aspa antes do nome do arquivo

 while (String[Cont]!= '"')//tudo que vier antes dessa aspa e o nome do arquivo
 {
  Arquivo[i] = String[Cont];
  i++; Cont++;
 }
 Arquivo[i] = '\0';

 //se for upload atraves do windows, tira todas as barras, pois vem com o nome do diretorio
 //coloca o nome do arquivo na ordem inversa
 indice=0;
 for (i=strlen(Arquivo)-1;i>=0;i--)
 {
  if ((Arquivo[i] != '/') && (Arquivo[i] != '\\'))
  {
   NomeArquivo[indice] = Arquivo[i];
    indice++;
  }
  else
   break;
 }
 NomeArquivo[indice] = '\0';

 //coloca o nome do arquivo na ordem certa
 indice=0;
 i=strlen(NomeArquivo)-1;
 while (i >=0)
 {
  Arquivo[indice] = NomeArquivo[i];
  indice++; i--;
 }
 Arquivo[indice] = '\0';

 Cont+=3;

 for (i=0;i<=12;i++)
 {
  if ((String[Cont] != '\r') && (String[Cont] != '\n')) //esses caracteres devem ser eliminados, pois nao fazem parte do conteudo do arquivo, e sim do cabecalho
   Texto[i] = String[Cont];
  Cont++;
 }

 Tamanho2=0; //variavel que sera o tamanho real a ser gravado
 //verifica se existe um Content-Type que diz qual e o tipo do arquivo,senao o proximo caractere ja faz parte do conteudo do arquivo
 if (!strcmp(Texto,"Content-Type:")) //se for igual e porque o arquivo tem um tipo
 {
  while (String[Cont] != '\r')
   Cont++;
  Cont++;
  while (String[Cont] != '\n')
   Cont++;

  while (String[Cont] != '\r')
   Cont++;
  Cont++;
  while (String[Cont] != '\n')
   Cont++;
  Cont++;

  Texto[0] = '\0';
  i=0;

  while (Cont < Tamanho) //le o conteudo do arquivo ate o final
  {
   if ((i==0) && ((String[Cont] == '\r') || (String[Cont] == '\n'))) //esses caracteres, se existirem, nao fazem parte do arquivo
    Cont++;
   else
   {
    //verifica se o '-' faz parte da linha de controle
    if (String[Cont] == '-')
    {
     cont2=Cont; // guarda o Cont pra nao perder a posicao atual do arquivo
     for (indice=0;indice<strlen(LinhaControle);indice++)
     {
      StringAux[indice] = String[cont2];
      cont2++;
     }
     StringAux[indice] = '\0';
    }
    if (strcmp(StringAux,LinhaControle)) //se for diferente da linha de controle, deve continuar lendo e gravando
    {
     Texto[i] = String[Cont];
     i++;  Tamanho2++;  Cont++;
    }
    else //chegou ao final e encontrou a linha de controle
    {
     while (String[Cont] != '"')
      Cont++;
     Cont++;
     while (String[Cont] != '"')
      Cont++;
     Cont++;
     while ((String[Cont] == '\r') || (String[Cont] == '\n'))
      Cont++;
     indice=0;
     while ((String[Cont] != '\r') && (String[Cont] != '\n'))
     {
      LogMensagem[indice] = String[Cont];
      Cont++; indice++;
     }
     LogMensagem[indice] = '\0';
     while (String[Cont] != '"')
      Cont++;
     Cont++;
     while (String[Cont] != '"')
      Cont++;
     Cont++;
     while ((String[Cont] == '\r') || (String[Cont] == '\n'))
      Cont++;

     indice=0;
     while ((String[Cont] != '\r') && (String[Cont] != '\n'))
     {
      Revisao[indice] = String[Cont];
      Cont++; indice++;
     }
     Revisao[indice] = '\0';
     break;
    }
   }
  }
 }
 else //nao tem tipo de arquivo
 {
  while (Cont < Tamanho) //le o conteudo do arquivo ate o tamanho maximo
  {
   //verifica se o '-' faz parte da linha de controle
   if (String[Cont] == '-')
   {
    cont2=Cont;
    for (indice=0;indice<strlen(LinhaControle);indice++)
    {
     StringAux[indice] = String[cont2];
     cont2++;
    }
    StringAux[indice] = '\0';
   }
   if (strcmp(StringAux,LinhaControle)) //se for diferente da linha de controle, deve continuar lendo e gravando
   {
    Texto[i] = String[Cont];
    i++;  Tamanho2++;  Cont++;
   }
   else
   {
    Tamanho2=i-2;// o tamanho2 fica com dois bytes a mais, entao deve remove-lo
    while (String[Cont] != '"')
     Cont++;
    Cont++;
    while (String[Cont] != '"')
     Cont++;
    Cont++;
    while ((String[Cont] == '\r') || (String[Cont] == '\n'))
     Cont++;
    indice=0;
    while ((String[Cont] != '\r') && (String[Cont] != '\n'))
    {
     LogMensagem[indice] = String[Cont];
     Cont++; indice++;
    }
    LogMensagem[indice] = '\0';
    while (String[Cont] != '"')
     Cont++;
    Cont++;
    while (String[Cont] != '"')
     Cont++;
    Cont++;
    while ((String[Cont] == '\r') || (String[Cont] == '\n'))
     Cont++;
    indice=0;
    while ((String[Cont] != '\r') && (String[Cont] != '\n'))
    {
     Revisao[indice] = String[Cont];
     Cont++; indice++;
    }
    Revisao[indice] = '\0';
    break;
   }
  }
 }
 Texto[i] = '\0';

 //posiciona dentro do diretorio tmp para pegar o caminho do repositorio que esta
 // gravado no arquivo "caminho"
 strcpy(Caminho,"/tmp/");
 strcat(Caminho,Login);
 strcat(Caminho,"/");
 AlteraDiretorio(Caminho);

 if ((ArquivoCaminhoRepositorio=fopen("caminho","r")) == NULL)  //a primeira linha do arquivo contem o caminho do repositorio
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<head>");
  printf("<script>");
  printf("alert(\"Error to open file...\");\n");
  printf("</script>\n");
  printf("</head>");
  printf("</html>");
  free(String); free(Texto);
  exit(1);
 }
 rewind(ArquivoCaminhoRepositorio);
 fgets(Linha,100,ArquivoCaminhoRepositorio); //a primeira linha do arquivo vale o caminho do repositorio informado pelo usuario na tela de login
 Linha[strlen(Linha)-1] = '\0';

 //salva essa linha para usar no checkout com pserver depois
 strcpy(CaminhoRepositorioAux,Linha);
 //elimina a ultima barra do caminho do repositorio, pois no pserver na o pode colocar a ultima barra
 CaminhoRepositorioAux[strlen(CaminhoRepositorioAux)-1] = '\0';
 fclose(ArquivoCaminhoRepositorio);

 Cont=0;
 while (Linha[Cont] == CaminhoRepositorio[Cont]) //CaminhoRepositorio vale o caminho completo sem o arquivo para checkout, ou seja, ate o ultimo diretorio listado
  Cont++;
 i=0;

 while (CaminhoRepositorio[Cont] != '\0') //pega somente a parte selecionada pelo usuario (diretorio e arquivo)
 {
  ModuloCheckout[i] = CaminhoRepositorio[Cont]; //ModuloCheckout vale tudo que vem depois do caminhorepositorio na tela de login
  Cont++; i++;
 }
 ModuloCheckout[i] = '\0';

 Cont=0;
 while (ModuloCheckout[Cont] != '/') //pega somente o primeiro diretorio para remove-lo depois
 {
  ModuloCheckoutAux[Cont] = ModuloCheckout[Cont];
  Cont++;
 }
 ModuloCheckoutAux[Cont] = '\0';


 //posiciona dentro do modulo que fez checkout local (no diretorio do usuario) para verificar se
 //o usuario fez chekout local do arquivo que ele esta querendo fazer checkin
 strcpy(Caminho,LOCALCHECKOUT);
 strcat(Caminho,Login);
 strcat(Caminho,"/");
 strcat(Caminho,ModuloCheckout);
 //posiciona dentro do diretorio que foi feito checkout local pra verificar se o arquivo que se quer fazer o commit existe no repositorio
 AlteraDiretorio(Caminho);

 //verifica se o arquivo para commit existe
 strcpy(ListaConteudoDiretorio,"ls -l ");
 strcat(ListaConteudoDiretorio,Arquivo);
 strcat(ListaConteudoDiretorio," > arquivos"); //coloca o resultado de ls dentro do arquivo "arquivos"

 system(ListaConteudoDiretorio);

 if ((ConteudoDiretorio=fopen("arquivos","r")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<base href=%s>",IMAGES);
  printf("<body background=bolor.jpg>");
  printf("<script>");
  printf("alert(\"Error to open file!\")\n");
  printf("</script>\n");
  printf("</body></html>");
  free(String); free(Texto);
  exit(1);
 }
 rewind(ConteudoDiretorio);
 Linha[0] = '\0';
 fgets(Linha,255,ConteudoDiretorio);
 fclose(ConteudoDiretorio);

 //pega o nome do arquivo (ordem inversa), exemplo:-rw-r--r--   1 root     root        30033 Oct 23 10:05 commit.c
 i=0;
 for (Cont=strlen(Linha)-2;Cont>0;Cont--)
 {
  if (Linha[Cont] != ' ')
  {
   LinhaAux[i] = Linha[Cont];
   i++;
  }
  else
   break;
 }
 LinhaAux[i] = '\0'; //LinhaAux vale "c.timmoc"

 //coloca o arquivo na ordem correta
 Cont=0;
 i=strlen(LinhaAux)-1;
 while (i >=0)
 {
  Linha[Cont] = LinhaAux[i];
  Cont++; i--;
 }
 Linha[Cont] = '\0';

 //se o arquivo "arquivos estiver em branco" e' proque nao foi feito o checkout local do arquivo que se deseja fazer o commit
 if (strcmp(Linha,Arquivo))
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<base href=%s>",IMAGES);
  printf("<body background=bolor.jpg>");
  printf("<script>");
  printf("alert(\"You did not make local checkout of this file!\")\n");
  printf("</script>\n");
  printf("</body></html>");
  free(String); free(Texto);
  exit(1);
 }

 //se foi feito o checkout local do arquivo, este arquivo "revisaocheckout" contem a revisao que foi feito o chekout local
 //este arquivo e' gerado na hora em que faz o checkout local
 if ((RevisaoCheckout = fopen("revisaocheckout","r")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<base href=%s>",IMAGES);
  printf("<body background=bolor.jpg>");
  printf("<script>");
  printf("alert(\"The file revision cannot be open!\")\n");
  printf("</script>\n");
  printf("</body></html>");
  free(String); free(Texto);
  exit(1);
 }
 fgets(Linha,30,RevisaoCheckout); //pega o numero da revisao que foi efetuada o checkout local
 fclose(RevisaoCheckout);
 Linha[strlen(Linha)-1] = '\0';

 strcpy(Caminho,LOCALCHECKOUT);
 strcat(Caminho,Login);
 strcat(Caminho,"/");
 AlteraDiretorio(Caminho);

 strcpy(Comando,"cvs -d :pserver:");
 strcat(Comando,Login);
 strcat(Comando,"@");
 strcat(Comando,HOST);
 strcat(Comando,CaminhoRepositorioAux);
 strcat(Comando," co -r");
 strcat(Comando,Linha); //essa linha contem a revisao lida do arquivo / revisao que foi feito o chec. local antes
 strcat(Comando," ");
 strcat(Comando,ModuloCheckout);
 strcat(Comando,Arquivo);

 //faz checkout da rev. espec. do arquivo para gerar a branche com as modificacoes que fez localmente do chec. local
 Resultado = malloc(10000);
 if ((ArquivoCheckout = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, ArquivoCheckout) != NULL)
  {
   strcat(Resultado, buf);
   strcat(Resultado, "<br>");
  }
  pclose(ArquivoCheckout);
 }
 free(Resultado);

 //posiciona dentro do diretorio que foi feito o checkout para substituir o arquivo antigo pelo novo
 strcpy(Caminho,LOCALCHECKOUT);
 strcat(Caminho,Login);
 strcat(Caminho,"/");
 strcat(Caminho,ModuloCheckout);

 AlteraDiretorio(Caminho);

 remove(Arquivo); //remove o arquivo antigo e substitui pelo novo

 if ((ArquivoDados=fopen(Arquivo,"a+")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<base href=%s>",IMAGES);
  printf("<body background=bolor.jpg>");
  printf("<script>");
  printf("alert(\"Error to open file...\")\n");
  printf("</script>\n");
  printf("</body></html>");
  free(String); free(Texto);
  exit(1);
 }
 rewind(ArquivoDados);
 fwrite(Texto,Tamanho2-2,1,ArquivoDados);
 fclose(ArquivoDados);

 strcpy(Comando,"cvs commit -r ");
 strcat(Comando,Revisao);
 strcat(Comando," -m \"");
 strcat(Comando,LogMensagem);
 strcat(Comando,"\" ");
 strcat(Comando,Arquivo);

 //faz o commit do arquivo gerando a branche especificada
 Resultado = malloc(10000);
 if ((ArquivoCommit = popen(Comando,"r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, ArquivoCommit) != NULL)
  {
   strcat(Resultado, buf);
   strcat(Resultado, "<br>");
  }
  pclose(ArquivoCommit);
 }

 //posiciona dentro do diretorio html para remover o diretorio do usuario
 strcpy(Caminho,LOCALCHECKOUT);

 //verifica se o commit deu errado
 if ((!strstr(Resultado,"done")) || (!strstr(Resultado,"new revision:")))
 {
  free(Resultado);
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<base href=%s>",IMAGES);
  printf("<body background=bolor.jpg>");
  printf("<script language=javascript>");
  printf("alert(\"Conflits found in %s! The revision could not be generated!\");",Arquivo);
  printf("</script>");
  printf("</body></html>");
  free(String); free(Texto);
  exit(1);
 }
 else //deu certo
 {
  free(Resultado);
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<base href=%s>",IMAGES);
  printf("<body background=bolor.jpg>");
  printf("<script language=javascript>");
  printf("alert(\"Commit done! Reload this page!\");");
  printf("</script></body></html>");
  free(String); free(Texto);
  exit(1);
 }
 return;
}

void AlteraDiretorio(char *Caminho)
{
 if (chdir(Caminho))
 {
  perror("chdir()");
  exit(1);
 }
}
