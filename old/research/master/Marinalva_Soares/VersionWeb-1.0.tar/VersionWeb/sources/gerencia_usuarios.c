/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */                                                                                 
/******************************************************************************************************************/

// Este cgi exibe o formulario de gerenciamento de usuarios

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void AlteraDiretorio(char *Caminho);
char *CriptografaSenha(char SenhaUsuario[20]);
char *rsalt();
void AutenticaAdministrador(char LoginAux[20],char SenhaAux[20]);
void ExibeFormulario_Usuarios();
char CaminhoRepositorio[100];

int main (void)
{
 unsigned char *String,Login[20],Senha[20],*SenhaCriptografada,PrimeiroCampo[100];
 char Nome[50],TipoUsuario[20],Operacao[10];
 char LinhaArquivoUsuario[100],LinhaArquivoPasswd[100],LinhaU[100],LinhaP[100],LinhaPAux[10],Lista[50],Indice[20];
 int Cont=0,I=0,Flag=0,IndiceAutor,IndiceGrupo,IndiceAdministrador,Ia,Ig,Ix,Tamanho;

 //o arquivo de usuarios guarda o flag, nome,login e senha do usuario
 //o arquivo de passwd guarda o usuario, a senha e nobody
 FILE *ArquivoUsuarios,*ArquivoPasswd,*ArquivoAuxUsuario,*ArquivoAuxPasswd;

 String = getenv("QUERY_STRING");

 while (String[Cont] != '=') //elimina o nome do campo de login
 {
  PrimeiroCampo[Cont] = String[Cont];
  Cont++;
 }
 PrimeiroCampo[Cont] = '\0';

 //se o primeiro campo for login, entao deve fazer a autenticacao do usuario e depois exibir o formulario de usuarios
 if (!strcmp(PrimeiroCampo,"login"))
 {
  Cont++; 
  while(String[Cont] != '&')
  {
   Login[I] = String[Cont];
   Cont++; I++;
  }
  Login[I] = '\0';
  I=0;
  while (String[Cont] != '=') //elimina o nome do campo da senha
   Cont++;
  Cont++; 
  while(String[Cont] != '&')
  {
   Senha[I] = String[Cont];
   Cont++; I++;
  }
  Senha[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo do caminho do repositorio
   Cont++;
  Cont++; 
  while(String[Cont] != '&')
  {
   if (String[Cont] == '%') //%2F (/)
   {
    CaminhoRepositorio[I] = '/';
    Cont+=2;
   }
   else
    CaminhoRepositorio[I] = String[Cont];
   Cont++; I++;
  }
  CaminhoRepositorio[I] = '\0';
  
  if (CaminhoRepositorio[strlen(CaminhoRepositorio)-1] != '/') 
   strcat(CaminhoRepositorio,"/CVSROOT/");
  else
   strcat(CaminhoRepositorio,"CVSROOT/");

  AlteraDiretorio(CaminhoRepositorio);

  SenhaCriptografada = malloc(20);
  strcpy(SenhaCriptografada,CriptografaSenha(Senha));
  AutenticaAdministrador(Login,SenhaCriptografada);
  free (SenhaCriptografada);
  ExibeFormulario_Usuarios();
  return;
 }

 //pega o tipo de operacao
 Cont++; //elimina o '=' antes do tipo de operacao
 I=0;
 while (String[Cont] != '&')
 {
  Operacao[I] = String[Cont];
  Cont++; I++;
 }
 Operacao[I] = '\0';
 I=0;

 if (!strcmp(Operacao,"inserir"))
 {
  while (String[Cont] != '=') //elimina o nome do campo tipo de usuario a ser inserido
   Cont++;
  Cont++;

  while (String[Cont] != '&') //pega o tipo de usuario (autor, grupo ou administrador)
  {
   TipoUsuario[I] = String[Cont];
   Cont++; I++;
  }
  TipoUsuario[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo nome do usuario a ser inserido
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&') //pega o nome do usuario
  {
   if (String[Cont] == '+')
    Nome[I] = ' ';
   else
    Nome[I] = String[Cont];
   Cont++; I++;
 }
  Nome[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo de login (username)
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&') //pega o username
  {
   Login[I] = String[Cont];
   Cont++; I++;
  }
  Login[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo de senha
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&') //pega a senha
  {
   Senha[I] = String[Cont];
   Cont++; I++;
  }
  Senha[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo caminho do repositorio
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&')
  {
   if (String[Cont] == '%') //%2F (/)
   {
    CaminhoRepositorio[I] = '/';
    Cont+=2;
   }
   else
    CaminhoRepositorio[I] = String[Cont];
   Cont++; I++;
  }
  CaminhoRepositorio[I] = '\0';
  I=0;
 }

 if (!strcmp(Operacao,"alterar"))
 {
  while (String[Cont] != '=') //elimina o nome do campo da lista de usuarios
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&') //pega o nome da lista
  {
   Lista[I] = String[Cont];
   Cont++; I++;
  }
  Lista[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo indice da lista selecionada
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&') //pega o indice da lista selecionada
  {
   Indice[I] = String[Cont];
   Cont++; I++;
  }
  Indice[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo de nome do usuario
   Cont++;
  Cont++;

  while (String[Cont] != '&') //pega o nome do usuario
  {
   if (String[Cont] == '+')
    Nome[I] = ' ';
   else
    Nome[I] = String[Cont];
   Cont++; I++;
  }
  Nome[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo de login do usuario
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&') //pega o username
  {
   Login[I] = String[Cont];
   Cont++; I++;
  }
  Login[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo de senha
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&') //pega a senha
  {
   Senha[I] = String[Cont];
   Cont++; I++;
  }
  Senha[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo caminho do repositorio
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&')
  {
   if (String[Cont] == '%') //%2F (/)
   {
    CaminhoRepositorio[I] = '/';
    Cont+=2;
   }
   else
    CaminhoRepositorio[I] = String[Cont];
   Cont++; I++;
  }
  CaminhoRepositorio[I] = '\0';
  I=0;
 }

 if (!strcmp(Operacao,"remover"))
 {
  while (String[Cont] != '=') //elimina o nome do campo da lista de usuarios
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&') //pega o nome da lista
  {
   Lista[I] = String[Cont];
   Cont++; I++;
  }
  Lista[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo indice da lista selecionada
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&') //pega o indice da lista selecionada
  {
   Indice[I] = String[Cont];
   Cont++; I++;
  }
  Indice[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo caminho do repositorio
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&')
  {
   if (String[Cont] == '%') //%2F (/)
   {
    CaminhoRepositorio[I] = '/';
    Cont+=2;
   }
   else
    CaminhoRepositorio[I] = String[Cont];
   Cont++; I++;
  }
  CaminhoRepositorio[I] = '\0';
  I=0;
 }

 if (!strcmp(Operacao,"transferir"))
 {
  while (String[Cont] != '=') //elimina o nome do campo tipo de usuario para transferencia (para qual lista sera transferido)
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&') //pega o tipo de usuario escolhido no botao de radio
  {
   TipoUsuario[I] = String[Cont];
   Cont++; I++;
  }
  TipoUsuario[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo lista de usuarios
   Cont++;
  Cont++;

  while (String[Cont] != '&') //pega o nome da lista
  {
   Lista[I] = String[Cont];
   Cont++; I++;
  }
  Lista[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo indice da lista selecionada
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&') //pega o indice da lista selecionada
  {
   Indice[I] = String[Cont];
   Cont++; I++;
  }
  Indice[I] = '\0';
  I=0;

  while (String[Cont] != '=') //elimina o nome do campo caminho do repositorio
   Cont++;
  Cont++;

  I=0;
  while (String[Cont] != '&')
  {
   if (String[Cont] == '%') //%2F (/)
   {
    CaminhoRepositorio[I] = '/';
    Cont+=2;
   }
   else
    CaminhoRepositorio[I] = String[Cont];
   Cont++; I++;
  }
  CaminhoRepositorio[I] = '\0';
  I=0;
 }

 //criptografa  a senha para inserir nos arquivos
 SenhaCriptografada = malloc(20);
 strcpy(SenhaCriptografada,CriptografaSenha(Senha));

 //converte os indices das listas para inteiro
 IndiceAutor = atoi(Indice);
 IndiceGrupo = atoi(Indice);
 IndiceAdministrador = atoi(Indice);

 //verifica o tipo de usuario para colocar o flag no arquivo
 if ((!strcmp(Operacao,"inserir")) || (!strcmp(Operacao,"transferir")))
 {
  if (!strcmp(TipoUsuario,"autor"))
   strcpy(LinhaArquivoUsuario,"A:");
  if (!strcmp(TipoUsuario,"grupo"))
   strcpy(LinhaArquivoUsuario,"G:");
  if (!strcmp(TipoUsuario,"administrador"))
   strcpy(LinhaArquivoUsuario,"X:");
 }
 if (!strcmp(Operacao,"alterar"))
 {
  if (!strcmp(Lista,"ListaAutores"))
   strcpy(LinhaArquivoUsuario,"A:");
  if (!strcmp(Lista,"ListaGrupos"))
   strcpy(LinhaArquivoUsuario,"G:");
  if (!strcmp(Lista,"ListaAdministradores"))
   strcpy(LinhaArquivoUsuario,"X:");
 }

 //concatena o nome, login e senha para colocar no arquivo de usuarios
 strcat(LinhaArquivoUsuario,Nome);
 strcat(LinhaArquivoUsuario,":");
 strcat(LinhaArquivoUsuario,Login);
 strcat(LinhaArquivoUsuario,":");
 strcat(LinhaArquivoUsuario,SenhaCriptografada);
 strcat(LinhaArquivoUsuario,"\n");

 //concatena o login, senha e username a ser usado para colocar no arquivo passwd
 strcpy(LinhaArquivoPasswd,Login);
 strcat(LinhaArquivoPasswd,":");
 strcat(LinhaArquivoPasswd,SenhaCriptografada);
 strcat(LinhaArquivoPasswd,":nobody");
 strcat(LinhaArquivoPasswd,"\n");

 //abre o arquivo de usuarios no CVSROOT para efetuar as operacoes
 AlteraDiretorio(CaminhoRepositorio);
 if ((ArquivoUsuarios=fopen("usuarios","a+")) == NULL)
 {
  printf("<script>");
  printf("alert(\"Erro ao abrir o arquivo de usuarios do CVSROOT\")");
  printf("</script>");
  exit(1);
 }
 //abre o arquivo de senha no CVSROOT para efetuar as operacoes
 if ((ArquivoPasswd=fopen("passwd","a+")) == NULL)
 {
  printf("<script>");
  printf("alert(\"Erro ao abrir o arquivo passwd do CVSROOT\")");
  printf("</script>");
  exit(1);
 }
 if (!strcmp(Operacao,"inserir"))
 {
  if (!strcmp(TipoUsuario,"grupo")) //se o usuario a ser inserido pertencer a um grupo, insere apenas no arquivo de usuarios
   fputs(LinhaArquivoUsuario,ArquivoUsuarios);
  else //senao insere nos dois arquivos, usuarios e passwd
  {
   fputs(LinhaArquivoUsuario,ArquivoUsuarios);
   fputs(LinhaArquivoPasswd,ArquivoPasswd);
  }
  fclose(ArquivoUsuarios); fclose(ArquivoPasswd);
 }

 if (!strcmp(Operacao,"alterar"))
 {
  //abre o arquivo de usuarios auxiliar
  if ((ArquivoAuxUsuario=fopen("usuariosaux","a+")) == NULL)
  {
   fclose(ArquivoUsuarios); fclose(ArquivoPasswd);
   printf("<script>");
   printf("alert(\"Error flie open...\");");
   printf("</script>");
   exit(1);
  }
  //abre o arquivo de senha auxiliar
  if ((ArquivoAuxPasswd=fopen("passwdaux","a+")) == NULL)
  {
   fclose(ArquivoUsuarios); fclose(ArquivoPasswd);
   printf("<script>");
   printf("alert(\"Error file open...\");");
   printf("</script>");
   exit(1);
  }
  Ia=0; Ix=0; Ig=0;
  rewind(ArquivoUsuarios);
  rewind(ArquivoPasswd);
  while (!feof(ArquivoUsuarios))
  {
   //Le o conteudo dos dois arquivos
   fgets(LinhaU,100,ArquivoUsuarios);
   if (!feof(ArquivoUsuarios))
   {
    if (!strcmp(Lista,"ListaAdministradores")) //o usuario a ser alterado pertence a lista de administradores
    {
     if (LinhaU[0] == 'A')
     {
      //se for autor, escreve o que ja estava nos arquivos originais nos novos arquivos
      fgets(LinhaP,100,ArquivoPasswd);
      fputs(LinhaU,ArquivoAuxUsuario);
      fputs(LinhaP,ArquivoAuxPasswd);
     }
     if (LinhaU[0] == 'G') //se for grupo, escreve somente no arquivo de usuarios
      fputs(LinhaU,ArquivoAuxUsuario);
     if (LinhaU[0] == 'X') //e administrador, entao pode ser que essa seja a linha a ser alterada
     {
      if (Ix == IndiceAdministrador) //se forem iguais essa e a linha a ser alterada
      {
       //atualiza nos dois arquivos
       fgets(LinhaP,100,ArquivoPasswd);
       fputs(LinhaArquivoUsuario,ArquivoAuxUsuario);
       fputs(LinhaArquivoPasswd,ArquivoAuxPasswd);
      }
      else //nao e a linha a ser alterada
      {
       //escreve o que ja estava nos arquivos originais nos novos arquivos
       fgets(LinhaP,100,ArquivoPasswd);
       fputs(LinhaU,ArquivoAuxUsuario);
       fputs(LinhaP,ArquivoAuxPasswd);
      }
      Ix++;
     }
    }
    if (!strcmp(Lista,"ListaAutores")) //o usuario a ser alterado pertence a lista de autores
    {
     if (LinhaU[0] == 'X')  // X - administrador
     {
      //se for administrador, escreve o que ja estava nos arquivos originais no novo arquivo
      fgets(LinhaP,100,ArquivoPasswd);
      fputs(LinhaU,ArquivoAuxUsuario);
      fputs(LinhaP,ArquivoAuxPasswd);
     }
     if (LinhaU[0] == 'G') //pertence a grupos - escreve somente em um arquivo
      fputs(LinhaU,ArquivoAuxUsuario);
     if (LinhaU[0] == 'A') //e autor, entao pode ser que essa seja a linha a ser alterada
     {
      if (Ia == IndiceAutor) //se for igual, essa e a linha a ser alterada
      {
       //atualiza nos dois arquivos
       fgets(LinhaP,100,ArquivoPasswd);
       fputs(LinhaArquivoUsuario,ArquivoAuxUsuario);
       fputs(LinhaArquivoPasswd,ArquivoAuxPasswd);
      }
      else //ainda nao e a linha a ser alterada
      {
       //escreve o que ja estava nos arquivos originais nos novos arquivos
       fgets(LinhaP,100,ArquivoPasswd);
       fputs(LinhaU,ArquivoAuxUsuario);
       fputs(LinhaP,ArquivoAuxPasswd);
      }
      Ia++;
     }
    }
    if (!strcmp(Lista,"ListaGrupos")) //o usuario a ser alterado pertence a lista de grupos
    {
     if ((LinhaU[0] == 'X') || (LinhaU[0] == 'A'))//e administrador ou autor
     {
      //escreve o que ja estava nos arquivos originais nos novos arquivos
      fgets(LinhaP,100,ArquivoPasswd);
      fputs(LinhaU,ArquivoAuxUsuario);
      fputs(LinhaP,ArquivoAuxPasswd);
     }
     if (LinhaU[0] == 'G') //e grupo, entao pode ser que essa seja a linha a ser alterada
     {
      if (Ig == IndiceGrupo) //e a linha a ser alterada
       fputs(LinhaArquivoUsuario,ArquivoAuxUsuario);
      else
       fputs(LinhaU,ArquivoAuxUsuario);
      Ig++;
     }
    }
   }
  }
  fclose(ArquivoUsuarios); fclose(ArquivoPasswd);
  fclose(ArquivoAuxUsuario); fclose(ArquivoAuxPasswd);
  remove("usuarios"); remove("passwd");
  rename("usuariosaux","usuarios");
  rename("passwdaux","passwd");
  remove("passwdaux"); remove("usuariosaux");
  system("chmod 777 usuarios");
  system("chmod 777 passwd");
 }

 if (!strcmp(Operacao,"remover"))
 {
  //abre o arquivo de usuarios auxiliar
  if ((ArquivoAuxUsuario=fopen("usuariosaux","a+")) == NULL)
  {
   fclose(ArquivoUsuarios); fclose(ArquivoPasswd);
   printf("<script>");
   printf("alert(\"Error file open...\");");
   printf("</script>");
   exit(1);
  }
  //abre o arquivo de senha auxiliar
  if ((ArquivoAuxPasswd=fopen("passwdaux","a+")) == NULL)
  {
   fclose(ArquivoUsuarios); fclose(ArquivoPasswd);
   printf("<script>");
   printf("alert(\"Error file open...\");");
   printf("</script>");
   exit(1);
  }
  Ia=0; Ix=0; Ig=0;
  rewind(ArquivoUsuarios);
  rewind(ArquivoPasswd);
  while (!feof(ArquivoUsuarios))
  {
   fgets(LinhaU,100,ArquivoUsuarios);
   if (!feof(ArquivoUsuarios))
   {
    if (!strcmp(Lista,"ListaAdministradores")) //o usuario a ser removido pertence a lista de administradores
    {
     if (LinhaU[0] == 'A') // A - autor
     {
      //escreve o que ja estava nos arquivos originais nos novos arquivos
      fgets(LinhaP,100,ArquivoPasswd);
      fputs(LinhaU,ArquivoAuxUsuario);
      fputs(LinhaP,ArquivoAuxPasswd);
     }
     if (LinhaU[0] == 'G')  // G - grupo
      fputs(LinhaU,ArquivoAuxUsuario); //escreve apenas em um arquivo, pois grupo nao faz parte do arquivo de senha
     if (LinhaU[0] == 'X') //e administrador, entao pode ser que essa seja a linha a ser alterada
     {
      fgets(LinhaP,100,ArquivoPasswd);
      if (Ix != IndiceAdministrador) //se forem diferentes nao deve remover
      {
       //escreve o que ja estava nos arquivos originais nos novos arquivos
       fputs(LinhaU,ArquivoAuxUsuario);
       fputs(LinhaP,ArquivoAuxPasswd);
      }
      Ix++;
     }
    }
    if (!strcmp(Lista,"ListaAutores")) // o usuario a ser removido pertence a lista de autores
    {
     if (LinhaU[0] == 'X')   //e administrador
     {
      //escreve o que ja estava nos arquivos originais no novo arquivo
      fgets(LinhaP,100,ArquivoPasswd);
      fputs(LinhaU,ArquivoAuxUsuario);
      fputs(LinhaP,ArquivoAuxPasswd);
     }
     if (LinhaU[0] == 'G')   //grupo
      fputs(LinhaU,ArquivoAuxUsuario);
     if (LinhaU[0] == 'A') //e autor, entao pode ser que essa seja a linha a ser alterada
     {
      fgets(LinhaP,100,ArquivoPasswd);
      if (Ia != IndiceAutor)  //se for diferente nao remove
      {
       //escreve o que ja estava nos arquivos originais nos novos arquivos
       fputs(LinhaU,ArquivoAuxUsuario);
       fputs(LinhaP,ArquivoAuxPasswd);
      }
      Ia++;
     }
    }
    if (!strcmp(Lista,"ListaGrupos")) //o usuario a ser removido pertence a lista de grupos
    {
     if ((LinhaU[0] == 'X') || (LinhaU[0] == 'A')) //e administrador ou autor
     {
      //escreve o que ja estava nos arquivos originais no novo arquivo
      fgets(LinhaP,100,ArquivoPasswd);
      fputs(LinhaU,ArquivoAuxUsuario);
      fputs(LinhaP,ArquivoAuxPasswd);
     }
     if (LinhaU[0] == 'G') //e grupo, entao pode ser que essa seja a linha a ser removida
     {
      if (Ig != IndiceGrupo)   //nao e a linha a ser removida
	fputs(LinhaU,ArquivoAuxUsuario);
      Ig++;
     }
    }
   }
  }
  fclose(ArquivoUsuarios); fclose(ArquivoPasswd);
  fclose(ArquivoAuxUsuario); fclose(ArquivoAuxPasswd);
  remove("usuarios"); remove("passwd");
  rename("usuariosaux","usuarios");
  rename("passwdaux","passwd");
  remove("passwdaux"); remove("usuariosaux");
  system("chmod 777 usuarios");
  system("chmod 777 passwd");
 }

 if (!strcmp(Operacao,"transferir"))
 {
  //abre o arquivo de usuarios auxiliar
  if ((ArquivoAuxUsuario=fopen("usuariosaux","a+")) == NULL)
  {
   fclose(ArquivoUsuarios); fclose(ArquivoPasswd);
   printf("<script>");
   printf("alert(\"Error file open...\");");
   printf("</script>");
   exit(1);
  }
  //abre o arquivo de senha auxiliar
  if ((ArquivoAuxPasswd=fopen("passwdaux","a+")) == NULL)
  {
   fclose(ArquivoUsuarios); fclose(ArquivoPasswd);
   printf("<script>");
   printf("alert(\"Error file open...\");");
   printf("</script>");
   exit(1);
  }
  Ia=0; Ix=0; Ig=0;
  rewind(ArquivoUsuarios);
  rewind(ArquivoPasswd);
  while (!feof(ArquivoUsuarios))
  {
   fgets(LinhaU,100,ArquivoUsuarios);
   if (!feof(ArquivoUsuarios))
   {
    if (!strcmp(Lista,"ListaAdministradores")) //o usuario a ser transferido pertence a lista de administradores
    {
     if (LinhaU[0] == 'A') //verifica se a linha lida do arquivo de usuarios e um autor
     {
      fgets(LinhaP,100,ArquivoPasswd);
      fputs(LinhaU,ArquivoAuxUsuario); //escreve o que ja estava no arquivo original no novo arquivo
      fputs(LinhaP,ArquivoAuxPasswd); //escreve o que ja estava no arquivo original no novo arquivo
     }
     if (LinhaU[0] == 'G') //e grupo
      fputs(LinhaU,ArquivoAuxUsuario); //escreve o que ja estava no arquivo original no novo arquivo
     if (LinhaU[0] == 'X') //e administrador, entao pode ser que esse seja o usuario a ser transferido
     {
      fgets(LinhaP,100,ArquivoPasswd);
      if (Ix == IndiceAdministrador) //se forem iguais esse e o usuario a ser transferido
      {
       if (!strcmp(TipoUsuario,"autor")) //transfere o usuario da categoria administrador para autor
       {
        LinhaU[0] = 'A';
        fputs(LinhaU,ArquivoAuxUsuario); //coloca a nova linha no arquivo novo
        fputs(LinhaP,ArquivoAuxPasswd); //coloca a nova linha no arquivo novo
       }
       if (!strcmp(TipoUsuario,"grupo")) //transfere o usuario da categoria administrador para grupo
       {
        LinhaU[0] = 'G';
        fputs(LinhaU,ArquivoAuxUsuario); //coloca a nova linha no arquivo novo
       }
      }
      else
      {
       fputs(LinhaU,ArquivoAuxUsuario); //coloca a mesma linha lida do arquivo original para o novo arquivo
       fputs(LinhaP,ArquivoAuxPasswd); //coloca a mesma linha lida do arquivo original para o novo arquivo
      }
      Ix++;
     }
    }
    if (!strcmp(Lista,"ListaAutores")) //o usuario a ser transferido pertence a lista de autores
    {
     if (LinhaU[0] == 'X')  //e administrador
     {
      fgets(LinhaP,100,ArquivoPasswd); 	
      fputs(LinhaU,ArquivoAuxUsuario);  //escreve o que ja estava no arquivo original no novo arquivo
      fputs(LinhaP,ArquivoAuxPasswd);  //escreve o que ja estava no arquivo original no novo arquivo
     }
     if (LinhaU[0] == 'G') //grupo
      fputs(LinhaU,ArquivoAuxUsuario);  //escreve o que ja estava no arquivo original no novo arquivo
     if (LinhaU[0] == 'A') //e autor, entao pode ser que esse seja o usuario a transferido
     {	
      fgets(LinhaP,100,ArquivoPasswd);
      if (Ia == IndiceAutor) //e o usuario a ser transferido
      {
       if (!strcmp(TipoUsuario,"grupo")) //transfere o usuario da categoria autor para grupo
       {
	LinhaU[0] = 'G';
	fputs(LinhaU,ArquivoAuxUsuario); //coloca a nova linha no arquivo novo
       }
       if (!strcmp(TipoUsuario,"administrador")) //transfere o usuario da categoria autor para administrador
       {
	LinhaU[0] = 'X';
	fputs(LinhaU,ArquivoAuxUsuario); //coloca a nova linha no arquivo novo
	fputs(LinhaP,ArquivoAuxPasswd); //coloca a nova linha no arquivo novo
       }
      }
      else
      {
       fputs(LinhaU,ArquivoAuxUsuario); //coloca a mesma linha lida do arquivo original para o novo arquivo
       fputs(LinhaP,ArquivoAuxPasswd); //coloca a mesma linha lida do arquivo original para o novo arquivo
      }
      Ia++;
     }
    }
    if (!strcmp(Lista,"ListaGrupos")) //o usuario a ser transferido pertence a lista de grupos
    {
     if (LinhaU[0] == 'X') //e administrador
     {
      fgets(LinhaP,100,ArquivoPasswd);
      fputs(LinhaU,ArquivoAuxUsuario); //escreve o que ja estava no arquivo original no novo arquivo
      fputs(LinhaP,ArquivoAuxPasswd); //escreve o que ja estava no arquivo original no novo arquivo
     }
     if (LinhaU[0] == 'A') //e autor
     {
      fgets(LinhaP,100,ArquivoPasswd);
      fputs(LinhaU,ArquivoAuxUsuario); //escreve o que ja estava no arquivo original no novo arquivo
      fputs(LinhaP,ArquivoAuxPasswd); //escreve o que ja estava no arquivo original no novo arquivo
     }
     if (LinhaU[0] == 'G') //e grupo, entao pode ser que esse seja o usuario a ser transferido
     {
      if (Ig == IndiceGrupo)//e a linha a ser alterada
      {
       if (!strcmp(TipoUsuario,"autor")) //transfere o usuario da categoria grupo para autor
       {
	LinhaU[0] = 'A';
	fputs(LinhaU,ArquivoAuxUsuario); //coloca a nova linha no novo arquivo
        Cont=2; //elimina o flag de usuario e os ":"
        LinhaP[0] = '\0';
        while (LinhaU[Cont] != ':')//elimina o nome do usuario
         Cont++;
        Cont++; I=0;
        while (LinhaU[Cont] != '\n') //pega o username e a senha
        {
         LinhaP[I] = LinhaU[Cont];
         Cont++; I++;
        }
        LinhaP[I] = ':';
        I++;
        for (Cont=0;Cont<=7;Cont++)
        {
         LinhaP[I] = LinhaPAux[Cont];
         I++;
        }
        //strcat(LinhaP,"nobody\n");
	fputs(LinhaP,ArquivoAuxPasswd); //coloca a nova linha no novo arquivo
        LinhaP[0] = '\0';
       }
       if (!strcmp(TipoUsuario,"administrador")) //transfere o usuario da categoria grupo para administrador
       {
	LinhaU[0] = 'X';
	fputs(LinhaU,ArquivoAuxUsuario); //coloca a nova linha no novo arquivo
        Cont=2; //elimina o flag de usuario
        LinhaP[0] = '\0';
        while (LinhaU[Cont] != ':')//elimina o nome do usuario
         Cont++;
        Cont++; I=0;
        while (LinhaU[Cont] != '\n') //pega o username e a senha
        {
         LinhaP[I] = LinhaU[Cont];
         Cont++; I++;
        }
        LinhaP[I] = ':';
        I++;
        for (Cont=0;Cont<=7;Cont++)
        {
         LinhaP[I] = LinhaPAux[Cont];
         I++;
        }
 	fputs(LinhaP,ArquivoAuxPasswd); //coloca a nova linha no novo arquivo
        LinhaP[0] = '\0';
       }
      }
      else
       fputs(LinhaU,ArquivoAuxUsuario); //coloca a mesma linha lida do arquivo original para o novo arquivo
      Ig++;
     }
    }
   }
  }
  fclose(ArquivoUsuarios); fclose(ArquivoPasswd);
  fclose(ArquivoAuxUsuario); fclose(ArquivoAuxPasswd);
  remove("usuarios"); remove("passwd");
  rename("usuariosaux","usuarios");
  rename("passwdaux","passwd");
  remove("passwdaux"); remove("usuariosaux");
  system("chmod 777 usuarios");
  system("chmod 777 passwd");
 }
 free(SenhaCriptografada);
 ExibeFormulario_Usuarios();
 return;
}

void AutenticaAdministrador(char LoginAux[20],char SenhaAux[20])
{
 char Linha[100],LinhaAux[20]; 
 FILE *ArquivoUsuarios;
 int Flag=0,i=0,Cont=0;

 AlteraDiretorio(CaminhoRepositorio);

 if ((ArquivoUsuarios=fopen("usuarios","r")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<head><script>");
  printf("alert(\"Error file open...\");\n");
  printf("</script></head>"); 
  printf("</html>");
  exit(1);
 }
 rewind(ArquivoUsuarios);
 
//verifica se o login e a senha do administrador estao corretos, senao da erro
 while(!feof(ArquivoUsuarios))
 {
  if (!feof(ArquivoUsuarios))
  {
   strcpy(LinhaAux," ");
   fgets(Linha,100,ArquivoUsuarios);
   if (!Flag) //ainda nao encontrou o usuario
   {
    if (Linha[0] == 'X') //Flag para administrador
    {
     Cont=2;i=0;
     while (Linha[Cont] != ':')//elimina o nome do usuario
      Cont++;
     Cont++; 
     while (Linha[Cont] != ':')
     {
      LinhaAux[i] = Linha[Cont];
      Cont++; i++;
     }
     LinhaAux[i] = '\0';
     if (strcmp(LinhaAux,LoginAux))
     {
      if (feof(ArquivoUsuarios))
      {
       printf("Content-type: text/html\n\n");
       printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
       printf("<html>");
       printf("<head>");
       printf("<script>");
       printf("alert(\"Invalid user!\")\n");  
       printf("</script>\n");
       printf("</head>");
       printf("</html>"); 
       exit(1);
      }
     }
     else
     {
      Flag = 1;
      Cont++; i=0; strcpy(LinhaAux," ");
      while (Linha[Cont] != '\0') 
      { 
       LinhaAux[i] = Linha[Cont]; 
       i++; Cont++; 
      } 
      LinhaAux[i-1] = '\0'; 
      if (strcmp(LinhaAux,SenhaAux)) 
      { 
       printf("Content-type: text/html\n\n"); 
       printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
       printf("<html>"); 
       printf("<head>"); 
       printf("<script>"); 
       printf("alert(\"Invalid password!\")\n"); 
       printf("</script>\n"); 
       printf("</head>"); 
       printf("</html>"); 
       exit(1); 
      }
     }
    }
   }
  } 
  i=0; Cont=0; 
 }
 if (!Flag)
 { 
  printf("Content-type: text/html\n\n"); 
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
  printf("<html>"); 
  printf("<head>"); 
  printf("<script>"); 
  printf("alert(\"Invalid user!\")\n"); 
  printf("</script>\n"); 
  printf("</head>"); 
  printf("</html>"); 
  exit(1); 
 }
}

void ExibeFormulario_Usuarios()
{
 struct ListaUsuarios 
 { 
  char Autor[100]; 
  char Grupo[100]; 
  char Administrador[100];
 }; 
 struct ListaUsuarios Usuarios[100]; 
 char Linha[100];
 FILE *ArquivoUsuarios;
 int Contador,ContAux,ContAutor,ContGrupo,ContAdministrador;

 AlteraDiretorio(CaminhoRepositorio);

 if ((ArquivoUsuarios=fopen("usuarios","a+")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<head><script>");
  printf("alert(\"Error file open...\");\n");
  printf("</script></head>"); 
  printf("</html>");
  exit(1);
 }

 //verifica se e autor, grupo ou administradores para exibir as respectivas listas
 rewind(ArquivoUsuarios);
 ContAutor=0; ContGrupo=0;ContAdministrador=0;//contadores para a estrutura de usuarios

 while (!feof(ArquivoUsuarios))
 {
  fgets(Linha,100,ArquivoUsuarios);
  if (!feof(ArquivoUsuarios)) //para nao repetir o ultimo usuario
  {
   if (Linha[0] == 'A') //autor
   {
    Contador=2; ContAux=0;
    while (Linha[Contador] != ':')
    {
     Usuarios[ContAutor].Autor[ContAux] = Linha[Contador];
     Contador++;ContAux++;
    }
    strcat(Usuarios[ContAutor].Autor," (");
    Contador++; ContAux+=2;
    while (Linha[Contador] != ':')
    {
     Usuarios[ContAutor].Autor[ContAux] = Linha[Contador];
     Contador++; ContAux++;
    }
    Usuarios[ContAutor].Autor[ContAux] = ')';
    ContAutor++;
   }
   if (Linha[0] == 'G')  //Grupo
   {
    Contador=2; ContAux=0;
    while (Linha[Contador] != ':')
    {
     Usuarios[ContGrupo].Grupo[ContAux] = Linha[Contador];
     Contador++; ContAux++;
    }
    strcat(Usuarios[ContGrupo].Grupo," (");
    Contador++; ContAux+=2;
    while (Linha[Contador] != ':')
    {
     Usuarios[ContGrupo].Grupo[ContAux] = Linha[Contador];
     Contador++; ContAux++;
    }
    Usuarios[ContGrupo].Grupo[ContAux] = ')';
    ContGrupo++;
   } 
   if (Linha[0] == 'X')  //Administrador
   { 
    Contador=2; ContAux=0;
    while (Linha[Contador] != ':') 
    { 
     Usuarios[ContAdministrador].Administrador[ContAux] = Linha[Contador]; 
     Contador++; ContAux++;
    } 
    strcat(Usuarios[ContAdministrador].Administrador," (");
    Contador++; ContAux+=2;
    while (Linha[Contador] != ':')
    {
     Usuarios[ContAdministrador].Administrador[ContAux] = Linha[Contador];
     Contador++; ContAux++;
    }
    Usuarios[ContAdministrador].Administrador[ContAux] = ')'; 
    ContAdministrador++; 
   }
  }
 }

 printf("Content-type: text/html\n\n");
 printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
 printf("<html>\n");
 printf("<head>\n");

 //script para verificar as operacoes
 printf("<script>\n");

 //funcao para insercao de usuarios
 printf("function Inserir()\n{\n");
 printf("if ((document.formadministra.tipo_usuario[0].checked == false) && (document.formadministra.tipo_usuario[1].checked == false) && (document.formadministra.tipo_usuario[2].checked == false))\n{\n");
 printf("alert(\"Select the type of user!\");return false;}");

 printf("if ((document.formadministra.nome.value.length <= 0) || (document.formadministra.login.value.length <= 0) || (document.formadministra.senha.value.length <= 0))\n{\n");
 printf("alert(\"All entries must to be fill!\");return false;\n}\n");

 printf("if (document.formadministra.tipo_usuario[0].checked == true)\n{");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=inserir&tipo_usuario=autor&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=inserir&tipo_usuario=autor&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}");

 printf("if (document.formadministra.tipo_usuario[1].checked == true)\n{");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=inserir&tipo_usuario=grupo&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=inserir&tipo_usuario=grupo&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}");
 printf("if (document.formadministra.tipo_usuario[2].checked == true)\n{");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=inserir&tipo_usuario=administrador&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=inserir&tipo_usuario=administrador&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}}");

 //funcao para alteracao de usuarios
 printf("function Alterar()\n{\n");
 //verifica se mais de um usuario esta selecionado
 printf(" if ((document.formadministra.ListaAutores.options.selectedIndex != -1) && ((document.formadministra.ListaGrupos.options.selectedIndex != -1) || (document.formadministra.ListaAdministradores.options.selectedIndex != -1)))\n");
 printf("{\n  alert(\"Select only one user for this transaction!\");return false;\n}");
 printf(" if ((document.formadministra.ListaAutores.options.selectedIndex == -1) && (document.formadministra.ListaGrupos.options.selectedIndex != -1) && (document.formadministra.ListaAdministradores.options.selectedIndex != -1))\n");
 printf("{\n  alert(\"Select only one user for this transaction!\");return false;\n}");
 //verifica se algum usuario esta selecionado
 printf(" if ((document.formadministra.ListaAutores.options.selectedIndex == -1) && (document.formadministra.ListaGrupos.options.selectedIndex == -1) && (document.formadministra.ListaAdministradores.options.selectedIndex == -1))\n");
 printf("{\n  alert(\"Select the user for this operation!\");return false;\n}");
 //verifica se todos os campos pra alteracao foram preenchidos
 printf("if ((document.formadministra.nome.value.length <= 0) || (document.formadministra.login.value.length <= 0) || (document.formadministra.senha.value.length <= 0))\n{\n");
 printf("alert(\"All entries must to be fill!\");return false;\n}\n");

 //verifica se usuario da lista de autores foi selecionado
 printf("if (document.formadministra.ListaAutores.options.selectedIndex != -1)\n{");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=alterar&lista=ListaAutores&Indice=\"+document.formadministra.ListaAutores.options.selectedIndex+\"&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=alterar&lista=ListaAutores&Indice=\"+document.formadministra.ListaAutores.options.selectedIndex+\"&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}");
 //verifica se usuario da lista de grupos foi selecionado
 printf("if (document.formadministra.ListaGrupos.options.selectedIndex != -1)\n{");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=alterar&lista=ListaGrupos&Indice=\"+document.formadministra.ListaGrupos.options.selectedIndex+\"&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=alterar&lista=ListaGrupos&Indice=\"+document.formadministra.ListaGrupos.options.selectedIndex+\"&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}");
 //verifica se usuario da lista de administradores foi selecionado
 printf("if (document.formadministra.ListaAdministradores.options.selectedIndex != -1)\n{");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=alterar&lista=ListaAdministradores&Indice=\"+document.formadministra.ListaAdministradores.options.selectedIndex+\"&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=alterar&lista=ListaAdministradores&Indice=\"+document.formadministra.ListaAdministradores.options.selectedIndex+\"&nome=\"+document.formadministra.nome.value+\"&login=\"+document.formadministra.login.value+\"&senha=\"+document.formadministra.senha.value+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}}");

 //funcao para remocao de usuarios
 printf("function Remover()\n{\n");
 //verifica se mais de um usuario esta selecionado
 printf(" if ((document.formadministra.ListaAutores.options.selectedIndex != -1) && ((document.formadministra.ListaGrupos.options.selectedIndex != -1) || (document.formadministra.ListaAdministradores.options.selectedIndex != -1)))\n");
 printf("{\n  alert(\"Select only one user for this transaction!\");return false;\n}");
 printf(" if ((document.formadministra.ListaAutores.options.selectedIndex == -1) && (document.formadministra.ListaGrupos.options.selectedIndex != -1) && (document.formadministra.ListaAdministradores.options.selectedIndex != -1))\n");
 printf("{\n  alert(\"Select only one user for this transaction!\");return false;\n}");
 //verifica se algum usuario esta selecionado
 printf(" if ((document.formadministra.ListaAutores.options.selectedIndex == -1) && (document.formadministra.ListaGrupos.options.selectedIndex == -1) && (document.formadministra.ListaAdministradores.options.selectedIndex == -1))\n");
 printf("{\n  alert(\"Select the user for this operation!\");return false;\n}");
 //verifica se usuario da lista de autores foi selecionado
 printf("if (document.formadministra.ListaAutores.options.selectedIndex != -1)\n{");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=remover&lista=ListaAutores&Indice=\"+document.formadministra.ListaAutores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=remover&lista=ListaAutores&Indice=\"+document.formadministra.ListaAutores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}");
 //verifica se usuario da lista de grupos foi selecionado
 printf("if (document.formadministra.ListaGrupos.options.selectedIndex != -1)\n{");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=remover&lista=ListaGrupos&Indice=\"+document.formadministra.ListaGrupos.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=remover&lista=ListaGrupos&Indice=\"+document.formadministra.ListaGrupos.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}");
 //verifica se usuario da lista de administradores foi selecionado
 printf("if (document.formadministra.ListaAdministradores.options.selectedIndex != -1)\n{");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=remover&lista=ListaAdministradores&Indice=\"+document.formadministra.ListaAdministradores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=remover&lista=ListaAdministradores&Indice=\"+document.formadministra.ListaAdministradores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}}");

 //funcao pra transferencia de usuarios
 printf("function Transferir()\n{\n");
 //verifica se mais de um usuario esta selecionado
 printf(" if ((document.formadministra.ListaAutores.options.selectedIndex != -1) && ((document.formadministra.ListaGrupos.options.selectedIndex != -1) || (document.formadministra.ListaAdministradores.options.selectedIndex != -1)))\n");
 printf("{\n  alert(\"Select only one user for this transaction!\");return false;\n}");
 printf(" if ((document.formadministra.ListaAutores.options.selectedIndex == -1) && (document.formadministra.ListaGrupos.options.selectedIndex != -1) && (document.formadministra.ListaAdministradores.options.selectedIndex != -1))\n");
 printf("{\n  alert(\"Select only one user for this transaction!\");return false;\n}");
 //verifica se algum usuario esta selecionado
 printf("if ((document.formadministra.ListaAutores.options.selectedIndex == -1) && (document.formadministra.ListaGrupos.options.selectedIndex == -1) && (document.formadministra.ListaAdministradores.options.selectedIndex == -1))\n");
 printf("{\n  alert(\"Select the user for this operation!\");return false;\n}");
 //verifica se o tipo de usuario foi selecionado no botao de radio
 printf("if ((document.formadministra.tipo_usuario[0].checked == false) && (document.formadministra.tipo_usuario[1].checked == false) && (document.formadministra.tipo_usuario[2].checked == false))\n{\n");
 printf("alert(\"Select the type of user for transfer!\");return false;}");

 //verifica se a lista selecionada e o tipo (botao de radio selecionado) sao iguais
 printf(" if ((document.formadministra.ListaAutores.options.selectedIndex != -1) && (document.formadministra.tipo_usuario[0].checked == true)){");
 printf("alert(\"Select differents types of users for this operation!\");return false;}");
 printf(" if ((document.formadministra.ListaGrupos.options.selectedIndex != -1) && (document.formadministra.tipo_usuario[1].checked == true)){");
 printf("alert(\"Select differents types of users for this operation!\");return false;}");
 printf(" if ((document.formadministra.ListaAdministradores.options.selectedIndex != -1) && (document.formadministra.tipo_usuario[2].checked == true)){");
 printf("alert(\"Select differents types of users for this operation!\");return false;}");

 //verifica se usuario da lista de autores foi selecionado
 printf("if (document.formadministra.ListaAutores.options.selectedIndex != -1)\n{");
 printf("if (document.formadministra.tipo_usuario[1].checked == true){");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=grupo&lista=ListaAutores&Indice=\"+document.formadministra.ListaAutores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=grupo&lista=ListaAutores&Indice=\"+document.formadministra.ListaAutores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}");
 printf("if (document.formadministra.tipo_usuario[2].checked == true){");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=administrador&lista=ListaAutores&Indice=\"+document.formadministra.ListaAutores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=administrador&lista=ListaAutores&Indice=\"+document.formadministra.ListaAutores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}}");

 //verifica se o usuario da lista de grupos foi selecionado
 printf("if (document.formadministra.ListaGrupos.options.selectedIndex != -1)\n{");
 printf("if (document.formadministra.tipo_usuario[0].checked == true){");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=autor&lista=ListaGrupos&Indice=\"+document.formadministra.ListaGrupos.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=autor&lista=ListaGrupos&Indice=\"+document.formadministra.ListaGrupos.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}");
 printf("if (document.formadministra.tipo_usuario[2].checked == true){");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=administrador&lista=ListaGrupos&Indice=\"+document.formadministra.ListaGrupos.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=administrador&lista=ListaGrupos&Indice=\"+document.formadministra.ListaGrupos.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}}");

 //verifica se o usuario da lista de administradores foi selecionado
 printf("if (document.formadministra.ListaAdministradores.options.selectedIndex != -1)\n{");
 printf("if (document.formadministra.tipo_usuario[0].checked == true){");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=autor&lista=ListaAdministradores&Indice=\"+document.formadministra.ListaAdministradores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=autor&lista=ListaAdministradores&Indice=\"+document.formadministra.ListaAdministradores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}");
 printf("if (document.formadministra.tipo_usuario[1].checked == true){");
// printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=grupo&lista=ListaAdministradores&Indice=\"+document.formadministra.ListaAdministradores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=700,height=500,scrollbars=yes\");\n",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?operacao=transferir&tipo_usuario=grupo&lista=ListaAdministradores&Indice=\"+document.formadministra.ListaAdministradores.options.selectedIndex+\"&caminhorepositorio=\"+document.formadministra.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n",LOCALCGI);
 printf("return true;}}}");

 printf("</script>");
 printf("<title>Users Management</title>");
 printf("</head>\n");
 printf("<base href=%s>",IMAGES);
 printf("<body background=bolor.jpg>\n");
 printf("<img src=nome1.jpg align=right><br><hr><br>");

 //Tabela principal
 printf("<center>\n");
 printf("<table border bgcolor=#E1F0FF>");
 printf("<tr>\n");
 printf("<td BGCOLOR=#A8BAC3>");
 printf("<img src=man01.gif width=24 height=24><font color=#000088><font size=+2><font face=arial,helvetica> Users Management</font></font></font></center>\n");
 printf("</td>\n"); 
 printf("</tr>\n"); 

 printf("<tr><td bgcolor=#E1F0FF>\n");//segunda linha da tabela principalque contem a outra tabela
 printf("<center><table border width=100% bgcolor=#E1F0FF");
 printf("<tr><td bgcolor=#A8BAC3>");
 printf("<center><font color=#000088><font size=+1><font face=arial,helvetica>Authors</font></font></font></center>\n");
 printf("</td>\n"); 
 printf("<td bgcolor=#A8BAC3>");
 printf("<center><font color=#000088><font size=+1><font face=arial,helvetica>Groups</font></font></font></center>\n");
 printf("</td>\n");
 printf("<td bgcolor=#A8BAC3>");
 printf("<center><font color=#000088><font size=+1><font face=arial,helvetica>Administrators</font></font></font></center>\n");
 printf("</td>\n");
 printf("</tr>\n"); //final da linha com os titulos de usuarios da segunda tabela
 printf("<tr>\n"); //linha para conter as listas de usuarios
 printf("<form method=POST name=formadministra>\n");

 //lista de autores
 printf("<td bgcolor=#E1F0FF><center><font face=arial,helvetica>\n");
 printf("<select name=ListaAutores size=5>\n"); 
 for (Contador=0;Contador<ContAutor;Contador++)
  printf("<option value=%s>%s</option>\n",Usuarios[Contador].Autor,Usuarios[Contador].Autor);
 printf("<option>______________________________</option>");
 printf("</select></td></center></font>\n");
 
 //lista de grupos
 printf("<td bgcolor=#E1F0FF><center><font face=arial,helvetica>\n");
 printf("<select name=ListaGrupos size=5>\n");
 for (Contador=0;Contador<ContGrupo;Contador++)
  printf("<option value=%s>%s</option>\n",Usuarios[Contador].Grupo,Usuarios[Contador].Grupo);
 printf("<option>______________________________</option>");
 printf("</select></td></center></font>\n");

 //lista de administradores
 printf("<td bgcolor=#E1F0FF><center><font face=arial,helvetica>\n");
 printf("<select name=ListaAdministradores size=5>"); 
 for (Contador=0;Contador<ContAdministrador;Contador++) 
  printf("<option value=%s>%s</option>\n",Usuarios[Contador].Administrador,Usuarios[Contador].Administrador);
 printf("<option>______________________________</option>");
 printf("</select></td></center></font>\n");
 
 printf("</tr></table></td></tr>\n"); //final da segunda linha da tabela principal que contem a segunda tabela
 printf("<tr><td bgcolor=#E1F0FF>\n"); //terceira linha da tabela principal que contem as opcoes de operacoes
 printf("<center>\n");
 
 printf("<br><font face=arial,helvetica><input type=radio name=tipo_usuario value=autor> <b>Authors</b>\n");
 printf("&nbsp;&nbsp;&nbsp;&nbsp;"); 
 printf("<input type=radio name=tipo_usuario value=grupo> <b>Groups</b>\n");
 printf("&nbsp;&nbsp;&nbsp;&nbsp;"); 
 printf("<input type=radio name=tipo_usuario value=administrador> <b>Administrators</b><br><br>\n");
 
 printf("<b>Identification name:</b> <input type=text size=40 maxlength=40 name=nome><p>\n");
 printf("<b>Login:</b> <input type=text size=30 maxlength=20 name=login><p>\n");
 printf("<b>Password:</b> <input type=password size=30 maxlength=20 name=senha><p>\n");

 printf("<input type=hidden name=IndiceAutor value=\"\">\n"); //o indice selecionado da lista de autores
 printf("<input type=hidden name=IndiceGrupo value=\"\">\n"); //o indice selecionado da lista de grupos
 printf("<input type=hidden name=IndiceAdministrador value=\"\">\n"); //o indice selecionado da lista de administradores
 printf("<input type=hidden name=caminho_repositorio value=%s>\n",CaminhoRepositorio);

 printf("<input type=button name=inserir value=Insert onClick=Inserir();>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
 printf("<input type=button name=alterar value=Change onClick=Alterar();>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
 printf("<input type=button name=remover value=Delete onClick=Remover();>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
 printf("<input type=button name=transferir value=Transfer onClick=Transferir();>");

 printf("<p><br></font>\n");
 printf("</form>\n");
 printf("</td></tr>\n");//final da terceira linha da tabela principal
 printf("</table></center>\n");
 printf("</body>\n");
 printf("</html>\n");
}

void AlteraDiretorio(char *Caminho) 
{ 
 if (chdir(Caminho)) 
 { 
  perror("chdir()"); 
  exit(1); 
 } 
} 

char *rsalt()  /* rsalt() - generate a random 2-char salt */
{
 static char str[3];  /* salt alphabet (c.f. crypt(3)): 0-9 a-z A-Z ./ */
 char  *saltalpha="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ./";
 long  lword1;
 int   alphalen;
 char  *ptr1;

 alphalen=strlen(saltalpha);
 lword1=random(); 
 ptr1=(char *)&lword1;
 str[0] = saltalpha[(unsigned char) ptr1[0]%alphalen];
 str[1] = saltalpha[(unsigned char) ptr1[1]%alphalen]; str[2]='\0';
 return(str);
}

char *CriptografaSenha(char SenhaUsuario[20])
{
 char salt[9],pw[30];
 char *crypt(); 

 strcpy(pw,SenhaUsuario);
 strcpy(salt,rsalt());
 salt[2] = '\0';
 return crypt(pw,salt);
}
