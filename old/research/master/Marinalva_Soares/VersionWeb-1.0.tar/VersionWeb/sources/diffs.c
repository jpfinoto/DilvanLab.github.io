/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */                                                                                  
/******************************************************************************************************************/

// Este cgi gera o formulario com opcoes para exibir diferencas entre duas versoes

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void AlteraDiretorio(char *Caminho);

int main (void)
{
 //estrutura para guardar a versao, data e autor
 struct GuardaVersao
 {
  char Versao[100];
 };

 struct GuardaVersao Estrutura[100];
 char *String,CaminhoRepositorio[100],NomePagina[30],ModuloCheckout[100];
 char DiretorioPagina[100],Linha[100],LinhaAux[100],CaminhoAux[100],Comando[100],*Resultado,buf[1000];
 int ontLinha,ContVersao=0,ContAux=0,ContData=0,ContAutor=0,Cont=0,i=0,ContLinha=0;
 FILE *ArquivoVersao,*Arquivo;

 String = getenv("QUERY_STRING");

 while (String[Cont] != '=') //elimina o campo caminho_repositorio
  Cont++;
 Cont++; 

 while(String[Cont] != '&')
 {
   if ((String[Cont] == '%') && (String[Cont+1] == '2') && (String[Cont+2] == 'F'))
  {
   CaminhoRepositorio[i] = '/';
   Cont+=2;
  }
  else
   CaminhoRepositorio[i] = String[Cont];
  Cont++; i++;
 }
 CaminhoRepositorio[i] = '\0';
 i=0; 

 while (String[Cont] != '=') //elimina o campo caminho_repositorio
  Cont++;
 Cont++;

 while(String[Cont] != '&')
 {
   if ((String[Cont] == '%') && (String[Cont+1] == '2') && (String[Cont+2] == 'F'))
  {
   DiretorioPagina[i] = '/';
   Cont+=2;
  }
  else
   DiretorioPagina[i] = String[Cont];
  Cont++; i++;
 }
 DiretorioPagina[i] = '\0';
 i=0;


 while (String[Cont] != '=') //elimina o nome do campo do arquivo selecionado
  Cont++;
 Cont++; 

 while(String[Cont] != '\0')
 {
  NomePagina[i] = String[Cont];
  Cont++; i++;
 }
 NomePagina[i] = '\0';
 i=0;

 if ((NomePagina[strlen(NomePagina)-1] == 'v') && (NomePagina[strlen(NomePagina)-2] == ','))
   NomePagina[strlen(NomePagina)-2] = '\0'; //elimina o ",v"

 Cont=0;
 while (DiretorioPagina[Cont] == CaminhoRepositorio[Cont]) //elimina o caminho onde reside o repositorio
  Cont++;
 i=0;
 while (DiretorioPagina[Cont] != '\0') //pega somente a parte selecionada pelo usuario (diretorio e arquivo)
 {
  ModuloCheckout[i] = DiretorioPagina[Cont]; //ModuloCheckout vale tudo que vem depois do caminhorepositorio na tela de login
  Cont++; i++;
 }

 //para setar a variavel CVSROOT
 if (CaminhoRepositorio[strlen(CaminhoRepositorio)-1] == '/')
   CaminhoRepositorio[strlen(CaminhoRepositorio)-1] = '\0';

  //acrescenta uma barra no final pra listar o diretorio
 if (DiretorioPagina[strlen(DiretorioPagina)-1] != '/')
  strcat(DiretorioPagina,"/");

  //seta a variavel ambiente pra reconhecer o repositorio, pois o checkout nao sera feito com -d
 setenv("CVSROOT",CaminhoRepositorio,1);
 strcpy(CaminhoAux,"/tmp/");
 strcpy(Comando,"cvs co ");
 strcat(Comando,ModuloCheckout);
 strcat(Comando,NomePagina);

 AlteraDiretorio("/tmp/");

 //faz checkout do arquivo pra verificar as versoes pra serem exibidas
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
  {
   strcat(Resultado, buf);
   strcat(Resultado, "<br>");
  }
  pclose(Arquivo);
 }
 free(Resultado);

 //posiciona dentro do diretorio que foi feito o checkout
 strcpy(CaminhoAux,"/tmp/");
 strcat(CaminhoAux,ModuloCheckout);
 AlteraDiretorio(CaminhoAux);

 strcpy(Comando,"cvs log ");
 strcat(Comando,NomePagina);
 strcat(Comando," > log");

 //no arquivo de log estao todas as versoes a serem listadas para exibir o form. de diferencas
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
  {
   strcat(Resultado, buf);
   strcat(Resultado, "<br>");
  }
  pclose(Arquivo);
 }
 free(Resultado);

 if ((ArquivoVersao = fopen("log","r")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<HTML>\n");
  printf("<BODY>\n");
  printf("The file log can not be opened...<br>");
  printf("</BODY>\n");
  printf("</HTML>\n");
  exit(1);
 }

 //elimina as 11 primeiras linhas   fgets(Linha,100,ArquivoVersao);
 for (ContLinha=0;ContLinha<12;ContLinha++)
  fgets(Linha,255,ArquivoVersao);

 while(!feof(ArquivoVersao))
 {
  fgets(Linha,255,ArquivoVersao); //primeira linha com a versao (revision 1.1)
  Cont=0; i=0;
  if (Linha[0] == '=') //final do arquivo de logs
   break;
  while (Linha[Cont] != ' ') //elimina o nome revision
   Cont++;
  Cont++;
  while(Linha[Cont] != '\0') //pega o numero da versao
  {
   Estrutura[ContVersao].Versao[i] = Linha[Cont];
   Cont++; i++;
  }
  //  Estrutura[ContVersao].Versao[i] = '\0';
  i=0; Cont=0;
  ContVersao++;

  fgets(Linha,255,ArquivoVersao); //pega a linha com data, hora e autor
  fgets(Linha,255,ArquivoVersao); //log message
  fgets(Linha,255,ArquivoVersao);//-----------
  if (Linha[0] != '-')
   fgets(Linha,255,ArquivoVersao);
 }
 fclose(ArquivoVersao);

 if (ContVersao == 1)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<script>");
  printf("alert(\"There's only one version for this file!\");");
  printf("</script>");
  exit(1);
 }

 printf("Content-type: text/html\n\n");
 printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
 printf("<html>");
 printf("<head>");

 //script para verificar se as duas versoes selecionadas sao iguais. Se for, emite mensagem de erro.
 printf("<script>\n");
 printf("function ValidaVersao()\n{\n");
 printf(" if (document.diferenca.versao_1.options.selectedIndex == document.diferenca.versao_2.options.selectedIndex)\n{");
 printf("  alert(\"Select differents versions!\");\n  return false;\n}");
 printf("return true;\n}\n");
 printf("</script>");

 printf("</head>");
 printf("<base href=%s>",IMAGES);
 printf("<body background=bolor.jpg>");
 printf("<img src=nome1.jpg align=right><br><hr><br>");

 //Tabela onde devera ser exibido o formulario de diferencas
 printf("<center><table BORDER WIDTH=80% BGCOLOR=#E1F0FF bordercolor=#C0C0C0 bordercolordark=#C0C0C0 bordercolorlight=#C0C0C0>");
 printf("<tr>");
 printf("<td colspan=2 WIDTH=50% BGCOLOR=#A8BAC3 bordercolor=#C0C0C0 bordercolordark=#C0C0C0 bordercolorlight=#C0C0C0>");
 printf("<img src=diff.gif width=24 height=24><b><font color=#000088><font size=+1><font face=arial,helvetica> Differences</font></font></b>");
 printf("</td></tr>");
 printf("<tr><td><center>");
 printf("<form method=POST name=diferenca onSubmit=\"return ValidaVersao();\" action=%s/exibediferenca.cgi target=janela2>",LOCALCGI);  //chama o cgi para exibir as diferencas
 //Botoes de radio para a escolher como exibir as diferencas - Cvs ou Cores
 printf("<font face=arial,helvetica><b>Select the manner to show the differences:</b><br>");
 printf("<font face=arial,helvetica><input type=radio name=cvs_cor value=cvs>&nbsp;Cvs Diff&nbsp;&nbsp;&nbsp;");
 printf("<font face=arial,helvetica><input type=radio name=cvs_cor value=cor checked>&nbsp;Collors</font>");
 printf("</td>");
 printf("<td>");

 //Botoes de radio para escolher a exibicao do source ou do html
 printf("<font face=arial,helvetica><b>Select the file type to be show:</b><br>");
 printf("<font face=arial,helvetica><input type=radio name=source_html value=source>&nbsp;Show source&nbsp;&nbsp;&nbsp;");
 printf("<font face=arial,helvetica><input type=radio name=source_html value=html checked>&nbsp;Show html</font>");
 printf("</td></tr>");

 //Menu de versoes 1
 printf("</td></tr>");
 printf("<tr><td>");
 printf("<font face=arial,helvetica><center><b>First version:</b></center>");
 printf("<center><select name=versao_1>"); //primeiro menu de versoes

 for (Cont=0;Cont<=ContVersao-1;Cont++)
 {
  printf("<option value=\"");
  printf("%s",NomePagina);
  printf(" ");
  ContAux=0;

  //escreve a versao posicao por posicao, pois se escrever o "\0" da erro
  while (Estrutura[Cont].Versao[ContAux] != 10) //e' o correspondente ao "\0"
  {
   printf("%c",Estrutura[Cont].Versao[ContAux]);
   ContAux++;
  }
  printf("\">%s %s",NomePagina,Estrutura[Cont].Versao);
 }
 printf("</select></center>");
 printf("</td>");
 printf("<td>");

 //Menu de versoes 2
 printf("<font face=arial,helvetica><center><b>Second version:</b></center>");
 printf("<center><select name=versao_2>"); //segundo menu de versoes
 for (Cont=0;Cont<=ContVersao-1;Cont++)
 {
  printf("<option value=\"");
  printf("%s",NomePagina);
  printf(" ");
  ContAux=0;
  while (Estrutura[Cont].Versao[ContAux] != 10)
  {
   printf("%c",Estrutura[Cont].Versao[ContAux]);
   ContAux++;
  }
  printf("\">%s %s",NomePagina,Estrutura[Cont].Versao);
 }
 printf("</select></center>");
 printf("<tr><td colspan=2 border=0>");
 printf("<input type=hidden name=caminho value=%s>",CaminhoRepositorio);
 printf("<input type=hidden name=diretorio value=%s>",ModuloCheckout);
 printf("<input type=hidden name=pagina value=%s>",NomePagina);
 printf("<center><font face=arial,helvetica><input type=submit value=Send></center>");
 printf("</form>");
 printf("</td></tr></table><br>");
 printf("</body>");
 printf("</html>");
}

void AlteraDiretorio(char *Caminho)
{
 if (chdir(Caminho))
 {
  perror("chdir()");
  exit(1);
 }
}

