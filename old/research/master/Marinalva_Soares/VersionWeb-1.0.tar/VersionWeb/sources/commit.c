/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */                                                                                  
/******************************************************************************************************************/

// Este cgi efetua o commit de um checkout remoto (pode ou nao gerar branches)

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

void AlteraDiretorio(char *Caminho);

int main (void)
{
 struct ConteudoArquivo 
 { 
  char Linha[255]; 
 }; 
 struct ConteudoArquivo Conteudo[10000]; 

 char NomeArquivo[100],String[100000],Operacao[30],Arquivo[100],CaminhoDiretorio[100],Diretorio[100],Linha[255];
 char Comando[100],Modulo[100],CaminhoAux[100],buf[10000],*Resultado,CaminhoUsuario[100],LogMensagem[1000],Revisao[30];
 int Cont1=0,Cont2=0,i=0,Tamanho,Flag=0;
 FILE *ArquivoCommit,*ExecutaCommit;

 //obtem o tamanho do arquivo
 const char *TamanhoInformacao = getenv("CONTENT_LENGTH"); 
 Tamanho=atoi(TamanhoInformacao); 

 //obtem o conteudo do arquivo
 fread(String,Tamanho,1,stdin);

 while (String[Cont1] != '=') //elimina o nome do campo do formulario
  Cont1++; 
 Cont1++; 

 while (String[Cont1] != '&') //Final de informacao de entrada pelo usuario
 { 
  if (String[Cont1] == '%') //Quando encontra caracteres em hexadecimal 
  { 
   if ((String[Cont1+1] == '0') && (String[Cont1+2] == 'D') && (String[Cont1+3] == '%') && (String[Cont1+4] == '0')&& (String[Cont1+5] == 'A'))
   { 
    Conteudo[i].Linha[Cont2] = '\n';
    i++; Cont1+=5; Cont2=-1; // qando e <enter> vem "%0A%0D"
   } 
   else 
   { 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == 'F')) 
    { 
     Conteudo[i].Linha[Cont2] = '/'; 
     Cont1+=2; 
    } 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == 'C')) 
    { 
     Conteudo[i].Linha[Cont2] = ','; 
     Cont1+=2; 
    } 
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'C')) 
    { 
     Conteudo[i].Linha[Cont2] = '<'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'E')) 
    { 
     Conteudo[i].Linha[Cont2] = '>'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'F')) 
    { 
     Conteudo[i].Linha[Cont2] = '?'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '2')) 
    { 
     Conteudo[i].Linha[Cont2] = '\"'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '7')) 
    { 
     Conteudo[i].Linha[Cont2] = '\''; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'A')) 
    { 
     Conteudo[i].Linha[Cont2] = ':'; 
     Cont1+=2; 
    } 
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'B')) 
    { 
     Conteudo[i].Linha[Cont2] = ';'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'B')) 
    { 
     Conteudo[i].Linha[Cont2] = '['; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'D')) 
    { 
     Conteudo[i].Linha[Cont2] = ']'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'B')) 
    { 
     Conteudo[i].Linha[Cont2] = '{'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'D')) 
    { 
     Conteudo[i].Linha[Cont2] = '}'; 
     Cont1+=2; 
    } 
    if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'E')) 
    { 
     Conteudo[i].Linha[Cont2] = '~'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '6') && (String[Cont1+2] == '0')) 
    { 
     Conteudo[i].Linha[Cont2] = '`'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '1')) 
    { 
     Conteudo[i].Linha[Cont2] = '!'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '4') && (String[Cont1+2] == '0')) 
    { 
     Conteudo[i].Linha[Cont2] = '@'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '3')) 
    { 
     Conteudo[i].Linha[Cont2] = '#'; 
     Cont1+=2; 
    } 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '4')) 
    { 
     Conteudo[i].Linha[Cont2] = '$'; 
     Cont1+=2; 
    } 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '5')) 
    { 
     Conteudo[i].Linha[Cont2] = '%'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'E')) 
    { 
     Conteudo[i].Linha[Cont2] = '^'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '6')) 
    { 
     Conteudo[i].Linha[Cont2] = '&'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '8')) 
    { 
     Conteudo[i].Linha[Cont2] = '('; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '9')) 
    { 
     Conteudo[i].Linha[Cont2] = ')'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == 'B')) 
    { 
     Conteudo[i].Linha[Cont2] = '+'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'D')) 
    { 
     Conteudo[i].Linha[Cont2] = '='; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'C')) 
    { 
     Conteudo[i].Linha[Cont2] = '|'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '7')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '1')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    } 
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '9')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'D')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '3')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'F') && (String[Cont1+2] == 'A')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '1')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '9')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'D')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '3')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'D') && (String[Cont1+2] == 'A')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '3')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '5')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '3')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '5')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '0')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '8')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'C')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '2')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '9')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '0')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '8')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'C')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '2')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '9')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '2')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'A')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'E')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '4')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'F') && (String[Cont1+2] == 'B')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '2')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'A')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'E')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '4')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'D') && (String[Cont1+2] == 'B')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '4')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'B')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'F')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '6')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'F') && (String[Cont1+2] == 'c')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '4')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'B')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'F')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '6')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == 'D') && (String[Cont1+2] == 'C')) 
    { 
     Conteudo[i].Linha[Cont2] = '�'; 
     Cont1+=2;
    }
    if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'C')) 
    { 
     Conteudo[i].Linha[Cont2] = '\\'; 
     Cont1+=2;
    } 
   } 
  } 
  else 
  { 
   if (String[Cont1] == '+') //quando encontra o +, foi digitado espaco em branco
   {
    Conteudo[i].Linha[Cont2] = ' ';
   }
   else
   {
    if (String[Cont1] != '&')
     Conteudo[i].Linha[Cont2] = String[Cont1];
    else
     Cont1--;
   }
  }
  Cont2++;
  Cont1++;
 }
 Conteudo[i].Linha[Cont2] = '\n';
 Cont2 = 0; Cont1++; //o cont1 aumenta porque ele esta posicionado no & antes do nome da operacao

 while (String[Cont1] != '=') //elimina o nome do campo usuario que fez o checkout
  Cont1++;
 Cont1++;

 while (String[Cont1] != '&') //obtem o nome do usuario (login), pois o checkout � feito dentro do diretorio de quem logou
 {
  if ((String[Cont1] == '%') && (String[Cont1+1] == '2') && (String[Cont1+2] == 'F'))
  {
   CaminhoUsuario[Cont2] = '/';
   Cont1+=2;
  }
  else
   CaminhoUsuario[Cont2] = String[Cont1];
  Cont2++; Cont1++;
 }
 CaminhoUsuario[Cont2] = '\0';
 Cont2=0; Cont1++;

 while (String[Cont1] != '=') //elimina o nome do campo modulo que foi feito o checkout, para remove-lo apos o commit dentro do diretorio do usuario
  Cont1++;
 Cont1++;

 while (String[Cont1] != '&') //obtem o nome do modulo
 {
  Modulo[Cont2] = String[Cont1];
  Cont2++; Cont1++;
 }
 Modulo[Cont2] = '\0';
 Cont2=0; Cont1++;
 
 while (String[Cont1] != '=') //elimina o campo nome do diretorio que fez o checkout (todo o caminho do diretorio, menos o arquivo. Ex.: Projeto/Paginas/pagina.html,pega tudo menos o pagina.html
  Cont1++;
 Cont1++;

 while (String[Cont1] != '&') //obtem o nome do diretorio que fez o checkout //ex., Projeto/Paginas
 {
  if ((String[Cont1] == '%') && (String[Cont1+1] == '2') && (String[Cont1+2] == 'F'))
  {
   Diretorio[Cont2] = '/';
   Cont1+=2;
  }
  else
   Diretorio[Cont2] = String[Cont1];
  Cont2++; Cont1++;
 }
 Diretorio[Cont2] = '\0';
 Cont2=0; 

 while (String[Cont1] != '=') //elimina o campo nome do arquivo para o commit (arquivo o qual foi feito checkout e agora e preciso fazer commit)
  Cont1++;
 Cont1++;

 while (String[Cont1] != '&') //obtem o nome do arquivo para o commit
 {
  Arquivo[Cont2] = String[Cont1];
  Cont2++; Cont1++;
 }
 Arquivo[Cont2] = '\0';
 Cont2=0; Cont1++;

 while (String[Cont1] != '=') //elimina o campo log de mensagem
  Cont1++;
 Cont1++;

 while (String[Cont1] != '&') //obtem o comentario sobre o commit
 {
  if (String[Cont1] == '%') //Quando encontra caracteres em hexadecimal 
  { 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == 'F')) 
   { 
    LogMensagem[Cont2] = '/'; 
    Cont1+=2; 
   } 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == 'C')) 
   { 
    LogMensagem[Cont2] = ','; 
    Cont1+=2; 
   } 
   if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'C')) 
   { 
    LogMensagem[Cont2] = '<'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'E')) 
   { 
    LogMensagem[Cont2] = '>'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'F')) 
   { 
    LogMensagem[Cont2] = '?'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == '2')) 
   { 
    LogMensagem[Cont2] = '\"'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == '7')) 
   { 
    LogMensagem[Cont2] = '\''; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'A')) 
   { 
    LogMensagem[Cont2] = ':'; 
    Cont1+=2; 
   } 
   if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'B')) 
   { 
    LogMensagem[Cont2] = ';'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'B')) 
   { 
    LogMensagem[Cont2] = '['; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'D')) 
   { 
    LogMensagem[Cont2] = ']'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'B')) 
   { 
    LogMensagem[Cont2] = '{'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'D')) 
   { 
    LogMensagem[Cont2] = '}'; 
    Cont1+=2; 
   } 
   if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'E')) 
   { 
    LogMensagem[Cont2] = '~'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '6') && (String[Cont1+2] == '0')) 
   { 
    LogMensagem[Cont2] = '`'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == '1')) 
   { 
    LogMensagem[Cont2] = '!'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '4') && (String[Cont1+2] == '0')) 
   { 
    LogMensagem[Cont2] = '@'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == '3')) 
   { 
    LogMensagem[Cont2] = '#'; 
    Cont1+=2; 
   } 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == '4')) 
   { 
    LogMensagem[Cont2] = '$'; 
    Cont1+=2; 
   } 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == '5')) 
   { 
    LogMensagem[Cont2] = '%'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'E')) 
   { 
    LogMensagem[Cont2] = '^'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == '6')) 
   { 
    LogMensagem[Cont2] = '&'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == '8')) 
   { 
    LogMensagem[Cont2] = '('; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == '9')) 
   { 
    LogMensagem[Cont2] = ')'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '2') && (String[Cont1+2] == 'B')) 
   { 
    LogMensagem[Cont2] = '+'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'D')) 
   { 
    LogMensagem[Cont2] = '='; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'C')) 
   { 
    LogMensagem[Cont2] = '|'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '7')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '1')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   } 
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '9')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'D')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '3')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'F') && (String[Cont1+2] == 'A')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '1')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '9')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'D')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '3')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'D') && (String[Cont1+2] == 'A')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
    }
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '3')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '5')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '3')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '5')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '0')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '8')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'C')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '2')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '9')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '0')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '8')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'C')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '2')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '9')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '2')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'A')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'E')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '4')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'F') && (String[Cont1+2] == 'B')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '2')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'A')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'E')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '4')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'D') && (String[Cont1+2] == 'B')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == '4')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'B')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'E') && (String[Cont1+2] == 'F')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'F') && (String[Cont1+2] == '6')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'F') && (String[Cont1+2] == 'c')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == '4')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'B')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'C') && (String[Cont1+2] == 'F')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'D') && (String[Cont1+2] == '6')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == 'D') && (String[Cont1+2] == 'C')) 
   { 
    LogMensagem[Cont2] = '�'; 
    Cont1+=2;
   }
   if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'C')) 
   { 
    LogMensagem[Cont2] = '\\'; 
    Cont1+=2;
   }
  }
  else 
  { 
   if (String[Cont1] == '+') //quando encontra o +, foi digitado espaco em branco 
   {
    LogMensagem[Cont2] = ' '; 
   } 
   else 
   {
    if (String[Cont1] != '&') 
     LogMensagem[Cont2] = String[Cont1]; 
    else 
     Cont1--; 
   }
  } 
   Cont2++;
   Cont1++; 
 }
 LogMensagem[Cont2] = '\0';
 Cont2=0; Cont1++;

 while(String[Cont1] != '=')
  Cont1++;
 Cont1++;
 while(String[Cont1] != '&')
 {
  Revisao[Cont2] = String[Cont1];
  Cont2++; Cont1++;
 }
 Revisao[Cont2] = '\0';
 Cont2=0; Cont1++;

 while (String[Cont1] != '=') //visualizar ou commit
 {
  Operacao[Cont2] = String[Cont1];
  Cont2++; Cont1++;
 }
 Operacao[Cont2] = '\0';
 Cont1 = 0;

 if (!strcmp(Operacao,"commit"))
 {
  strcpy(CaminhoAux,CaminhoUsuario); // guarda o caminho do usuario (ex., "/tmp/mdsoares/" para depois posicionar dentro dele e remover o modulo que foi feito o checkout
  strcat(CaminhoAux,Diretorio); //concatena ao caminho do usuario o diretorio que foi feito o checkout (ex., Projeto/Paginas ou Projeto/)
  AlteraDiretorio(CaminhoAux);

  if ((ArquivoCommit=fopen("arquivoaux","w"))==NULL) //cria um arquivo auxiliar para gravar todo o conteudo do arquivo do checkout
  {
   printf("Content-type: text/html\n\n"); 
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
   printf("<html>");
   printf("<base href=%s>",IMAGES);
   printf("<body background=bolor.jpg>");
   printf("<script>");
   printf("alert(\"Error to open file (arquivo auxiliar de commit)...\")\n");
   printf("</script>\n");
   printf("</body></html>");
   exit(1);
  }

  if (!strcmp(Conteudo[i].Linha,"-->\n")) //para nao gravar o final de comentario
   i=i-1;

  if (!strcmp(Conteudo[0].Linha,"<!--\n")) //para nao gravar o inicio de comentario
  {
   for (Cont1=1;Cont1<=i;Cont1++)
    fputs(Conteudo[Cont1].Linha,ArquivoCommit); //grava o conteudo do arquivo alterado no arquivo auxiliar
  }
  else
  {
   for (Cont1=0;Cont1<=i;Cont1++)
    fputs(Conteudo[Cont1].Linha,ArquivoCommit); //grava o conteudo do arquivo alterado no arquivo auxiliar
  }
  fclose(ArquivoCommit);
  remove(Arquivo); //remove o arquivo que foi feito o checkout (com o conteudo antigo)
  rename("arquivoaux",Arquivo); //renomea o arquivo atualizado (para fazer o commit) para seu nome original
  remove("arquivoaux"); //remove o arquivo atualizado

  if (!strcmp(Revisao,"")) //gera a revisao automaticamente (de acordo com o cvs)
  {
   strcpy(Comando,"cvs update ");
   strcat(Comando,Arquivo);

  //faz o merging caso tenha mais de uma pessoa fazendo commit
   Resultado = malloc(10000);
   if ((ExecutaCommit = popen(Comando, "r")) != NULL)  //faz o commit do arquivo alterado
   {
    while (fgets(buf, BUFSIZ, ExecutaCommit) != NULL)
    {
     strcat(Resultado, buf);
     strcat(Resultado, "<br>");
    }
    pclose(ExecutaCommit);
   }
   free(Resultado);

   strcpy(Comando,"cvs commit -m \"");
  }
  else //gera uma revisao especifica (branches)
  {
   strcpy(Comando,"cvs commit -r");
   strcat(Comando,Revisao);
   strcat(Comando," -m \"");
  }
  strcat(Comando,LogMensagem);
  strcat(Comando,"\" ");
  strcat(Comando,Arquivo); //concatena o arquivo a ser feito o commit

 //faz o commit do arquivo depois de ja ter feito o merging
  Resultado = malloc(10000);
  if ((ExecutaCommit = popen(Comando, "r")) != NULL)  //faz o commit do arquivo alterado
  {
   while (fgets(buf, BUFSIZ, ExecutaCommit) != NULL)
   {
    strcat(Resultado, buf);
    strcat(Resultado, "<br>");
   }
   pclose(ExecutaCommit);
  }

  if ((!strstr(Resultado,"done")) || (!strstr(Resultado,"new revision:")))
  {
   free(Resultado);
   printf("Content-type: text/html\n\n");
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
   printf("<html>");
   printf("<base href=%s>",IMAGES);
   printf("<body background=bolor.jpg>");
   printf("<script language=javascript>");
   printf("alert(\"Conflits found in %s! There's a new revision this file in repository!\");",Arquivo);
   printf("</script>");
   printf("</body></html>");
   exit(1);
  }
  else
  {
   free(Resultado);
   printf("Content-type: text/html\n\n");
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
   printf("<html>");
   printf("<base href=%s>",IMAGES);
   printf("<body background=bolor.jpg>");
   printf("<script language=javascript>");
   printf("alert(\"Commit done! Close this window!\");");
   printf("</script></body></html>");
  }
 }
 return;
}

void AlteraDiretorio(char *Caminho) 
{ 
 if (chdir(Caminho)) 
 { 
  perror("chdir()"); 
  exit(1); 
 } 
} 
