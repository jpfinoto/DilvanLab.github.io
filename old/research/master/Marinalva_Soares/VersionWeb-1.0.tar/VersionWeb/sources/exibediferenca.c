/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */ 
/******************************************************************************************************************/

//Cgi que exibe as diferencas entre as versoes escolhidas. A exibicao e atraves de cor ou nao, e pode 
//ser exibido o fonte ou o html

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

void AlteraDiretorio(char *Caminho);
void ExecutaComando(char *Comando);
char DiretorioPagina[100],Pagina[30],DiretorioAux[100];

int main (void)
{
 ExecutaComando("CONTENT_LENGTH");//contem as opcoes escolhidas para a exibicao das diferencas
 return;
}

void AlteraDiretorio(char *Caminho)  
{  
 if (chdir(Caminho))  
 {  
  perror("chdir()");  
  exit(1);  
 }  
}  
 
void ExecutaComando(char *NomeComando)
{
 struct DifVersao//guardar as linhas alteradas e comuns do arquivo
 {
  char Ver1[255];
  char Ver2[255];
  char Cvs[255];
 };

 struct DifVersao TabelaDiferenca[255]; 
 char String[10000],Comando[100],*Resultado,*Result,Arquivo[30],buf[BUFSIZ],Linha[255],CaminhoRepositorio[100];
 char Versao1[10],Versao2[10],ComandoAux[100],OpcaoRadioCvs_Cor[10],OpcaoRadioSource_Html[10],CaminhoDiretorio[100];
 int Cont=0,Cont1=0,ContAux,i=0,Flag=0,Tamanho;
 FILE *ArquivoCheckout,*ArquivoDif;

 const char *TamanhoInformacao = getenv(NomeComando); 
 Tamanho=atoi(TamanhoInformacao); 
 fread(String,Tamanho,1,stdin); 

 while(String[Cont] != '=') //cvs_cor=opcao escolhida (nome do campo do botao de radio para escolher a forma de exibicao)
  Cont++;
 Cont++;

 while(String[Cont] != '&') //o que tem antes do '&' e a forma de exibicao escolhida no botao de radio
 {
  OpcaoRadioCvs_Cor[i] = String[Cont];
  Cont++; i++;
 }
 OpcaoRadioCvs_Cor[i] = '\0';
 i=0;Cont++;
 
 while(String[Cont] != '=') //source_html=opcao escolhida (nome do campo do botao de radio para escolher o tipo de arquivo a ser exibido)
  Cont++;
 Cont++;

 while(String[Cont] != '&')  //o que tem antes do '&' e o tipo de arquivo a ser exibido escolhido no botao de radio
 {
  OpcaoRadioSource_Html[i] = String[Cont];
  Cont++; i++;
 }
 OpcaoRadioSource_Html[i] = '\0';
 i=0;

 while(String[Cont] != '=') //elimina o nome do campo do menu 1 de versoes
  Cont++;
 Cont++;

 while(!Flag)
 {
 //nome_pagina+versao
  if (String[Cont] != '+') //antes do + e o nome da pagina
   Pagina[i] = String[Cont];
  else
  {
   Pagina[i] = '\0';
   Cont++; i=0;

  //depois do + e o numero da versao. Apos o numero da versao vem o &
  //para separar o proximo campo que e a segunda versao
   while(String[Cont] != '&')
   {
    Versao1[i] = String[Cont];
    Cont++; i++;
   }
   Versao1[i] = '\0';
   Flag = 1;
  }
  Cont++; i++;
 }
 while(String[Cont] != '+') //depois do + e o valor da versao
  Cont++;
 Cont++; i = 0;

 while(String[Cont] != '&')
 {
  Versao2[i] = String[Cont];
  Cont++; i++;
 }
 Versao2[i] = '\0';
 i=0;

 while (String[Cont] != '=')
  Cont++;
 Cont++;

 while(String[Cont] != '&') 
 {
  if ((String[Cont] == '%') && (String[Cont+1] == '2') && (String[Cont+2] == 'F'))
  {
   CaminhoRepositorio[i] = '/';
   Cont+=2;
  }
  else
   CaminhoRepositorio[i] = String[Cont];
  Cont++; i++;
 }
 CaminhoRepositorio[i] = '\0';
 i=0;

 while (String[Cont] != '=')
  Cont++;
 Cont++;

 while(String[Cont] != '&') 
 {
  if ((String[Cont] == '%') && (String[Cont+1] == '2') && (String[Cont+2] == 'F'))
  {
   DiretorioPagina[i] = '/';
   Cont+=2;
  }
  else
   DiretorioPagina[i] = String[Cont];
  Cont++; i++;
 }
 DiretorioPagina[i] = '\0';
 i=0;

 if (DiretorioPagina[strlen(DiretorioPagina)-1] != '/')
  strcat(DiretorioPagina,"/");

 strcpy(Comando,"cvs co ");
 strcat(Comando,DiretorioPagina); 
 strcat(Comando,Pagina);

 setenv("CVSROOT",CaminhoRepositorio,1); 

 AlteraDiretorio("/tmp/");

 Resultado = malloc(10000);

 //O "ComandoAux" e para fazer o checkout da pagina
 if ((ArquivoCheckout = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, ArquivoCheckout) != NULL)
  {
   strcat(Resultado, buf);
   strcat(Resultado, "<br>");
  }
  pclose(ArquivoCheckout);
 }

 strcpy(CaminhoDiretorio,"/tmp/");
 strcat(CaminhoDiretorio,DiretorioPagina);
 AlteraDiretorio(CaminhoDiretorio);

 Resultado = malloc(10000);

 strcpy(Comando,"cvs diff -u -r"); 
 strcat(Comando,Versao1); 
 strcat(Comando," -r"); 
 strcat(Comando,Versao2); 
 strcat(Comando," "); 
 strcat(Comando,Pagina); 
 strcat(Comando," > diferencas");//a saida do diff vai para um arquivo chamado diferencas 

 //O "Comando" e para exibir as diferencas
 if ((ArquivoDif = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, ArquivoDif) != NULL)
   strcat(Resultado, buf);
  pclose(ArquivoDif);
 }

 //o resultado do comando diff e colocado no arquivo diferencas
 if ((ArquivoDif = fopen("diferencas","r")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<body>");
  printf("Erro arquivo no arquivo de diferencas");
  printf("</body>");
  printf("</html>");
  exit(1);
 }

 if (!strcmp(OpcaoRadioCvs_Cor,"cvs"))
 {
  printf("Content-type: text/html\n\n"); //exibe o fonte HTML
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
  printf("<html>"); 
  printf("<body bgcolor=#FFFFFF>");
  rewind(ArquivoDif);
  Cont=0;
  while(!feof(ArquivoDif)) 
  {
   ContAux=0; i=0;
   fgets(Linha,100,ArquivoDif); 
   if (!feof(ArquivoDif))
   {
    while(ContAux<=strlen(Linha)) 
    {
     if ((Linha[ContAux] != '<') && (Linha[ContAux] != '>'))
     {
      TabelaDiferenca[Cont].Cvs[i] = Linha[ContAux];
      i++;
     }
     if (Linha[ContAux] == '<')
     {        
      strcat(TabelaDiferenca[Cont].Cvs,"&lt;");
      i+=4; 
     }
     if (Linha[ContAux] == '>')
     {        
      strcat(TabelaDiferenca[Cont].Cvs,"&gt;");
      i+=4; 
     }
     ContAux++;
    }      
   }
   Cont++; 
  } 
  for (i=0;i<Cont-1;i++)
   printf("<font face=arial,helvetica>%s<br>",TabelaDiferenca[i].Cvs);
  printf("</body>");
  printf("</html>");
  fclose(ArquivoDif);
 }
 else
 {
  for (Cont=0;Cont<=8;Cont++) //elimina o cabecalho diff para comecar no texto em si
  {
   fgets(Linha,255,ArquivoDif);
   if (feof(ArquivoDif))
   {
    printf("Content-type: text/html\n\n");
    printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
    printf("<html>");
    printf("<head>");
    printf("<script>");
    printf("alert(\"There is not differences between these revisions!\")");
    printf("</script>");
    printf("</head>");
    printf("</html>");
    exit(1);
   }
  }
  //legenda
   printf("Content-type: text/html\n\n");
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
   printf("<html>");
   printf("<body bgcolor=#FFFFFF>");
   printf("<table border=2 cellpadding=1 cellspacing=1 width=15%>");
   printf("<font face=arial,helvetica>&nbsp;Legend:");
   printf("<tr>");
   printf("<td align=left width=30% bgcolor=#ff9999><font face=arial,helvetica>Common to the versions %s and %s</td>",Versao1,Versao2);
   printf("</tr>");
   printf("<tr>");
   printf("<td align=center bgcolor=#D5FFD5><font face=arial,helvetica>Version %s</b></td>",Versao1);
   printf("</tr>");
   printf("<tr>");
   printf("<td align=right bgcolor=#B7B7FF><font face=arial,helvetica>Version %s</td>",Versao2);
   printf("</tr>");
   printf("</table><p>"); //fim legenda
  printf("</body>");

  Cont=0;
  if (!strcmp(OpcaoRadioSource_Html,"source"))
  {
   while(!feof(ArquivoDif)) 
   {
    ContAux=0; i=0;
    if (!feof(ArquivoDif))
    {
     fgets(Linha,255,ArquivoDif); 
     if ((Linha[0] != '-') && (Linha[0] != '+') && (Linha[0] != '@') && (strcmp(Linha," ")))  //cor rosa - comum as duas versoes 
     {
      while(ContAux<=strlen(Linha)) 
      {
       if ((Linha[ContAux] != '<') && (Linha[ContAux] != '>'))
       {
        TabelaDiferenca[Cont].Ver1[i] = Linha[ContAux];
        TabelaDiferenca[Cont].Ver2[i] = Linha[ContAux];
        i++;
       }
       if (Linha[ContAux] == '<')
       {        
        strcat(TabelaDiferenca[Cont].Ver1,"&lt;");
        strcat(TabelaDiferenca[Cont].Ver2,"&lt;");
        i+=4; 
       }
       if (Linha[ContAux] == '>')
       {        
        strcat(TabelaDiferenca[Cont].Ver1,"&gt;");
        strcat(TabelaDiferenca[Cont].Ver2,"&gt;");
        i+=4; 
       }
       ContAux++;
      }      
     } 
     if (Linha[0] == '-') //cor verde - pertence a primeira versao 
     {
      while(ContAux<=strlen(Linha))
      {
       if ((Linha[ContAux] != '<') && (Linha[ContAux] != '>'))
       {
        TabelaDiferenca[Cont].Ver1[i] = Linha[ContAux];     
        i++;
       }
       if (Linha[ContAux] == '<')
       {
        strcat(TabelaDiferenca[Cont].Ver1,"&lt;");
        i+=4;
       }
       if (Linha[ContAux] == '>')
       {
        strcat(TabelaDiferenca[Cont].Ver1,"&gt;");
        i+=4;
       }
       ContAux++;
      }
      strcat(TabelaDiferenca[Cont].Ver2," ");
     }
     if (Linha[0] == '+') //cor azul - pertence a segunda versao 
     {
      while(ContAux<=strlen(Linha))
      {
       if ((Linha[ContAux] != '<') && (Linha[ContAux] != '>'))
       {
        TabelaDiferenca[Cont].Ver2[i] = Linha[ContAux];     
        i++;
       }
       if (Linha[ContAux] == '<')
       {
        strcat(TabelaDiferenca[Cont].Ver2,"&lt;");
        i+=4;
       }
       if (Linha[ContAux] == '>')
       {
        strcat(TabelaDiferenca[Cont].Ver2,"&gt;");
        i+=4;
       }
       ContAux++;
      }
      strcat(TabelaDiferenca[Cont].Ver1," ");
     }
    }
     Cont++; 
   } 
  }
  else
  {
   while(!feof(ArquivoDif)) 
   { 
    if (!feof(ArquivoDif))
    {
     fgets(Linha,255,ArquivoDif); 
     if ((Linha[0] != '-') && (Linha[0] != '+') && (Linha[0] != '@') && (strcmp(Linha," ")))  //cor rosa - comum as duas versoes 
     { 
      strcpy(TabelaDiferenca[Cont].Ver1,Linha); 
      strcpy(TabelaDiferenca[Cont].Ver2,Linha); 
     } 
     if (Linha[0] == '-') //cor verde - pertence a primeira versao 
     { 
      strcpy(TabelaDiferenca[Cont].Ver1,Linha); 
      strcpy(TabelaDiferenca[Cont].Ver2," "); 
     } 
     if (Linha[0] == '+') //cor azul - pertence a segunda versao 
     { 
      strcpy(TabelaDiferenca[Cont].Ver2,Linha); 
      strcpy(TabelaDiferenca[Cont].Ver1," "); 
     }  
    }
    Cont++; 
   } 
  }
  fclose(ArquivoDif); 
  Cont1 = 0;
  printf("<table bgcolor=#000000 cellpadding=0 cellspacing=0 width=100%>");
  printf("<tr>");
  printf("<td align=center bgcolor=#CCCCCC><font face=arial,helvetica><b>Version %s</b></td><td align=center bgcolor=#CCCCCC><font face=arial,helvetica><b>Version %s</td></b>",Versao1,Versao2);
  printf("</tr>");

 //escreve o conteudo nas 2 colunas da tabela
  while (Cont1 < Cont-1)
  {
   printf("<tr>");
   if (!strcmp(TabelaDiferenca[Cont1].Ver1," "))
    printf("<td bgcolor=#FFFFFF></td>");
   else
   {
    if (TabelaDiferenca[Cont1].Ver1[0] == ' ') //cor de rosa
     printf("<td bgcolor=#ff9999><font face=arial,helvetica>%s</td>",TabelaDiferenca[Cont1].Ver1);
    else //cor verde
    {
     TabelaDiferenca[Cont1].Ver1[0] = ' ';
     printf("<td bgcolor=#D5FFD5><font face=arial,helvetica>%s</td>",TabelaDiferenca[Cont1].Ver1);
    }
   }
   if (!strcmp(TabelaDiferenca[Cont1].Ver2," "))
    printf("<td bgcolor=#FFFFFF></td>");
   else
   {
    if (TabelaDiferenca[Cont1].Ver2[0] == ' ') //cor de rosa
     printf("<td bgcolor=#ff9999><font face=arial,helvetica>%s</td>",TabelaDiferenca[Cont1].Ver2);
    else // cor azul
    {
     TabelaDiferenca[Cont1].Ver2[0] = ' ';
     printf("<td bgcolor=#B7B7FF><font face=arial,helvetica>%s</td>",TabelaDiferenca[Cont1].Ver2);
    }
   }
   printf("</tr>");
   Cont1++;
  }
  printf("</table>"); //fim da tabela de versoes
  printf("</body>");
  printf("</html>");
 }

 AlteraDiretorio("/tmp/");

 Cont=0;
 while (DiretorioPagina[Cont] != '/') //para eliminar o modulo em  que foi feito o checkout
 {
  DiretorioAux[Cont] = DiretorioPagina[Cont];
  Cont++;
 }
 DiretorioAux[Cont] = '\0';
 strcpy(Comando,"rm -rf ");
 strcat(Comando,DiretorioAux);
 system(Comando);

 free(Resultado);
 return;
}

