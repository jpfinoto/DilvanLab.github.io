/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */ 
/******************************************************************************************************************/

//Cgi que gera o formulario de gerenciamento de arquivos

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

char *CriptografaSenha(char SenhaUsuario[20]);
char *rsalt();

void EfetuaOperacao();
void AutenticaAutor(char LoginAux[20],char SenhaAux[20]);
void AlteraDiretorio(char *Caminho);
void ExibeFormulario_Arquivos();
char CaminhoRepositorio[100],Login[20],Senha[20],*SenhaCriptografada,Diretorio_Arquivo_Selecionado[100],Operacao[30],Comando[100];
char Renomea_Arq_Dir[30],CriaDiretorio[30];
FILE *Diretorios;
char CaminhoUsuario[100],PrimeiroCampo[30],Revisao[30];

int indice=0; //indice da estrutura Conteudo

int main (void)
{
 char Linha[100],*String,Comando[100];
 int Cont=0,i=0,AchouBarra=0,Flag=0,Cont2=0,Tamanho;
 FILE *ArquivoCaminhoRepositorio;
 
// A String vem com as seguintes informacoes: tipousuario,caminhorepositorio,login,senha,nome da pagina, nome do diretorio
// ou arquivo a ser listado ou a fazer checkout, operacao

 String = getenv("QUERY_STRING");

 while (String[Cont] != '=') //elimina o primeiro campo de informacao enviada (tipo_usuario ou caminho_repositorio)
 {
  PrimeiroCampo[Cont] = String[Cont];
  Cont++;
 }
 PrimeiroCampo[Cont] = '\0';
 Cont++;

 //se for igual a login � a primeira vez que esta entrando, entao deve fazer a autenticacao de usuario
 if (!strcmp(PrimeiroCampo,"login")) 
 {
  while (String[Cont] != '&') //Estrutura de repeticao que pega o username do autor
  {
   Login[i] = String[Cont];
   i++; Cont++;
  }
  Login[i] = '\0';
  i=0;
  while (String[Cont] != '=') //elimina o nome do campo de Senha
   Cont++;
  Cont++;
  while (String[Cont] != '&') //Estrutura de repeticao que pega a senha do usuario
  {
   Senha[i] = String[Cont];
   i++; Cont++;
  }
  Senha[i] = '\0'; 
  i=0;
  while (String[Cont] != '=') //elimina o nome do campo do repositorio
   Cont++;
  Cont++;
  while (String[Cont] != '&') //Estrutura de repeticao que pega o caminho onde esta o repositorio cvs 
  { 
   if (String[Cont] == '%') //%2F (/)
   {
    CaminhoRepositorio[i] = '/';
    Cont+=2;
   }
   else
    CaminhoRepositorio[i] = String[Cont]; 
   i++; Cont++; 
  } 
  CaminhoRepositorio[i] = '\0';

  //Criptografa a senha
  SenhaCriptografada = malloc(20);
  strcpy(SenhaCriptografada,CriptografaSenha(Senha));
  AutenticaAutor(Login,SenhaCriptografada);
  free (SenhaCriptografada);
 }
 i=0;

 //se for igual � a segunda vez que chama o gerencia_arquivos.cgi e nao precisa autenticar o usuario
 if (!strcmp(PrimeiroCampo,"caminho_repositorio")) 
 { 
  while(String[Cont] != '&') //obtem o valor do caminho_repositorio
  {
   CaminhoRepositorio[i] = String[Cont];
   i++; Cont++;
  }
  CaminhoRepositorio[i] = '\0';
  i=0;

  while(String[Cont] != '=') //elimina o nome do campo diretorio ou arquivo (ou operacao, quando e subir nivel)
   Cont++; 
  Cont++; 
  while(String[Cont] != '&') //obtem o nome do diretorio ou arquivo a ser listado ou fazer checkout
  {
   Diretorio_Arquivo_Selecionado[i] = String[Cont];
   i++; Cont++;
  }
  Diretorio_Arquivo_Selecionado[i] = '\0';
  i=0;
  while (String[Cont] != '=') //elimina o campo operacao
   Cont++;
  Cont++;
  while(String[Cont] != '&') //obtem o tipo de operacao. Se e checkout remoto ou listar diretorio
  {
   Operacao[i] = String[Cont];
   Cont++; i++;
  }
  Operacao[i] = '\0';
  i=0; 

  if ((!strcmp(Operacao,"versions")) || (!strcmp(Operacao,"versionlog")) || (!strcmp(Operacao,"listar")) || (!strcmp(Operacao,"checkoutremoto")) || (!strcmp(Operacao,"subir_nivel")) || (!strcmp(Operacao,"remover")) || (!strcmp(Operacao,"checkoutlocal")) || (!strcmp(Operacao,"checkoutlocalversion")) || (!strcmp(Operacao,"checkoutremotoversion")) || (!strcmp(Operacao,"checkoutremotobranch")))
  {
   while (String[Cont] != '=') //elimina o campo usuario
    Cont++;
   Cont++;
   while(String[Cont] != '&') //obtem o usuario (username)
   {
    Login[i] = String[Cont];
    Cont++; i++;
   }
   Login[i] = '\0';
   i=0; 
  }
 }

 if (!strcmp(Operacao,"checkoutlocalversion"))
 {
  while(String[Cont] != '=')
   Cont++;
  Cont++;
  while(String[Cont] != '&')
  {
   Revisao[i] = String[Cont];
   i++; Cont++;
  }
  Revisao[i] = '\0';
  i=0;
 }

 if ((!strcmp(Operacao,"checkoutremotoversion")) || (!strcmp(Operacao,"checkoutremotobranch")))
 {
  while(String[Cont] != '=')
   Cont++;
  Cont++;
  while(String[Cont] != '&')
  {
   Revisao[i] = String[Cont];
   i++; Cont++;
  }
  Revisao[i] = '\0';
  i=0;
 }

 if (!strcmp(Operacao,"renomear")) //pega o valor do novo nome do arquivo a ser renomeado
 {
  while (String[Cont] != '=') //elimina o nome do campo do novo arquivo
   Cont++;
  Cont++;
  while(String[Cont] != '&') //obtem o nome do arquivo novo.
  {
   Renomea_Arq_Dir[i] = String[Cont];
   Cont++; i++;
  }
  Renomea_Arq_Dir[i] = '\0';
  i=0; 

  while (String[Cont] != '=') //elimina o campo usuario
   Cont++;
  Cont++;
  while(String[Cont] != '&') //obtem o usuario (username)
  {
   Login[i] = String[Cont];
   Cont++; i++;
  }
  Login[i] = '\0';
  i=0; 
 }

 if (!strcmp(Operacao,"criar")) //pega o valor do diretorio a ser criado
 {
  while (String[Cont] != '=') //elimina o nome do campo diretorio
   Cont++;
  Cont++;
  while(String[Cont] != '&') //obtem o nome do diretorio
  {
   CriaDiretorio[i] = String[Cont];
   Cont++; i++;
  }
  CriaDiretorio[i] = '\0';
  i=0; 

  while (String[Cont] != '=') //elimina o campo usuario
   Cont++;
  Cont++;
  while(String[Cont] != '&') //obtem o usuario (username)
  {
   Login[i] = String[Cont];
   Cont++; i++;
  }
  Login[i] = '\0';
  i=0; 
 }

 if (!strcmp(Operacao,"subir_nivel"))
 {
  strcpy(CaminhoUsuario,"/tmp/");
  strcat(CaminhoUsuario,Login);
  strcat(CaminhoUsuario,"/");
  AlteraDiretorio(CaminhoUsuario); //posiciona dentro do diretorio do usuario para criar o arquivo caminho (o diretorio do usuario foi criado no momento de listar o conteudo do diretorio)

  if ((ArquivoCaminhoRepositorio=fopen("caminho","r")) == NULL)  
  {  
   printf("Content-type: text/html\n\n");  
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");  
   printf("<html>");  
   printf("<head>");  
   printf("<script>");  
   printf("alert(\"Error to open file (caminho)...\")\n");  
   printf("</script>\n");  
   printf("</head>");  
   printf("</html>");  
   exit(1);  
  }  
  fgets(Linha,100,ArquivoCaminhoRepositorio);
  fclose(ArquivoCaminhoRepositorio);
  
  if (!strcmp(Linha,CaminhoRepositorio)) //se o CaminhoRepositorio for igual ao que foi informado na tela de login, nao precisa subir um nivel
  {
   ExibeFormulario_Arquivos();
   return;
  }
  else
  {
   Cont = strlen(CaminhoRepositorio)-1;
   i = strlen(Linha)-1;
   if (Cont > i) //se for maior, o CaminhoRepositorio deve subir um nivel na arvore de diretorios
   {
    while (AchouBarra < 2)
    {
     if (CaminhoRepositorio[Cont] == '/') //para subir um nivel, deve-se achar duas barras (do final pro inicio), assim � eliminado o ultimo diretorio
      AchouBarra++;
     if (AchouBarra == 2) //encontrou as duas barras
      CaminhoRepositorio[Cont+1] = '\0'; //elimina-se o diretorio atual para subir um nivel
     Cont--;
    } 
    ExibeFormulario_Arquivos(); //exibe o formulario com o conteudo do diretorio anterior
    return;
   }
   ExibeFormulario_Arquivos();
   return;
  }
 }

  //se for login ou listar, nao precisa do EfetuaOperacao
  if ((!strcmp(PrimeiroCampo,"login")) || (!strcmp(Operacao,"listar")))
   ExibeFormulario_Arquivos();// Essa funcao apenas lista o conteudo de um diretorio
  else
   EfetuaOperacao(); // efetua as outras operacoes requisitadas (exceto login e listar)
 return;
}

void AutenticaAutor(char LoginAux[20],char SenhaAux[20])
{
 char Linha[255],LinhaAux[255],CaminhoAux[100];
 FILE *ArquivoUsuarios;
 int Flag=0,i=0,Cont=0;

 strcpy(CaminhoAux,CaminhoRepositorio);
 if (CaminhoRepositorio[strlen(CaminhoRepositorio)-1] != '/') 
  strcat(CaminhoAux,"/CVSROOT/");
 else
  strcat(CaminhoAux,"CVSROOT/");

 AlteraDiretorio(CaminhoAux);

 if ((ArquivoUsuarios=fopen("usuarios","r")) == NULL) 
 { 
  printf("Content-type: text/html\n\n"); 
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
  printf("<html>"); 
  printf("<head>"); 
  printf("<script>"); 
  printf("alert(\"Error to open file (usuarios)...\")\n"); 
  printf("</script>\n"); 
  printf("</head>"); 
  printf("</html>"); 
  exit(1); 
 } 
 rewind(ArquivoUsuarios);
 
//verifica se o login e a senha do autor estao corretos, senao da erro 
 while(!feof(ArquivoUsuarios)) 
 { 
  if (!feof(ArquivoUsuarios)) 
  { 
   strcpy(LinhaAux," ");
   fgets(Linha,100,ArquivoUsuarios); 
   if (!Flag) //ainda nao encontrou o usuario
   {
    if ((Linha[0] == 'A') || (Linha[0] == 'X')) //Flag para grupo
    { 
     Cont=2;i=0; 
     while (Linha[Cont] != ':')  //elimina o nome do usuario
      Cont++;
     Cont++; 
     while (Linha[Cont] != ':')
     {
      LinhaAux[i] = Linha[Cont]; 
      Cont++; i++; 
     } 
     LinhaAux[i] = '\0'; 
     if (strcmp(LinhaAux,LoginAux))
     { 
      if (feof(ArquivoUsuarios))
      {
       printf("Content-type: text/html\n\n"); 
       printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
       printf("<html>"); 
       printf("<head>"); 
       printf("<script>"); 
       printf("alert(\"Invalid user!\")\n"); 
       printf("</script>\n"); 
       printf("</head>"); 
       printf("</html>"); 
       exit(1); 
      }
     } 
     else
     {
      Flag = 1;
      Cont++; i=0; strcpy(LinhaAux," ");
      while (Linha[Cont] != '\0') 
      { 
       LinhaAux[i] = Linha[Cont]; 
       i++; Cont++; 
      } 
      LinhaAux[i-1] = '\0'; 
      if (strcmp(LinhaAux,SenhaAux)) 
      { 
       printf("Content-type: text/html\n\n"); 
       printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
       printf("<html>"); 
       printf("<head>"); 
       printf("<script>"); 
       printf("alert(\"Invalid password!\")\n"); 
       printf("</script>\n"); 
       printf("</head>"); 
       printf("</html>"); 
       exit(1); 
      }
     }
    }
   }
  }  
  i=0; Cont=0; 
 } 
 if (!Flag)
 { 
  printf("Content-type: text/html\n\n"); 
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
  printf("<html>"); 
  printf("<head>"); 
  printf("<script>"); 
  printf("alert(\"Invalid user!\")\n"); 
  printf("</script>\n"); 
  printf("</head>"); 
  printf("</html>"); 
  exit(1); 
 }
 strcpy(Comando,"rm -rf ");
 strcat(Comando,Login);
 strcat(Comando,"\0");
 AlteraDiretorio("/tmp/");
 system(Comando); //remove o diretorio do usuario que fez checkout remoto e nao fez commit
}

void ExibeFormulario_Arquivos()
{
 struct Conteudo_Repositorio
 {
  char Diretorio[100];
  char Arquivo[100];
 };
 struct Conteudo_Repositorio Repositorio[100];

 char Linha[255],LinhaAux[100],Caminho[200],Comando[100],CaminhoRepositorioAux[100];
 FILE *ArquivoDirArq,*ArquivoCaminhoRepositorio,*ListaDiretorios;
 int Flag=0,i=0,Cont=0,ContArq=0,ContDir=0;

 //verifica�ao do tipo de opera��o pra fazer
 if ((strcmp(Operacao,"checkoutlocalversion")) && (strcmp(Operacao,"criar")) && (strcmp(Operacao,"versions")) && (strcmp(Operacao,"versionlog")) && (strcmp(Operacao,"checkoutremoto")) && (strcmp(Operacao,"checkoutremotoversion")) && (strcmp(Operacao,"checkoutremotobranch")) && (strcmp(Operacao,"remover")) && (strcmp(Operacao,"renomear")) && (strcmp(Operacao,"checkoutlocal"))) //� para listar o caminho completo (juntamente com o diretorio que o usuario escolhe para listar
 { 
  strcat(CaminhoRepositorio,Diretorio_Arquivo_Selecionado); //passa o caminho completo para fazer a listagem
  // verifica se no caminho que o usuario informou foi colocada uma barra no final ou nao
  if (CaminhoRepositorio[strlen(CaminhoRepositorio)-1] != '/')
   strcat(CaminhoRepositorio,"/");
 } 
 strcat(Caminho,"ls -l ");
 strcat(Caminho,CaminhoRepositorio);
 strcat(Caminho," > repositorio");
 
 //cria um diretorio com o nome do usuario para criar o arquivo com o conteudo do repositorio dentro dele (para nao substituir o do outro)
 //pois podem logar usuarios diferentes com repositorios diferentes

 if (!strcmp(PrimeiroCampo,"login")) //para criar o diretorio do usuario apenas uma vez
 {
  AlteraDiretorio("/tmp/");
  strcpy(Comando,"mkdir ");
  strcat(Comando,Login);
  system(Comando);
 }
 
 strcpy(CaminhoUsuario,"/tmp/");
 strcat(CaminhoUsuario,Login);
 strcat(CaminhoUsuario,"/");
 AlteraDiretorio(CaminhoUsuario); //posiciona dentro do diretorio do usuario que esta em "/tmp/"

 // lista o conteudo do repositorio ou diretorio selecionado
 system(Caminho);

 //este arquivo guarda o caminho do repositorio cvs informado na tela de login pelo usuario
 if ((ArquivoCaminhoRepositorio=fopen("caminho","a+")) == NULL)
 {  
  printf("Content-type: text/html\n\n");  
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");  
  printf("<html>");  
  printf("<head>");  
  printf("<script>");  
  printf("alert(\"Error to open file (2caminho)...\")\n");  
  printf("</script>\n");  
  printf("</head>");  
  printf("</html>");  
  exit(1);  
 }  
 //grava o caminho do repositorio antes que ele seja atualizado por um arquivo ou diretorio que o usuario selecionar
 fputs(CaminhoRepositorio,ArquivoCaminhoRepositorio);
 fputs("\n",ArquivoCaminhoRepositorio);
 fclose(ArquivoCaminhoRepositorio);

 //abre o arquivo com o conteudo do repositorio
 if ((ArquivoDirArq=fopen("repositorio","a+"))==NULL)
 {
  printf("Content-type: text/html\n\n"); 
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
  printf("<html>"); 
  printf("<head>"); 
  printf("<script>"); 
  printf("alert(\"Error to open file (repositorio) ...\")\n"); 
  printf("</script>\n"); 
  printf("</head>"); 
  printf("</html>"); 
  exit(1);
 }
 strcpy(Linha," ");
 strcpy(LinhaAux," ");
 rewind(ArquivoDirArq);

 //verifica o que e arquivo e diretorio
 fgets(Linha,100,ArquivoDirArq);
 while(!feof(ArquivoDirArq))
 {
  fgets(Linha,100,ArquivoDirArq);
  if (!feof(ArquivoDirArq))
  {
   if (Linha[0] == 'd') //eh diretorio
   {
    i=0;
    for (Cont=strlen(Linha)-2;Cont>0;Cont--)
    {
     if (Linha[Cont] != ' ')
     {
      LinhaAux[i] = Linha[Cont];
      i++;
     }
     else
      break;
    }
    LinhaAux[i] ='\0';
    Cont=0; i=strlen(LinhaAux)-1;
    while (i > -1)
    {
     Repositorio[ContDir].Diretorio[Cont] = LinhaAux[i];
     i--; Cont++;
    }
    Repositorio[ContDir].Diretorio[Cont] = '\0';
    ContDir++;
   }
   if (Linha[0] == '-') //eh arquivo
   {
    i=0;
    if ((Linha[strlen(Linha)-2] == 'v') && (Linha[strlen(Linha)-3] == ','))
     Linha[strlen(Linha)-2] = '\0'; //elimina o ",v"

    for (Cont=strlen(Linha)-2;Cont>0;Cont--)
    {
     if (Linha[Cont] != ' ')
     {
      LinhaAux[i] = Linha[Cont];
      i++;
     }
     else
      break;
    }
    LinhaAux[i] ='\0';
    Cont=0; i=strlen(LinhaAux)-1;
    while (i> -1)
    {
     Repositorio[ContArq].Arquivo[Cont] = LinhaAux[i];
     i--; Cont++;
    }
    Repositorio[ContArq].Arquivo[Cont] = '\0';
    ContArq++;
   }
  }
 }
 fclose(ArquivoDirArq);

 //remove para o arquivo nao ficar muito grande (cada vez que se deseja remover ou renomear, o arquivo � criado novamente)
 remove("diretorios");
 if ((Diretorios=fopen("diretorios","a+"))==NULL)
 {
  printf("Content-type: text/html\n\n"); 
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
  printf("<html>"); 
  printf("<head>"); 
  printf("<script>"); 
  printf("alert(\"Error to open file (diretorios)...\")\n"); 
  printf("</script>\n"); 
  printf("</head>"); 
  printf("</html>"); 
  exit(1);
 }

 //grava a lista de diretorios porque para renomear ou remover diretorios no formulario
 // precisa verificar se o que se deseja remover ou renomear � um diretorio
 if (ContDir != 0)
 {
  for (Cont=0; Cont < ContDir; Cont++)
  {
   fputs(Repositorio[Cont].Diretorio,Diretorios);
   fputs("\n",Diretorios);
  }
 }
 fclose(Diretorios);

 //pega o caminho do repositorio informado na tela de login pra exibir as diferencas, pois la nao faz checkout com opcao -d
 //entao tem que usar setenv pra CVSROOT
 if ((ArquivoCaminhoRepositorio=fopen("caminho","r")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<head>");
  printf("<script>");
  printf("alert(\"Error to open file (caminho)...\")\n");
  printf("</script>\n");
  printf("</head>");
  printf("</html>");
  exit(1);
 }
 fgets(CaminhoRepositorioAux,100,ArquivoCaminhoRepositorio);
 if (CaminhoRepositorioAux[strlen(CaminhoRepositorioAux)-1] == '\n')
  CaminhoRepositorioAux[strlen(CaminhoRepositorioAux)-1] = '\0';
 fclose(ArquivoCaminhoRepositorio);

 //senao exibe o formlario de gerenciamento de arquivos
 printf("Content-type: text/html\n\n");
 printf("<!doctype html public -//w3c//dtd html 4.0 transitional//en>");
 printf("<html>\n");
 printf("<head>\n");

 printf("<script>\n");  

 //funcao que verifica se esta sendo selecionado arquivo e diretorio ao mesmo tempo
 printf("function Valida()\n{\n ");  
 printf(" if ((document.gerenciarepositorio.lista_diretorios.options.selectedIndex != -1) && (document.gerenciarepositorio.lista_arquivos.options.selectedIndex != -1))\n"); 
 printf("{\n  alert(\"Select only one item for this transaction!\");return false;\n }\n}\n\n");  

  //funcao de javascript que verifica qual diretorio foi selecionado para fazer a listagem
 printf("function ListaDir()\n{\n ");
 printf("if (document.gerenciarepositorio.lista_arquivos)\n{ ");
 printf(" if (document.gerenciarepositorio.lista_arquivos.options.selectedIndex != -1)\n { ");
 printf("alert(\"Operation allowed only to directories!\");\n return false;\n}\n}\n");
 printf(" var Indice = document.gerenciarepositorio.lista_diretorios.options.selectedIndex;\n ");
 printf("if (Indice == -1)\n {\n ");
 printf(" alert(\"No directory selected!\");\n  return false;\n  }\n  else\n{\n");

 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_diretorios.options[Indice].value+\"&operacao=listar&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"GerenciaArquivos\");\n",LOCALCGI,CaminhoRepositorio);

 printf("return true;\n}");
 printf("}\n\n");

 //funcao javascript para criar diretorios e arquivos no repositorio
 printf("function Criar()\n{\n "); 
 printf(" if (document.criar.criar_diretorio.value < 1)\n{");
 printf("alert(\"Missing name to directory!\");\n");
 printf("return false;\n}");
 printf("if (document.criar.criar_diretorio.value)\n{\n ");
//
 printf("carac = 'a';");
 printf("for (cont=0; cont < document.criar.criar_diretorio.value.length; cont++){");
 printf("carac= document.criar.criar_diretorio.value.charAt(cont);");
 printf("if ((carac<'a' || carac>'z' ) && (carac <'A' || carac>'Z') && (carac<'0' || carac>'9') && (carac!='_' && carac!='-') && (carac!= '.')){");
 printf("alert(\"Invalid value!\");");
 printf("return false;}}");

 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=&operacao=criar&diretorio=\"+document.criar.criar_diretorio.value+\"&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"GerenciaArquivos\");\n",LOCALCGI,CaminhoRepositorio);
 printf("return true;}}");

 //funcao que verifica qual arquivo foi selecionado para fazer o checkout remoto
 printf("function CheckoutRemoto()\n{\n");
 printf("if (document.gerenciarepositorio.lista_diretorios)\n{ ");
 printf(" if (document.gerenciarepositorio.lista_diretorios.options.selectedIndex != -1)\n { ");
 printf("alert(\"Operation allowed only to files!\");\n return false;\n}\n}\n");
 printf("if (document.gerenciarepositorio.lista_arquivos)\n{\n ");
 printf("var Indice = document.gerenciarepositorio.lista_arquivos.options.selectedIndex;");
 printf("if (Indice == -1)\n{");
 printf("alert(\"No file selected!\");\n return false;\n}\nelse\n{\n");

// printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_arquivos.options[Indice].value+\"&operacao=checkoutremoto&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"JanelaCommit\",\"width=800,height=600,scrollbars=yes,resizeable=yes\");\n",LOCALCGI,CaminhoRepositorio);
 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_arquivos.options[Indice].value+\"&operacao=checkoutremoto&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"JanelaCommit\",\"location=no\");\n",LOCALCGI,CaminhoRepositorio);
 printf("return true;\n}}");
 printf("}");

 //funcao que verifica qual arquivo foi selecionado para fazer o checkout remoto e depois mostrar o log
 printf("function VersionLog()\n{\n");
 printf("if (document.gerenciarepositorio.lista_diretorios)\n{ ");
 printf(" if (document.gerenciarepositorio.lista_diretorios.options.selectedIndex != -1)\n { ");
 printf("alert(\"Operation allowed only to files!\");\n return false;\n}\n}\n");
 printf("if (document.gerenciarepositorio.lista_arquivos)\n{\n ");
 printf("var Indice = document.gerenciarepositorio.lista_arquivos.options.selectedIndex;");
 printf("if (Indice == -1)\n{");
 printf("alert(\"No file selected!\");\n return false;\n}\nelse\n{\n");

 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_arquivos.options[Indice].value+\"&operacao=versionlog&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"VersionsLog\",\"width=500,height=400,scrollbars=yes\");\n",LOCALCGI,CaminhoRepositorio);
 printf("return true;\n}}");
 printf("}");

 //funcao que verifica qual arquivo foi selecionado para exibir a lista de versoes
 printf("function Versions()\n{\n");
 printf("if (document.gerenciarepositorio.lista_diretorios)\n{ ");
 printf(" if (document.gerenciarepositorio.lista_diretorios.options.selectedIndex != -1)\n { ");
 printf("alert(\"Operation allowed only to files!\");\n return false;\n}\n}\n");
 printf("if (document.gerenciarepositorio.lista_arquivos)\n{\n ");
 printf("var Indice = document.gerenciarepositorio.lista_arquivos.options.selectedIndex;");
 printf("if (Indice == -1)\n{");
 printf("alert(\"No file selected!\");\n return false;\n}\nelse\n{\n");

// printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_arquivos.options[Indice].value+\"&operacao=versions&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"Versions\",\"width=800,height=600,scrollbars=yes,resizeable=yes\");\n",LOCALCGI,CaminhoRepositorio);
 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_arquivos.options[Indice].value+\"&operacao=versions&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"Versions\",\"toolbar=no\");\n",LOCALCGI,CaminhoRepositorio);
 printf("return true;\n}}");
 printf("}");

 printf("function SubirNivel()\n{\n");

 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=&operacao=subir_nivel&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"GerenciaArquivos\");\n",LOCALCGI,CaminhoRepositorio);
 printf("return true;\n}");

 //funcao de javascript que verifica qual diretorio ou arquivo foi selecionado para renomear
 printf("function Renomea()\n{\n "); 
 printf("if (document.gerenciarepositorio.lista_arquivos)\n ");
 printf("var IndiceArq = document.gerenciarepositorio.lista_arquivos.options.selectedIndex;\n"); //pega o indice do arquivo selecionado
 printf("if (document.gerenciarepositorio.lista_diretorios)\n ");
 printf("var IndiceDir = document.gerenciarepositorio.lista_diretorios.options.selectedIndex;\n"); //pega o indice do diretorio selecionado
 printf("if ((IndiceArq >= 0) && (IndiceDir >=0))\n{\n ");
 printf("alert(\"Select only one item for this operation!\");\n ");
 printf("return false;\n}\n");
 printf("if (IndiceArq >= 0)\n{\n ");
 printf("Nome = window.prompt(\"Type the file name:\");\n ");
 printf("if (Nome == null)\n ");
 printf("return false;");
 printf("document.gerenciarepositorio.novo_arquivo.value = Nome;\n ");

 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_arquivos.options[IndiceArq].value+\"&operacao=renomear&novo_arquivo=\"+document.gerenciarepositorio.novo_arquivo.value+\"&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"GerenciaArquivos\");\n ",LOCALCGI,CaminhoRepositorio);
 printf("return true;}");
 printf("if (IndiceDir >= 0)\n{\n ");
 printf("Nome = window.prompt(\"Type the file name:\");\n ");
 printf("if (Nome == null)\n ");
 printf("return false;\n");
 printf("document.gerenciarepositorio.novo_arquivo.value = Nome;\n ");
 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_diretorios.options[IndiceDir].value+\"&operacao=renomear&novo_arquivo=\"+document.gerenciarepositorio.novo_arquivo.value+\"&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"GerenciaArquivos\");\n",LOCALCGI,CaminhoRepositorio);
 printf("return true; }");
 printf("if (document.gerenciarepositorio.lista_diretorios)\n {\n ");
 printf("if (IndiceDir == -1)\n ");
 printf("alert(\"There is nothing selected!\"); return false;}");
 printf("if (document.gerenciarepositorio.lista_arquivos)\n {\n ");
 printf("if (IndiceArq == -1)\n ");
 printf("alert(\"There is nothing selected!\"); return false;}");
 printf("}\n\n");

 //funcao de javascript que verifica qual arquivo ou diretorio foi selecionado para remover
 printf("function Remove()\n{\n "); 
 printf("if (document.gerenciarepositorio.lista_arquivos)\n ");
 printf("var IndiceArq = document.gerenciarepositorio.lista_arquivos.options.selectedIndex;\n"); //pega o indice do arquivo selecionado
 printf("if (document.gerenciarepositorio.lista_diretorios)\n ");
 printf("var IndiceDir = document.gerenciarepositorio.lista_diretorios.options.selectedIndex;\n"); //pega o indice do diretorio selecionado
 printf("if ((IndiceArq >= 0) && (IndiceDir >=0))\n{\n ");
 printf("alert(\"Select only one item for this operation!\");\n ");
 printf("return false;\n}\n");
 printf("if (IndiceArq >= 0)\n{\n ");
 printf("Resp = window.confirm(\"Delete this file?\");\n "); //verifica se realmente quer remover
 printf("if (Resp == true)\n{ "); //se a resposta for sim chama o cgi para efetuar a remocao
 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_arquivos.options[IndiceArq].value+\"&operacao=remover&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"GerenciaArquivos\");\n ",LOCALCGI,CaminhoRepositorio);
 printf("return true;}");
 printf("else return false;\n}\n");
 printf("if (IndiceDir >= 0)\n{\n ");
 printf("Resp = window.confirm(\"Delete this directory?\");\n"); //verifica se realmente quer remover
 printf("if (Resp == true)\n "); //se a resposta for sim chama o cgi para efetuar a remocao
 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_diretorios.options[IndiceDir].value+\"&operacao=remover&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"GerenciaArquivos\");\n ",LOCALCGI,CaminhoRepositorio);
 printf("else return false;\n}\n");
 printf("if (document.gerenciarepositorio.lista_diretorios)\n {\n ");
 printf("if (IndiceDir == -1)\n ");
 printf("alert(\"There is nothing selected!\"); return false;}");
 printf("if (document.gerenciarepositorio.lista_arquivos)\n {\n ");
 printf("if (IndiceArq == -1)\n ");
 printf("alert(\"There is nothing selected!\"); return false;}");
 printf("}\n\n"); //senao nenhum arquivo foi selecionado

 //funcao javascript para download de diretorios e arquivos
 printf("function Download()\n{\n"); 
 printf("if (document.gerenciarepositorio.lista_arquivos)\n ");
 printf("var IndiceArq = document.gerenciarepositorio.lista_arquivos.options.selectedIndex;\n"); //pega o indice do arquivo selecionado
 printf("if (document.gerenciarepositorio.lista_diretorios)\n ");
 printf("var IndiceDir = document.gerenciarepositorio.lista_diretorios.options.selectedIndex;\n"); //pega o indice do diretorio selecionado
 printf("if ((IndiceArq >= 0) && (IndiceDir >=0))\n{\n ");
 printf("alert(\"Select only one item for this operation!\");\n ");
 printf("return false;\n}\n");
 printf("if (IndiceArq >=0)\n{\n ");
 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_arquivos.options[IndiceArq].value+\"&operacao=checkoutlocal&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"Download\",\"width=500,height=400,scrollbars=yes\");\n ",LOCALCGI,CaminhoRepositorio);
 printf("return true;\n}\n");
 printf("if (IndiceDir >= 0)\n{\n ");
 printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_diretorios.options[IndiceDir].value+\"&operacao=checkoutlocal&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"Download\",\"width=500,height=400,scrollbars=yes\");\n ",LOCALCGI,CaminhoRepositorio);
 printf("return true;\n}\n");
 printf("if (document.gerenciarepositorio.lista_diretorios)\n {\n ");
 printf("if (IndiceDir == -1)\n ");
 printf("alert(\"There is nothing selected!\"); return false;}");
 printf("if (document.gerenciarepositorio.lista_arquivos)\n {\n ");
 printf("if (IndiceArq == -1)\n ");
 printf("alert(\"There is nothing selected!\"); return false;}");
 printf("}\n\n");

 //funcao que chama o cgi pra exibir as diferencas do arquivo selecionado
 printf("function Diffs()\n{\n");
 printf("if (document.gerenciarepositorio.lista_diretorios)\n{ ");
 printf(" if (document.gerenciarepositorio.lista_diretorios.options.selectedIndex != -1)\n { ");
 printf("alert(\"Operation allowed only to files!\");\n return false;\n}\n}\n");
 printf("if (document.gerenciarepositorio.lista_arquivos)\n{\n ");
 printf("var Indice = document.gerenciarepositorio.lista_arquivos.options.selectedIndex;");
 printf("if (Indice == -1)\n{");
 printf("alert(\"No file selected!\");\n return false;\n}\nelse\n{\n");
 //CaminhoRepositorioAux e o caminho informado na tela de login.
 //CaminhoRepositorio e o caminho do repositorio+diretorio selecionado
 printf("window.open(\"%sdiffs.cgi?caminho_repositorioaux=%s&caminho_repositorio=%s&dir_arq=\"+document.gerenciarepositorio.lista_arquivos.options[Indice].value,\"Diffs\",\"width=600,height=300,scrollbars=yes\");\n",LOCALCGI,CaminhoRepositorioAux,CaminhoRepositorio);
 printf("return true;\n}}");
 printf("}");

 printf("</script>");
 printf("<title>Files Management</title>\n");
 printf("</head>\n");
 printf("<base href=%s>",IMAGES);
 printf("<body background=bolor.jpg>\n");
 printf("<img src=nome1.jpg align=right><br><hr><br>");
 //tabela principal que contem a tabela que exibe o conteudo do repositorio
 printf("<center><table BORDER CELLSPACING=0 CELLPADDING=0 WIDTH=60% BGCOLOR=#E1F0FF bordercolor=#C0C0C0 bordercolordark=#C0C0C0 bordercolorlight=#C0C0C0>\n");
 printf("<tr><td colspan=2 bgcolor=#A8BAC3><img src=FILCAB1.GIF width=24 height=24> <font color=#000088><font face=arial,helvetica><font size=+2> Files Management</font></font></font></td></tr>\n");
 printf("<tr><td colspan=2 WIDTH=50% BGCOLOR=#C0C0C0><img src=dir_open.gif><font color=#000080><font face=arial,helvetica><font size=+1> %s</font></font></font></td></tr>\n",CaminhoRepositorio);
 printf("<tr>\n");
 printf("<td colspan=2>\n");
 printf("<table BORDER COLS=2 WIDTH=100%>\n"); //tabela que exibe o conteudo do repositorio
 printf("<tr>\n");
 printf("<td><img src=dir1.gif><b> Directories</b>\n");
 printf("<br><form name=gerenciarepositorio method=POST>\n");

 printf("<center><select name=lista_diretorios size=5>\n");

 //mostra diretorios do repositorio
 for (Cont=0;Cont<ContDir;Cont++)
 {
  if (strcmp(Repositorio[Cont].Diretorio,"CVSROOT"))
   printf("<option value=%s>%s</option>\n",Repositorio[Cont].Diretorio,Repositorio[Cont].Diretorio);
 }
 printf("<option>______________________________________________</option>");
 printf("</select>");
 printf("</center></td>\n");
 printf("<td><img src=doc07.gif width=24 height=24> <b>Files</b>\n" );

 printf("<p><center><select name=lista_arquivos size=5>\n");

 //mostra arquivos do repositorio
 for (Cont=0;Cont<ContArq;Cont++)
  printf("<option value=%s>%s</option>\n",Repositorio[Cont].Arquivo,Repositorio[Cont].Arquivo);
 printf("<option>______________________________________________</option>");
 printf("</select>");
 printf("</center></td></tr> \n");

 printf("</table>\n");//final da tabela que exibe o conteudo do arquivo
 printf("<tr>");
 printf("<td colspan=2>\n");
 printf("<table><tr>"); //tabela que exibe os botoes com as opcoes

 printf("<td><input type=button name=listar_diretorio value=List&nbsp;Directory onClick=ListaDir();></td>\n");
 printf("<td><input type=button  name=subir_nivel value=Up&nbsp;Level onClick=SubirNivel();></td>\n");
 printf("<td><input type=button name=renomear value=Rename onClick=Renomea();></td>\n");
 printf("<td><input type=button name=remover value=Remove onClick=Remove();></td>\n");
 printf("<td><input type=button name=checkout_local value=Local&nbsp;Checkout onClick=Download();></td>\n");
 printf("<td><input type=button name=checkout_remoto value=Remote&nbsp;Checkout onClick=CheckoutRemoto();></td>\n");
 printf("<td><input type=button name=versionlog value=Versions&nbsp;History onClick=VersionLog();></td>\n");
 printf("<td><input type=button name=versions value=Versions&nbsp;List onClick=Versions();></td>\n");
 printf("<td><input type=button name=diffs value=Differences onClick=Diffs();></td>\n");
 printf("<input type=hidden name=novo_arquivo value=>"); //guarda o novo nome do arquivo a ser renomeado
 printf("<input type=hidden name=usuario value=%s>",Login); //guarda o usuario que logou para depois fazer checkout com o nome dele
 printf("</form>"); //fim do formulario gerenciarepositorio
 printf("</tr></table></td></tr>"); //final da tabela dos botoes
 printf("</table></center><br>"); //final da tabela principal

 printf("<center><table border width=60% bgcolor=E1F0FF>");//tabela para area de criacao de diretorios e arquivos (upload de arquivos)
 printf("<tr><td colspan=2 bgcolor=#A8BAC3>");
 printf("<img src=boxin2.gif width=24 height=24><font color=#000088><font face=arial,helvetica><font size=+1> Create directories and add files</font></font></font></td></tr>");
 printf("<tr><td colspan=2><form name=criar method=POST>"); //inicio do formulario para criacao de arquivos e diretorios no repositorio
 printf("<br><center><img src=dir1.gif>  <b>Directory name:</b> <input type=text name=criar_diretorio size=30>");
 printf("  <input type=button name=criar value=Create&nbsp;directory onClick=Criar();>\n");
 printf("</form>"); //final do formulario de criacao de arquivos e diretorios no repositorio
 printf("<form enctype=multipart/form-data method=POST action=%supload.cgi target=area2>",LOCALCGI);
 printf("<hr>");
 printf("<img src=Add24.gif>  <b>File to upload:</b> <input type=file size=30 name=%s_%s><p>",Login,CaminhoRepositorio); //envia o nome do usuario para o upload
 printf("<input type=submit name=fazer_upload value=Add&nbsp;file></center>\n");
 printf("</form>"); //final do formulario de upload
 printf("</td></tr>");
 printf("</table></center><br>"); //final da tabela de area de criacao de arquivos e diretorios

 printf("<center><table border width=60% bgcolor=#E1F0FF>"); //inicio da tabela de commit de checkout remoto
 printf("<tr><td colspan=2 bgcolor=#A8BAC3>");
 printf("<form enctype=multipart/form-data method=POST action=%scheckin.cgi target=area2>",LOCALCGI);
 printf("<img src=BOXIN.GIF width=24 height=24><font color=#000088><font face=arial,helvetica><font size=+1> Commit of the local checkout</font></font></font></td></tr>");
 printf("<tr><td colspan=2>");
 printf("<br><center><img src=doc07.gif width=24 height=24>  <b>File to commit:</b> ");
 printf("<input type=file size=30 name=%s_%s></center>\n",Login,CaminhoRepositorio); //envia o nome do usuario para o upload
 printf("<br><center><input type=submit name=fazer_checkin value=Commit&nbsp;of&nbsp;the&nbsp;local&nbsp;checkout></center>\n");
 printf("</form>"); //final do formulario de upload
 printf("</td></tr>\n");
 printf("</table></center>\n"); //final da tabela de commit de checkout remoto
 printf("<center><form><input type=button name=reload value=Reload&nbsp;this&nbsp;page onClick=location.reload();></form></center>");
 printf("</body></html>\n");
}

void EfetuaOperacao()
{
 struct GuardaVersao
 {
  char Versao[100];
  char Branch[100];
  char Data[30];
  char Autor[30];
 };

 struct GuardaVersao Estrutura[100];

 char ComandoAux[100],DiretorioAux[100],ComandoVersao[100];
 char LinhaCaminho[100],LinhaDir[100],Linha[255],Comando[100],buf[10000],*Resultado,ModuloCheckout[100],ModuloAux[100],CaminhoAux[100],ModuloCheckoutAux[100];
 FILE *Arquivo,*ArquivoCaminhoRepositorio,*ArquivoDir,*ArquivoCriar,*ArquivoVersao,*RevisaoCheckout;
 int i=0,Cont=0,AchouDir=0,Flag=0,ContAutor=0,ContData=0,ContVersao=0,ContLinha=0,FlagModulo=0,Tamanho=0,Ponto=0,ContBranch=0,Igual=0;

 //as operacoes (exceto essas tres abaixo) sao chamadas antes do ExibeFormulario_Arquivos,portanto a variavel CaminhoUsuario nao contem nada
 if ((strcmp(Operacao,"login")) || (strcmp(Operacao,"checkoutremoto")) || (strcmp(Operacao,"listar")))
 {
  strcpy(CaminhoUsuario,"/tmp/");
  strcat(CaminhoUsuario,Login);
  strcat(CaminhoUsuario,"/");
  AlteraDiretorio(CaminhoUsuario);
 }

 //para efetuar essas operacoes � preciso eliminar a parte do local onde reside o repositori e pegar somente a parte selecionada pelo usurio
 //Por isso, le-se o arquivo "caminho", pois sua primeira linha guarda o caminho do repositorio informado pelo usuario na tela de login
 if ((!strcmp(Operacao,"checkoutremoto")) || (!strcmp(Operacao,"checkoutremotoversion"))  || (!strcmp(Operacao,"checkoutremotobranch")) || (!strcmp(Operacao,"renomear")) || (!strcmp(Operacao,"remover")) || (!strcmp(Operacao,"checkoutlocal")) || (!strcmp(Operacao,"checkoutlocalversion")) || (!strcmp(Operacao,"criar")) || (!strcmp(Operacao,"versionlog")) || (!strcmp(Operacao,"versions")))
 {
  AlteraDiretorio(CaminhoUsuario);
  if ((ArquivoCaminhoRepositorio=fopen("caminho","r")) == NULL)  //a primeira linha do arquivo contem o caminho do repositorio
  {
   printf("Content-type: text/html\n\n");
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
   printf("<html>");
   printf("<head>");
   printf("<script>");
   printf("alert(\"Error to open file...\");\n");
   printf("</script>\n");
   printf("</head>");
   printf("</html>");
   exit(1);
  }
  rewind(ArquivoCaminhoRepositorio);
  fgets(Linha,100,ArquivoCaminhoRepositorio); //a primeira linha do arquivo vale o caminho do repositorio informado pelo usuario na tela de login
  Linha[strlen(Linha)-1] = '\0';
  fclose(ArquivoCaminhoRepositorio);
  Cont=0;

  //essa linha sera usada para verificar se o diretorio a ser criado e na raiz (/cvsroot/, por exemplo)
  strcpy(LinhaCaminho,Linha);

  while (Linha[Cont] == CaminhoRepositorio[Cont]) //CaminhoRepositorio vale o caminho completo sem o arquivo para checkout, ou seja, ate o ultimo diretorio listado
   Cont++;
  i=0;

  while (CaminhoRepositorio[Cont] != '\0') //pega somente a parte selecionada pelo usuario (diretorio e arquivo)
  {
   ModuloCheckout[i] = CaminhoRepositorio[Cont]; //ModuloCheckout vale tudo que vem depois do caminhorepositorio na tela de login
   Cont++; i++;
  }
  ModuloCheckout[i] = '\0';

  // CaminhoAux (ex.,"/tmp/mdsoares/Projeto") sera usado para posicionar no diretorio e ler o arquivo de checkout para jogar no browser
  strcat(CaminhoAux,CaminhoUsuario);
  strcat(CaminhoAux,ModuloCheckout);

  strcpy(ModuloAux,ModuloCheckout); //o modulo � guardado para remove-lo depois do checkout

  Cont=0;
  while (ModuloAux[Cont] != '/') //por exemplo,"Projeto/mari", para remover � "rm -rf Projeto"
   Cont++;
  ModuloAux[Cont] = '\0';

  strcpy(ModuloCheckoutAux,ModuloCheckout); //passa a variavel ModuloCheckoutAux para commit.cgi para fazer o commit dentro desse diretorio

  if (LinhaCaminho[strlen(LinhaCaminho)-1] == '/') //elimina a ultima barra para fazer checkout
   LinhaCaminho[strlen(LinhaCaminho)-1] = '\0';

  //quando o checkout e de um diretorio (na raiz do cvsroot) a variavel Modulocheckout fica com sujeira
  if (strlen(ModuloCheckout) <= 2)
  {
   strcpy(ModuloCheckout,Diretorio_Arquivo_Selecionado);
   FlagModulo = 1;
  }
  else
   strcat(ModuloCheckout,Diretorio_Arquivo_Selecionado); //concatena o arquivo ao modulo a ser feito o checkout
  strcpy(Comando," ");
  strcat(Comando,"cvs -d :pserver:");
  strcat(Comando,Login);
  strcat(Comando,"@");
  strcat(Comando,HOST);
  strcat(Comando,LinhaCaminho); //linha contem o caminho completo do repositorio
  strcat(Comando," co ");
  strcat(Comando,ModuloCheckout); //diretorio e arquivo, ex., Projeto/pagina.html

  //este comando ira fazer checkout de uma versao especifica
  strcpy(ComandoVersao,"cvs -d :pserver:");
  strcat(ComandoVersao,Login);
  strcat(ComandoVersao,"@");
  strcat(ComandoVersao,HOST);
  strcat(ComandoVersao,LinhaCaminho);  //linha contem o caminho completo do repositorio
  strcat(ComandoVersao," co -r");
  strcat(ComandoVersao,Revisao);
  strcat(ComandoVersao," ");
  strcat(ComandoVersao,ModuloCheckout);

  //faz o checkout tanto para mostrar o arquivo como para alterar e remover
  if (!strcmp(Operacao,"checkoutremoto"))
  {
   Resultado = malloc(10000);
   if ((Arquivo = popen(Comando, "r")) != NULL)
   {
    while (fgets(buf, BUFSIZ, Arquivo) != NULL)
    {
     strcat(Resultado, buf);
     strcat(Resultado, "<br>");
    }
    pclose(Arquivo);
   }
   free(Resultado);

   AlteraDiretorio(CaminhoAux); //posiciona dentro do diretorio que foi feito o checkout - ex., Projeto/Pagina

   if ((ArquivoDir=fopen(Diretorio_Arquivo_Selecionado,"r")) == NULL)  //o nome do arquivo que fez o checkout - le o arquivo pra jogar no browser
   {
    printf("Content-type: text/html\n\n");
    printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
    printf("<html>");
    printf("<head>");
    printf("<script>");
    printf("alert(\"Error to open file \");");
    printf("</script>\n");
    printf("</head>");
    printf("</html>");
    exit(1);
   }
   rewind(ArquivoDir);

   printf("Content-type: text/html\n\n");
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
   printf("<html>");
   printf("<base href=%s>",IMAGES);
   printf("<body background=bolor.jpg><br>");
   printf("<img src=nome1.jpg align=right><br><hr><br>");

   //formulario que exibe o conteudo do arquivo que foi feito o checkout
   printf("<center><table border width=70% bgcolor=#E1F0FF>");//tabela que exibe a area de texto para commit de arquivos
   printf("<tr><td colspan=2 bgcolor=#A8BAC3>\n");
   printf("<img src=writit1.gif width=24 height=24><font color=#000088><font face=arial,helvetica><font size=+2> Area to change text files</font></font></font></td></tr>");
   printf("<tr><td colspan=2><br>");
   printf("<center><b>File: %s</b></center>",Diretorio_Arquivo_Selecionado);
   printf("<form name=commit method=POST action=%scommit.cgi target=area2>",LOCALCGI);
   printf("<center><textarea name=altera_arquivo rows=20 cols=100 align=center>");
   printf("<!--\n");
   while (!feof(ArquivoDir))
   {
    fgets(Linha,255,ArquivoDir);
    if (!feof(ArquivoDir))
     printf("%s",Linha);
   }
   printf("-->");
   printf("</textarea><br>");
   printf("<input type=hidden name=caminho_usuario value=%s>",CaminhoUsuario); //envia tambem o diretorio gerado com o nome de quem fez login,pois o checkout e feito dentro desse diretorio
   printf("<input type=hidden name=modulo value=%s>",ModuloAux); //envia tambem o modulo para remove-lo depois do commit
   printf("<input type=hidden name=diretorio_checkout value=%s>",ModuloCheckoutAux); //envia tambem o nome do diretorio para fazer o commit dentro dele
   printf("<input type=hidden name=arquivo_checkout value=%s>",Diretorio_Arquivo_Selecionado); //envia tambem o nome do arquivo para fazer o commit
   printf("<img src=writit3.gif width=24 height=24><b> Log message:</b> <input type=text name=log_message size=40><br><br>");
   printf("<input type=hidden name=revisao value=\"\">");
   printf("<input type=submit name=commit value=Commit>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
   printf("</td></tr></table></center>");
   printf("</form>"); //final do formulario (commit) que exibe o conteudo do arquivo que foi feito o checkout
   fclose(ArquivoDir);
  }

  //faz o checkout remoto para depois exibir o arquivo de log
  if (!strcmp(Operacao,"versionlog"))
  {
    //faz o checkout do arquivo
   Resultado = malloc(10000);
   if ((Arquivo = popen(Comando, "r")) != NULL)
   {
    while (fgets(buf, BUFSIZ, Arquivo) != NULL)
    {
     strcat(Resultado, buf);
     strcat(Resultado, "<br>");
    }
    pclose(Arquivo);
   }
   free(Resultado);

   AlteraDiretorio(CaminhoAux); //posiciona dentro do diretorio que foi feito o checkout - ex., Projeto/Pagina
   strcpy(ComandoAux,"cvs log ");
   strcat(ComandoAux,Diretorio_Arquivo_Selecionado);
   strcat(ComandoAux," > logs");

   //faz o log do arquivo (este log contem os autores de todas as revisoes
   Resultado = malloc(10000);
   if ((Arquivo = popen(ComandoAux,"r")) != NULL)
   {
    while (fgets(buf, BUFSIZ, Arquivo) != NULL)
    {
     strcat(Resultado,buf);
     strcat(Resultado,"<br>");
    }
    pclose(Arquivo);
   }
   free(Resultado);

  if ((ArquivoVersao = fopen("logs","r")) == NULL)
  {
   printf("Content-type: text/html\n\n");
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
   printf("<HTML>\n");
   printf("<BODY>\n");
   printf("The file log can not be opened...<br>");
   printf("</BODY>\n");
   printf("</HTML>\n");
   exit(1);
  }
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html><head>");
  printf("<title>Versions logs</title>");
  printf("<base href=%s>",IMAGES);
  printf("<body background=bolor.jpg>");
  printf("<img src=nome1.jpg align=right><br><hr><br>");
  while(!feof(ArquivoVersao))
  {
   fgets(Linha,255,ArquivoVersao);
   if (!feof(ArquivoVersao))
    printf("%s<br>",Linha);
  }
  fclose(ArquivoVersao);
  printf("</head></body></html>");
  AlteraDiretorio(CaminhoUsuario); //volta pra o diretorio do usuario
  strcpy(ComandoAux,"rm -rf ");
  strcat(ComandoAux,ModuloAux);
  system(ComandoAux); // remove o diretorio que foi feito o checkout
  exit(1);
 }

 if ((!strcmp(Operacao,"checkoutremotoversion")) || (!strcmp(Operacao,"checkoutremotobranch")))
 {
  AlteraDiretorio(CaminhoUsuario);
  //faz o checkout remoto para revisoes especificas
  Resultado = malloc(10000);
  if ((Arquivo = popen(ComandoVersao, "r")) != NULL)
  {
   while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   {
    strcat(Resultado, buf);
    strcat(Resultado, "<br>");
   }
   pclose(Arquivo);
  }
  free(Resultado);
  AlteraDiretorio(CaminhoAux); //posiciona dentro do diretorio que foi feito o checkout - ex., Projeto/Pagina
  if ((ArquivoDir=fopen(Diretorio_Arquivo_Selecionado,"r")) == NULL)  //o nome do arquivo que fez o checkout - le o arquivo pra jogar no browser
  {
   printf("Content-type: text/html\n\n");
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
   printf("<html>");
   printf("<head>");
   printf("<script>");
   printf("alert(\"Error to open file \");");
   printf("</script>\n");
   printf("</head>");
   printf("</html>");
   exit(1);
  }
  rewind(ArquivoDir);
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<head><script>");

  printf("function ValidaBranch(){");
  printf("if (document.commitversion.branch.value.length == 0){");
  printf("alert(\"Missing number for branch!\");");
  printf("return false;}");
  printf("if (document.commitversion.branch.value)\n{\n ");
  printf("carac = 'a';");
  printf("for (cont=0; cont < document.commitversion.branch.value.length; cont++){");
  printf("carac= document.commitversion.branch.value.charAt(cont);");
  printf("if ((carac < '0' || carac > '9') && (carac!= '.')){");
  printf("alert(\"Invalid value for branch!\");");
  printf("return false;}}}}");

  printf("</head></script>");
  printf("<base href=%s>",IMAGES);
  printf("<body background=bolor.jpg><br>");
  printf("<img src=nome1.jpg align=right><br><hr><br>");

  //formulario que exibe o conteudo do arquivo que foi feito o checkout
  printf("<center><table border width=70% bgcolor=E1F0FF>");//tabela que exibe a area de texto para commit de arquivos
  printf("<tr><td COLSPAN=2 bgcolor=#A8BAC3>\n");
  printf("<img src=writit1.gif width=24 height=24><font color=#000088><font face=arial,helvetica><font size=+2> Area to change text files</font></font></font></td></tr>");
  printf("<tr><td colspan=2><br>");
  printf("<center><b>Revision: %s</b></center>",Revisao);

  if (!strcmp(Operacao,"checkoutremotoversion"))
   printf("<form name=commitversion method=POST onSubmit=\"return ValidaBranch();\" action=%scommit.cgi target=area2>",LOCALCGI);
  else
    printf("<form name=commitbranch method=POST action=%scommit.cgi target=area2>",LOCALCGI);
  printf("<center><textarea name=altera_arquivo rows=20 cols=100 align=center>");

  //formulario que exibe o conteudo do arquivo que foi feito o checkout
  printf("<!--\n");
  while (!feof(ArquivoDir))
  {
   fgets(Linha,255,ArquivoDir);
   if (!feof(ArquivoDir))
    printf("%s",Linha);
  }
  printf("-->");
  printf("</textarea><br><br>");
  printf("<input type=hidden name=caminho_usuario value=%s>",CaminhoUsuario); //envia tambem o diretorio gerado com o nome de quem fez login,pois o checkout e feito dentro desse diretorio
  printf("<input type=hidden name=modulo value=%s>",ModuloAux); //envia tambem o modulo para remove-lo depois do commit
  printf("<input type=hidden name=diretorio_checkout value=%s>",ModuloCheckoutAux); //envia tambem o nome do diretorio para fazer o commit dentro dele
  printf("<input type=hidden name=arquivo_checkout value=%s>",Diretorio_Arquivo_Selecionado); //envia tambem o nome do arquivo para fazer o commit
  printf("<img src=writit3.gif width=24 height=24> <b>Log message:</b> <input type=text name=log_message size=40><br>");

  //se for checkout remoto de branches o numero e gerado automaticamente e nao precisa do campo abaixo
  if (!strcmp(Operacao,"checkoutremotoversion"))
   printf("<img src=branche.gif width=24 height=24><b> Branch number:</b> <input type=text name=branch><br>");
  else
   printf("<input type=hidden name=revisao value=\"\">");
  printf("<input type=submit name=commit value=Commit>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
  printf("</td></tr></center>") ;
  printf("</form>");//final do formulario do texto para commit
  printf("</table><br>");
  fclose(ArquivoDir);
 }

  //faz o checkout remoto para exibir a lista de versoes
  if (!strcmp(Operacao,"versions"))
  {
   //faz o checkout do arquivo
   Resultado = malloc(10000);
   if ((Arquivo = popen(Comando, "r")) != NULL)
   {
    while (fgets(buf, BUFSIZ, Arquivo) != NULL)
    {
     strcat(Resultado, buf);
     strcat(Resultado, "<br>");
    }
    pclose(Arquivo);
   }
   free(Resultado);

   AlteraDiretorio(CaminhoAux); //posiciona dentro do diretorio que foi feito o checkout - ex., Projeto/Pagina
   strcpy(ComandoAux,"cvs log ");
   strcat(ComandoAux,Diretorio_Arquivo_Selecionado);
   strcat(ComandoAux," > logs");

   //faz o log do arquivo (este log contem os autores de todas as revisoes
   Resultado = malloc(10000);
   if ((Arquivo = popen(ComandoAux,"r")) != NULL)
   {
    while (fgets(buf, BUFSIZ, Arquivo) != NULL)
    {
     strcat(Resultado,buf);
     strcat(Resultado,"<br>");
    }
    pclose(Arquivo);
   }
   free(Resultado);

   if ((ArquivoVersao = fopen("logs","r")) == NULL)
   {
    printf("Content-type: text/html\n\n");
    printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
    printf("<HTML>\n");
    printf("<BODY>\n");
    printf("The file log can not be opened...<br>");
    printf("</BODY>\n");
    printf("</HTML>\n");
    exit(1);
   }
   //le o arquivo de log para listar as versoes do arquivo
   //Obtem as 11 primeiras linhas antes do numero da versao
   for (ContLinha=0;ContLinha<12;ContLinha++) //elimina as 11 primeiras linhas
    fgets(Linha,255,ArquivoVersao);

   while(!feof(ArquivoVersao))
   {
    while (!strstr(Linha,"revision"))
     fgets(Linha,255,ArquivoVersao); //primeira linha com a versao (revision 1.1)
    Cont=0; i=0;
    if (Linha[0] == '=') //final do arquivo de logs
     break;
    while (Linha[Cont] != ' ') //elimina o nome revision
     Cont++;
    Cont++;
    while(Linha[Cont] != '\0') //pega o numero da versao
    {
     Estrutura[ContVersao].Versao[i] = Linha[Cont];
     Cont++; i++;
    }
    Estrutura[ContVersao].Versao[i] = '\0';
    i=0; Cont=0;
    ContVersao++;

    fgets(Linha,255,ArquivoVersao); //linha com a data da revisao, hora e autor
    while (Linha[Cont] != ':') //elimina o "date:"
     Cont++;
    Cont++;
    while(i<11)
    {
     Estrutura[ContData].Data[i] = Linha[Cont];
     Cont++; i++;
    }
    Estrutura[ContData].Data[i] = '\0';
    i=0; Cont++;
    ContData++;

    while (Linha[Cont] != ';') //elimina a hora
     Cont++;
    Cont++;
    while (Linha[Cont] != ':') //elimina o "author:"
     Cont++;
    Cont++;
    while(Linha[Cont] != ';')
    {
     Estrutura[ContAutor].Autor[i] = Linha[Cont];
     Cont++; i++;
    }
    Estrutura[ContAutor].Autor[i] = '\0';
    i=0;
    ContAutor++;

    fgets(Linha,255,ArquivoVersao); //log message
    fgets(Linha,255,ArquivoVersao);//-----------
    if (Linha[0] != '-')
     fgets(Linha,255,ArquivoVersao);
   }
   fclose(ArquivoVersao);

   //pega somente as branches
   Cont=0;
   while (Cont <= ContVersao) //quantidade de versoes existentes da pagina
   {
    Tamanho = strlen(Estrutura[Cont].Versao);
    while (Estrutura[Cont].Versao[Tamanho] != '.') //elimina o ultimo ponto, pois depois dele e a versao da branch
     Tamanho--;

    indice=0;
    while (indice < Tamanho)
    {
     if (Estrutura[Cont].Versao[indice] == '.') //verifica se existe mais de um ponto, se nao existir nao existe branch
      Ponto++;
     indice++;
    }
    if (indice>1) //se exsitir branch
    {
     for (indice=0; indice<Tamanho;indice++)
      Estrutura[ContBranch].Branch[indice] = Estrutura[Cont].Versao[indice];

     //atualiza os autores das branches
     strcpy(Estrutura[ContBranch].Data,Estrutura[Cont].Data);
     strcpy(Estrutura[ContBranch].Autor,Estrutura[Cont].Autor);
     ContBranch++;
    }
    Cont++;
   } //final branches

   printf("Content-type: text/html\n\n");
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
   printf("<html><head>");
   printf("<title>Especifics versions</title>");
   printf("<script>");

   //funcao javascript para download da opcao checkout local da tela de versoes especificas
   printf("function CheckoutLocalVersion()\n{\n");
   printf("var Indice = document.versoes.lista_versoes.options.selectedIndex;\n"); //pega o indice do arquivo selecionado
   printf("if (Indice == -1)\n{\n ");
   printf("alert(\"No file selected!\");");
   printf("return false;}");
   printf("if (Indice != -1)\n{\n ");
   printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=%s&operacao=checkoutlocalversion&usuario=%s&revisao=\"+document.versoes.lista_versoes.options[Indice].value+\"&\",\"DownloadVersions\",\"width=500,height=400,scrollbars=yes\");\n ",LOCALCGI,CaminhoRepositorio,Diretorio_Arquivo_Selecionado,Login);
   printf("return true;\n}\n");
   printf("}\n\n");

   //funcao javascript para download da opcao checkout local da tela de versoes especificas
   printf("function CheckoutLocalBranch()\n{\n");
   printf("var Indice = document.branches.lista_branch.options.selectedIndex;\n"); //pega o indice do arquivo selecionado
   printf("if (Indice == -1)\n{\n ");
   printf("alert(\"No file selected!\");");
   printf("return false;}");
   printf("if (Indice != -1)\n{\n ");
   printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=%s&operacao=checkoutlocalversion&usuario=%s&revisao=\"+document.branches.lista_branch.options[Indice].value+\"&\",\"DownloadBranches\",\"width=500,height=400,scrollbars=yes\");\n ",LOCALCGI,CaminhoRepositorio,Diretorio_Arquivo_Selecionado,Login);
   printf("return true;\n}\n");
   printf("}\n\n");

   //funcao que verifica qual versao do arquivo foi selecionado para fazer o checkout remoto
   printf("function CheckoutRemotoVersions()\n{\n");
   printf("var Indice = document.versoes.lista_versoes.options.selectedIndex;");
   printf("if (Indice == -1)\n{");
   printf("alert(\"No file selected!\");\n return false;\n}\nelse\n{\n");
//   printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=%s&operacao=checkoutremotoversion&usuario=%s&revisao=\"+document.versoes.lista_versoes.options[Indice].value+\"&\",\"ArquivoCommit\",\"width=700,height=500,scrollbars=yes\");\n ",LOCALCGI,CaminhoRepositorio,Diretorio_Arquivo_Selecionado,Login);
   printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=%s&operacao=checkoutremotoversion&usuario=%s&revisao=\"+document.versoes.lista_versoes.options[Indice].value+\"&\",\"ArquivoCommit\",\"toolbar=no\");\n ",LOCALCGI,CaminhoRepositorio,Diretorio_Arquivo_Selecionado,Login);
   printf("return true;\n}");
   printf("}");

   //funcao que verifica qual branch do arquivo foi selecionada para fazer o checkout remoto
   printf("function CheckoutRemotoBranch()\n{\n");
   printf("var Indice = document.branches.lista_branch.options.selectedIndex;");
   printf("if (Indice == -1)\n{");
   printf("alert(\"No file selected!\");\n return false;\n}\nelse\n{\n");
//   printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=%s&operacao=checkoutremotobranch&usuario=%s&revisao=\"+document.branches.lista_branch.options[Indice].value+\"&\",\"ArquivoCommit\",\"width=700,height=500,scrollbars=yes\");\n ",LOCALCGI,CaminhoRepositorio,Diretorio_Arquivo_Selecionado,Login);
   printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=%s&operacao=checkoutremotobranch&usuario=%s&revisao=\"+document.branches.lista_branch.options[Indice].value+\"&\",\"ArquivoCommit\",\"toolbar=no\");\n ",LOCALCGI,CaminhoRepositorio,Diretorio_Arquivo_Selecionado,Login);
   printf("return true;\n}");
   printf("}");


    //funcao que chama o cgi pra fazer o merging entre duas versoes
   printf("function Merging()\n{\n");
   printf("Versao1 = document.merging.lista_versoes1.options.selectedIndex;\n ");
   printf("Versao2 = document.merging.lista_versoes2.options.selectedIndex;\n ");
   printf(" if (Versao1 >= Versao2)\n { ");
   printf("alert(\"The first revision must to be higher!\");\n return false;\n}\n");
   printf("window.open(\"%smerging.cgi?login=%s&revisao1=\"+document.merging.lista_versoes1.options[Versao1].value+\"&revisao2=\"+document.merging.lista_versoes2.options[Versao2].value+\"&caminho_usuario=\"+document.merging.caminho_usuario.value+\"&modulo=\"+document.merging.modulo.value+\"&diretorio_checkout=\"+document.merging.diretorio_checkout.value+\"&arquivo=\"+document.merging.arquivo_checkout.value+\"&\",\"area2\");\n",LOCALCGI,Login);
   printf("return true;\n}");

   // funcao que verifica se o campo file to checkin esta vazio
   printf("function ValidaBranch(){");
   printf("if (document.checkin2.branch.value.length == 0){");
   printf("alert(\"Missing number for branch!\");");
   printf("return false;}");
   printf("if (document.checkin2.branch.value)\n{\n ");
   printf("carac = 'a';");
   printf("for (cont=0; cont < document.checkin2.branch.value.length; cont++){");
   printf("carac= document.checkin2.branch.value.charAt(cont);");
   printf("if ((carac < '0' || carac > '9') && (carac!= '.')){");
   printf("alert(\"Invalid value for branch!\");");
   printf("return false;}}");
   printf("window.open(\"%sjanelaarquivos.cgi?caminho_repositorio=%s&dir_arq=&operacao=criar&diretorio=\"+document.criar.criar_diretorio.value+\"&usuario=\"+document.gerenciarepositorio.usuario.value+\"&\",\"GerenciaArquivos\");\n",LOCALCGI,CaminhoRepositorio);
   printf("return true;}}");
   printf("</script>");

   printf("<base href=%s>",IMAGES);
   printf("<body background=bolor.jpg>\n");
   printf("<img src=nome1.jpg align=right><br><hr><br>");
   //tabela que exibe a lista das versoes de um arquivo e permite fazer merging
   printf("<center><table border width=100% bgcolor=#E1F0FF bordercolor=#C0C0C0 bordercolordark=#C0C0C0 bordercolorlight=#C0C0C0>\n");
   printf("<tr><td bgcolor=#A8BAC3>");
   printf("<img src=rolodex4.gif width=24 height=24><font color=#000088><font size=+1><font face=arial,helvetica> Versions list of %s</font></font>\n",Diretorio_Arquivo_Selecionado);
   printf("</td><td bgcolor=#A8BAC3><img src=branche.gif width=24 height=24><font color=#000088><font size=+1><font face=arial,helvetica> Branches list of %s</font></font></font></td>",Diretorio_Arquivo_Selecionado);
   printf("</td><td bgcolor=#A8BAC3><img src=recycl02.gif width=24 height=24><font color=#000088><font size=+1><font face=arial,helvetica> Remove changes between two revisions</font></font></font></td>");
   printf("</tr>\n");
   printf("<tr><td>\n");

  //exibe na pagina a lista das versoes com a data e autores
   printf("<form name=versoes method=POST>\n");

   //exibe a lista de versoes do arquivo e lista de versoes das branches
   printf("<center><select name=lista_versoes size=5>\n");
   for (Cont=0; Cont<=ContVersao-1;Cont++)
    printf("<option value=%s>%s&nbsp;%s&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;%s&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;%s</option>\n",Estrutura[Cont].Versao,Diretorio_Arquivo_Selecionado,Estrutura[Cont].Versao,Estrutura[Cont].Data,Estrutura[Cont].Autor);
   printf("<option>________________________________________</option>");
   printf("</select><br><br>\n");

   printf("<input type=button name=checkout_local value=Local&nbsp;Checkout onClick=CheckoutLocalVersion();>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n");
   printf("<input type=button name=checkout_remoto value=Remote&nbsp;Checkout onClick=CheckoutRemotoVersions();>\n");
   printf("</center>\n");
   printf("<p></td>"); //final lista de versoes
   printf("</form>"); //fim do formulario com a lista das versoes

   //exibe lista de branches
   printf("<td>\n");
   printf("<form name=branches method=POST>\n"); //inicio formulario de lista das branches
   printf("<br><center><select name=lista_branch size=5>\n");
   for (Cont=0; Cont<=ContBranch-1;Cont++)
   {
    if (!strcmp(Estrutura[Cont].Branch,Estrutura[Cont+1].Branch)) //se existirem duas branches com o mesmo numero, escreve somente uma, pois uma branche pode ter varias versoes
     Igual = 1;
    else
     Igual = 0;
    if (!Igual) //escreve a branch somente uma vez
     printf("<option value=%s>%s&nbsp;%s</option>\n",Estrutura[Cont].Branch,Diretorio_Arquivo_Selecionado,Estrutura[Cont].Branch);
   }
   printf("<option>________________________________________</option>");
   printf("</select><br><br>\n");

   printf("<input type=button name=checkout_local value=Local&nbsp;Checkout onClick=CheckoutLocalBranch();>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n");
   printf("<input type=button name=checkout_remoto value=Remote&nbsp;Checkout onClick=CheckoutRemotoBranch();>\n");
   printf("</center>\n");
   printf("</form>"); //fim do formulario com a lista das branches
   printf("</td>");
   printf("<td>");

   printf("<form name=merging method=GET>"); //inicio do formulario para fazer o merging entre duas revisoes
   printf("<center><b>First revision:</b> ");
   printf("<select name=lista_versoes1>\n");
   for (Cont=0; Cont<=ContVersao-1;Cont++)
    printf("<option value=%s>Versao %s</option>\n",Estrutura[Cont].Versao,Estrutura[Cont].Versao);
   printf("</select><br><br>\n");

   printf("<center><b>Second revision:</b> ");
   printf("<select name=lista_versoes2>\n");
   for (Cont=0; Cont<=ContVersao-1;Cont++)
    printf("<option value=%s>Versao %s</option>\n",Estrutura[Cont].Versao,Estrutura[Cont].Versao);
   printf("</select><br><br>\n");

   printf("<input type=hidden name=caminho_usuario value=%s>",CaminhoUsuario); //envia tambem o diretorio gerado com o nome de quem fez login,pois o checkout e feito dentro desse diretorio
   printf("<input type=hidden name=modulo value=%s>",ModuloAux); //envia tambem o modulo para remove-lo depois do commit
   printf("<input type=hidden name=diretorio_checkout value=%s>",ModuloCheckoutAux); //envia tambem o nome do diretorio para fazer o commit dentro dele
   printf("<input type=hidden name=arquivo_checkout value=%s>",Diretorio_Arquivo_Selecionado); //envia tambem o nome do arquivo para fazer o commit

   printf("<input type=button name=merging value=Remove&nbsp;Changes onClick=Merging();></center>");
   printf("</form>");
   printf("</td></tr>");
   printf("</table><br>"); //final da tabela que exibe a lista de versoes e permite fazer merging

   printf("<center><table border width=70% bgcolor=#E1F0FF>");  //inicio da tabela para fazer commit de checkout local
   printf("<tr><td colspan=2 bgcolor=#A8BAC3>");
   printf("<form name=checkin2 enctype=multipart/form-data method=POST onSubmit=\"return ValidaBranch();\" action=%scheckin2.cgi target=area2>",LOCALCGI); //inicio do formulario de checkin
   printf("<img src=BOXIN.GIF width=24 height=24><font color=#000088><font face=arial,helvetica><font size=+1> Commit of the local checkout</font></font></font></td></tr>");
   printf("<tr><td colspan=2><br>");
   printf("<center><img src=doc07.gif width=24 height=24> <b>File to commit: </b><input type=file size=30 name=%s_%s><br><br>\n",Login,CaminhoRepositorio); //envia o nome do usuario para o upload
   printf("<img src=writit3.gif width=24 height=24><b> Log message: </b><input type=text name=log_message size=40><br><br>");
   printf("<img src=branche.gif width=24 height=24><b> Branch number: </b><input type=text name=branch><br><br>");
   printf("<input type=submit name=fazer_checkin value=Commit&nbsp;of&nbsp;the&nbsp;local&nbsp;checkout></center>\n");
   printf("</form>"); //final do formulario de checkin
   printf("</td></tr></table></center>"); //fim da tabela de commit para checkout local
   printf("<center><form><input type=button name=reload value=Reload&nbsp;this&nbsp;page onClick=location.reload();></form></center>");
   printf("</head></body></html>");
   exit(1);
  }

  //checkout local de revisoes especificas
  if (!strcmp(Operacao,"checkoutlocalversion"))
  {
   AlteraDiretorio(LOCALCHECKOUT);
   //cria do diretorio do usuario caso ele ainda  nao exista
   strcpy(ComandoAux,"mkdir ");
   strcat(ComandoAux,Login);
   system(ComandoAux);

   //posiciona dentro do diretorio do usuario
   strcpy(CaminhoAux,LOCALCHECKOUT);
   strcat(CaminhoAux,Login);
   strcat(CaminhoAux,"/");
   AlteraDiretorio(CaminhoAux);

   //faz checkout de uma versao especifica do arquivo para fazer download
   Resultado = malloc(10000);
   if ((Arquivo = popen(ComandoVersao, "r")) != NULL)
   {
    while (fgets(buf, BUFSIZ, Arquivo) != NULL)
    {
     strcat(Resultado, buf);
     strcat(Resultado, "<br>");
    }
    pclose(Arquivo);
   }
   free(Resultado);

   //posiciona dentro do diretorio que fez checkout e cria um arquivo para guardar o numero da versao
   //essa versao sera usada quando for fazer checkin de checkout local (revisoes especificas)
   strcat(CaminhoAux,ModuloCheckoutAux);
   AlteraDiretorio(CaminhoAux);
   if ((RevisaoCheckout = fopen("revisaocheckout","w")) == NULL)
   {
    printf("Content-type: text/html\n\n");
    printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
    printf("<HTML>\n");
    printf("<BODY>\n");
    printf("The file revision can not be opened...<br>");
    printf("</BODY>\n");
    printf("</HTML>\n");
    exit(1);
   }
   fputs(Revisao,RevisaoCheckout);
   fputs("\n",RevisaoCheckout);
   fclose(RevisaoCheckout);

   printf("Content-type: text/html\n\n");
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
   printf("<html><head>");
   printf("<title>Checkout local to especifics versions</title></head>");
   printf("<base href=%s>",IMAGES);
   printf("<body background=bolor.jpg>");
   printf("<img src=nome1.jpg align=right><br><hr><br>");
   printf("<center><h2>Download the file for local checkout</h2></center><br>");

   //ModuloAux � o modulo que foi feito o checkout
   printf("<a href=%s%s/%s%s>%s</a><br>",IMAGES,Login,ModuloCheckoutAux,Diretorio_Arquivo_Selecionado,Diretorio_Arquivo_Selecionado);
   printf("</head></body></html>");
   exit(1);
  }

  // checkout local da ultima versao do arquivo ou diretorio
  if (!strcmp(Operacao,"checkoutlocal"))
  {
   AlteraDiretorio(LOCALCHECKOUT); //este diretorio esta fixo na absolut
   strcpy(ComandoAux,"mkdir ");
   strcat(ComandoAux,Login);
   system(ComandoAux);
   strcpy(CaminhoAux,LOCALCHECKOUT); //este diretorio esta fixo na absolut
   strcat(CaminhoAux,Login);
   strcat(CaminhoAux,"/");
   AlteraDiretorio(CaminhoAux);

   //faz checkout da versao corrente do arquivo ou diretorio para download
   Resultado = malloc(10000);
   if ((Arquivo = popen(Comando, "r")) != NULL)
   {
    while (fgets(buf, BUFSIZ, Arquivo) != NULL)
    {
     strcat(Resultado, buf);
     strcat(Resultado, "<br>");
    }
    pclose(Arquivo);
   }
   free(Resultado);

   if (FlagModulo) //o checkout e do diretorio da raiz de cvsroot
    strcat(CaminhoAux,Diretorio_Arquivo_Selecionado);
   else
    strcat(CaminhoAux,ModuloCheckoutAux);
   AlteraDiretorio(CaminhoAux); //posiciona dentro do diretorio que foi feito o checkout - ex., Projeto/Pagina

   if (!FlagModulo)//nao e o diretorio da raiz a fazer checkout
   {
    strcpy(ComandoAux,"cvs log ");
    strcat(ComandoAux,Diretorio_Arquivo_Selecionado);
    strcat(ComandoAux," > logs");

    //faz o log do arquivo (este log contem os autores de todas as revisoes
    Resultado = malloc(10000);
    if ((Arquivo = popen(ComandoAux,"r")) != NULL)
    {
     while (fgets(buf, BUFSIZ, Arquivo) != NULL)
     {
      strcat(Resultado,buf);
      strcat(Resultado,"<br>");
     }
     pclose(Arquivo);
    }
    free(Resultado);

    if ((ArquivoVersao = fopen("logs","r")) == NULL)
    {
     printf("Content-type: text/html\n\n");
     printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
     printf("<HTML>\n");
     printf("<BODY>\n");
     printf("The file log can not be opened...<br>");
     printf("</BODY>\n");
     printf("</HTML>\n");
     exit(1);
    }
    //le o arquivo de log para listar as versoes do arquivo
    //Obtem as 11 primeiras linhas antes do numero da versao
    for (ContLinha=0;ContLinha<12;ContLinha++) //elimina as 11 primeiras linhas
     fgets(Linha,255,ArquivoVersao);
    fgets(Linha,255,ArquivoVersao); //primeira linha com a versao (revision 1.1)
    Cont=0; i=0;

    while (Linha[Cont] != ' ') //elimina o nome revision
     Cont++;
    Cont++;

    while(Linha[Cont] != '\0') //pega o numero da versao
    {
     Revisao[i] = Linha[Cont];
     Cont++; i++;
    }
    Revisao[i] = '\0';

    //posiciona dentro do diretorio que fez checkout e cria um arquivo para guardar o numero da versao
   //essa versao sera usada quando for fazer checkin de checkout local

    if ((RevisaoCheckout = fopen("revisaocheckout","w")) == NULL)
    {
     printf("Content-type: text/html\n\n");
     printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
     printf("<HTML>\n");
     printf("<BODY>\n");
     printf("The file revision can not be opened...<br>");
     printf("</BODY>\n");
     printf("</HTML>\n");
     exit(1);
    }
    fputs(Revisao,RevisaoCheckout);
    fputs("\n",RevisaoCheckout);
    fclose(RevisaoCheckout);
   }

   printf("Content-type: text/html\n\n");
   printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
   printf("<html><head>");
   printf("<title>Checkout local to files and directories</title></head>");
   printf("<base href=%s>",IMAGES);
   printf("<body background=bolor.jpg>");
   printf("<img src=nome1.jpg align=right><br><hr><br>");
   printf("<center><h2>Download files for local checkout</h2></center><br>");

   //ModuloAux � o modulo que foi feito o checkout
   if (FlagModulo) //nao coloca o ModuloCheckoutAux, pois e o diretorio da raiz
    printf("<a href=%s%s/%s>%s</a><br>",IMAGES,Login,Diretorio_Arquivo_Selecionado,Diretorio_Arquivo_Selecionado);
   else
     printf("<a href=%s%s/%s%s>%s</a><br>",IMAGES,Login,ModuloCheckoutAux,Diretorio_Arquivo_Selecionado,Diretorio_Arquivo_Selecionado);
   printf("</head></body></html>");
   exit(1);
  }

  //cria arquivos ou diretorios dentro do repositorio
  if (!strcmp(Operacao,"criar"))
  {
   strcat(LinhaCaminho,"/");
   if (!strcmp(LinhaCaminho,CaminhoRepositorio)) //se forem iguais o usuario nao entrou em nenhum diretorio, ou seja, esta posicionado na raiz do repositorio
   {
    AlteraDiretorio(CaminhoRepositorio);
    strcpy(ComandoAux,"mkdir ");
    strcat(ComandoAux,CriaDiretorio);
    system(ComandoAux); //cria o diretorio dentro do repositorio sem fazer checkout
    AlteraDiretorio(CaminhoUsuario); //volta para o diretorio do usuario
   }
   else
   {
    //faz checkout do diretorio dentro do qual se deseja criar o novo diretorio
    Resultado = malloc(10000);
    if ((Arquivo = popen(Comando, "r")) != NULL)
    {
     while (fgets(buf, BUFSIZ, Arquivo) != NULL)
     {
      strcat(Resultado, buf);
      strcat(Resultado, "<br>");
     }
     pclose(Arquivo);
    }
    free(Resultado);
    AlteraDiretorio(CaminhoAux); //posiciona dentro do diretorio que fez o checkout
   
    //cria o novo diretorio dentro do diretorio que fez o checkout
    strcpy(ComandoAux,"mkdir ");
    strcat(ComandoAux,CriaDiretorio);
    system(ComandoAux);
    
    //adiciona ao repositorio o diretorio que acabou de ser criado
    strcpy(ComandoAux,"cvs add ");
    strcat(ComandoAux,CriaDiretorio);
 
    Resultado = malloc(10000);
    if ((Arquivo = popen(ComandoAux, "r")) != NULL)  //deve ser adicionado com popen porque o comando emite mensagem
    {
     while (fgets(buf, BUFSIZ, Arquivo) != NULL)
     {
      strcat(Resultado, buf);
      strcat(Resultado, "<br>");
     }
     pclose(Arquivo);
    }
    free(Resultado);
    AlteraDiretorio(CaminhoUsuario); //volta pra o diretorio do usuario
    strcpy(ComandoAux,"rm -rf ");
    strcat(ComandoAux,ModuloAux);
    system(ComandoAux); // remove o diretorio que foi feito o checkout
   }
   ExibeFormulario_Arquivos();
  }

  // renomea arquivo ou diretorio dentro do repositorio
  if (!strcmp(Operacao,"renomear"))
  {
   if ((Diretorios=fopen("diretorios","r"))==NULL) //esse arquivo contem a lista de diretorios  que o usuario listou
   {
    printf("Content-type: text/html\n\n"); 
    printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
    printf("<html>"); 
    printf("<head>"); 
    printf("<script>"); 
    printf("alert(\"Error to open file (diretorios)...\")\n"); 
    printf("</script>\n"); 
    printf("</head>"); 
    printf("</html>"); 
    exit(1);
   }
   rewind(Diretorios);
   while (!feof(Diretorios))
   {
    fgets(LinhaDir,100,Diretorios);
    LinhaDir[strlen(LinhaDir)-1] = '\0';
    if (!strcmp(LinhaDir,Diretorio_Arquivo_Selecionado)) //se for igual e para renomear diretorios
    {
     AchouDir = 1;
     break;
    }
   }
   fclose(Diretorios);

   if (AchouDir) //renomea o diretorio dentro do repositorio
   {
    AlteraDiretorio(CaminhoRepositorio);
    strcpy(Comando,"mv ");
    strcat(Comando,Diretorio_Arquivo_Selecionado);
    strcat(Comando," ");
    strcat(Comando,Renomea_Arq_Dir);
    system(Comando);
   }
   else //senao � arquivo para ser renomeado
   {
    Resultado = malloc(10000); 
    if ((Arquivo = popen(Comando, "r")) != NULL)  //faz checkout do arquivo para renomear
    { 
     while (fgets(buf, BUFSIZ, Arquivo) != NULL) 
     { 
     strcat(Resultado, buf); 
     strcat(Resultado, "<br>");           
    } 
    pclose(Arquivo); 
   } 
   free(Resultado);

   AlteraDiretorio(CaminhoAux); //altera o diretorio para dentro do diretorio que fez o checkout

   strcpy(Comando,"mv ");
   strcat(Comando,Diretorio_Arquivo_Selecionado); //concatena o arquivo que se deseja renomear
   strcat(Comando," ");
   strcat(Comando,Renomea_Arq_Dir);
   system(Comando); //move o arquivo antigo para o novo
 
   strcpy(Comando,"cvs remove ");
   strcat(Comando,Diretorio_Arquivo_Selecionado);
 
   //remove o arquivo antigo
    Resultado = malloc(10000); 
    if ((Arquivo = popen(Comando, "r")) != NULL) //executa o comando com popen porque o remove emite mensagem
    { 
     while (fgets(buf, BUFSIZ, Arquivo) != NULL) 
     { 
      strcat(Resultado, buf); 
      strcat(Resultado, "<br>");           
     } 
     pclose(Arquivo); 
    } 
    free(Resultado); 

    strcpy(Comando,"cvs add ");
    strcat(Comando,Renomea_Arq_Dir);
     
    //adiciona o novo arquivo para commit
    Resultado = malloc(10000); 
    if ((Arquivo = popen(Comando, "r")) != NULL) //executa o comando com popen porque o add emite mensagem
    { 
     while (fgets(buf, BUFSIZ, Arquivo) != NULL) 
     { 
      strcat(Resultado, buf); 
     strcat(Resultado, "<br>");           
     } 
     pclose(Arquivo); 
    } 
    free(Resultado);
    
    strcpy(Comando,"cvs commit -m \"\" ");
    strcat(Comando,Diretorio_Arquivo_Selecionado);
    strcat(Comando," ");
    strcat(Comando,Renomea_Arq_Dir);

    //coloca o novo arquivo permanentemente no repositorio e remove o velho permanentemente
    Resultado = malloc(10000); 
    if ((Arquivo = popen(Comando, "r")) != NULL) //executa o comando com popen porque o commit emite mensagem
    { 
     while (fgets(buf, BUFSIZ, Arquivo) != NULL) 
     { 
      strcat(Resultado, buf); 
      strcat(Resultado, "<br>");           
     } 
     pclose(Arquivo);  
    }  
    free(Resultado); 

    AlteraDiretorio(CaminhoUsuario);
    strcpy(Comando,"rm -rf ");
    strcat(Comando,ModuloAux);
    system(Comando); //remove o modulo que foi feito o checkout

    //remove o diretorio Attic criado dentro de cvsroot
    AlteraDiretorio(CaminhoRepositorio);
    strcpy(Comando,"rm -rf Attic");
    system(Comando); //remove o arquivo com rm
   }
   ExibeFormulario_Arquivos();
  }
  
  if (!strcmp(Operacao,"remover"))
  {
   AlteraDiretorio(CaminhoUsuario);
   if ((Diretorios=fopen("diretorios","r"))==NULL)
   {
    printf("Content-type: text/html\n\n"); 
    printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
    printf("<html>"); 
    printf("<head>"); 
    printf("<script>"); 
    printf("alert(\"Error to open file (diretorios)...\")\n"); 
    printf("</script>\n"); 
    printf("</head>"); 
    printf("</html>"); 
    exit(1);
   }
   rewind(Diretorios);
   while (!feof(Diretorios))
   {
    fgets(LinhaDir,50,Diretorios);
    LinhaDir[strlen(LinhaDir)-1] = '\0';
    if (!strcmp(LinhaDir,Diretorio_Arquivo_Selecionado)) //se for igual e para remover diretorios
    {
     AchouDir = 1;
     break;
    }
   }
   fclose(Diretorios);

   if (AchouDir) //remove o diretorio dentro do repositorio, ou seja, sem fazer checkout
   {
    AlteraDiretorio(CaminhoRepositorio);
    strcpy(Comando,"rm -rf ");
    strcat(Comando,Diretorio_Arquivo_Selecionado);
    system(Comando);
   }
   else
   {
    Resultado = malloc(10000); 
    if ((Arquivo = popen(Comando, "r")) != NULL) 
    { 
     while (fgets(buf, BUFSIZ, Arquivo) != NULL) 
     { 
      strcat(Resultado, buf); 
      strcat(Resultado, "<br>");           
     } 
     pclose(Arquivo); 
    } 
    free(Resultado);

    AlteraDiretorio(CaminhoAux); //altera o diretorio para dentro do diretorio que fez o checkout


    strcpy(Comando,"rm -rf ");
    strcat(Comando,Diretorio_Arquivo_Selecionado); //concatena o arquivo que se deseja deletar
    system(Comando); //remove o arquivo com rm

    strcpy(Comando,"cvs remove ");
    strcat(Comando,Diretorio_Arquivo_Selecionado);

    Resultado = malloc(10000); 
    if ((Arquivo = popen(Comando, "r")) != NULL) //executa o comando com popen porque o cvs remove emite mensagem
    { 
     while (fgets(buf, BUFSIZ, Arquivo) != NULL) 
     { 
      strcat(Resultado, buf); 
      strcat(Resultado, "<br>");           
     } 
     pclose(Arquivo); 
    }   
    free(Resultado);

    strcpy(Comando,"cvs commit -m \"\" ");
    strcat(Comando,Diretorio_Arquivo_Selecionado);

    Resultado = malloc(10000); 
    if ((Arquivo = popen(Comando, "r")) != NULL) //executa o comando com popen porque o commit emite mensagem
    { 
     while (fgets(buf, BUFSIZ, Arquivo) != NULL) 
     { 
      strcat(Resultado, buf); 
      strcat(Resultado, "<br>");           
     } 
     pclose(Arquivo); 
    }  
    free(Resultado);
     
    AlteraDiretorio(CaminhoUsuario);
    strcpy(Comando,"rm -rf ");
    strcat(Comando,ModuloAux);
    system(Comando); //remove o modulo que foi feito o checkout

    //remove o diretorio Attic que e criado depois que remove um arquivo
    AlteraDiretorio(CaminhoRepositorio);
    strcpy(Comando,"rm -rf Attic");
    system(Comando); //remove o arquivo com rm
   }
   ExibeFormulario_Arquivos();
  }
 }
}

void AlteraDiretorio(char *Caminho) 
{ 
 if (chdir(Caminho)) 
 { 
  perror("chdir()"); 
  exit(1); 
 } 
} 

char *rsalt()  /* rsalt() - generate a random 2-char salt */
{
 static char str[3];  /* salt alphabet (c.f. crypt(3)): 0-9 a-z A-Z ./ */
 char  *saltalpha="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ./";
 long  lword1;
 int   alphalen;
 char  *ptr1;

 alphalen=strlen(saltalpha);
 lword1=random(); 
 ptr1=(char *)&lword1;
 str[0] = saltalpha[(unsigned char) ptr1[0]%alphalen];
 str[1] = saltalpha[(unsigned char) ptr1[1]%alphalen]; str[2]='\0';
 return(str);
}

char *CriptografaSenha(char SenhaUsuario[20])
{
 char salt[9],pw[20];
 char *crypt(); 

 strcpy(pw,SenhaUsuario);
 strcpy(salt,rsalt());
 salt[2] = '\0';
 return crypt(pw,salt);
}
