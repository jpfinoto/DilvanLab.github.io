/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */                                                                                 
/******************************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void AlteraDiretorio(char *Caminho);
void ExibeFormulario(void);
char *CriptografaSenha(char SenhaUsuario[20]);
char *rsalt();
void AutenticaGrupo(char LoginAux[20],char SenhaAux[20]);
char CaminhoRepositorio[100],DiretorioPagina[100],NomePagina[30];

int main (void)
{
 char *String,*SenhaCriptografada,Login[30],Senha[30];
 int Cont=0,i=0,Tamanho,Flag=0;

 String = getenv("QUERY_STRING");

 while (String[Cont] != '=') //elimina o campo caminho_repositorio
  Cont++;
 Cont++; 

 while(String[Cont] != '&')
 {
   if ((String[Cont] == '%') && (String[Cont+1] == '2') && (String[Cont+2] == 'F'))
  {
   CaminhoRepositorio[i] = '/';
   Cont+=2;
  }
  else
   CaminhoRepositorio[i] = String[Cont];
  Cont++; i++;
 }
 CaminhoRepositorio[i] = '\0';
 i=0; 

 while (String[Cont] != '=') //elimina o nome do campo diretorio onde reside a pagina
  Cont++;
 Cont++; 

 while(String[Cont] != '&')
 {
  if ((String[Cont] == '%') && (String[Cont+1] == '2') && (String[Cont+2] == 'F'))
  {
   DiretorioPagina[i] = '/';
   Cont+=2;
  }
  else
   DiretorioPagina[i] = String[Cont];
  Cont++; i++;
 }
 DiretorioPagina[i] = '\0';
 i=0;

 while (String[Cont] != '=') //elimina o nome do campo da pagina
  Cont++;
 Cont++; 

 while (String[Cont] != '&')
 {
  NomePagina[i] = String[Cont];
  Cont++; i++;
 }
 NomePagina[i] = '\0';
 i=0; 

 //se ainda houver mais informacao, e porque o internauta deve passar por autenticacao, senao exibe o formulario direto
 if (String[Cont+1])
 {
  Flag=1;
  while (String[Cont] != '=') //elimina o nome do campo de login
   Cont++;
  Cont++;

  while(String[Cont] != '&')
  {
   Login[i] = String[Cont];
   Cont++; i++;
  }
  Login[i] = '\0';
  i=0;
  
  while (String[Cont] != '=') //elimina o nome do campo de senha
   Cont++;
  Cont++;

  while(String[Cont] != '&')
  {
   Senha[i] = String[Cont];
   Cont++; i++;
  }
  Senha[i] = '\0';
  i=0;
 }
 if (Flag)
 {
  SenhaCriptografada = malloc(20);
  strcpy(SenhaCriptografada,CriptografaSenha(Senha));
  AutenticaGrupo(Login,SenhaCriptografada);
  free (SenhaCriptografada);
 }
 else
  ExibeFormulario();
 return;
}


void AutenticaGrupo(char LoginAux[20],char SenhaAux[20])
{
 char Linha[100],LinhaAux[20],Caminho[100];
 FILE *ArquivoUsuarios;
 int Flag=0,i=0,Cont=0;

 if (CaminhoRepositorio[strlen(CaminhoRepositorio)-1] != '/')
  strcat(CaminhoRepositorio,"/");

 strcpy(Caminho,CaminhoRepositorio);
 strcat(Caminho,"CVSROOT/");
 AlteraDiretorio(Caminho);

 if ((ArquivoUsuarios=fopen("usuarios","r")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<head>");
  printf("<script language=javascript\n>");
  printf("<!-- Ocultar JavaScript\n");
  printf("alert(\"Error file open...\")\n");
  printf("//deixar de ocultar o codigo -->\n");
  printf("</script>\n"); 
  printf("</head>"); 
  printf("</html>"); 
  exit(1); 
 } 
 rewind(ArquivoUsuarios);
 
//verifica se o login e a senha do administrador estao corretos, senao da erro 
 while(!feof(ArquivoUsuarios)) 
 { 
  if (!feof(ArquivoUsuarios)) 
  { 
   strcpy(LinhaAux," ");
   fgets(Linha,100,ArquivoUsuarios); 
   if (!Flag) //ainda nao encontrou o usuario
   {
    if (Linha[0] == 'G') //Flag para grupo
    { 
     Cont=2;i=0; 
     while (Linha[Cont] != ':')  //elimina o nome do usuario
      Cont++;
     Cont++; 
     while (Linha[Cont] != ':')
     {
      LinhaAux[i] = Linha[Cont]; 
      Cont++; i++; 
     } 
     LinhaAux[i] = '\0'; 
     if (strcmp(LinhaAux,LoginAux))
     { 
      if (feof(ArquivoUsuarios))
      {
       printf("Content-type: text/html\n\n"); 
       printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
       printf("<html>"); 
       printf("<head>"); 
       printf("<script language=javascript\n>"); 
       printf("<!-- Ocultar JavaScript\n"); 
       printf("alert(\"Invalid user!\")\n"); 
       printf("//deixar de ocultar o codigo -->\n"); 
       printf("</script>\n"); 
       printf("</head>"); 
       printf("</html>"); 
       exit(1); 
      }
     } 
     else
     {
      Flag = 1;
      Cont++; i=0; strcpy(LinhaAux," ");
      while (Linha[Cont] != '\0') 
      { 
       LinhaAux[i] = Linha[Cont]; 
       i++; Cont++; 
      } 
      LinhaAux[i-1] = '\0'; 
      if (strcmp(LinhaAux,SenhaAux)) 
      { 
       printf("Content-type: text/html\n\n"); 
       printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
       printf("<html>"); 
       printf("<head>"); 
       printf("<script>"); 
       printf("alert(\"Invalid password!\")\n"); 
       printf("</script>\n"); 
       printf("</head>"); 
       printf("</html>"); 
       exit(1); 
      }
     }
    }
   }
  }  
  i=0; Cont=0; 
 } 
 if (!Flag)
 { 
  printf("Content-type: text/html\n\n"); 
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
  printf("<html>"); 
  printf("<head>"); 
  printf("<script language=javascript\n>"); 
  printf("<!-- Ocultar JavaScript\n"); 
  printf("alert(\"Invalid user!\")\n"); 
  printf("//deixar de ocultar o codigo -->\n"); 
  printf("</script>\n"); 
  printf("</head>"); 
  printf("</html>"); 
  exit(1); 
 }
 ExibeFormulario();
}

//Exibe a lista de versoes para visualizacao, para exibicao de diferencas e formulario pra notificacao e comentarios
void ExibeFormulario(void)
{
 struct GuardaVersao
 {
  char Versao[100];//guarda o valor da Linha (com o n� da versao) lida do arquivo
  char Data[30];
  char Autor[30];
 };

 struct GuardaVersao Estrutura[100]; //*** aumentar depois o vetor ***
 char Linha[100],LinhaAux[100],CaminhoAux[100],Comando[100],*Resultado,buf[1000];
 int ContLinha,Cont,ContVersao=0,ContAux=0,i=0,ContData=0,ContAutor=0;
 FILE *ArquivoVersao,*Arquivo;

 //acrescenta uma barra no final pra listar o diretorio
 if (DiretorioPagina[strlen(DiretorioPagina)-1] != '/')
  strcat(DiretorioPagina,"/");

  //seta a variavel ambiente pra reconhecer o repositorio
 setenv("CVSROOT",CaminhoRepositorio,1);
 strcpy(CaminhoAux,"/tmp/");
 strcpy(Comando,"cvs co ");
 strcat(Comando,DiretorioPagina);
 strcat(Comando,NomePagina);
 AlteraDiretorio("/tmp/");

 //faz checkout do arquivo pra verificar as versoes pra serem exibidas
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
  {
   strcat(Resultado, buf);
   strcat(Resultado, "<br>");
  }
  pclose(Arquivo);
 }
 free(Resultado);

 strcpy(CaminhoAux,"/tmp/");
 strcat(CaminhoAux,DiretorioPagina);
 AlteraDiretorio(CaminhoAux);

 //adiciona esse arquivo para notificacao de usuarios
 strcpy(Comando,"cvs watch add -a commit ");
 strcat(Comando,NomePagina);
 system(Comando);

 //faz log de arquivo para exibir versoes, autores e datas
 strcpy(Comando,"cvs log ");
 strcat(Comando,NomePagina);
 strcat(Comando," > log");

 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
  {
   strcat(Resultado, buf);
   strcat(Resultado, "<br>");
  }
  pclose(Arquivo);
 }
 free(Resultado);

 if ((ArquivoVersao = fopen("log","r")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<HTML>\n");
  printf("<BODY>\n");
  printf("The file log can not be opened...<br>");
  printf("</BODY>\n");
  printf("</HTML>\n");
  exit(1);
 }

 //elimina as 11 primeiras linhas   fgets(Linha,100,ArquivoVersao);
 for (ContLinha=0;ContLinha<12;ContLinha++)
  fgets(Linha,255,ArquivoVersao);

 while(!feof(ArquivoVersao))
 {
  fgets(Linha,255,ArquivoVersao); //primeira linha com a versao (revision 1.1)
  Cont=0; i=0;
  if (Linha[0] == '=') //final do arquivo de logs
   break;
  while (Linha[Cont] != ' ') //elimina o nome revision
   Cont++;
  Cont++;
  while(Linha[Cont] != '\0') //pega o numero da versao
  {
   Estrutura[ContVersao].Versao[i] = Linha[Cont];
   Cont++; i++;
  }
//  Estrutura[ContVersao].Versao[i] = '\0';
  i=0; Cont=0;
  ContVersao++;

  fgets(Linha,255,ArquivoVersao); //linha com a data da revisao, hora e autor
  while (Linha[Cont] != ':') //elimina o "date:"
   Cont++;
  Cont++;
  while(i<11)
  {
   Estrutura[ContData].Data[i] = Linha[Cont];
   Cont++; i++;
  }
  Estrutura[ContData].Data[i] = '\0';
  i=0; Cont++;
  ContData++;

  while (Linha[Cont] != ';') //elimina a hora
   Cont++;
  Cont++;
  while (Linha[Cont] != ':') //elimina o "author:"
   Cont++;
  Cont++;
  while(Linha[Cont] != ';')
  {
   Estrutura[ContAutor].Autor[i] = Linha[Cont];
   Cont++; i++;
  }
  Estrutura[ContAutor].Autor[i] = '\0';
  i=0;
  ContAutor++;

  fgets(Linha,255,ArquivoVersao); //log message
  fgets(Linha,255,ArquivoVersao);//-----------
  if (Linha[0] != '-')
   fgets(Linha,255,ArquivoVersao);
 }

 fclose(ArquivoVersao);

 printf("Content-type: text/html\n\n");
 printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
 printf("<html>");
 printf("<head>");

 //script para verificar se as duas versoes selecionadas sao iguais. Se for, emite mensagem de erro.
 printf("<script>\n");
 printf("function ValidaVersao()\n{\n");
 printf(" if (document.diferenca.versao_1.options.selectedIndex == document.diferenca.versao_2.options.selectedIndex)\n{");
 printf("  alert(\"Select differents versions!\");\n  return false;\n}");
 printf("return true;\n}\n");

 //funcao para validar o tamanho da informacao
 printf("function ValidLength(item,len)\n{\n");
 printf(" return (item.length >= len);\n}\n\n");

//funcao para validar o campo Nome
 printf("function ValidNome(item)\n{\n");
 printf(" if (!ValidLength(item,1))\n  return false;\n");
 printf(" return true;\n}\n\n");

//funcao para validar o campo E-mail
 printf("function ValidEmail(item)\n{\n");
 printf(" if (!ValidLength(item,5))\n  return false;\n");
 printf(" if (item.indexOf (\'@\',0) == -1)\n  return false;\n");
 printf(" return true;\n}\n\n");

//funcao para verificar se o campo E-mail esta vazio
 printf("function ValidaEmailBranco(item)\n{\n");
 printf(" if (!ValidLength(item,1))\n  return false;\n");
 printf(" return true;\n}\n\n");

//mostra um alert de erro
 printf("function error(elem,text)\n{\n");
 printf(" window.alert(text)\n");
 printf(" elem.select();\n");
 printf(" elem.focus();\n}\n\n");

 //funcao principal de validacao
 printf("function Validate()\n{\n");
 printf(" if (!ValidNome(document.notificacao.nome.value))\n {\n");
 printf("  error(document.notificacao.nome, \"All entries must to be fill!\");\n");
 printf("  return false;\n }\n");
 printf(" if (!ValidaEmailBranco(document.notificacao.email.value))\n {\n");
 printf("  error(document.notificacao.email, \"All entries must to be fill!\");\n");
 printf("  return false;\n }\n");

 printf(" if (!ValidEmail(document.notificacao.email.value))\n {\n");
 printf("  error(document.notificacao.email, \"Invalid address mail!\");\n");
 printf("  return false;\n }\n");
 printf(" else\n {\n  return true;\n }\n}\n");

//funcao que verifica se o usuario digitou alguma coisa
 printf("function ValidComentario(item)\n{\n");
 printf(" if (!ValidLength(item,1))\n  return false;\n");
 printf(" return true;\n}\n\n");

//funcao principal de validacao
 printf("function ValidaComentario()\n{\n");
 printf(" if (!ValidComentario(document.comentarios.comentario.value))\n {\n");
 printf("  error(document.comentarios.comentario,\"No entry for this form!\");\n");
 printf("  return false;\n }\n");
 printf(" else\n {\n return true;\n }\n}\n");

 printf("</script>");
 printf("</head>");
 printf("<base href=%s>",IMAGES);
 printf("<body background=bolor.jpg>");
 printf("<img src=nome1.jpg align=right><br><hr><br>");

 //tabela onde deverao ser exibidas as versoes
 printf("<center><table BORDER WIDTH=100% BGCOLOR=#E1F0FF bordercolor=#C0C0C0 bordercolordark=#C0C0C0 bordercolorlight=#C0C0C0>");
 printf("<tr>");
 printf("<td WIDTH=50% BGCOLOR=#A8BAC3 bordercolor=#C0C0C0 bordercolordark=#C0C0C0 bordercolorlight=#C0C0C0>");
 printf("<img src=rolodex4.gif width=24 height=24><font color=#000088><font size=+1><font face=arial,helvetica> Versions list of page %s</font></font>",NomePagina);
 printf("</td><td BGCOLOR=#A8BAC3>");
 printf("<img src=diff.gif width=24 height=24><font color=#000088><font size=+1><font face=arial,helvetica> Differences</font></font>");
 printf("</td></tr>");
 printf("<tr><td>");
 printf("<form name=rec_versao method=GET action=%srecuperaversao.cgi target=recuperaversao>",LOCALCGI);
 printf("<input type=hidden name=caminho_repositorio value=%s>",CaminhoRepositorio);
 printf("<input type=hidden name=diretorio_pagina value=%s>",DiretorioPagina);
 printf("<input type=hidden name=pagina value=%s>",NomePagina);
 printf("<center><select name=versoes size=5>");
 //exibe a pagina a lista das versoes

 for (Cont=0; Cont<=ContVersao-1;Cont++)
  printf("<option value=%s>%s %s&nbsp;&nbsp;&nbsp;&nbsp;%s&nbsp;&nbsp;&nbsp;&nbsp;%s</option>",Estrutura[Cont].Versao,NomePagina,Estrutura[Cont].Versao,Estrutura[Cont].Data,Estrutura[Cont].Autor);
 printf("<option>__________________________________________</option>");
 printf("</select><br>");
 printf("<input type=submit name=send value=Retrieve&nbsp;Version></center>");
 printf("</td>");
 printf("</form>");

 //Tabela onde devera ser exibido o formulario de diferencas
 printf("<td>");
 printf("<form method=POST name=diferenca onSubmit=\"return ValidaVersao();\" action=%sexibediferenca.cgi target=janela2>",LOCALCGI);  //chama o cgi para exibir as diferencas

 //Botoes de radio para a escolher como exibir as diferencas - Cvs ou Cores
 printf("<center><table border=1><tr><td><font face=arial,helvetica><input type=radio name=cvs_cor value=cvs>Cvs Diff&nbsp;&nbsp;&nbsp;");
 printf("<font face=arial,helvetica><input type=radio name=cvs_cor value=cor checked>&nbsp;Collors</font></td>");

 //Botoes de radio para escolher a exibicao do source ou do html
 printf("<td><font face=arial,helvetica><input type=radio name=source_html value=source>&nbsp;Source&nbsp;file&nbsp;&nbsp;");
 printf("<font face=arial,helvetica><input type=radio name=source_html value=html checked>&nbsp;Html file</font></td></tr></table>");

 //Menu de versoes 1
 printf("<br><font face=arial,helvetica>First version:<br>");
 printf("<select name=versao_1>"); //primeiro menu de versoes

 for (Cont=0;Cont<=ContVersao-1;Cont++)
 {
  printf("<option value=\"");
  printf("%s",NomePagina);
  printf(" ");
  ContAux=0;

  //escreve a versao posicao por posicao, pois se escrever o "\0" da erro
  while (Estrutura[Cont].Versao[ContAux] != 10) //e' o correspondente ao "\0"
  {
   printf("%c",Estrutura[Cont].Versao[ContAux]);
   ContAux++;
  }
  printf("\">%s %s",NomePagina,Estrutura[Cont].Versao);
 }
 printf("</select>");

 //Menu de versoes 2
 printf("<br><font face=arial,helvetica>Second version:<br>");
 printf("<select name=versao_2>"); //segundo menu de versoes
 for (Cont=0;Cont<=ContVersao-1;Cont++)
 {
  printf("<option value=\"");
  printf("%s",NomePagina);
  printf(" ");
  ContAux=0;
  while (Estrutura[Cont].Versao[ContAux] != 10)
  {
   printf("%c",Estrutura[Cont].Versao[ContAux]);
   ContAux++;
  }
  printf("\">%s %s",NomePagina,Estrutura[Cont].Versao);
 }
 printf("</select>");
 printf("<input type=hidden name=caminho value=%s>",CaminhoRepositorio);
 printf("<input type=hidden name=diretorio value=%s>",DiretorioPagina);
 printf("<input type=hidden name=pagina value=%s>",NomePagina);
 printf("<br><font face=arial,helvetica><input type=submit value=Show&nbsp;Differences></center>");
 printf("</form>");
 printf("</td></tr></table><br>");

 //formulario para notificacao
 printf("<center><table BORDER WIDTH=100% BGCOLOR=#E1F0FF bordercolor=#C0C0C0 bordercolordark=#C0C0C0 bordercolorlight=#C0C0C0>");
 printf("<tr>");
 printf("<td WIDTH=50% BGCOLOR=#A8BAC3 bordercolor=#C0C0C0 bordercolordark=#C0C0C0 bordercolorlight=#C0C0C0>");
 printf("<img src=email05.gif width=24 height=24><font color=#000088><font size=+1><font face=arial,helvetica> Notification</font></font>\n");
 printf("</td><td BGCOLOR=#A8BAC3>");
 printf("<img src=note05.gif width=24 height=24><font color=#000088><font size=+1><font face=arial,helvetica> Commentary</font></font>\n");
 printf("</td></tr>");

 printf("<tr><td><center>\n");
 printf("<form name=notificacao method=GET onSubmit=\"return Validate();\" action=%sgravanotificacao.cgi target=area2>\n",LOCALCGI);
 printf("<font face=arial,helvetica>Name:  <input type=text size=20 name=nome>");
 printf("<br><font face=arial,helvetica>E-mail:  <input type=text size=20 name=email>\n");
 printf("<input type=hidden name=caminho_repositorio value=%s>",CaminhoRepositorio); //Envia o caminho do repositorio para colcoar o email do usuario no notify
 printf("<input type=hidden name=pagina value=%s>",NomePagina); //Envia o nome da pagina para gerar o arquivo de notificacao com o nome da pagina

 printf("<br><font face=arial,helvetica><input type=submit name=enviar value=Send> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
 printf("<font face=arial,helvetica><input type=reset name=limpar value=Reset>\n");
 printf("</form>\n");
 printf("<p></td>\n");

 //formulario para enviar comentarios
 printf("<td>\n");
 printf("<form method=POST name=comentarios onSubmit=\"return ValidaComentario();\" action=%sgravacomentario.cgi target=area2>\n",LOCALCGI);
 printf("<font color=#000000>\n");
 printf("</font><p><center><textarea name=comentario rows=8 cols=40>\n");
 printf("</textarea><br>\n");
 printf("<input type=hidden name=pagina value=%s>",NomePagina); //Envia o nome da pagina para criar o arquivo de comentarios com o nome da pagina
 printf("<input type=hidden name=caminho_repositorio value=%s>",CaminhoRepositorio);
 printf("<input type=hidden name=diretorio value=%s>",DiretorioPagina);
 printf("<font face=arial,helvetica><input type=submit name=enviar value=Send>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
 printf("<font face=arial,helvetica><input type=reset name=limpar value=Reset></center>\n");
 printf("</form></td></tr></table><br>\n");

 printf("</body>");
 printf("</html>");
}

void AlteraDiretorio(char *Caminho)
{
 if (chdir(Caminho))
 {
  perror("chdir()");
  exit(1);
 }
}

char *rsalt()  /* rsalt() - generate a random 2-char salt */
{
 static char str[3];  /* salt alphabet (c.f. crypt(3)): 0-9 a-z A-Z ./ */
 char  *saltalpha="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ./";
 long  lword1;
 int   alphalen;
 char  *ptr1;

 alphalen=strlen(saltalpha);
 lword1=random(); 
 ptr1=(char *)&lword1;
 str[0] = saltalpha[(unsigned char) ptr1[0]%alphalen];
 str[1] = saltalpha[(unsigned char) ptr1[1]%alphalen]; str[2]='\0';
 return(str);
}

char *CriptografaSenha(char SenhaUsuario[20])
{
 char salt[9],pw[30];
 char *crypt(); 

 strcpy(pw,SenhaUsuario);
 strcpy(salt,rsalt());
 salt[2] = '\0';
 return crypt(pw,salt);
}
