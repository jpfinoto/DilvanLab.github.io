/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */                                                                                 
/******************************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void AlteraDiretorio(char *Caminho);

int main(void)
{
 char *String,Revisao1[20],Revisao2[20],ArquivoCheckout[30],ModuloCheckout[30],DiretorioCheckout[100],CaminhoUsuario[100],Comando[200],*Resultado;
 char buf[10000],CaminhoAux[100],Login[30],Caminho[100],Linha[255];
 int Cont=0,i=0;
 FILE *Arquivo,*ArquivoCaminhoRepositorio;

 String = getenv("QUERY_STRING");

 while (String[Cont] != '=')
  Cont++;
 Cont++;

 while (String[Cont] != '&')
 {
  Login[i] = String[Cont];
  Cont++; i++;
 }
 Login[i] = '\0';
 i=0;

 while (String[Cont] != '=')
  Cont++;
 Cont++;

 while (String[Cont] != '&')
 {
  Revisao1[i] = String[Cont];
  Cont++; i++;
 }
 Revisao1[i] = '\0';
 i=0;

 while (String[Cont] != '=')
  Cont++;
 Cont++;

 while (String[Cont] != '&')
 {
  Revisao2[i] = String[Cont];
  Cont++; i++;
 }
 Revisao2[i] = '\0';
 i=0;

 while (String[Cont] != '=')
  Cont++;
 Cont++;

 while (String[Cont] != '&')
 {
  if ((String[Cont] == '%') && (String[Cont+1] == '2') && (String[Cont+2] == 'F'))
  {
   CaminhoUsuario[i] = '/';
   Cont+=2;
  }
  else
   CaminhoUsuario[i] = String[Cont];
  Cont++; i++;
 }
 CaminhoUsuario[i] = '\0';
 i=0;

 while (String[Cont] != '=')
  Cont++;
 Cont++;

 while (String[Cont] != '&')
 {
  if ((String[Cont] == '%') && (String[Cont+1] == '2') && (String[Cont+2] == 'F'))
  {
   ModuloCheckout[i] = '/';
   Cont+=2;
  }
  else
   ModuloCheckout[i] = String[Cont];
  Cont++; i++;
 }
 ModuloCheckout[i] = '\0';
 i=0;

 while (String[Cont] != '=')
  Cont++;
 Cont++;

 while (String[Cont] != '&')
 {
  if ((String[Cont] == '%') && (String[Cont+1] == '2') && (String[Cont+2] == 'F'))
  {
   DiretorioCheckout[i] = '/';
   Cont+=2;
  }
  else
   DiretorioCheckout[i] = String[Cont];
  Cont++; i++;
 }
 DiretorioCheckout[i] = '\0';
 i=0;

 while (String[Cont] != '=')
  Cont++;
 Cont++;

 while (String[Cont] != '&')
 {
  ArquivoCheckout[i] = String[Cont];
  Cont++; i++;
 }
 ArquivoCheckout[i] = '\0';
 i=0;

 AlteraDiretorio(CaminhoUsuario);

 if ((ArquivoCaminhoRepositorio=fopen("caminho","r")) == NULL)  //a primeira linha do arquivo contem o caminho do repositorio
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<head>");
  printf("<script>");
  printf("alert(\"Error to open file...\");\n");
  printf("</script>\n");
  printf("</head>");
  printf("</html>");
  exit(1);
 }
 rewind(ArquivoCaminhoRepositorio);
 fgets(Linha,100,ArquivoCaminhoRepositorio); //a primeira linha do arquivo vale o caminho do repositorio informado pelo usuario na tela de login
 Linha[strlen(Linha)-2] = '\0'; //elimina a ultima barra do caminho do repositorio
 fclose(ArquivoCaminhoRepositorio);

 strcpy(Comando,"cvs -d :pserver:");
 strcat(Comando,Login);
 strcat(Comando,"@");
 strcat(Comando,HOST);
 strcat(Comando,Linha);
 strcat(Comando," co ");
 strcat(Comando,DiretorioCheckout);
 strcat(Comando,ArquivoCheckout);

/*  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<body>");
  printf("%s %s",Comando,CaminhoUsuario);
  exit(1);*/

 //faz checkout do arquivo antes de efetuar o merging
 Resultado = malloc(10000); 
 if ((Arquivo = popen(Comando, "r")) != NULL) 
 { 
  while (fgets(buf, BUFSIZ, Arquivo) != NULL) 
   strcat(Resultado, buf);
  pclose(Arquivo);
 } 
 free(Resultado);

 strcpy(Caminho,CaminhoUsuario);
 strcat(Caminho,DiretorioCheckout);

 AlteraDiretorio(Caminho);
 strcpy(Comando,"cvs update -j ");
 strcat(Comando,Revisao1);
 strcat(Comando," -j ");
 strcat(Comando,Revisao2);
 strcat(Comando," ");
 strcat(Comando,ArquivoCheckout);
  
/* strcat(CaminhoAux,CaminhoUsuario);
 strcat(CaminhoAux,DiretorioCheckout);
 AlteraDiretorio(CaminhoAux); //posiciona dentro do diretorio que foi feito o checkout*/

 //efetua o mergin entre as duas revisoes
 Resultado = malloc(10000); 
 if ((Arquivo = popen(Comando, "r")) != NULL) 
 { 
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
  {
   strcat(Resultado, buf);
   strcat(Resultado,"<br>");
  }
  pclose(Arquivo);
 } 
 free(Resultado);

 strcpy(Comando,"cvs commit -m \"\" ");
 strcat(Comando,ArquivoCheckout);

 //faz o commit para gerar uma nova revisao com o merging das duas versoes
 Resultado = malloc(10000); 
 if ((Arquivo = popen(Comando, "r")) != NULL) 
 { 
  while (fgets(buf, BUFSIZ, Arquivo) != NULL) 
  {
   strcat(Resultado, buf);
   strcat(Resultado,"<br>");
  }
  pclose(Arquivo);
 }

 AlteraDiretorio(CaminhoUsuario);
 strcpy(Comando,"rm -rf ");
 strcat(Comando,ModuloCheckout);
 system(Comando); //remove o modulo que foi feito o checkout

 if ((strstr(Resultado,"done")) || (strstr(Resultado,"new revision:")))
 {
  free(Resultado);
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<base href=%s>",IMAGES);
  printf("<body background=bolor.jpg>");
  printf("<script language=javascript>");
  printf("alert(\"The changes were removed and a new revision was generated! Reload this page!\");",Arquivo);
  printf("</script>");
  printf("</body></html>");
  exit(1);
 }
 else
 {
  free(Resultado);
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<base href=%s>",IMAGES);
  printf("<body background=bolor.jpg>");
  printf("<script language=javascript>");
  printf("alert(\"There is not differences between these revisions!\");");
  printf("</script></body></html>");
  exit(1);
 }
 return;
}

void AlteraDiretorio(char *Caminho) 
{ 
 if (chdir(Caminho)) 
 { 
  perror("chdir()"); 
  exit(1); 
 } 
} 
