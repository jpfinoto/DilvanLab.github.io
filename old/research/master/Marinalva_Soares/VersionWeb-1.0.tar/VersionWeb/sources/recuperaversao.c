/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */                                                                                 
/******************************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void AlteraDiretorio(char *Caminho);
void ExecutaComando(char *NomeComando);

int main (void)
{
 ExecutaComando("QUERY_STRING");
 return;
}

void AlteraDiretorio(char *Caminho) 
{ 
 if (chdir(Caminho)) 
 { 
  perror("chdir()"); 
  exit(1); 
 } 
} 


void ExecutaComando(char *NomeComando)
{
 char Comando[100],*String,NomePagina[30],Versao[30],CaminhoRepositorio[100],DiretorioPagina[100],DiretorioAux[100],CaminhoAux[100];
 int Cont1=0,i=0;
 FILE *ArquivoVersao,*Arquivo;
 char Linha[255],*Resultado;
 char buf[1000];

 strcpy(Comando,"cvs co -r");

 String = getenv(NomeComando); // Obtem o valor da variavel QUERY_STRING

 while(String[Cont1] != '=') //elimina o nome do campo caminho_repositorio
  Cont1++; 
 Cont1++; 
 
 while (String[Cont1] != '&') //o que vem antes do & e o caminho do repositorio
 { 
  if ((String[Cont1] == '%') && (String[Cont1+1] == '2') && (String[Cont1+2] == 'F'))
  {
   CaminhoRepositorio[i] = '/';
   Cont1+=2;
  }
  else
   CaminhoRepositorio[i] = String[Cont1]; 
  Cont1++; i++; 
 } 
 CaminhoRepositorio[i] ='\0'; 
 i=0; 

 while(String[Cont1] != '=') //elimina o nome do campo que contem o nome da pagina 
  Cont1++; 
 Cont1++; 
 
 while (String[Cont1] != '&') //o que vem antes do & e o nome da pagina 
 { 
  if ((String[Cont1] == '%') && (String[Cont1+1] == '2') && (String[Cont1+2] == 'F'))
  {
   DiretorioPagina[i] = '/';
   Cont1+=2;
  }
  else
   DiretorioPagina[i] = String[Cont1]; 
  Cont1++; i++; 
 } 
 DiretorioPagina[i] ='\0'; 
 i=0; 

 while(String[Cont1] != '=') //elimina o nome do campo que contem o nome da pagina
  Cont1++;
 Cont1++;

 while (String[Cont1] != '&') //o que vem antes do & e o nome da pagina
 {
  NomePagina[i] = String[Cont1];
  Cont1++; i++;
 }
 NomePagina[i] ='\0';
 i=0;

 while (String[Cont1] != '=') //elimina o nome do campo que contem o numero da versao
  Cont1++;
 Cont1++;

 while (String[Cont1] != '&') //o que vem depois do & e o botao submit
 {
  Versao[i] = String[Cont1];
  Cont1++; i++;
 }
 Versao[i] = '\0';

 setenv("CVSROOT",CaminhoRepositorio,1);

 if (DiretorioPagina[strlen(DiretorioPagina)-1] != '/')
  strcat(DiretorioPagina,"/");
 strcat(Comando,Versao);
 strcat(Comando," ");
 strcat(Comando,DiretorioPagina);
 strcat(Comando,NomePagina);
 strcat(Comando,"\0");

 AlteraDiretorio("/tmp/");

 Resultado = malloc(1000);

 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
  {
   strcat(Resultado, buf);
   strcat(Resultado, "<br>");          
  }
  pclose(Arquivo);
 }
 
// Gera uma pagina HTML 

 strcpy(CaminhoAux,"/tmp/");
 strcat(CaminhoAux,DiretorioPagina);
 AlteraDiretorio(CaminhoAux);

 printf("Content-type: text/html\n\n");  
 printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");  
 printf("<html>\n");
 printf("<body>\n");
 
 if ((ArquivoVersao = fopen(NomePagina,"r")) == NULL) 
 { 
  printf("*** O arquivo %s nao pode ser aberto ***<br>",NomePagina); 
  exit(1); 
 } 
 rewind(ArquivoVersao);
 while (!feof(ArquivoVersao))
 {
  fgets(Linha,255,ArquivoVersao);
  printf("%s<br>",Linha);
 } 
 fclose(ArquivoVersao);
 printf("</body>\n");
 printf("</html>\n");
 AlteraDiretorio("/tmp/");

 Cont1=0;
 while (DiretorioPagina[Cont1] != '/') //para eliminar o modulo em  que foi feito o checkout
 {
  DiretorioAux[Cont1] = DiretorioPagina[Cont1];
  Cont1++;
 }
 DiretorioAux[Cont1] = '\0';
 strcpy(Comando,"rm -rf ");
 strcat(Comando,DiretorioAux);
 system(Comando); 
 free(Resultado);
}
