/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */                                                                                 
/******************************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
 char *String,CaminhoRepositorio[50],Repositorio[50],Pagina[30],Diretorio[50],DiretorioPagina[50];
 int Cont=0,i=0,Flag=0;
 
 //essa variavel vem da pagina do usuario (informacao necessaria apenas para grupos)
 String = getenv("QUERY_STRING");

 if (strlen(String) > 0)
 {
  while (String[Cont] != '=') //elimina o campo repositorio 
   Cont++;
  Cont++;
  while(String[Cont] != '&')
  {
   if ((String[Cont] == '%') && (String[Cont+1] == '2') && (String[Cont+2] == 'F'))
   {
    CaminhoRepositorio[i] = '/';
    Cont+=2;
   }
   else
    CaminhoRepositorio[i] = String[Cont];
   Cont++; i++;
  }
  CaminhoRepositorio[i] = '\0';
  i=0;

  strcpy(Repositorio,CaminhoRepositorio);

  while (String[Cont] != '=') //elimina o campo diretorio onde reside a pagina
   Cont++;
  Cont++;
  while(String[Cont] != '&')
  {
   if ((String[Cont] == '%') && (String[Cont+1] == '2') && (String[Cont+2] == 'F'))
   {
    DiretorioPagina[i] = '/';
    Cont+=2;
   }
   else
    DiretorioPagina[i] = String[Cont];
   Cont++; i++;
  }
  DiretorioPagina[i] = '\0';
  i=0;
  strcpy(Diretorio,DiretorioPagina);

  while (String[Cont] != '=') //elimina o campo nome da pagina
   Cont++;
  Cont++;
  while(String[Cont] != '&')
  {
   Pagina[i] = String[Cont];
   Cont++; i++;
  }
  Pagina[i] = '\0';
  i=0;
 }
 else
  Flag=1;

 printf("Content-type: text/html\n\n");
 printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
 printf("<html>");
 printf("<head>");
 printf("<script>");

//funcao para validar o tamanho da informacao
 printf("function ValidLength(item,len)\n{\n");
 printf(" return (item.length >= len);\n}\n\n");

//funcao para validar o campo Nome
 printf("function ValidCampo(item)\n{\n");
 printf(" if (!ValidLength(item,1))\n  return false;\n");
 printf(" return true;\n}\n\n");

 //funcao que verifica qual usuario foi selecionado para exibir o formulario de gerenciamento de arquivos
 printf("function ValidaLogin()\n{\n");

 printf("if ((document.regform.tipo_usuario[0].checked == true) || (document.regform.tipo_usuario[2].checked == true)){");
 printf(" if ((!ValidCampo(document.regform.login.value)) || (!ValidCampo(document.regform.senha.value)) || (!ValidCampo(document.regform.caminho_repositorio.value)))\n {\n");
 printf("  alert(\"You should to fill all the fields!\");\n");
 printf("  return false;\n }}\n");

 printf("if (document.regform.tipo_usuario[1].checked == true){");
 printf(" if ((!ValidCampo(document.regform.login.value)) || (!ValidCampo(document.regform.senha.value)))\n {\n");
 printf("  alert(\"Missing value to login or password!\");\n");
 printf("  return false;\n }}\n");

 printf("if ((document.regform.tipo_usuario[0].checked == false) && (document.regform.tipo_usuario[1].checked == false) && (document.regform.tipo_usuario[2].checked == false))");
 printf("{alert(\"You should to select the type of user.\");return false;}");

 printf("if (document.regform.tipo_usuario[0].checked == true)\n");
// printf("window.open(\"%sjanelaarquivos.cgi?login=\"+document.regform.login.value+\"&senha=\"+document.regform.senha.value+\"&caminho_repositorio=\"+document.regform.caminho_repositorio.value+\"&\",\"GerenciaArquivos\",\"width=800,height=600,scrollbars=yes,resizable=yes\");\n",LOCALCGI);
 printf("window.open(\"%sjanelaarquivos.cgi?login=\"+document.regform.login.value+\"&senha=\"+document.regform.senha.value+\"&caminho_repositorio=\"+document.regform.caminho_repositorio.value+\"&\",\"GerenciaArquivos\",\"toolbar=no\");\n",LOCALCGI);

 printf("if (document.regform.tipo_usuario[1].checked == true)\n");
 printf("window.open(\"%sjanelagrupos.cgi?caminho_repositorio=\"+document.regform.repositorio_grupo.value+\"&diretorio=\"+document.regform.diretorio.value+\"&pagina=\"+document.regform.pagina.value+\"&login=\"+document.regform.login.value+\"&senha=\"+document.regform.senha.value+\"&\",\"Grupos\",\"width=800,height=600,scrollbars=yes,resizeable=yes\");\n",LOCALCGI);

 printf("if (document.regform.tipo_usuario[2].checked == true)\n");
// printf("window.open(\"%sgerencia_usuarios.cgi?login=\"+document.regform.login.value+\"&senha=\"+document.regform.senha.value+\"&caminho_repositorio=\"+document.regform.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"width=800,height=600,scrollbars=yes,resizeable=yes\");\n}",LOCALCGI);
 printf("window.open(\"%sgerencia_usuarios.cgi?login=\"+document.regform.login.value+\"&senha=\"+document.regform.senha.value+\"&caminho_repositorio=\"+document.regform.caminho_repositorio.value+\"&\",\"GerenciaUsuarios\",\"toolbar=no\");\n}",LOCALCGI);

 printf("</script>\n");
 printf("</head>\n");

 printf("<base href=%s>",IMAGES);

 printf("<body background=bolor.jpg>\n");
 printf("<center><img src=versionweb.jpg alt=Gerenciamento&nbsp;de&nbsp;Versoes&nbsp;de&nbsp;Paginas&nbsp;Web></center>");
 printf("<br><br><br>\n");
 printf("<center><table border WIDTH=50% BGCOLOR=#E1F0FF bordercolor=#C0C0C0 bordercolordark=#C0C0C0 bordercolorlight=#C0C0C0>\n");
 printf("<tr>\n");
 printf("<td BGCOLOR=#A8BAC3 bordercolor=#C0C0C0 bordercolordark=#C0C0C0 bordercolorlight=#C0C0C0>\n");
 printf("<img src=\"KEY02.GIF\" width=24 height=24>");
 printf("<font color=#000088><font size=+2><font face=arial,helvetica> Users Authentication</font></font></font>\n");
 printf("</td></tr>\n");
 printf("<tr><td>\n");
 printf("<table width=100%>\n");
 printf("<form name=regform method=GET>\n");
 printf("<tr><td bgcolor=#E1F0FF>\n");
 printf("<center><input type=radio name=tipo_usuario value=autor><font face=arial,helvetica> <b>Authors</b></font></center>\n");
 printf("</td>\n");
 printf("<td bgcolor=#E1F0FF>\n");
 printf("<center><input type=radio name=tipo_usuario value=grupo><font face=arial,helvetica> <b>Groups</b></font></center>\n");
 printf("</td>\n");
 printf("<td bgcolor=#E1F0FF>\n");
 printf("<center><input type=radio name=tipo_usuario value=administrador><font face=arial,helvetica> <b>Administrators</b></center></font>\n");
 printf("</td>\n");
 printf("</tr></table></td></tr>\n");
 printf("<tr><td>\n");
 printf("<br><center><font face=arial,helvetica><b>Repository Path</b><br><input type=text name=caminho_repositorio size=40>\n");
 printf("<br><br><font face=arial,helvetica><b>Login</b><br><input type=text name=login size=30 maxlenght=20>\n");
 printf("<br><br><b>Password</b><br><input type=password name=senha size=30 maxlenght=20>\n");
 printf("<br><input type=hidden name=repositorio_grupo value=%s>\n",CaminhoRepositorio);
 printf("<input type=hidden name=diretorio value=%s>\n",Diretorio);
 printf("<input type=hidden name=pagina value=%s>\n",Pagina);
 printf("<br><font face=arial,helvetica><input type=button name=ok value=&nbsp;&nbsp;Ok&nbsp;&nbsp; onClick=ValidaLogin();>&nbsp;&nbsp;\n");
 printf("<input type=reset name=limpar value=&nbsp;&nbsp;Reset&nbsp;&nbsp;></center></font><br></td></tr>\n");
 printf("</table></center><p>\n");
 printf("</body>\n");
 printf("</html>");
 return;
}

