#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (void)
{
 char IMAGES[255],LOCALCGI[255],HOST[255],LOCALCHECKOUT[255],Comando[255],buf[1000],*Resultado;
 FILE *Arquivo;
 int Flag=0;

 //obtem as informacoes do usuario
 printf("The absolute path for images: ");
 fgets(IMAGES,255,stdin);
 printf("\nThe absolute path for cgi: ");
 fgets(LOCALCGI,255,stdin);
 printf("\nThe hostname for repository cvs: ");
 fgets(HOST,255,stdin);
 printf("\nThe absolute path for download files in VersionWeb: ");
 fgets(LOCALCHECKOUT,255,stdin);
 IMAGES[strlen(IMAGES)-1] = '\0';
 LOCALCGI[strlen(LOCALCGI)-1] = '\0';
 HOST[strlen(HOST)-1] = '\0';
 LOCALCHECKOUT[strlen(LOCALCHECKOUT)-1] = '\0';

 printf("Compiling sources. Wait...\n");

 //compilacao dos fontes
 strcpy(Comando,"gcc -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," -D HOST=");
 strcat(Comando,HOST);
 strcat(Comando," -D LOCALCHECKOUT=");
 strcat(Comando,LOCALCHECKOUT);
 strcat(Comando," checkin.c -o checkin.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);

 //se der alguma mensagem de erro na compilacao, nao escreve "done"  no final
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," -D HOST=");
 strcat(Comando,HOST);
 strcat(Comando," -D LOCALCHECKOUT=");
 strcat(Comando,LOCALCHECKOUT);
 strcat(Comando," checkin2.c -o checkin2.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D LOCALCGI=");
 strcat(Comando,LOCALCGI);
 strcat(Comando," -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," versionweb.c -o versionweb.cgi");

 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D LOCALCGI=");
 strcat(Comando,LOCALCGI);
 strcat(Comando," -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," -D HOST=");
 strcat(Comando,HOST);
 strcat(Comando," -D LOCALCHECKOUT=");
 strcat(Comando,LOCALCHECKOUT);
 strcat(Comando," -lcrypt gerencia_arquivos.c -o gerencia_arquivos.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D LOCALCGI=");
 strcat(Comando,LOCALCGI);
 strcat(Comando," -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," -D HOST=");
 strcat(Comando,HOST);
 strcat(Comando," -lcrypt gerencia_usuarios.c -o gerencia_usuarios.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D LOCALCGI=");
 strcat(Comando,LOCALCGI);
 strcat(Comando," -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," -lcrypt grupos.c -o grupos.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D LOCALCGI=");
 strcat(Comando,LOCALCGI);
 strcat(Comando," -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," diffs.c -o diffs.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," gravacomentario.c -o gravacomentario.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," gravanotificacao.c -o gravanotificacao.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," -D HOST=");
 strcat(Comando,HOST);
 strcat(Comando," merging.c -o merging.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," nada.c -o nada.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," -D HOST=");
 strcat(Comando,HOST);
 strcat(Comando," upload.c -o upload.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc -D IMAGES=");
 strcat(Comando,IMAGES);
 strcat(Comando," commit.c -o commit.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc recuperaversao.c -o recuperaversao.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc exibediferenca.c -o exibediferenca.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 strcpy(Comando,"gcc janelaarquivos.c -o janelaarquivos.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);

 strcpy(Comando,"gcc janelagrupos.c -o janelagrupos.cgi");
 Resultado = malloc(1000);
 if ((Arquivo = popen(Comando, "r")) != NULL)
 {
  while (fgets(buf, BUFSIZ, Arquivo) != NULL)
   strcat(Resultado, buf);
  pclose(Arquivo);
 }
 free(Resultado);
 if (strcmp(Resultado,""))
  Flag = 1;

 if (!Flag) //se nao deu erro durante a compilacao
  printf("done\n");
 return;
}
