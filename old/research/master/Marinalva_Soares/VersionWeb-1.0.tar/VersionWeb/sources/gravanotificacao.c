/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */                                                                                 
/******************************************************************************************************************/

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

void AlteraDiretorio(char *Caminho);

int main (void)
{
 FILE *Notificacao;
 char *String,Nome[40],Mail[40],NomePagina[30],CaminhoRepositorio[100],LinhaMail[100],Comando[100];
 int Cont1=0,Cont2=0,Flag=0,i=0,Tamanho;

 String = getenv("QUERY_STRING");

 while (String[Cont1] != '=') //elimina o nome do campo do nome do usuario
  Cont1++;
 Cont1++;

 while (!Flag)
 {
  while (String[Cont1] != '&')
  {
   if (String[Cont1] == '+') 
    Nome[Cont2] = ' ';
   else 
    Nome[Cont2] = String[Cont1];
   Cont1++; Cont2++;
  }
  Nome[Cont2] = '\0';
  Cont2 = 0;

  while (String[Cont1] != '=') //elimina o nome do campo de Email
   Cont1++;
  Cont1++;
 
  while (String[Cont1] != '&')
  {
   if (String[Cont1] == '%')
   {
    Mail[Cont2] = '@';
    Cont1+=2;
   }
   else
    Mail[Cont2] = String[Cont1];
   Cont1++; Cont2++;
  }
  Mail[Cont2] = '\0';
  Flag = 1;
 }
 while (String[Cont1] != '=') //elimina o nome do campo do caminho do repositorio
  Cont1++;
 Cont1++;

 Cont2=0;
 while (String[Cont1] != '&')
 {
  if ((String[Cont1] == '%') && (String[Cont1+1] == '2') && (String[Cont1+2] == 'F'))
  {
   CaminhoRepositorio[Cont2] = '/';
   Cont1+=2;
  }
  else
   CaminhoRepositorio[Cont2] = String[Cont1];
  Cont1++; Cont2++;
 }
 CaminhoRepositorio[Cont2] = '\0';

 while (String[Cont1] != '=') //elimina o nome do campo do caminho do repositorio
  Cont1++;
 Cont1++;

 Cont2=0;
 while (String[Cont1] != '&') //
 {
  NomePagina[Cont2] = String[Cont1];
  Cont1++; Cont2++;
 }
 NomePagina[Cont2] = '\0';

 //posiciona dentro do repositorio para adicionar o usuario para notificacao no arquivo notify
 strcat(CaminhoRepositorio,"CVSROOT/");
 AlteraDiretorio(CaminhoRepositorio);

 strcpy(Comando,"chmod 777 notify");
 system(Comando);

 strcpy(LinhaMail,"ALL mail ");
 strcat(LinhaMail,Mail);
 strcat(LinhaMail, " -s \"VersionWeb notification\"\n");

 if ((Notificacao=fopen("notify","a+")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<head>");
  printf("<script>");
  printf("alert(\"Error file create/open\")\n");
  printf("</script>\n");
  printf("</head>");
  printf("</html>");
  exit(1);
 }
 fputs(LinhaMail,Notificacao); //adiciona o usuario no arquivo notify para notificacao
 fclose(Notificacao);

 printf("Content-type: text/html\n\n"); 
 printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n"); 
 printf("<html>");
 printf("<base href=%s>",IMAGES);
 printf("<body background=bolor.jpg>\n");
 printf("<script>\n");
 printf("alert(\"Data received! Thanks!\")\n");
 printf("</script>\n");
 printf("</body></html>");
 return;
}

void AlteraDiretorio(char *Caminho)
{
 if (chdir(Caminho))
 {
  perror("chdir()");
  exit(1);
 }
}
