/******************************************************************************************************************/
/* Web Pages Versions Management System - VersionWeb 1.0                                                          */
/*                                                                                                                */ 
/* Copyright (C) 2000 Marinalva Dias Soares. All rights reserved.                                                 */   
/*                                                                                                                */   
/* VersionWeb is free software; you can redistribute it and/or modify it under the terms of the GNU General       */
/* Public License as published by the Free Software Foundation; either version 2 of the License, or any later     */
/* version.                                                                                                       */
/*                                                                                                                */
/* VersionWeb is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the       */
/* implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License    */
/* for more details.                                                                                              */
/*                                                                                                                */
/* You should have received a copy of the GNU General Public License along with this program; if not, write to    */
/* the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.                   */
/*                                                                                                                */
/* Contact:                                                                                                       */
/*       Eletronic mail: mdsoares@icmc.sc.usp.br or renata@icmc.sc.usp.br or dilvan@computer.org                  */
/*       Paper mail: Av. Dr. Carlos Botelho, 1465 Cx. Postal 668,S�o Carlos,S�o Paulo - Brasil CEP 13560-970      */                                                                                  
/******************************************************************************************************************/

// Este cgi grava os comentarios enviados pelos usuarios

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

void AlteraDiretorio(char *Caminho);
void GravaComentario(char *TextoComentario);

int main (void) 
{ 
 GravaComentario("CONTENT_LENGTH"); //tamanho da informacao recebida via metodo POST
}
   
void GravaComentario(char *TextoComentario)
{
 struct GravaComen
 {
  char Texto[255];
 };

 struct GravaComen Comen[10];
 FILE *Comentario,*Arquivo;
 char String[10000],NomePagina[50],Linha[255],CaminhoRepositorio[100],Diretorio[100];
 int Cont1=0,Cont2=0,i=0,Flag=0,ContAux,Tamanho;

 const char *TamanhoInformacao = getenv("CONTENT_LENGTH");
 Tamanho=atoi(TamanhoInformacao);

 fread(String,Tamanho,1,stdin);

 while (String[Cont1] != '=') //elimina o nome do campo do formulario
  Cont1++;
 Cont1++;

 while (String[Cont1] != '&') //Final de informacao de entrada pelo usuario
 {
  if (String[Cont1] == '%') //Quando encontra caracteres em hexadecimal
  {
   if (String[Cont1+1] == '0') 
   {
    Comen[i].Texto[Cont2] = '\0';
    i++;Cont1+=5; Cont2=-1; // qando e <enter> vem "%0A%0D"
   }
   else
   {
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == 'F'))
    {
     Comen[i].Texto[Cont2] = '/';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == 'C'))
    {
     Comen[i].Texto[Cont2] = ',';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'C'))
    {
     Comen[i].Texto[Cont2] = '<';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'E'))
    {
     Comen[i].Texto[Cont2] = '>';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'F'))
    {
     Comen[i].Texto[Cont2] = '?';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '2'))
    {
     Comen[i].Texto[Cont2] = '\"';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '7'))
    {
     Comen[i].Texto[Cont2] = '\'';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'A'))
    {
     Comen[i].Texto[Cont2] = ':';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'B'))
    {
     Comen[i].Texto[Cont2] = ';';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'B'))
    {
     Comen[i].Texto[Cont2] = '[';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'D'))
    {
     Comen[i].Texto[Cont2] = ']';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'B'))
    {
     Comen[i].Texto[Cont2] = '{';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'D'))
    {
     Comen[i].Texto[Cont2] = '}';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'E'))
    {
     Comen[i].Texto[Cont2] = '~';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '6') && (String[Cont1+2] == '0'))
    {
     Comen[i].Texto[Cont2] = '`';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '1'))
    {
     Comen[i].Texto[Cont2] = '!';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '4') && (String[Cont1+2] == '0'))
    {
     Comen[i].Texto[Cont2] = '@';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '3'))
    {
     Comen[i].Texto[Cont2] = '#';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '4'))
    {
     Comen[i].Texto[Cont2] = '$';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '5'))
    {
     Comen[i].Texto[Cont2] = '%';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'E'))
    {
     Comen[i].Texto[Cont2] = '^';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '6'))
    {
     Comen[i].Texto[Cont2] = '&';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '8'))
    {
     Comen[i].Texto[Cont2] = '(';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == '9'))
    {
     Comen[i].Texto[Cont2] = ')';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '2') && (String[Cont1+2] == 'B'))
    {
     Comen[i].Texto[Cont2] = '+';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '3') && (String[Cont1+2] == 'D')) 
    { 
     Comen[i].Texto[Cont2] = '='; 
     Cont1+=2;
     Flag = 0; 
    } 
    if ((String[Cont1+1] == '7') && (String[Cont1+2] == 'C'))
    {
     Comen[i].Texto[Cont2] = '|';
     Cont1+=2;
     Flag = 0;
    }
    if ((String[Cont1+1] == '5') && (String[Cont1+2] == 'C')) 
    { 
     Comen[i].Texto[Cont2] = '\\'; 
     Cont1+=2;
     Flag = 0; 
    } 
   }
  }
  else
  {
   if (String[Cont1] == '+') //quando encontra o +, foi digitado espaco em branco
   {
    Comen[i].Texto[Cont2] = ' ';
    Flag = 0;
   }
   else
    if (String[Cont1] != '&')
    {
     Comen[i].Texto[Cont2] = String[Cont1];
     Flag = 0;
    }
    else
     Cont1--;
  }
   Cont2++;
   Cont1++; 
 }

 while (String[Cont1] != '=')
  Cont1++;
 Cont1++;

 Cont2=0;
 while (String[Cont1] != '.') //o nome do botao submit e o nome da pagina
 {
  NomePagina[Cont2] = String[Cont1];
  Cont1++; Cont2++;
 }
 strcat(NomePagina,".comentario.txt"); //devido ao tipo MIME a extensao do arquivo deve vir no final

 while (String[Cont1] != '=')
  Cont1++;
 Cont1++;

 Cont2=0;
 while (String[Cont1] != '&')
 {
  if ((String[Cont1] == '%') && (String[Cont1+1] == '2') && (String[Cont1+2] == 'F'))
  {
   CaminhoRepositorio[Cont2] = '/';
   Cont1+=2;
  }
  else
   CaminhoRepositorio[Cont2] = String[Cont1];
  Cont1++; Cont2++;
 }
 CaminhoRepositorio[Cont2] = '\0';

 while (String[Cont1] != '=')
  Cont1++;
 Cont1++;

 Cont2=0;
 while (String[Cont1] != '&')
 {
  if ((String[Cont1] == '%') && (String[Cont1+1] == '2') && (String[Cont1+2] == 'F'))
  {
   Diretorio[Cont2] = '/';
   Cont1+=2;
  }
  else
   Diretorio[Cont2] = String[Cont1];
  Cont1++; Cont2++;
 }
 Diretorio[Cont2] = '\0';

 strcat(CaminhoRepositorio,Diretorio);
 AlteraDiretorio(CaminhoRepositorio);

 //Cria o arquivo e anexa o conteudo no final
 if ((Comentario=fopen(NomePagina,"a+")) == NULL)
 {
  printf("Content-type: text/html\n\n");
  printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
  printf("<html>");
  printf("<head>");
  printf("<script language=javascript\n>");
  printf("<!-- Ocultar JavaScript\n");
  printf("alert(\"Error file open...\")\n");
  printf("//deixar de ocultar o codigo -->\n");
  printf("</script>\n");
  printf("</head>");
  printf("</html>");
  exit(1);
 }

 fputs("********** Inicio Comentario **********\n",Comentario);
 for (Cont1=0; Cont1<=i+1;Cont1++)
 {
  if ((Comen[Cont1].Texto[0] != '\0') && (Comen[Cont1].Texto[0] != '@'))
  {
   fputs(Comen[Cont1].Texto,Comentario);
   fputs("\n",Comentario);
  }
 }
 
 fputs("********** Fim Comentario **********\n\n",Comentario);

 printf("Content-type: text/html\n\n");
 printf("<!DOCTYPE HTML PUBLIC \"-//W3O//DTD W3 HTML 3.2//EN\">\n");
 printf("<html>");
 printf("<base href=%s>",IMAGES);
 printf("<body background=bolor.jpg>\n");
 printf("<script>");
 printf("alert(\"Message received! Thanks!\")");
 printf("</script>");
 printf("</body>");
 printf("</html>");
 fclose(Comentario);
 return;
}

void AlteraDiretorio(char *Caminho)
{
 if (chdir(Caminho))
 {
  perror("chdir()");
  exit(1);
 }
}
