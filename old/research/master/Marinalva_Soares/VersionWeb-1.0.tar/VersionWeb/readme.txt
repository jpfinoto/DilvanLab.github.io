*******************************************************************
*                                                                 *
* Copyright (c) 2000, Marinalva Dias Soares. All rights reserved. *
*                                                                 *  
*******************************************************************

=========
CONTENTS
=========

1. VersionWeb operation

2. CVS configuration

3. Sources compilation

========================================
1. VersionWeb operation
========================================

The VersionWeb needs the following for running:

	- Operating System Unix/Linux
	- CVS (Concurrent Versions System) - version 1.10 or higher
	- HTTP Server (Apache, for example)

======================
2. CVS configuration
======================

	- Create the CVS repository
	- Give the permissions rwxrwxrwx to the "history" file in $CVSROOT/CVSROOT
    	- Put the files "passwd" and "usuarios" in $CVSROOT/CVSROOT and give them the permissions rwxrwxrwx
	- Give the permissions rwxrwxrwx for the CVSROOT directory
        - Give the permissions rwxrwxrwx for the parent directory of CVSROOT
	- Put the follow line in the file "inetd.conf": 2401 stream tcp nowait root /usr/bin/cvs cvs --allow-root=path_to_repository pserver
	- login as nobody user and do login of the "versionweb" user in the CVS with pserver method (the login have to be make in $HOME of nobody user).
	  The password for versionweb is "versionweb"
	- Give the permissions rwxrwxrwx for the "/tmp" directory

========================
3. Sources compile
========================

	- Put the images in a WWW directory
	- Put all the source in a cgi-bin directory

-------------------------
The process of compilation
-------------------------

In directory where are the sources, type "configure<enter>" - the program configure will prompt you for the following information:

The absolute path for images: this is the absolute path (with hostname) where you will put the images -  for example: \"http://java2.intermidia.icmc.sc.usp.br/~mari/\"
The absolute path for cgi: this is the absolute path (with hostname) where you will put the CGI's - for example: \"http://java2.intermidia.icmc.sc.usp.br/cgi-bin/mari_cgi/\"
The hostname for repository cvs: hostname where the CVS repository is in followed of ':' - for example: \"java2.intermidia.icmc.sc.usp.br:\"
The absolute path for local checkout of files in VersionWeb: this is the absolute path where you will put the local checkout files in VersionWeb for download - for example: \"/home/mari/WWW/\"


Now, in a browser's URL:"hostname/local_to_cgi/versionweb.cgi"