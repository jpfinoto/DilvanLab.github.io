
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server. 
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

/* Tests the concurrency of the Pool. It prints Hello until the
end of its lifetime. */

package testagents;

import structures.DBImplementation;

public class TestAgent4 {
    public static void main(String[] args) throws Exception {
	     while(true) {
	        System.out.println("Hello");
	        Thread.currentThread().sleep(1000);
	     }
    }
}