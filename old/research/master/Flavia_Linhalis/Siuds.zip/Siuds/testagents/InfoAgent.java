
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server. 
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

package testagents;

import java.io.PrintWriter;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import structures.DBImplementation;
import structures.StoreThreadsControll;

/*
*	It is a simple HTTP server. It Acceps sockets
* connectons from browsers on port 82 and sends an informative page
* about the SIUDS situation.
*/

class Server extends Thread {
    private Socket socket;
    private PrintWriter out;

    public Server(Socket s) throws IOException {
	     socket = s;

	     out = new PrintWriter(new BufferedWriter(
		        new OutputStreamWriter(
			 socket.getOutputStream())),true);
	     start();
    }

    public void run() {

	     DBImplementation g = new DBImplementation();
	     String s = null;
       String[] groups = g.getGroups();
	     System.out.println(groups);

	     Vector t = getThreads();
	     Enumeration et = t.elements();
	     String s2 = null;
	     String s3 = null;

	     try {
          out.print("HTTP/1.0 200 OK \r\n");
          out.print("MIME-version: 1.0 \r\n");
          out.print("Content-Type: text/html");
          out.print("\r\n");
          out.print("\r\n");
		      out.println(">");
		      out.println("<html>");
		      out.println("<body>");
		      out.println("SIUDS");
		      out.println("<p>");
		      out.println("Groups in the Database:");
		      out.println("<p>");
		      for (int i = 0; i < groups.length; i++) {
//		while (enum.hasMoreElements()) {
//		    s = (String)enum.nextElement();
		    out.println(groups[i]);
		    out.println("<p>");
		}
		out.println("Running agents:");
		out.println("<p>");
//		ThreadsControll TC = new ThreadsControll();
		while (et.hasMoreElements()) {
			s = (String)et.nextElement();
		        s2 = g.getGroup(s);
			s3 = g.getAgentName(s);
			out.println(s3);
			out.println("    do grupo ");
			out.println(s2);
			out.println("<p>");
		}
		out.println("</body>");
		out.println("</html>");
		out.flush();
		out.close();
	} catch (Exception e) {
	} finally {
	    try {
		socket.close();
	    } catch (IOException e) { }
	}

    }
    Vector getThreads() {

	StoreThreadsControll STC = new StoreThreadsControll();
	Vector threads = new Vector();
	String s = null;

	try {
    	    File file = new File("c:\\siuds\\threads.out");
	    	ObjectInputStream in =
		    new ObjectInputStream(
		    	new FileInputStream("c:\\siuds\\threads.out"));
                STC = (StoreThreadsControll)in.readObject();
	    } catch (Exception e){
	    	e.printStackTrace();
	    }
	Hashtable ht = STC.getThreadsDataBase();
	Enumeration e = ht.keys();
	while (e.hasMoreElements()) {
	    s = (String)e.nextElement();
	    threads.addElement(s);
	}
	return threads;
    }
}

/*
* This method starts the server for connections at port 82 then
* creates a thread to handle the request.
*/
public class InfoAgent {

    public static final int SERVER_PORT = 82;

    public InfoAgent() throws IOException {
	     ServerSocket s = new ServerSocket(SERVER_PORT);
       System.out.println("Info Agent Started. Port number: " + SERVER_PORT);

	     try {
	        while(true) {
	           /* Blocks until a connection occurs */
	           Socket socket = s.accept();
	    	     try {
		           new Server(socket);
	    	     } catch (IOException e) {
		            socket.close();
	    	     }
	        }
	     } finally {
	        s.close();
	     }
    }

    public static void main(String[] args) throws IOException {
	     InfoAgent ia = new InfoAgent();
    }
}
