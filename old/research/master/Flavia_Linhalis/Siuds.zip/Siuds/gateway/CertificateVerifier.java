
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server. 
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

package gateway;

import structures.DBImplementation;
import pool.JarRunner;
import pool.TimeCounter;
import java.lang.reflect.Method;
import java.security.KeyStore;
import java.security.NoSuchProviderException;
import java.security.NoSuchAlgorithmException;
import java.security.KeyStoreException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;

/**
 * Extracts and checks the validity of the Jar's certificates.
 * A Jar can execute just if its certificates are valid.
 */
public class CertificateVerifier {

    private JarEntry je;
    String alias = null;
    private String poolPathURL = "file:c:/siuds/";
    private String poolPath = "c:\\siuds\\";
    String pathURL = null;

    /* The keystore with the imported certificate must be stored in a
    specific file named "c:\\siuds\siudsKeystore".*/
    private String keyStorePath = "c:\\siuds\\" + "siudsKeystore";
    /* The keystore is protected by the password "siuds2001"*/
    private String pass = "siuds2001";

   /**
    * Extracts the Jar certificates and compares them with the certificate
    * imported to a keystore.
    * If there is a certificate in the keystore equals to the Jar's
    * certificate it means that certificate is valid.
    * If one of the Jar certificates is valid the Jar is ready to run.
    * @see JarRunner
    * @param jar - the jar file name
    * @exception CertificateException If there is an invalid alias
                 associated to this Jar certificate or if there is
                 no certificates associated to this Jar file.
    * @exception InvalidAliasException If there is no group
                 corresponding to this alias stored in the database.
    * @return <code>true</code> if this Jar has a valid certificate,
              <code>false</code> otherwise.
    */
    public boolean getCert(String jar) {
	     boolean valCert = false;
	     String path = poolPath + jar;
	     pathURL = poolPathURL + jar;

	     try {
          System.out.println("Starting " + jar + " certificate verification...");
	        FileInputStream in2 = new FileInputStream(path);
	        JarInputStream jin = new JarInputStream(in2);
	        while ((je = jin.getNextJarEntry()) != null) {
		         String jarName = je.getName();
             if (jarName.endsWith(".class")) {
		            valCert = gc(je, jin);
		         }
		         jin.closeEntry();
	        }
	     } catch (IOException ioe) {
           ioe.printStackTrace();
	     }
	     return valCert;
    }

    private boolean gc(JarEntry je, JarInputStream jin) {

	     boolean bgc = false;
	     BufferedInputStream bis = new BufferedInputStream(jin);
	     int b;
	     try {
	        while ((b = bis.read()) != -1) {}
		      Certificate certs[] = je.getCertificates();
	      	if (certs != null) {
		         FileInputStream in = new FileInputStream(keyStorePath);
                BufferedInputStream ksbufin = new BufferedInputStream(in);
		         KeyStore ks = KeyStore.getInstance("JKS","SUN");
		         ks.load(ksbufin,pass.toCharArray());

		         alias = ks.getCertificateAlias(certs[0]);
		         if (alias.equals(null)) {
			          throw new CertificateException("Invalid alias associated to certificate");
		         } else {
			          DBImplementation dbi = new DBImplementation();
			          boolean bol = dbi.isGroup(alias);
			          if (bol == true) {  /* Calls Jar Runner */
			             bgc = true;
			          } else {
			             throw new InvalidAliasException("There is no group corresponding to this alias");
			          }
		         }
		      } else {
		         throw new CertificateException("There is no certificates associated to this Jar file");
 		      }
 	     } catch (Exception e) {
		      e.printStackTrace();
	     }
	     return bgc;
   }
}