
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server. 
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

package gateway;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;


/**
 * Tests if a Jar is valid, i.e if it was not modified while in transit.
 */
public class JarVerifier {

/**
 * Makes the JAR file verification using the jarsigner tool.
 * NOTE: The jarsigner tool have to be placed at c:\jdk1.2.1\bin.
 * If the JAR is successfuly verified, the certificate verification
 * begins, otherwise, an exception is thrown.
 * @see CertificateVerifier
 * @param jarName - the jar path
 * @exception InvalidJarException if the JAR is not correctly signed.
 * @return <code>true</code> if the Jar verification succeeds, <code>false</code> otherwise.
 */
    public boolean verification(String jarName) throws InvalidJarException {

	    boolean verJar = false;
      String command = "c:\\jdk1.2.1\\bin\\jarsigner -verify c:\\siuds\\" + jarName;

        /* Verify a DSA signature */

	    try {
	       System.out.println("Starting " + jarName + " verification...");
         Runtime r = Runtime.getRuntime();
	       Process p = r.exec(command);
	       InputStream in = p.getInputStream();
	       BufferedReader d = new BufferedReader(new InputStreamReader(in));
	       String st = d.readLine();
 	       p.destroy();
	       if (st.equals("jar verified.")) {
		        verJar = true;
		        System.out.println(jarName + " correctly signed.");
         } else {
		        throw new InvalidJarException("Jar not correctly signed");
         }

      } catch (IOException e) {
	       e.printStackTrace();
	    }
    	return verJar;
    }
}
