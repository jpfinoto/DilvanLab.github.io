
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server.
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

package gateway;

import java.net.Socket;
import java.net.ServerSocket;
import java.security.*;

import pool.Pool;


/**
*	It is the Main-Class of the Gateway agent.
* It Acceps sockets connectons from remote clients to permit file transfer.
* @see Server
* @see CertificateVerifier
* NOTE: it does not accept the JAR if there is another JAR with
* the same name in the pool of agents.
*/
public class ServerFTP {
    /**
     * Port number.
     * The Gateway acceps sockets connectons from remote clients through this port number.
     */
    public static final int SERVER_PORT = 3500;

    CertificateVerifier cv = new CertificateVerifier();

    public void run() throws Throwable {
	     ServerSocket s = new ServerSocket(SERVER_PORT);
	     System.out.println("Sever Started. Port number: " + SERVER_PORT);

       try {
	        while(true) {
	           /* Blocks until a connection occurs */
	           Socket socket = s.accept();
	    	     try {
		            Server serv = new Server(socket);
                serv.enviaCert(cv);
		            boolean b = serv.verifyAll();
		            System.out.println("Jar Verification: " + b);

		            if (b) { /* Sends Jar info to Pool */
			             Pool.receiveJarInfo(cv.alias, cv.pathURL);
                }
             } catch (Exception e) {
                 e.printStackTrace();
		         } finally {
                 socket.close();
             }
	        }
	     } finally {
	         s.close();
	     }
    }
/**
 * Starts the Gateway agent
 */
    public static void main(String[] args) throws Exception {
      try {
	       ServerFTP sFTP = new ServerFTP();
         sFTP.run();
      } catch (Throwable t) {}
    }
}
