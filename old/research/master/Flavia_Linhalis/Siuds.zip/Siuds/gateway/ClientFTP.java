
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server. 
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

package gateway;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;

/**
 * The agents can use this class to establish a connection to the Gateway.
 * However, agents could establish a connection directly to the
 * ServerFTP.
 * @see ServerFTP
 */

public class ClientFTP {

	private static final int BUFSIZ = 1024;

/** Establishes a connection to the Server FTP and sends a file.
 * Usage: java gateway/ClientFTP <ServerFTP Host> <port number>
 * Ex: java gateway/ClientFTP localhost 3500
 */
	public static void main(String[] args) throws IOException {
     InetAddress addr = InetAddress.getByName(args[0]);
		 Socket socket = new Socket(addr, ServerFTP.SERVER_PORT);

 		 try {
		     System.out.println("socket = " + socket);
		     BufferedReader in = new BufferedReader(new
			   InputStreamReader(socket.getInputStream()));

		     PrintWriter out = new PrintWriter(new BufferedWriter(new
			           OutputStreamWriter(socket.getOutputStream())), true);

		     System.out.println("Type file name:");
		     BufferedReader br = new BufferedReader(
					   new InputStreamReader(System.in));
		     String arqName = br.readLine();
		     arqName.trim();
		     out.println(arqName);

 		     String str = null;
		     while (str == null)
            str = in.readLine();
		     str.trim();

		     if (str == "File already exists")
			      System.out.println(str);
		     else {
			      OutputStream out2 = socket.getOutputStream();
			      BufferedInputStream in2 = new BufferedInputStream(new
			      FileInputStream(arqName));

			      byte buf[] = new byte[BUFSIZ];
			      int nread;
			      while ((nread = in2.read(buf)) > 0)
				       out2.write(buf, 0, nread);

			      in2.close();
			      out2.close();
			      System.out.println("Transfer Complete");
		     }
		 } finally {
		    socket.close();
		 }
	}
}
