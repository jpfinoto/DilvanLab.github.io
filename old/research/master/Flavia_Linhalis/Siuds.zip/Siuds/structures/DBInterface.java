
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server. 
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

package structures;

/**
 * Defines the methods that allow the agents to manipulate the roots,
 * the groups and establish associations between roots and groups
 * (to control which groups will read or write an specific root)
 * stored in a database.
 * The methods defined in this interface can be classified in three groups:
 * <UL>
 * <LI> Methods for manipulation of roots.
 * <LI> Methods for manipulation of groups' properties.
 * <LI> Methods for controlling the execution of agents' threads
 * </UL>
 */
public interface DBInterface {

    /**
     * Initializes the database with the firsts groups.
     */
    public void initialize();

    /**
     * Creates a new group and specifies the lifetime of the agents
     * that will belong to the group.
     * @param groupName   the group name
     * @param time   the lifetime of the agents that belongs to this group.
     */
    public void createGroup(String groupName, long time);

    /**
     * Deletes an existing group.
     * @param groupName  the name of the group to be deleted
     */
    public void deleteGroup(String groupName);

    /**
     * Gets the names of the roots that this group has permission to read.
     * @param groupName  the group name
     * @return  the names of the roots
     */
    public String[] getRootsToRead(String groupName);

    /**
     * Gets the names of the roots that this group has permission to write and delete.
     * @param groupName  the group name
     * @return  the names of the roots
     */
    public String[] getRootsToWrite(String groupName);

    /**
     * Gets the lifetime of the agents that belongs to this group.
     * @param groupName  the group name
     * @return  the lifetime of this group's agents
     */
    public long getTime(String groupName);

    /**
     * Tests if this group name already exists in the database.
     * @param groupName  the group name
     * @return <code>true</code> if the group already exists, <code>false</code> otherwise.
     */
    public boolean isGroup(String groupName);

    /**
     * Gets the names of all the groups stored in the database.
     * @return  the names of the stored groups.
     */
    public String[] getGroups();

    /**
     * Creates an empty root in the database.
     * @param rootName  the name of the root to be created
     */
    public void createRoot(String rootName);

    /**
     * Deletes an existing group of the database.
     * @param rootName  the name of the root to be deleted
     */
    public void deleteRoot(String rootName);

    /**
     * Gets a root content.
     * @param rootName   the root name
     * @return  the contents of this root stored in the database
     */
    public Object get(String rootName);

    /**
     * Updates a root content.
     * @param rootName  the name of the root to be updated.
     * @param root  the contents to be stored.
     */
    public void set(String rootName, Object root);

    /**
     * Gives permission for a group to read a specified root.
     * @param rootName  the root name
     * @param groupToRead  the group name
     */
    public void setGroupToRead(String rootName, String groupToRead);

    /**
     * Gives permission for a group to write and delete a specified root.
     * @param rootName  the root name
     * @param groupToRead  the group name
     */
    public void setGroupToWrite(String rootName, String groupToWrite);

    /**
     * Gets the names of all the roots stored in the database.
     * @return  the roots names
     */
    public String[] getRoots();

    /**
     * Tests if a root exists in the database.
     * @param rootName  the root name
     * @return <code>true</code> if the roor already exists, <code>false</code> otherwise.
     */
    public boolean isRoot(String rootName);

    /**
     * Gets the names of the groups with read permission to a specific root.
     * @param rootName  the root name
     * @return the names of the groups that can read this root
     */
    public String[] getGroupsToRead(String rootName);

    /**
     * Gets the names of the groups with write and delete permissions to a specific root.
     * @param rootName  the root name
     * @return the names of the groups that can write and delete this root
     */
    public String[] getGroupsToWrite(String rootName);

    /**
     * Tests if a group has permission to read a root.
     * @param rootName  the root name
     * @param groupName  the group name
     * @return <code>true</code> if the group has permission to read the root, <code>false</code> otherwise.
     */
    public boolean isReadable(String rootName, String groupName);

    /**
     * Tests if a group has permission to write and delete a root.
     * @param rootName  the root name
     * @param groupName  the group name
     * @return <code>true</code> if the group has permission to write and delete the root, <code>false</code> otherwise.
     */
    public boolean isWriteable(String rootName, String groupName);

    /**
     * Associates a thread with an agent and its group.
     * It is necessary when a new agent starts running.
     * If each agent is executed in a thread its possible to know
     * to which group the thread belongs to.
     * @param threadName  the thread name
     * @param groupName  the group name
     * @param agentName  the agent name
     */
    public void associate(String threadName, String groupName, String agentName);

    /**
     * Gets the name of the group associated to the specified thread.
     * @param threadName  the thread name
     * @return the group name
     */
    public String getGroup(String threadName);

    /**
     * Gets the name of the agent associated to the specified thread.
     * @param threadName  the thread name
     * @return the agent name
     */
    public String getAgentName(String threadName);

    /**
     * Removes the association between an agent and a thread.
     * It is necessary when an agent finishes its execution or when
     * its lifetime ends.
     * @param threadName  the name of the thread to be excluded
     */
    public void removeAssociation(String threadName);
}