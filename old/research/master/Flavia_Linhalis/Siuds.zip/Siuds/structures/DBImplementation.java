
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server.
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

package structures;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;


/**
 * Implements DBInterface using files.
 * The information in the files are structured in <code>Hashtables</code>.
 * @see DBInterface
 * @see ObjectInputStream
 * @see FileInput Stream
 * @see Hashtable
 */
public class DBImplementation implements DBInterface {

    /* file to store the groups in a Hashtable*/
    private String fileName = "c:\\siuds\\groups.out";

    /* file to store the roots in a Hashtable*/
    private String fileName2 = "c:\\siuds\\roots.out";

    /* file to store read permissions in a Hashtable*/
    private String toRead = "c:\\siuds\\toRead.out";

    /* file to store write and delete permissions in a Hashtable*/
    private String toWrite = "c:\\siuds\\toWrite.out";

    /* file to store the threads and its associated agentes and groups.
     * It stores the information in a Hashtable */
    private String path = "c:\\siuds\\threads.out";

   /**
    * Initializes the database with the firsts groups.
    * Starts the groups database by creating the superusers and commonusers
    * groups. The superusers group have all permissions and its aplications
    * can run forever. The commonusers group have limited permissions
    * and its applications have 1 hour to run.
    */

    public void initialize() {
    	try {
	       File file = new File(fileName);
	       ObjectOutputStream out1 = new ObjectOutputStream(
					  new FileOutputStream(fileName));
	       StoreGroup SG1 = new StoreGroup();
	       out1.writeObject(SG1);
	       out1.close();

	       ObjectInputStream in1 = new ObjectInputStream(
				       new FileInputStream(fileName));
	       StoreGroup SG2 = (StoreGroup)in1.readObject();
	       Hashtable ht1 = SG2.getGroupsDataBase();
	       SG2.setGroupsDataBase("superusers", 0);
            ObjectOutputStream out2 =
                new ObjectOutputStream(
                    new FileOutputStream(fileName));
         out2.writeObject(SG2);
         out2.close();

	       ObjectInputStream in2 = new ObjectInputStream(
				       new FileInputStream(fileName));
	       StoreGroup SG3 = (StoreGroup)in2.readObject();
	       Hashtable ht2 = SG3.getGroupsDataBase();
	       SG3.setGroupsDataBase("commonusers", 3600000);
         ObjectOutputStream out3 =
                new ObjectOutputStream(
                    new FileOutputStream(fileName));
         out3.writeObject(SG3);
         out3.close();
      } catch (Exception e) {
            e.printStackTrace();
      }
    }

   /**
    * Creates a new group and specifies the lifetime of the agents that will belong to the group.
    * The superusers time is set to 0
    * Only the superusers group has permission to access this method.
    * @param groupName   the name of the group to be created
    * @param time   the lifetime of the agents that belongs to this group in milliseconds.
    * @exception SecurityException trown by the SecurityManager
    * if the group trying to acess this method in not the superusers group.
    * @exception GroupException If the group already exists in the database
    */
    public void createGroup(String groupName, long time) {

	     /* Checks what thread is accessing the method */
       String threadName = Thread.currentThread().getName();
	     String group = getGroup(threadName);
	     if (!group.equals("superusers")) {
	        throw new SecurityException("Method structures.DBImplemetation.createGroup(String groupName, long time) can be called just by the superusers group");
    	 } else {
           try {
	    	      File file = new File(fileName);
	            ObjectInputStream in = new ObjectInputStream(
		    	       new FileInputStream(fileName));
            	StoreGroup SG = (StoreGroup)in.readObject();
		          Hashtable ht = SG.getGroupsDataBase();
		          if (ht.containsKey(groupName)) {
	    	         throw new GroupException("Group already exists in the database");
	    	      } else {
		             SG.setGroupsDataBase(groupName, time);
		             ObjectOutputStream out = new ObjectOutputStream(
			              new FileOutputStream(fileName));
	               out.writeObject(SG);
	               out.close();
	    	      }
	         } catch (Exception e){
	    	       e.printStackTrace();
	         }
	     }
    }

   /**
    * Deletes an existing group from the database.
    * Only the superusers group has permission to access this method.
    * @param groupName   the name of the group to be deleted
    * @exception SecurityException trown by the SecurityManager
    * if the group trying to acess this method in not the superusers group.
    * @exception GroupException If the group does not exist in the database
    */
    public void deleteGroup(String groupName) {

	     /* Checks what thread is accessing the method */
       String threadName = Thread.currentThread().getName();
	     String group = getGroup(threadName);
	     if (!group.equals("superusers")) {
	        throw new SecurityException("structures.DBImplementation.deleteGroup.delete(String groupName, long time) can be called just by the superusers group");
	     } else {
            try {
	    	       File file = new File(fileName);
	             ObjectInputStream in = new ObjectInputStream(
		    	        new FileInputStream(fileName));
               StoreGroup SG = (StoreGroup)in.readObject();
		           Hashtable ht = SG.getGroupsDataBase();
		           if (!ht.containsKey(groupName)) {
	    	          throw new GroupException("Group do not exist in the database");
	    	       } else {
		              ht.remove(groupName);
		              ObjectOutputStream out =	new ObjectOutputStream(
			               new FileOutputStream(fileName));
	                out.writeObject(SG);
	                out.close();
	    	       }
	          } catch (Exception e){
	    	       e.printStackTrace();
	          }
	     }
    }

    /**
     * Retrieves from the database the names of the roots that this group has permission to read.
     * @param groupName  the group name
     * @return  the names of the roots this group has permission to read.
     */
    public String[] getRootsToRead(String groupName) {

	     StoreToRead STR = new StoreToRead();
	     String s = null;
	     ArrayList groups = new ArrayList();
	     String[] stored = {null};

  	   try {
    	    File file = new File(toRead);
	    	  ObjectInputStream in = new ObjectInputStream(
		    	   new FileInputStream(toRead));
          STR = (StoreToRead)in.readObject();
	     } catch (Exception e){
	    	  e.printStackTrace();
	     }
	     Hashtable ht = STR.getToReadDataBase();
	     Enumeration e = ht.keys();
       while (e.hasMoreElements()) {
	        s = (String)e.nextElement();
	        stored = STR.getToReadGroups(s);
	        for (int i = 0; i < stored.length; i++) {
	           if (stored[i].equals(groupName)) {
		            groups.add(s);
	           }
	        }
	     }
	     return (String[]) (groups.toArray(new String[0]));;
    }

   /**
    * Retrieves from the database the names of the roots that this group has permission to write and delete.
    * @param groupName  the group name
    * @return  the names of the roots this group has permission to write and delete.
    */
    public String[] getRootsToWrite(String groupName) {

	     StoreToWrite STW = new StoreToWrite();
	     String s = null;
	     ArrayList groups = new ArrayList();
	     String[] stored = {null};

	     try {
    	    File file = new File(toWrite);
	    	  ObjectInputStream in = new ObjectInputStream(
		    	   new FileInputStream(toWrite));
          STW = (StoreToWrite)in.readObject();
	     } catch (Exception e){
	    	  e.printStackTrace();
	     }
	     Hashtable ht = STW.getToWriteDataBase();
	     Enumeration e = ht.keys();
	     while (e.hasMoreElements()) {
	        s = (String)e.nextElement();
	        stored = STW.getToWriteGroups(s);
	        for (int i = 0; i < stored.length; i++) {
	           if (stored[i].equals(groupName)) {
		            groups.add(s);
	           }
	        }
	     }
	     return (String[]) (groups.toArray(new String[0]));
    }

    /**
     * Retrieves from the database the lifetime of the agents that belongs to this group.
     * @param groupName  the group name
     * @return  the lifetime of this group's agents
     * @exception GroupException  If the group does not exist in the database.
     */
    public long getTime(String groupName) {

	     long time = 0;
	     try {
    	    File file = new File(fileName);
	    	  ObjectInputStream in = new ObjectInputStream(
		    	   new FileInputStream(fileName));
          StoreGroup SG = (StoreGroup)in.readObject();
	        Hashtable ht = SG.getGroupsDataBase();
	        if (!ht.containsKey(groupName)) {
	    	     throw new GroupException("Group does not exist in the database");
	    	  } else {
		         time = SG.getGroupTime(groupName);
	    	  }
	     } catch (Exception e) {
	    	   e.printStackTrace();
	     }
	     return time;
    }

    /**
     * Tests if this group name already exists in the database.
     * @param groupName  the group name
     * @return <code>true</code> if the group already exists, <code>false</code> otherwise.
     */
    public boolean isGroup(String groupName) {

	     boolean found = false;
       try {
    	    File file = new File(fileName);
	    	  ObjectInputStream in = new ObjectInputStream(
		    	   new FileInputStream(fileName));
          StoreGroup SG = (StoreGroup)in.readObject();
	        Hashtable ht = SG.getGroupsDataBase();
	        if (ht.containsKey(groupName)) {
		         found = true;
	    	  }
	     } catch (Exception e) {
	    	  e.printStackTrace();
	     }
	     return found;
    }

    /**
     * Retrieves the names of all the groups stored in the database.
     * @return  the names of the stored groups.
     */
     public String[] getGroups() {

	      StoreGroup SG = new StoreGroup();
	      ArrayList v = new ArrayList();
	      String s = null;

	      try {
    	     File file = new File(fileName);
	    	   ObjectInputStream in = new ObjectInputStream(
		    	    new FileInputStream(fileName));
           SG = (StoreGroup)in.readObject();
	      } catch (Exception e){
	    	   e.printStackTrace();
	      }
	      Hashtable ht = SG.getGroupsDataBase();
	      Enumeration e = ht.keys();
	      while (e.hasMoreElements()) {
	         s = (String)e.nextElement();
	         v.add(s);
	      }
	      return (String[]) (v.toArray(new String[0]));
    }

    /**
     * Creates an empty root in the database.
     * @param rootName  the name of the root to be created
     * @exception RootException If the root already exists in the database.
     */
     public void createRoot(String rootName) {

     	  try {
	         File file = new File(fileName2);
	         if (!file.exists()) {
		          ObjectOutputStream out1 = new ObjectOutputStream(
					       new FileOutputStream(fileName2));
		          StoreRoot SR = new StoreRoot();
		          out1.writeObject(SR);
	         }
	         ObjectInputStream in = new ObjectInputStream(
		          new FileInputStream(fileName2));
           StoreRoot SR2 = (StoreRoot)in.readObject();
	         Hashtable ht = SR2.getRootsDataBase();
	         if (ht.containsKey(rootName)) {
		          throw new RootException("Root already exists in the database");
	         } else {
		          Vector vector = new Vector();
		          SR2.setRootsDataBase(rootName, vector);
		          ObjectOutputStream out2 = new ObjectOutputStream(
			           new FileOutputStream(fileName2));
              out2.writeObject(SR2);
	            out2.close();
	         }
  	    } catch (Exception e){
	          e.printStackTrace();
	      }
    }

    /**
     * Retrieves a root content from the database.
     * Only the groups that have read permission can access the specified root.
     * @param rootName   the root name
     * @return  the contents of this root stored in the database
     * @exception RootException thrown if the root is not stored in the database.
     * @exception SecurityException trown by the SecurityManager
     * if the group does not have read permission to this root.
     */
     public Object get(String rootName) {

        Object root = new Object();

    	  try {
	         boolean exists = isRoot(rootName);
	         if (exists == false) {
	    	      throw new RootException("Root do not exist in the database");
	         } else {
	            ObjectInputStream in = new ObjectInputStream(
		             new FileInputStream(fileName2));
              StoreRoot SR = (StoreRoot)in.readObject();
              String threadName = Thread.currentThread().getName();
	            String group = getGroup(threadName);
	            if (group.equals("superusers")) {
		             root = SR.getRootObject(rootName);
	            } else {
	    	         boolean access = isReadable (rootName, group);
                 if (access = true) {
		                root = SR.getRootObject(rootName);
	   	           } else {
		                throw new SecurityException("Acess Denied. Root can not be read by " + group);
	               }
              }
	         }
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      return root;
    }

    /**
     * Deletes an existing group from the database.
     * Only the groups that have write permission can access the specified root.
     * @param rootName   the name of the root to be deleted
     * @exception RootException thrown if the root does not exist in the database.
     * @exception SecurityException trown by the SecurityManager
     * if the group does not have write permission to this root.
     */
     public void deleteRoot(String rootName) {

	      try {
	         boolean exists = isRoot(rootName);
	         if (exists == false) {
	    	      throw new RootException("Root does not exist in the database");
	         } else {
	            ObjectInputStream in = new ObjectInputStream(
		             new FileInputStream(fileName2));
              StoreRoot SR = (StoreRoot)in.readObject();
	            Hashtable ht = SR.getRootsDataBase();
              String threadName = Thread.currentThread().getName();
	            String group = getGroup(threadName);
	            if (group.equals("superusers")) {
		             ht.remove(rootName);
	            } else {
	    	         boolean access = isWriteable (rootName, group);
	   	           if (access = true) {
		                ht.remove(rootName);
	   	           } else {
		                 throw new SecurityException("Acess Denied. Root can not be written by " + group);
	               }
	            }
              ObjectOutputStream out = new ObjectOutputStream(
                 new FileOutputStream(fileName2));
              out.writeObject(SR);
              out.close();
	         }
	      } catch (Exception e) {
	          e.printStackTrace();
	      }
    }

    /**
     * Updates a root content.
     * Only the groups that have write permission can update the specified root.
     * @param rootName  the name of the root to be updated.
     * @param root  the contents to be stored.
     * @exception RootException thrown if the root does not exist in the database.
     * @exception SecurityException trown by the SecurityManager
     * if the group does not have write permission to this root.
     */
     public void set(String rootName, Object root) {

	      try {
	         boolean exists = isRoot(rootName);
	         if (exists == false) {
	            throw new RootException("Root does not exist in the database");
	         } else {
	            ObjectInputStream in = new ObjectInputStream(
		             new FileInputStream(fileName2));
              StoreRoot SR = (StoreRoot)in.readObject();
              String threadName = Thread.currentThread().getName();
	            String group = getGroup(threadName);
	            if (group.equals("superusers")) {
                 SR.setRootsDataBase(rootName, root);
	            } else {
	    	         boolean access = isWriteable (rootName, group);
	   	           if (access = true) {
                    SR.setRootsDataBase(rootName, root);
	   	           } else {
		                throw new SecurityException("Acess Denied. Root can not be written by " + group);
	               }
	            }
              ObjectOutputStream out = new ObjectOutputStream(
                    new FileOutputStream(fileName2));
              out.writeObject(SR);
              out.close();
	         }
 	      } catch (Exception e) {
	          e.printStackTrace();
	      }
    }

    /**
     * Gives permission for a group to read a specified root.
     * @param rootName  the root name
     * @param groupToRead  the group name
     * @exception RootException thrown if the root does not exist in the database.
     * @exception GroupException thrown if the group does not exist in the database.
     */
     public void setGroupToRead(String rootName, String groupToRead) {

	         String[] newGroups = {null};
	         String[] existingGroups = {null};
	         ArrayList existing = new ArrayList();
	         boolean achou = false;

   	       try {
	            boolean b1 = isGroup(groupToRead);
	            boolean b2 = isRoot(rootName);
	            if (b1 == false) {
	    	         throw new GroupException("Group does not exist in the database");
	            }
	            if (b2 == false) {
	    	         throw new RootException("Root does not exist in the database");
	            }
	            if ((b1 == true) && (b2 == true)) {
	    	         File file = new File(toRead);
	    	         if (!file.exists()) {
		                ObjectOutputStream out1 = new ObjectOutputStream(
					      	      new FileOutputStream(toRead));
		                StoreToRead STR1 = new StoreToRead();
		                out1.writeObject(STR1);
	    	         }
	    	         ObjectInputStream in = new ObjectInputStream(
		    	         new FileInputStream(toRead));
            	   StoreToRead STR2 = (StoreToRead)in.readObject();
	    	         Hashtable ht = STR2.getToReadDataBase();
	    	         if (!ht.containsKey(rootName)) {
		               newGroups[0] = groupToRead;
                   STR2.setToReadDataBase(rootName, newGroups);
	    	         } else {
		                 existingGroups = STR2.getToReadGroups(rootName);
		                 int max = existingGroups.length;
		                 for (int i = 0; i < max; i++) {
		                    if (existingGroups[i].equals(groupToRead)) {
			                     achou = true;
			                  }
                     }
		                 if (!achou) {
			                  for (int i = 0; i < max; i++) {
		                       existing.add(existingGroups[i]);
			                  }
			                  existing.add(groupToRead);
			                  existingGroups = (String[]) (existing.toArray(new String[0]));
		                    STR2.setToReadDataBase(rootName, existingGroups);
		                 }
		             }
		             if (!achou) {
		                ObjectOutputStream out2 = new ObjectOutputStream(
			                 new FileOutputStream(toRead));
                    out2.writeObject(STR2);
                    out2.close();
		             }
	            }
	        } catch (Exception e){
	            e.printStackTrace();
	        }
     }

    /**
     * Gives permission for a group to read a specified root.
     * @param rootName  the root name
     * @param groupToRead  the group name
     * @exception RootException thrown if the root does not exist in the database.
     * @exception GroupException thrown if the group does not exist in the database.
     */
     public void setGroupToWrite(String rootName, String groupToWrite) {

	      String[] newGroups = {null};
	      String[] existingGroups = null;
	      ArrayList existing = new ArrayList();
	      boolean achou = false;

	      try {
	         boolean b1 = isGroup(groupToWrite);
	         boolean b2 = isRoot(rootName);
	         if (b1 == false) {
	    	      throw new GroupException("Group does not exist in the database");
	         }
	         if (b2 == false) {
	    	      throw new RootException("Root does not exist in the database");
	         }
	         if ((b1 == true) && (b2 == true)) {
	    	      File file = new File(toWrite);
	    	      if (!file.exists()) {
		             ObjectOutputStream out1 = new ObjectOutputStream(
					      	   new FileOutputStream(toWrite));
                 StoreToWrite STW1 = new StoreToWrite();
		             out1.writeObject(STW1);
	    	      }
	    	      ObjectInputStream in = new ObjectInputStream(
		    	        new FileInputStream(toWrite));
            	StoreToWrite STW2 = (StoreToWrite)in.readObject();
	    	      Hashtable ht = STW2.getToWriteDataBase();
	    	      if (!ht.containsKey(rootName)) {
	    	         newGroups[0] = groupToWrite;
                 STW2.setToWriteDataBase(rootName, newGroups);
	    	      } else {
		             existingGroups = STW2.getToWriteGroups(rootName);
		             int max = existingGroups.length;
		             for (int i = 0; i < max; i++) {
		                if (existingGroups[i].equals(groupToWrite)) {
			                 achou = true;
			              }
		             }
		             if (!achou) {
			              for (int i = 0; i < max; i++) {
		                   existing.add(existingGroups[i]);
                    }
                    existing.add(groupToWrite);
			              existingGroups = (String[]) (existing.toArray(new String[0]));
		                STW2.setToWriteDataBase(rootName, existingGroups);
                 }
		          }
  		        if (!achou) {
		             ObjectOutputStream out2 = new ObjectOutputStream(
			              new FileOutputStream(toWrite));
	               out2.writeObject(STW2);
	               out2.close();
		          }
           }
	      } catch (Exception e){
	          e.printStackTrace();
	      }
    }

    /**
     * Retrieves the names of all the roots stored in the database.
     * @return  the roots names
     */
     public String[] getRoots() {

	      StoreRoot SR = new StoreRoot();
  	    ArrayList roots = new ArrayList();
	      String s = null;

	      try {
    	     File file = new File(fileName2);
           ObjectInputStream in = new ObjectInputStream(
		    	    new FileInputStream(fileName2));
           SR = (StoreRoot)in.readObject();
	      } catch (Exception e){
	    	    e.printStackTrace();
	      }
	      Hashtable ht = SR.getRootsDataBase();
	      Enumeration e = ht.keys();
	      while (e.hasMoreElements()) {
	         s = (String)e.nextElement();
	         roots.add(s);
	      }
	      return (String[]) (roots.toArray(new String[0]));
     }

    /**
     * Tests if a root exists in the database.
     * @param rootName  the root name
     * @return <code>true</code> if the roor already exists, <code>false</code> otherwise.
     */
     public boolean isRoot(String rootName) {

	      boolean found = false;

	      try {
	         ObjectInputStream in = new ObjectInputStream(
		          new FileInputStream(fileName2));
           StoreRoot SR = (StoreRoot)in.readObject();
           Hashtable ht = SR.getRootsDataBase();
	         if (ht.containsKey(rootName)) {
	    	      found = true;
	         }
	      } catch (Exception e){
	          e.printStackTrace();
	      }
        return found;
     }

    /**
     * Retrieves from the database the names of the groups with read permission to a specific root.
     * @param rootName  the root name
     * @return the names of the groups that can read this root
     */
     public String[] getGroupsToRead(String rootName) {

	      String[] s = {null};

	      try {
	         ObjectInputStream in = new ObjectInputStream(
		          new FileInputStream(toRead));
           StoreToRead STR = (StoreToRead)in.readObject();
	         Hashtable ht = STR.getToReadDataBase();
	         if (ht.containsKey(rootName)) {
	    	      s = STR.getToReadGroups(rootName);
	         }
	      } catch (Exception e){
	          e.printStackTrace();
	      }
        return s;
     }

    /**
     * Retrieves from the database the names of the groups with write and delete permissions to a specific root.
     * @param rootName  the root name
     * @return the names of the groups that can write and delete this root
     */
     public String[] getGroupsToWrite(String rootName) {

	      String[] s = {null};

	      try {
	         ObjectInputStream in = new ObjectInputStream(
		          new FileInputStream(toWrite));
           StoreToWrite STW = (StoreToWrite)in.readObject();
	         Hashtable ht = STW.getToWriteDataBase();
	         if (ht.containsKey(rootName)) {
	    	      s = STW.getToWriteGroups(rootName);
           }
	      } catch (Exception e){
	          e.printStackTrace();
	      }
        return s;
     }

    /**
     * Tests if a group has permission to read a root.
     * @param rootName  the root name
     * @param groupName  the group name
     * @return <code>true</code> if the group has permission to read the root, <code>false</code> otherwise.
     * @exception RootException  if the root does not exist in the database.
     */
     public boolean isReadable(String rootName, String groupName) {

	      boolean found = false;

	      try {
	         ObjectInputStream in = new ObjectInputStream(
		          new FileInputStream(toRead));
           StoreToRead STR = (StoreToRead)in.readObject();
           Hashtable ht = STR.getToReadDataBase();
	         if (!ht.containsKey(rootName)) {
		          throw new RootException("Root does not exist in the database");
           } else {
		          String[] s = STR.getToReadGroups(rootName);
		          for (int i = 0; i < s.length; i++) {
		             if (s[i].equals(groupName)) {
		                found = true;
                 }
		          }
           }
	      } catch (Exception e){
	          e.printStackTrace();
	      }
        return found;
     }

    /**
     * Tests if a group has permission to write and delete a root.
     * @param rootName  the root name
     * @param groupName  the group name
     * @return <code>true</code> if the group has permission to write and delete the root, <code>false</code> otherwise.
     * @exception RootException  if the root does not exist in the database.
     */
     public boolean isWriteable(String rootName, String groupName) {

	      boolean found = false;

	      try {
	         ObjectInputStream in = new ObjectInputStream(
		          new FileInputStream(toWrite));
           StoreToWrite STW = (StoreToWrite)in.readObject();
           Hashtable ht = STW.getToWriteDataBase();
	         if (!ht.containsKey(rootName)) {
		         throw new RootException("Root does not exist in the database");
	         } else {
		          String[] s = STW.getToWriteGroups(rootName);
		          for (int i = 0; i < s.length; i++) {
		             if (s[i].equals(groupName)) {
		    	          found = true;
                 }
		          }
           }
	      } catch (Exception e){
	          e.printStackTrace();
	      }
        return found;
     }

    /**
     * Associates a thread with an agent and its group.
     * It is necessary when a new agent starts running.
     * If each agent is executed in a thread its possible to know
     * to which group the thread belongs to.
     * @param threadName  the thread name
     * @param groupName  the group name
     * @param agentName  the agent name
     */
    public void associate (String threadName, String groupName, String agentName) {

       try {
		     File file = new File(path);
         if (!file.exists()) {
		        ObjectOutputStream out1 = new ObjectOutputStream(
						    new FileOutputStream(path));
		        StoreThreadsControll STC = new StoreThreadsControll();
		        out1.writeObject(STC);
         }
		     ObjectInputStream in = new ObjectInputStream(
				  	new FileInputStream(path));
		     StoreThreadsControll STC2 = (StoreThreadsControll)in.readObject();
		     Hashtable ht = STC2.getThreadsDataBase();

		     STC2.setThreadsDataBase(threadName, groupName, agentName);
         ObjectOutputStream out2 = new ObjectOutputStream(
             new FileOutputStream(path));
         out2.writeObject(STC2);
         out2.close();

       } catch (Exception e){
            e.printStackTrace();
       }
    }

    /**
     * Retrieves from the database the name of the group associated to the specified thread.
     * @param threadName  the thread name
     * @return the group name
     */
     public String getGroup (String threadName) {

        String s = null;

        try {
            ObjectInputStream in = new ObjectInputStream(
               new FileInputStream(path));
	          StoreThreadsControll STC = (StoreThreadsControll)in.readObject();
	          Hashtable ht = STC.getThreadsDataBase();
	          s = STC.getGroupThread(threadName);
        } catch (Exception ex){
            ex.printStackTrace();
        }
        return s;
    }

    /**
     * Retrieves from the database the name of the agent associated to the specified thread.
     * @param threadName  the thread name
     * @return the agent name
     */
     public String getAgentName (String threadName) {

        String s = null;

        try {
            ObjectInputStream in = new ObjectInputStream(
                new FileInputStream(path));
	          StoreThreadsControll STC = (StoreThreadsControll)in.readObject();
	          Hashtable ht = STC.getThreadsDataBase();
	          s = STC.getAgentThread(threadName);
        } catch (Exception ex){
            ex.printStackTrace();
        }
        return s;
    }

    /**
     * Removes the association between an agent and a thread.
     * It is necessary when an agent finishes its execution or when
     * its lifetime ends.
     * @param threadName  the name of the thread to be excluded
     */
     public void removeAssociation(String threadName) {

	      try {
            ObjectInputStream in = new ObjectInputStream(
                 new FileInputStream(path));
	          StoreThreadsControll STC = (StoreThreadsControll)in.readObject();
	          Hashtable ht = STC.getThreadsDataBase();
	          if (ht.containsKey(threadName)) {
		            ht.remove(threadName);
                ObjectOutputStream out = new ObjectOutputStream(
                    new FileOutputStream(path));
                out.writeObject(STC);
                out.close();
            } else {
		            System.out.println("Thread nao existe");
                // Make InvalidThreadException
	          }
        } catch (Exception ex){
             ex.printStackTrace();
        }
    }
}
