
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server. 
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

package structures;

import java.util.Hashtable;
import java.util.Vector;
import java.io.Serializable;


/**
 * Sets information about roots and the groups that can write and delete them in the Hashtable, and gets it back.
 * @see Hashtable
 */
class StoreToWrite implements Serializable {
    private Hashtable toWriteDataBase = new Hashtable();

   /**
    * Adds a root and the groups with permission to write and delete it to the <code>Hashtable</code>
    * @param rootName  the root name. It is the <code>Hashtable</code> entry key.
    * @param groups  a <code>String[]</code> containing the groups.
    */
    void setToWriteDataBase(String rootName, String[] groups) {
        toWriteDataBase.put(rootName, groups);
    }

   /**
    * Gets from the Hashtable the groups that can write and delete this root.
    * @param rootName  the root name
    * @return a <code>String[]</code> containing the groups.
    */
    String[] getToWriteGroups(String rootName) {
        String[] s = (String[])toWriteDataBase.get(rootName);
        return s;
    }

   /**
    * Gets the <code>Hashtable</code> containing the writeable roots and associated groups.
    * @return the <code>Hashtable</code>
    */
    Hashtable getToWriteDataBase() {
	     return toWriteDataBase;
    }
}
