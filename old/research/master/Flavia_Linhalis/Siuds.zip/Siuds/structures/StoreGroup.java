
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server. 
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

package structures;


import java.io.Serializable;
import java.util.Hashtable;

/**
 * Sets information about the groups in the Hashtable and gets it back.
 * @see Hashtable
 */
class StoreGroup implements Serializable {
    private Hashtable groupsDataBase = new Hashtable();

   /**
    * Adds a new group to the <code>Hashtable</code>
    * @param groupName  the group name. It is the <code>Hashtable</code> entry key.
    * @param time  a <code>long</code> containing the lifetime of the agents that blongs to this group, in miliseconds.
    */
    void setGroupsDataBase(String groupName, long groupTime) {
        groupsDataBase.put(groupName, new Long(groupTime));
    }


   /**
    * Gets a group lifetime from the Hashtable
    * @param groupName  the group name
    * @return the lifetime of the agents that belongs to this group.
    */
    long getGroupTime(String groupName) {
       Long l = (Long)groupsDataBase.get(groupName);
	     long l2 = l.longValue();
       return l2;
    }


   /**
    * Gets the <code>Hashtable</code> containing all the groups objects.
    * @return the <code>Hashtable</code> containing the groups database.
    */
    Hashtable getGroupsDataBase() {
	     return groupsDataBase;
    }
}
