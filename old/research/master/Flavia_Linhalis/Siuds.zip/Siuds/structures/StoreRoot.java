
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server. 
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

package structures;

import java.util.Hashtable;
import java.util.Vector;
import java.io.Serializable;


/**
 * Sets information about the roots in the Hashtable and gets it back.
 * @see Hashtable
 */
class StoreRoot implements Serializable {
    private Hashtable rootsDataBase = new Hashtable();

   /**
    * Adds a new root to the <code>Hashtable</code>
    * @param rootName the root name. It is the <code>Hashtable</code> entry key.
    * @param rootObject  an <code>Object</code> with the root content.
    */
    void setRootsDataBase(String rootName, Object rootObject) {
        rootsDataBase.put(rootName, rootObject);
    }

   /**
    * Gets a root from the Hashtable
    * @param rootNamethe the root Name
    * @return an <code>Object</code> with the root content.
    */
    Object getRootObject(String rootName) {
        Object o = (Object)rootsDataBase.get(rootName);
        return o;
    }

   /**
    * Gets the <code>Hashtable</code> containing all the roots objects.
    * @return the <code>Hashtable</code> containing the roots database.
    */
    Hashtable getRootsDataBase() {
	     return rootsDataBase;
    }
}
