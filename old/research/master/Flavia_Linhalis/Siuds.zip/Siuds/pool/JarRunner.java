
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server.
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/

package pool;

import structures.DBImplementation;
import java.io.IOException;
import java.net.URL;
import java.net.MalformedURLException;
import java.lang.reflect.InvocationTargetException;


/**
 * Runs a jar application under SecurityManager.
 */
public class JarRunner extends Thread {

    private String threadName = null;
    private String name = null;
    private String[] newArgs = {null};
    private JarClassLoader cl;
    private DBImplementation tc = new DBImplementation();

/**
 * Creates a JarClassLoader for a jar application from any url.
 * Then, it gets the application MainClass.
 * @see JarClassLoader
 * Associates the thread with its corresponding group.
 * @see #ThreadsControll.associate()
 * @params alias the alias of the agent signer.
 *               It must be stored in the keystore.
 * @params path the path of the agent.
 *               It have to be in the format file:c:/directories/agent.jar
 * @throws Exception
 * @exception MalformedURLException
 *             If the specified path if an invalid URL
 * @exception IOException
 *            If any error occurs while loading the Jar file
 */
    public JarRunner(String alias, String path) throws Exception {
        URL url = null;
	      String[] jarPath = {path};
        try {
            url = new URL(jarPath[0]);
        } catch (MalformedURLException e) {
            fatal("Invalid URL: " + jarPath[0]);
        }

        /* Create the class loader for the jar */
        cl = new JarClassLoader(url);

        /* Get the application's main class */
        try {
            name = cl.getMainClassName();
        } catch (IOException e) {
            System.err.println("I/O error while loading JAR file:");
            e.printStackTrace();
            System.exit(1);
        }
        if (name == null) {
            fatal("Specified jar file does not contain a 'Main-Class'" +
                  " manifest attribute");
        }
        /* Get arguments for the application */
        newArgs = new String[jarPath.length - 1];
        System.arraycopy(jarPath, 1, newArgs, 0, newArgs.length);

	      /* Gets this thread's name */
	      threadName = getName();
	      System.out.println("Jar running on thread " + threadName);

	      /* Associates the thread with its group */
	      tc.associate(threadName, alias, path);
    }
/**
 * Starts a thread of excecution for the current Jar.
 * It first installs the SeurityManager class and then loads the Jar classes.
 * @see SecurityManager
 * @exception ClassNotFoundException
 *            If the Jar Main-Class is not found
 * @exception NoSuchMethodException
 *            If the Main-Class doen not define a main method
 * @exception InvocationTargetException
 */
    public void run() {

	     SecurityManager security = System.getSecurityManager();
	     if (security == null) {
	       System.setSecurityManager(new SecurityManager());
	       System.out.println("SecurityManager Installed.");
	     }

       System.out.println("Running jar...");

       /* Invoke application's main class */
       try {
            cl.invokeClass(name, newArgs);
       } catch (ClassNotFoundException e) {
            fatal("Class not found: " + name);
       } catch (NoSuchMethodException e) {
            fatal("Class does not define a 'main' method: " + name);
       } catch (InvocationTargetException e) {
            e.getTargetException().printStackTrace();
            System.exit(1);
	     } catch (Exception exep) {
	          exep.printStackTrace();
	     } catch (Throwable t) {
	          t.printStackTrace();
     	 }

	     System.out.println("Jar finished. Removing " + threadName + " association...");
	     tc.removeAssociation(threadName);
    }

    private static void fatal(String s) {
        System.err.println(s);
        System.exit(1);
    }

     private static void usage() {
        fatal("Usage: java pool/JarRunner alias path[file:c:/siuds/gateway.jar]");
    }

/**
 * Starts the Gateway agent.
 * @throws Exception
 */
  public static void main(String[] args) throws Exception {

     if (args.length != 2)
        JarRunner.usage();
	   String alias = args[0];
	   if (alias.equals("superusers")) {
	      JarRunner jr = new JarRunner(alias, args[1]);
	      jr.start();
	   } else {
	      JarRunner jr = new JarRunner(alias, args[1]);
	      TimeCounter tc = new TimeCounter(alias);
	      jr.start();
	      tc.sendJar(jr);
	      tc.start();
	   }
  }
}
