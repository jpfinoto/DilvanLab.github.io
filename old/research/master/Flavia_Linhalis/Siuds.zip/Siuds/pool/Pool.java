
/*************************************************************************

SIUDS - Secure Interface for a Universal Data Server.
Copyright (C) 2000  Flavia Linhalis, Dilvan Moreira

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Contact: flavialin@bol.com.br
         dilvan@computer.org
         Paper mail: SCE-ICMC-USP Caixa Postal 668
                     Av Dr Carlos Botelho, 1465
                     13560-970 Sao Carlos-SP
                     BRAZIL

***************************************************************************/


package pool;

/**
 * The Pool is an environment where all the software agents run.
 * @see JarRunner
 * @see TimeCounter
 */
public class Pool {

   private static JarRunner jr;

/**
 * Called when an agent is ready to excecute.
 * @params alias the alias of the agent signer.
 *               It must be stored in the keystore.
 * @params path the path of the agent.
                It have to be in the format file:c:/directories/agent.jar
 * @throws Exception
 */
    public static void receiveJarInfo(String alias, String path) throws Exception {

	    try {
  	    JarRunner jr2 = new JarRunner(alias, path);
	      TimeCounter tc = new TimeCounter(alias);
	      jr2.start();
	      tc.sendJar(jr);
	      tc.start();
	      } catch (Exception e) {
	          e.printStackTrace();
	      }
    }
}
