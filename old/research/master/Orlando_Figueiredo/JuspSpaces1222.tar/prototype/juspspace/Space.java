
package juspspace;

import acidchoir.*;
import madleaser.*;

import java.net.*;
import java.rmi.*;
import java.util.*;

import net.jini.core.event.*;
import net.jini.core.lease.*;
import net.jini.core.transaction.*;
import net.jini.core.transaction.server.*;
import net.jini.space.InternalSpaceException;

/** 
 * Main class in JuspSpaces service. It has a connection listener thread and
 * it provides the access methods to the service. It implements the MadGrantor
 * interface, so the collector could call it to expire the leases. 
 * It implements the TransactionParticipant interface, so the
 * TransactionManager could call it.
 *
 * @author Agents Research
 */
public class Space extends Thread implements MadGrantor, 
    TransactionParticipant, JuspConstants
{
    protected Repository rep;
    protected String hostName;
    protected int leasePort;
    protected ServerSocket listener;

    public Space(Repository rep, String hostName, int leasePort,
	ServerSocket listener) 
    {
	this.rep = rep;
	this.hostName = hostName;
	this.leasePort = leasePort;
	this.listener = listener;
    }

//    public static final int NO_WAIT = 0;
//    public static final int WAIT = 1;

    /** Data structure that is returned to the Handler as a result
     *  of getEntry method. The status field asks to block. */
    public class FieldPackage {
	int status;
	FieldData[] fields;

	public FieldPackage(int status) {
	    this.status = status;
	    this.fields = null;
	}

	public FieldPackage(int status, FieldData[] fields) {
	    this.status = status;
	    this.fields = fields;
	}
    }

    public Lease write(Class entryClass, FieldData[] fields, Transaction txn,
	long wantedLease) throws TransactionException
    {
	long id = System.currentTimeMillis(); //review: should be random
	long lease = wantedLease; //review: lease policy

	Object lock = rep.getLock();

	long txnId = processTransaction(lock, txn);

	String grp = rep.getGroup(lock, entryClass);

	Repository.XId xid = new Repository.XId(grp, id);
	rep.insertEntryAndMark(lock, xid, fields, txnId, lease);

	releaseTemplates(lock, entryClass, xid, fields, txnId);

	rep.releaseLock(lock);

	Lease result = new MadLease(hostName, leasePort, grp, id, lease);
	return result;
    }

    protected void releaseTemplates(Object lock, Repository.XId xid) {
	//get fields
	//releaseTemplates(lock, ???, xid, fields, 0);
    }

    protected void releaseTemplates(Object lock, Class entryClass, 
	Repository.XId xid, FieldData[] fields, long txnId) 
    {

	/* Searches for a template */
	Class[] classes = getClassAndSuperclasses(entryClass);
	Repository.XId[] tmpl = null;
	FieldData[] filtered = null; 
	String grp = null;
	for (int i = 0; i < classes.length; i++) {
	    filtered = filterFields(fields, classes[i]);
	    grp = rep.getGroup(lock, classes[i]);
	    tmpl = rep.findTemplates(lock, grp, filtered, txnId, "T");
	    if (tmpl != null) {
	        break;
	    }
	}
	if (tmpl != null) {
	    Repository.TemplateData td = rep.getTemplateData(lock, tmpl[0]);
	    Callback cb = (Callback) td.obj1;
	    cb.send(fields);
	    rep.removeEntry(lock, xid);
	    rep.removeTemplate(lock, tmpl[0]);
	} else {
	    Repository.XId[] tmpls = null;
	    Repository.TemplateData td = null;
	    Callback cb = null;
	    for (int i = 0; i < classes.length; i++) {
		filtered = filterFields(fields, classes[i]);
		grp = rep.getGroup(lock, classes[i]);
		tmpls= rep.findTemplates(lock, grp, filtered, txnId, "R");
		if (tmpls != null) {
		    for (int k = 0; k < tmpls.length; k++) {
			td = rep.getTemplateData(lock, tmpls[k]);
			cb = (Callback) td.obj1;
			cb.send(fields);
			rep.removeTemplate(lock, td.xid);
		    }
		}
	    }
	    for (int i = 0; i < classes.length; i++) {
		filtered = filterFields(fields, classes[i]);
		grp = rep.getGroup(lock, classes[i]);
		tmpls= rep.findTemplates(lock, grp, filtered, txnId, "N");
		if (tmpls != null) {
		    for (int k = 0; k < tmpls.length; k++) {
			td = rep.getTemplateData(lock, tmpls[k]);
			RemoteEvent event = new RemoteEvent(new Integer(1), 
			    td.xid.id, td.number, (MarshalledObject) td.obj2);
			try {
			     ((RemoteEventListener) td.obj1).notify(event);
			} catch (RemoteException re) {
			     //review
			} catch (UnknownEventException uee) {};//review
	    	    }
		}
	    }
	}
    }

    protected Class[] getClassAndSuperclasses(Class entryClass) {

	Class en = null;
	Class ob = null;
	try {
	    en = Class.forName("net.jini.core.entry.Entry");
	    ob = Class.forName("java.lang.Object");
	} catch (ClassNotFoundException cnfe) {};

	Class cl = entryClass;
	Vector v = new Vector();
	while (en.isAssignableFrom(cl) && !ob.equals(cl)) {
	    v.add(cl);
	    cl = cl.getSuperclass();
	}
	return (Class[]) v.toArray(new Class[0]);
    }

    public FieldPackage getEntry(int mode, Class tmplClass, FieldKey[] fields,
	Transaction txn, long timeout, Callback callback) 
	throws TransactionException
    {
	FieldPackage result = null;

	Object lock = rep.getLock();

	long txnId = processTransaction(lock, txn);
	
	String[] groups = rep.getGroupsForClassAndSubclasses(lock, tmplClass);

	Repository.XId xid = null;
	for (int k = 0; k < groups.length && xid == null; k++) {
	    xid = rep.findEntry(lock, groups[k], fields, txnId, true, mode);
	}
	if (xid != null) {
	    // free entry found!
	    result = new FieldPackage(NO_WAIT,
		rep.getFields(lock, xid, callback.wildcards));
	    if (mode == TAKE || mode == TAKE_BLOCK) {
		rep.removeEntry(lock, xid);
	    }
	    rep.releaseLock(lock);
	    return result; 
	}
	for (int k = 0; k < groups.length && xid == null; k++) {
	    xid = rep.findEntry(lock, groups[k], fields, txnId, false, mode);
	}
	String tmplType = "";
	if (mode == READ || mode == READ_BLOCK) {
	    tmplType = "R";
	} else {
	    tmplType = "T";
	}
	if (xid != null) {
	    // locked entry found!
	    long tmplId = System.currentTimeMillis(); //review: generateId()
	    Repository.XId tmplXid = new Repository.XId(groups[0], tmplId);
	    long discard = rep.insertTemplate(lock, tmplXid, fields, txnId, 
		timeout, callback.wildcards, null, tmplType);
	    rep.releaseLock(lock);
	    result = new FieldPackage(WAIT);
	} else {
	    if (mode == READ_BLOCK && mode == TAKE_BLOCK) {
		long tmplId = System.currentTimeMillis(); //review: generateId()
		Repository.XId tmplXid = new Repository.XId(groups[0], tmplId);
		long discard = rep.insertTemplate(lock, tmplXid, fields, txnId, 
		    timeout, callback.wildcards, null, tmplType);
		rep.releaseLock(lock);
		result = new FieldPackage(WAIT);
	    } else {
		rep.releaseLock(lock);
		result = new FieldPackage(NO_WAIT, null);
	    }
	}
	return result;
    }

    /**
     * Given an array of fields and a class, returns the fields of array
     * that belongs to the class.
     */
    protected FieldData[] filterFields(FieldData[] fields, Class cl) {
	FieldData[] results = null;
	Vector v = new Vector();
	for (int k = 0; k < fields.length; k++) {
	    try {
		cl.getField(fields[k].name);
		v.add(fields[k]);
		//System.out.println(fields[k].name);//debug
	    } catch (NoSuchFieldException e) {};
	}
	results = (FieldData[]) v.toArray(new FieldData[0]);
	return results;
    }

    public EventRegistration notify (Class tmplClass, FieldKey[] fields,
	Transaction txn, RemoteEventListener listener, long wantedLease,
	MarshalledObject handback) throws TransactionException
    {
	long lease = wantedLease;

	EventRegistration result = null;

	Object lock = rep.getLock();

	long txnId = processTransaction(lock, txn);

	String grp = rep.getGroup(lock, tmplClass);
	long id = System.currentTimeMillis();
	Repository.XId xid = new Repository.XId(grp, id);

	long seqNum = rep.insertTemplate(lock, xid, fields, txnId, lease, 
	    listener, handback, "N");

	rep.releaseLock(lock);

	Lease leaseObj = new MadLease(hostName, leasePort, grp, id, lease);

	result = new EventRegistration(id, this, leaseObj, seqNum);
	return result;
    }

    public void run () {
	/* Listens for connections */
	while (true) {
	    try {
		Socket client = listener.accept();
		//System.out.println(
		//    "$ Accepted from " + client.getInetAddress());
		Handler h = new Handler(client, this);
		h.start();
	    } catch (Exception e) {
		throw new InternalSpaceException("Cannot accept connection",e);
	    }
	}
    }
    
    public void abort(TransactionManager mgr, long id) 
        throws UnknownTransactionException 
    {
	Object lock = rep.getLock();

	long txnId = processTransaction(lock, mgr, id);

	String state = rep.getTransactionState(lock, txnId);
	if (state == "COMMITTED") {
	    // do something
	} 

	String[] groups = rep.getAllGroups(lock);
	for (int i = 0; i < groups.length; i++) {

	    long[] written =
		rep.getEntriesWrittenUnderTransaction(lock, groups[i], txnId);
	    for (int k = 0; k < written.length; k++) {
		rep.removeEntry(lock, 
		    new Repository.XId(groups[i], written[k]));
	    }
	    
	    long[] taken = 
		rep.getEntriesTakenUnderTransaction(lock, groups[i], txnId);
	    for (int k = 0; k < taken.length; k++) {
		rep.removeTakenMark(lock, 
		    new Repository.XId(groups[i], taken[k]));
	    }

	    long[] read =
		rep.getEntriesReadUnderTransaction(lock, groups[i], txnId);
	    for (int k = 0; k < read.length; k++) {
		rep.removeReadMark(lock, 
		    new Repository.XId(groups[i], read[k]), txnId);
	    }

	}

	rep.setTransactionState(lock, txnId, "ABORTED"); 
	rep.unregisterTransaction(lock, txnId);

	rep.releaseLock(lock);
    }

    public void commit(TransactionManager mgr, long id)
        throws UnknownTransactionException 
    {
	Object lock = rep.getLock();

	long txnId = processTransaction(lock, mgr, id);

	String state = rep.getTransactionState(lock, txnId);
	if (state != "PREPARED") {
	    // do something
	} 

	String[] groups = rep.getAllGroups(lock);
	for (int i = 0; i < groups.length; i++) {

	    long[] taken = 
		rep.getEntriesTakenUnderTransaction(lock, groups[i], txnId);
	    for (int k = 0; k < taken.length; k++) {
		rep.removeEntry(lock, 
		    new Repository.XId(groups[i], taken[k]));
	    }

	    long[] written =
		rep.getEntriesWrittenUnderTransaction(lock, groups[i], txnId);
	    for (int k = 0; k < written.length; k++) {
		releaseTemplates(lock, new Repository.XId(groups[i], written[k]));
		rep.removeWrittenMark(lock, 
		    new Repository.XId(groups[i], written[k]));
	    }
	    
	    long[] read =
		rep.getEntriesReadUnderTransaction(lock, groups[i], txnId);
	    for (int k = 0; k < read.length; k++) {
		rep.removeReadMark(lock, 
		    new Repository.XId(groups[i], read[k]), txnId);
	    }

	}

	rep.setTransactionState(lock, txnId, "COMMITTED"); 
	rep.unregisterTransaction(lock, txnId);

	rep.releaseLock(lock);
    }

    public int prepare(TransactionManager mgr, long id)
        throws UnknownTransactionException 
    {
	Object lock = rep.getLock();
	long txnId = processTransaction(lock, mgr, id);
	rep.setTransactionState(lock, txnId, "VOTING");
	int result = VOTING;
//	if (!rep.hasChanged(txnId)) {
//	    rep.setTransactionState(lock, txnId, "NOTCHANGED");
//	    result = NOTCHANGED;
//	    rep.commit(lock);
//	} else {
	    rep.setTransactionState(lock, txnId, "PREPARED");
	    result = PREPARED;
//	}
	rep.releaseLock(lock);
	return result;
    }

    public int prepareAndCommit(TransactionManager mgr, long id)
        throws UnknownTransactionException 
    {
	//review: not implemented
	return -1;
    }

    protected long calculateTxnId(Transaction txn) {
	AcidTransaction acidTxn = (AcidTransaction) txn;
	return calculateTxnId(acidTxn.host, acidTxn.port, acidTxn.id);
    }

    protected long calculateTxnId(TransactionManager mgr, long id) {
	ParticipantProxy proxyMgr = (ParticipantProxy) mgr;
	return calculateTxnId(proxyMgr.host, proxyMgr.port, id);
    }

    protected long calculateTxnId(String host, int port, long id) {
	return ((host.hashCode() % 10000) * 100000000 +
	    (port % 10000) * 10000 +
	    (id % 10000));
    }

    protected long processTransaction(Object lock, Transaction txn)
	throws TransactionException
    {
	if (txn == null) {
	    return 0;
	}
	long txnId = calculateTxnId(txn);
	if (!rep.isTransactionRegistered(lock, txnId)) {
	    AcidTransaction acidTxn = (AcidTransaction) txn;
	    try {
		acidTxn.join(this, 0);
	    } catch (RemoteException re) {
		throw new InternalSpaceException("Cannot access manager", re);
	    }
	    rep.registerTransaction(lock, txnId);
	}
	if (!rep.isTransactionActive(lock, txnId)) {
	    throw new TransactionException();
	}
	return txnId;
    }

    protected long processTransaction(Object lock, TransactionManager mgr,
	long id) throws UnknownTransactionException
    {
	long txnId = calculateTxnId(mgr, id);
	if (!rep.isTransactionRegistered(lock, txnId)) {
	    throw new UnknownTransactionException();
	}
	return txnId;
    }

    public void cancel(String grp, long id) throws UnknownLeaseException {
	Object lock = rep.getLock();

	//todo: Does the grp exist?
	//todo: Does the entry exist?
	Repository.XId xid = new Repository.XId(grp, id);
	rep.removeEntry(lock, xid);
	rep.releaseLock(lock);
    }

    public long renew(String grp, long id, long duration) 
	throws LeaseDeniedException, UnknownLeaseException
    {
	Object lock = rep.getLock();

	if (duration == Lease.ANY) {
	    duration = 24 * 60 * 60 * 1000;
	}
	Repository.XId xid = new Repository.XId(grp, id);
	rep.incrementEntryLease(lock, xid, duration);
	return duration;
    }

    public void collect() {
	Object lock = rep.getLock();

	String[] groups = rep.getAllGroups(lock);
	for (int i = 0; i < groups.length; i++) {
	    rep.removeExpiredEntries(lock, groups[i]);
	}

	//review: this code have to be in another method, 
	//  called by another thread
	for (int i = 0; i < groups.length; i++) {
	    long[] expired = rep.getExpiredTemplates(lock, groups[i]);
	    for (int j = 0; j < expired.length; j++) {
		Repository.TemplateData td = rep.getTemplateData(lock, 
		    new Repository.XId(groups[i], expired[j]));
		((Callback) td.obj1).send(null);
	    }
	}

	rep.releaseLock(lock);
    }

}
