
package juspspace;

import java.io.*;
import java.net.*;

import net.jini.space.InternalSpaceException;

/**
 * Holds all information to do a callback to the client. The information
 * is the client address and the fields that must be sent.
 *
 * @author Agents Research
 */
public class Callback implements Serializable {

    public String host;
    public int port;
    public String[] wildcards;
    public int mode;

    Callback(String host, int port, String[] wildcards, int mode) {
	this.host = host;
	this.port = port;
	this.wildcards = wildcards;
	this.mode = mode;
    }

    public void send(FieldData[] fields) {

	try {
	    // open a socket and streams
	    Socket s = new Socket(host, port);

	    ObjectOutputStream o = new ObjectOutputStream(
		new BufferedOutputStream(s.getOutputStream()));
	    o.flush();
	    ObjectInputStream i = new ObjectInputStream(s.getInputStream());

	    // compare each wildcard with all fields array

	    // send product
	    o.writeObject(fields);
	    o.flush();

	    // close all the thing
	    o.close();
	    i.close();
	    s.close();

	} catch (Exception e) {
	    throw new InternalSpaceException("Cannot callback client", e);
	}

    }
}
