
package juspspace;

import acidchoir.*;
import madleaser.*;

import java.io.*;
import java.net.*;
import java.rmi.*;
import java.util.*;
import java.lang.reflect.*;

import net.jini.core.entry.*;
import net.jini.core.event.*;
import net.jini.core.lease.*;
import net.jini.space.JavaSpace;
import net.jini.core.transaction.*;

/**
 * Client proxy that provides access to the JuspSpace server.
 * TCP sockets are used. 
 *
 * @author Agents Research
 */
public class Proxy implements JavaSpace, JuspConstants {

    protected String host;
    protected int port;

    public Proxy(String host, int port) throws IOException {
	this.host = host;
	this.port = port;
    }

    public Lease write(Entry e, Transaction txn, long lease) throws
	TransactionException, RemoteException
    {
	//review: test if some field is null
	//test if lease is negative, throw an exception if it is
	Lease result = null;

	Socket s = null;
	ObjectOutputStream o = null;
	ObjectInputStream i = null;
 
	try {
	    /* Connecting to the server */
	    s = new Socket (host, port);
	    o = new ObjectOutputStream(
		new BufferedOutputStream(s.getOutputStream()));
	    o.flush();
	    i = new ObjectInputStream(s.getInputStream());

	    /* Building serialized entry */
	    Class entryClass = e.getClass();
	    Field[] entryFields = entryClass.getFields();
	    FieldData[] serializedFields = new FieldData[entryFields.length];
	    for (int k=0; k < entryFields.length; k++) {
		serializedFields[k] = new FieldData(entryFields[k], e);
	    }
	    /* Begin message */
	    o.writeInt(WRITE);
	    /* Sending entry */
	    o.writeObject(entryClass);
	    o.writeObject(serializedFields);
	    /* Sending transaction */
	    if (txn == null) {
		o.writeInt(TRANSACTION_NULL);
	    } else {
		o.writeInt(TRANSACTION_NOT_NULL);
		o.writeUTF(((AcidTransaction) txn).host);
		o.writeInt(((AcidTransaction) txn).port);
		o.writeLong(((AcidTransaction) txn).id);
	    }
	    /* Sending lease request */
	    o.writeLong(lease);
	    o.flush();

	    /* Receiving response */
	    int status = i.readInt();
	    if (status == TRANSACTION_EXCEPTION) {
		throw (TransactionException) i.readObject();
	    }
	    result =  (MadLease) i.readObject();

	} catch (IOException ioe) { 
	    throw new RemoteException("Can't send entry", ioe);

	} catch (ClassNotFoundException cnfe) { //review
	    throw new TransactionException();

	} finally {
	    try {
		o.close();
		i.close();
		s.close();
	    } catch (Exception ex) {}
	}
	
	return result;
    }

    public Entry readIfExists(Entry tmpl, Transaction txn, long timeout) 
	throws TransactionException, RemoteException 
    {
        return getEntry(READ, tmpl, txn, timeout); 
    } 

    public Entry takeIfExists(Entry tmpl, Transaction txn, long timeout)
	throws TransactionException, RemoteException
    {
        return getEntry(TAKE, tmpl, txn, timeout);
    }
    
    public Entry read(Entry tmpl, Transaction txn, long timeout)
	throws TransactionException, RemoteException
    {
        return getEntry(READ_BLOCK, tmpl, txn, timeout); 
    } 

    public Entry take(Entry tmpl, Transaction txn, long timeout)
	throws TransactionException, RemoteException 
    {
        return getEntry(TAKE_BLOCK, tmpl, txn, timeout);
    }
    
    protected Entry getEntry(int mode, Entry tmpl, Transaction txn, 
        long timeout) throws TransactionException, RemoteException
    {
	Entry result = null;

	Socket s = null;
	ObjectOutputStream o = null;
	ObjectInputStream i = null;
 
	try {
	    /* Building serialized template */
	    Class tmplClass = tmpl.getClass();
	    Field[] tmplFields = tmplClass.getFields();
	    Vector wildcardVector = new Vector();
	    Vector fieldVector = new Vector();
	    FieldKey field = null;
	    for (int k = 0; k < tmplFields.length; k++) {
		field = new FieldKey(tmplFields[k], tmpl);
		if (field.key != 0) {
		    fieldVector.add(field);
		} else {
		    wildcardVector.add(field.name);
		}
	    }
	    FieldKey[] fields = 
		(FieldKey[]) fieldVector.toArray(new FieldKey[0]);
	    String[] wildcards =
		(String[]) wildcardVector.toArray(new String[0]);

	    /* Creating a callback */
	    ServerSocket cbListener = new ServerSocket(0);
	    //create a callback object
	    Callback callback = new Callback(
		cbListener.getInetAddress().getHostName(),
		cbListener.getLocalPort(), wildcards, mode);

	    /* Connecting to the server */
	    s = new Socket (host, port);
	    o = new ObjectOutputStream(
		new BufferedOutputStream(s.getOutputStream()));
	    o.flush();
	    i = new ObjectInputStream(s.getInputStream());

	    /* Begin message */
	    o.writeInt(GET_ENTRY);
	    o.writeInt(mode);
	    /* Sending template */
	    o.writeObject(tmplClass);
	    o.writeObject(fields);
	    /* Sending transaction */
	    if (txn == null) {
		o.writeInt(TRANSACTION_NULL);
	    } else {
		o.writeInt(TRANSACTION_NOT_NULL);
		o.writeUTF(((AcidTransaction) txn).host);
		o.writeInt(((AcidTransaction) txn).port);
		o.writeLong(((AcidTransaction) txn).id);
	    }
	    /* Sending timeout */
	    o.writeLong(timeout);
	    /* Sending callback */
	    o.writeObject(callback);
	    o.flush();

	    /* Receiving results */
	    int status = i.readInt();
	    if (status == WAIT) {
		//Callback!
		//close socket
		o.close();
		i.close();
		s.close();
		//wait for a connection
		s = cbListener.accept();
		//estabilish the connection
		o = new ObjectOutputStream(
		    new BufferedOutputStream(s.getOutputStream()));
		o.flush();
		i = new ObjectInputStream(s.getInputStream());
		//continue
		//Should read status again?
	    }
	    if (status == TRANSACTION_EXCEPTION) {
		throw (TransactionException) i.readObject();
	    }
	    if (status == NO_ENTRY) {
		return null;
	    }
	    FieldData[] received = (FieldData[]) i.readObject();
	    if (received != null) {
		result = tmpl;//review: result = tmpl.clone();
		Object value = null;
		for (int k = 0; k < received.length; k++) {
		    value = received[k].marshal.get();
		    tmplClass.getField(received[k].name).set(result, value);
		}
	    }
	    if (received == null && callback.wildcards.length == 0) {
		result = tmpl;//review: result = tmpl.clone();
	    }

	} catch (IOException ioe) { 
	    throw new RemoteException("Can't send entry", ioe);

	} catch (IllegalAccessException iae) { //review
	    iae.printStackTrace();
	    
	} catch (ClassNotFoundException cnfe) { //review
	    cnfe.printStackTrace();

	} catch (NoSuchFieldException nsfe) { //review
	    nsfe.printStackTrace();
	
	} finally {
	    try {
		o.close();
		i.close();
		s.close();
	    } catch (Exception ex) {}
	}

        return result;
    }

    public EventRegistration notify (Entry tmpl, Transaction txn,
	RemoteEventListener listener, long lease, MarshalledObject handback)
	throws TransactionException, RemoteException
    {
	EventRegistration result = null;

	Socket s = null;
	ObjectOutputStream o = null;
	ObjectInputStream i = null;
 
	try {
	    /* Building serialized template */
	    Class tmplClass = tmpl.getClass();
	    Field[] tmplFields = tmplClass.getFields();
	    Vector wildcardVector = new Vector();
	    Vector fieldVector = new Vector();
	    FieldKey field = null;
	    for (int k = 0; k < tmplFields.length; k++) {
		field = new FieldKey(tmplFields[k], tmpl);
		if (field.key != 0) {
		    fieldVector.add(field);
		} else {
		    wildcardVector.add(field.name);
		}
	    }
	    FieldKey[] fields = 
		(FieldKey[]) fieldVector.toArray(new FieldKey[0]);
	    String[] wildcards =
		(String[]) wildcardVector.toArray(new String[0]);

	    /* Connecting to the server */
	    s = new Socket (host, port);
	    o = new ObjectOutputStream(
		new BufferedOutputStream(s.getOutputStream()));
	    o.flush();
	    i = new ObjectInputStream(s.getInputStream());

	    /* Begin message */
	    o.writeInt(NOTIFY);
	    /* Sending template */
	    o.writeObject(tmplClass);
	    o.writeObject(fields);
	    o.writeObject(wildcards);
	    /* Sending transaction */
	    if (txn == null) {
		o.writeInt(TRANSACTION_NULL);
	    } else {
		o.writeInt(TRANSACTION_NOT_NULL);
		o.writeUTF(((AcidTransaction) txn).host);
		o.writeInt(((AcidTransaction) txn).port);
		o.writeLong(((AcidTransaction) txn).id);
	    }
	    /* Sending listener */
	    o.writeObject(listener);
	    /* Sending lease */
	    o.writeLong(lease);
	    /* Sending handback */
	    o.writeObject(handback);
	    o.flush();

	    /* Receiving results */
	    int status = i.readInt();
	    if (status == TRANSACTION_EXCEPTION) {
		throw (TransactionException) i.readObject();
	    }
	    result = (EventRegistration) i.readObject();

	} catch (IOException ioe) { 
	    throw new RemoteException("Can't send entry", ioe);

	} catch (ClassNotFoundException cnfe) { //review
	    throw new TransactionException();

	} finally {
	    try {
		o.close();
		i.close();
		s.close();
	    } catch (Exception ex) {}
	}
	
	return result;
    }

    /** NOT IMPLEMENTED. */
    public Entry snapshot(Entry e) {
	return null;
    }

}
