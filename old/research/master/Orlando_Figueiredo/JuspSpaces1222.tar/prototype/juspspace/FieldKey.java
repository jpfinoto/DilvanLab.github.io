
package juspspace;

import java.rmi.MarshalledObject;
import java.lang.reflect.*;
import java.io.Serializable;

import net.jini.core.entry.Entry;
import net.jini.space.InternalSpaceException;

/**
 * The field key of an entry instance, and the field name.
 * 
 * @author Agents Research
 */
class FieldKey implements Serializable {
    public String name;
    public long key;

    FieldKey(Field field, Entry entry) {
	try {
	    name = field.getName();
	    Object value = field.get(entry);
	    if (value == null) {
		key = 0;
	    } else {
	        key = KeyGenerator.getKey(value);
	    }
	} catch (Exception e) {
	    throw new InternalSpaceException("Cannot marshal entry", e);
	}
    }

    FieldKey(String name) {
        this.name = name;
	this.key = -1;
    }
}
