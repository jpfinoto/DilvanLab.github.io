/* O B S O L E T E   Must be discarded */
package juspspace;

import java.rmi.*;

import net.jini.core.entry.*;
import net.jini.core.event.*;
import net.jini.core.lease.*;
import net.jini.core.transaction.*;

/** JuspSpace is a persistent tuple space for Java.
 *  JuspSpace is very similar to JavaSpaces technology,
 *  from Sun Microsystems. The main difference is that
 *  JuspSpaces does not use Jini lookup and remote events.
 *
 *  @author Agents Research
 */
public interface JuspSpace {

    /** 
     *  Writes an entry into the space. 
     *  @param e An entry to be written in the space.
     */
    public Lease write(Entry e, Transaction txn, long lease) throws
        TransactionException, RemoteException;

    /** 
     *  Reads an entry from the space that matches a template,
     *  if the entry exists in the space.
     *  @param tmpl A template for retrieve an entry.
     */
    public Entry readIfExists (Entry tmpl, Transaction txn, long timeout)
        throws TransactionException, RemoteException;

    /**
     *  Takes an entry from the space that matches a template,
     *  if the entry exists in the space.
     *  @param tmpl A template for retrieve an entry.
     */
    public Entry takeIfExists (Entry tmpl, Transaction txn, long timeout)
        throws TransactionException, RemoteException;

    /** 
     *  Reads an entry from the space that matches a template,
     *  if the entry exists in the space.
     *  @param tmpl A template for retrieve an entry.
     */
    public Entry read (Entry tmpl, Transaction txn, long timeout) 
        throws TransactionException, RemoteException;

    /**
     *  Takes an entry from the space that matches a template,
     *  if the entry exists in the space.
     *  @param tmpl A template for retrieve an entry.
     */
    public Entry take (Entry tmpl, Transaction txn, long timeout)
        throws TransactionException, RemoteException;

    public EventRegistration notify (Entry tmpl, Transaction txn,
	RemoteEventListener listener, long lease, MarshalledObject handback)
	throws TransactionException, RemoteException;
}
