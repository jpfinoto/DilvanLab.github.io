
package juspspace;

import java.sql.*;
import java.io.*;
import java.util.*;
import java.rmi.*;
import java.lang.reflect.*;

import net.jini.space.InternalSpaceException;

/**
 * Implements Repository with a SQL database and JDBC.
 *
 * @author Agents Research
 */
public class SqlRepository implements Repository {

    protected String url;
    protected String uid;
    protected String password;

    public SqlRepository(String driver, String url, String uid, String password) {

	try {
	    Class.forName(driver).newInstance();
	} catch (Exception e) {
	    throw new InternalSpaceException("Cannot load jdbc driver", e);
	}

	this.url = url;
	this.uid = uid;
	this.password = password;

	try {
	    Connection con = DriverManager.getConnection(url, uid, password);

	    boolean cleanOldTables = true;

	    /* Lookup for the GROUPS table; create if necessary */
            DatabaseMetaData metaData = con.getMetaData();
            ResultSet rs = metaData.getTables(null, null, "Groups", null);
            if ( !rs.next() ) {
		String t = //review: varchar(20)?
		    "CREATE TABLE Groups (Base VARCHAR(20), Child VARCHAR(20))";
		Statement st = con.createStatement();
		st.executeUpdate(t);

		cleanOldTables = false;
	    }

	    /* Lookup for the TXNS table; create if necessary */
            rs = metaData.getTables(null, null, "Txns", null);
            if ( !rs.next() ) {
		String t = "CREATE TABLE Txns (TxnId BIGINT, " + 
		    "Status VARCHAR(10), HasChanged CHAR(1))"; 
		Statement st = con.createStatement();
		st.executeUpdate(t);
	    }

	    //todo: cleanup tables
	    if (cleanOldTables) {

	    }

	    con.close();

	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot initialize tables", sqle);
	}
    }

    // See javadoc in the interface
    public Object getLock() {
	Connection con = null;

	try {
	    con = DriverManager.getConnection(url, uid, password);

	    con.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
	    con.setAutoCommit(false);

	} catch (SQLException sqle) {
	    throw new InternalSpaceException(
		"Cannot connect database or configure isolation level" , sqle);
	}

	return con;
    }	

    // See javadoc in the interface
    public void releaseLock(Object lock) {
	Connection con = (Connection) lock;

	try {
	    con.commit();
	    con.close();

	} catch (SQLException sqle) {
	    try {
		con.rollback();
		con.close();
	    } catch (Exception e) {};
	    throw new InternalSpaceException("Cannot commit", sqle);
	}
    }

    // See javadoc in the interface
    public String getGroup(Object lock, Class entryClass) {
	Connection con = (Connection) lock;
	
	String result = null;

	try {
	    String s = Long.toString(KeyGenerator.getKey(entryClass));
	    s = s.replace('-','M');

	    Statement st = con.createStatement();
	    String q = "SELECT Base FROM GROUPS WHERE Base = '" + s + "'";
	    ResultSet rs = st.executeQuery(q);
	    if (rs.next()) {
	        result = s;
	    } else {
		result = createGroupsForClassAndSuperclasses(lock, entryClass);
	    }
	} catch (Exception e) {
	    throw new InternalSpaceException(
		"Cannot query database or calculate key", e);
	} 

	return result;
    }

    // See javadoc in the interface
    public String[] getAllGroups(Object lock) {
	Connection con = (Connection) lock;

	String[] results = null;

	/* Get all tables */
	String q = "SELECT DISTINCT Base FROM GROUPS";
	try {
	    Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery(q);
	    int resultSize = rs.getFetchSize();
	    results = new String[resultSize];
	    rs.next();
	    for (int i = 0; i < resultSize; i++, rs.next()) {
		results[i] = rs.getString(1);
	    }
	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot query database", sqle);
	}

	return results;
    }

    // See javadoc in the interface
    public String[] getGroupsForClassAndSuperclasses(Object lock, 
	Class entryClass) 
    {
	Connection con = (Connection) lock;

	String[] results = null;

	try {
	    String s = Long.toString(KeyGenerator.getKey(entryClass));
	    s = s.replace('-', 'M');

	    Statement st = con.createStatement();
	    String q = "SELECT * FROM GROUPS WHERE Base = '" + s + "'";
	    ResultSet r = st.executeQuery(q);
	    if (!r.next()) {
		createGroupsForClassAndSuperclasses(lock, entryClass);
	    }
	    Vector v = new Vector();
	    String child = s;
	    while (true) {
		v.add(child);
		q = "SELECT Base FROM GROUPS WHERE Child = '" + child + "'";
		r = st.executeQuery(q);
		if (!r.next()) {
		    break;
		} else {
		    child = r.getString(1);
		}
	    }
	    results = (String[]) v.toArray(new String[0]);
	} catch (Exception e) {
	    throw new InternalSpaceException("Cannot query database", e);
	} 
	
	return results;
    }

    // See javadoc in the interface
    public String[] getGroupsForClassAndSubclasses(Object lock, 
	Class entryClass)
    {
	Connection con = (Connection) lock;

	String[] results = null;

	try {
	    String s = Long.toString(KeyGenerator.getKey(entryClass));
	    s = s.replace('-', 'M');

	    Statement st = con.createStatement();
	    String q = "SELECT * FROM GROUPS WHERE Base = '" + s + "'";
	    ResultSet r = st.executeQuery(q);
	    if (!r.next()) {
		createGroupsForClassAndSuperclasses(lock, entryClass);
	    }
	    String base = s;
	    Vector v = new Vector();
	    v.add(base);
	    int cursor = 1;
	    String aux = null;
	    while (true) {
		q = "SELECT Child FROM GROUPS WHERE Base = '" + base + "'";
		r = st.executeQuery(q);
		while (r.next()) {
		    aux = r.getString(1);
		    if (!aux.equals("nihil")) {
			v.add(aux);
		    }
		}
		if (v.size() == cursor) {
		    break;
		}
		base = (String) v.elementAt(cursor++);
	    }
	    results = (String[]) v.toArray(new String[0]);
	  
	} catch (Exception e) {
	    throw new InternalSpaceException("Cannot create table", e);
	} 

	return results;
    }

    /**
     * Creates a group corresponding to the entry class. Also creates the
     * groups for the entry superclasses, if necessary.
     * @param entryClass the class
     * @return the created group
     */
    protected String createGroupsForClassAndSuperclasses(Object lock, 
	Class entryClass) throws Exception 
    {
	Connection con = (Connection) lock;

	Vector cls = new Vector();
	Vector grp = new Vector();
	Class e = Class.forName("net.jini.core.entry.Entry");
	Class o = Class.forName("java.lang.Object");
	Class c = entryClass;
	while (e.isAssignableFrom(c) && !o.equals(c)) {
	    cls.add(c);
	    grp.add(
		(Long.toString(KeyGenerator.getKey(c))).replace('-','M'));
	    c = c.getSuperclass();
	}
	Class[] classes = (Class[]) cls.toArray(new Class[0]);
	String[] groups = (String[]) grp.toArray(new String[0]);

	Statement st = con.createStatement();
	for (int k = 0; k < groups.length; k++) {
	    Field[] fields = classes[k].getFields();
	    String q = "SELECT Base FROM GROUPS WHERE Base = '" + 
		groups[k] + "'";
	    ResultSet r = st.executeQuery(q);
	    if (r.next()) {
		break;
	    }
	    String t = "CREATE TABLE E" + groups[k] + " (Id BIGINT, " +
		"Time BIGINT, Lease BIGINT, WTxn BIGINT, TTxn BIGINT";
	    for (int i = 0; i < fields.length ; i++) {
		t = t + ", " + fields[i].getName() + "Field BIGINT, " +
		    fields[i].getName() + "Data OID";
	    }
	    t = t + ")";
	    st.executeUpdate(t);
	    t = "CREATE TABLE R" + groups[k] + 
		" (RId BIGINT, RTxn BIGINT)";
	    st.executeUpdate(t);
	    t = "CREATE TABLE T" + groups[k] + " (Id BIGINT, Type CHAR(1), " +
		"Time BIGINT, Expiration BIGINT, Txn BIGINT, Number BIGINT, " +
		"Obj1 OID, Obj2 OID";
	    for (int i = 0; i < fields.length ; i++) {
		t = t + ", " + fields[i].getName() + "Field BIGINT"; 
	    }
	    t = t + ")";
	    st.executeUpdate(t);
	}
	String child = "nihil";
	for (int k = 0; k < groups.length; k++) {
	    String q = "SELECT Base FROM GROUPS WHERE Base = '" + 
		groups[k] + "' AND Child = '" + child + "'";
	    ResultSet r = st.executeQuery(q);
	    if (r.next()) {
		break;
	    }
	    String in = "INSERT INTO GROUPS VALUES ('" + groups[k] + 
		"', '" + child + "')";
	    st.executeUpdate(in);
	    child =  groups[k];
	}
	return groups[0];
    }

    
    // See javadoc in the interface
    public void insertEntryAndMark(Object lock, XId xid, FieldData[] fields, 
	long txnId, long lease) 
    {
	Connection con = (Connection) lock;
	//review: filter sql prohibited characters in fields

        try {
	    /* Insert the entry into the table */
	    String insertInto = "INSERT INTO E" + xid.group + 
		" VALUES (?, ?, ?, ?, ?";
	    for (int i = 0; i < fields.length; i++) {
	        insertInto = insertInto + ", ?, ?";
	    }
	    insertInto = insertInto + ")";
	    PreparedStatement pstmt = con.prepareStatement(insertInto);
	    for (int i = 0; i < fields.length; i++) {
	        pstmt.setLong(6 + 2 * i, fields[i].key);
	    }
	    pstmt.setLong(1, xid.id);
	    pstmt.setLong(2, System.currentTimeMillis());
	    pstmt.setLong(3, lease);
	    pstmt.setLong(4, txnId);
	    pstmt.setLong(5, 0);//TTxn column
	    ByteArrayOutputStream bottom;
	    ObjectOutputStream top;
	    byte[] mem;
	    ByteArrayInputStream in; 
	    for (int i = 0; i < fields.length; i++) {
	        bottom = new ByteArrayOutputStream();
		top = new ObjectOutputStream(bottom);
	        top.writeObject(fields[i].marshal);
		mem = bottom.toByteArray();
	        in = new ByteArrayInputStream(mem);
		pstmt.setBinaryStream(7 + 2 * i, in, mem.length);
	    }
	    pstmt.executeUpdate();
	    pstmt.close();

	    String insertIntoRead = "INSERT INTO R" + xid.group + 
		" VALUES (" + xid.id + ", 0)";
	    //System.out.println(insertIntoRead);//debug
	    Statement st = con.createStatement();
	    st.executeUpdate(insertIntoRead);
	    st.close();
	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot update database", sqle);
	} catch (IOException ioe) {
	    throw new InternalSpaceException("Cannot write blob", ioe);
	}
    }

    // See javadoc in the interface
    public XId findEntry(Object lock, String group, FieldKey[] fields, 
	long txnId, boolean free, int mode) 
    { 
	Connection con = (Connection) lock;

	XId result = null;

	/* Creates query - transaction part */
	String q = "";
	String extra = "";
	String extra2 = "";
	if (free && (mode == READ || mode == READ_BLOCK) && txnId == 0) {
	    q = " (WTxn = 0) AND (TTxn = 0) ";
	} else 
	if (free && (mode == READ || mode == READ_BLOCK) && txnId != 0) {
	    q = " ((WTxn = 0) AND (TTxn = 0)) OR " + 
		" ((WTxn = " + txnId + ") AND (TTxn = 0)) ";
	} else
	if (free && (mode == TAKE || mode == TAKE_BLOCK) && txnId == 0) {
	    q = " (WTxn = 0) AND (TTxn = 0) AND (RTxn = 0) ";
	    extra = ", R" + group;
	    extra2 = "AND (Id = RId)";
	} else
	if (free && (mode == TAKE || mode == TAKE_BLOCK) && txnId != 0) {
	    q = " ((WTxn = 0) AND (TTxn = 0) AND (RTxn = 0)) OR " + 
		"((WTxn = " + txnId + ") AND (TTxn = 0) AND (RTxn = 0)) OR " +
		"((WTxn = " + txnId + ") AND (TTxn = 0) AND (RTxn = " + 
		txnId + "))";
	    extra = ", R" + group;
	    extra2 = "AND (Id = RId)";
	} else
	if (!free && (mode == READ || mode == READ_BLOCK) && txnId == 0) {
	    q =  " (WTxn = " + txnId + ") OR (TTxn = " + txnId + ") ";
	} else
	if (!free && (mode == READ || mode == READ_BLOCK) && txnId != 0) {
	    q = " ((WTxn = 0) AND (TTxn <> " + txnId + ") OR " + 
		" (WTxn <> " + txnId + ") " ;
	} else
	if (!free && (mode == TAKE || mode == TAKE_BLOCK) && txnId == 0) {
	    q = " ((WTxn = 0) AND (TTxn = " + txnId + ")) OR " + 
		" ((WTxn = 0) AND (RTxn = " + txnId + ")) OR " + 
		" (WTxn = " + txnId + ") ";
	    extra = ", R" + group;
	    extra2 = "AND (Id = RId)";
	} else 
	if (!free && (mode == TAKE || mode == TAKE_BLOCK) && txnId != 0) {
	    q = " ((WTxn = 0) AND (TTxn <> " + txnId + ") OR " + 
		" (WTxn <> " + txnId + ") OR " + 
		" (RTxn <> " + txnId + ") ";
	    extra = ", R" + group;
	    extra2 = "AND (Id = RId)";
	}

	/* Creates query - main part */
        String select = "SELECT Id FROM E" + group + extra + " WHERE ";
	if (fields.length > 0) {
	    select = select + fields[0].name + "Field = " + 
		fields[0].key; 
	    for (int i = 1; i < fields.length; i++) {
		select = select + " AND " + fields[i].name + "Field = " + 
		fields[i].key;
	    }
	    select = select + " AND ";
	}
	select = select + "(" + q + ") " + extra2;
	//System.out.println(select); //debug

	try {
	    /* Executes query */
            Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery(select);

	    /* Builds result */
	    if (rs.next()) { //review: more than one row could be retrieved
		result = new XId(group, rs.getLong(1));
	    }
            st.close();

	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot query database", e);
	}

	return result;
    }

    // See javadoc in the interface
    public FieldData[] getFields(Object lock, XId xid, String[] wildcards) {
	Connection con = (Connection) lock;

	FieldData[] results = null;

	if (wildcards.length == 0) {
	    return results;
	}

	/* Creates query */
        String select = "SELECT " + wildcards[0] + "Data ";
	for (int i = 1; i < wildcards.length; i++) {
	    select = select + ", " + wildcards[i] + "Data ";
	}
	select = select + " FROM E" + xid.group + " WHERE Id = " + xid.id;

	try {
	    /* Executes query */
            Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery(select);

	    /* Builds result */
	    if (rs.next()) { //review: more than one row could be retrieved
	        try {
		    results = new FieldData[wildcards.length];
		    InputStream is = null;
		    ObjectInputStream ois = null;
		    for (int i = 0; i < wildcards.length; i++) {
		        is = rs.getBinaryStream(i + 1);
			ois = new ObjectInputStream(is);
			results[i] = new FieldData(wildcards[i],
			    (MarshalledObject) ois.readObject());
	    	        ois.close();
		    }
		} catch (IOException ex) {
		    ex.printStackTrace(); //review
		} catch (ClassNotFoundException cnfe) {
		    cnfe.printStackTrace(); //review
		}
		rs.close();
	    } 
            st.close();

	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot query database", e);
	}

	return results;
    }

    // See javadoc in the interface
    public void removeEntry(Object lock, XId xid) {
	Connection con = (Connection) lock;

	String d = "DELETE FROM E" + xid.group + " WHERE Id = " + xid.id; 

        try {
	    Statement st = con.createStatement();
	    st.executeUpdate(d);
	    st.close();
	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot update database", e);
	}
    }

    // See javadoc in the interface
    public long [] getEntriesWrittenUnderTransaction(Object lock, 
	String group, long txnId)
    {
	String q = "SELECT Id FROM E" + group + " WHERE WTxn = " + txnId;
	return getEntriesByQuery(lock, q);
    }

    // See javadoc in the interface
    public long [] getEntriesTakenUnderTransaction(Object lock,
	String group, long txnId)
    {
	String q = "SELECT Id FROM E" + group + " WHERE TTxn = " + txnId;
	return getEntriesByQuery(lock, q);
    }

    // See javadoc in the interface
    public long [] getEntriesReadUnderTransaction(Object lock,
	String group, long txnId)
    {
	String q = "SELECT Id FROM R" + group + " WHERE RTxn = " + txnId;
	return getEntriesByQuery(lock, q);
    }

    /** Missing javadoc.*/
    protected long [] getEntriesByQuery(Object lock, String query) {
	Connection con = (Connection) lock;

	long [] results = null;

	try {
	    Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery(query);
	    int resultSize = rs.getFetchSize();
	    results = new long[resultSize];
	    rs.next();
	    for (int i = 0; i < resultSize; i++, rs.next()) {
		results[i] = rs.getLong(1);
	    }
	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot query database", sqle);
	}; 

	return results;
    }

    //See javadoc in the interface
    public void incrementEntryLease(Object lock, XId xid, long duration) {
	Connection con = (Connection) lock;

	String u = "UPDATE E" + xid.group + " SET Lease = Lease + " + duration +
	    " WHERE id = " + xid.id;
	try {
	    Statement st = con.createStatement();
	    st.executeUpdate(u);
	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot update database", sqle);
	}

    }

    //See javadoc in the interface
    public void removeExpiredEntries(Object lock, String group) 
    {
	Connection con = (Connection) lock;

	long now = System.currentTimeMillis();
	String d = "DELETE FROM E" + group + " WHERE Time + Lease < " + now;

	try {
	    Statement ds = con.createStatement();
	    ds.executeUpdate(d);
	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot update database", sqle);
	}
    }


    // See javadoc in the interface
    public long insertTemplate(Object lock, XId xid, FieldKey[] fields, 
	long txnId, long expiration, Object obj1, Object obj2, String tmplType)
    {
	Connection con = (Connection) lock;
	//review: filter sql prohibited characters in fields

	String insert = "INSERT INTO T" + xid.group + 
	    " (Id, Type, Time, Expiration, Txn, Number, Obj1, Obj2, ";
	for (int i = 0; i < fields.length; i++) {
	    insert = insert + ", " + fields[i].name + "Field";
	}
	insert = insert + ")  VALUES (?, ?, ?, ?, ?, ?, ?, ?";
	for (int i = 0; i < fields.length; i++){
	    insert = insert + ", ?";
	}
	insert = insert + ")";

	try {
	    PreparedStatement pstmt = con.prepareStatement(insert);

	    pstmt.setLong(1, xid.id);
	    pstmt.setString(2, tmplType);
	    pstmt.setLong(3, System.currentTimeMillis());
	    pstmt.setLong(4, expiration);
	    pstmt.setLong(5, txnId);
	    pstmt.setLong(6, 1);
	    for (int k = 0; k < fields.length; k++) {
	        pstmt.setLong(k + 9, fields[k].key);
	    }
	    ByteArrayOutputStream bottom = new ByteArrayOutputStream();
	    ObjectOutputStream top = new ObjectOutputStream(bottom);
	    top.writeObject(obj1);
	    byte[] mem = bottom.toByteArray();
	    ByteArrayInputStream in = new ByteArrayInputStream(mem);
	    pstmt.setBinaryStream(7, in, mem.length);
	    bottom = new ByteArrayOutputStream();
	    top = new ObjectOutputStream(bottom);
	    top.writeObject(obj2);
	    mem = bottom.toByteArray();
	    in = new ByteArrayInputStream(mem);
	    pstmt.setBinaryStream(8, in, mem.length);

	    pstmt.executeUpdate();
	    pstmt.close();

	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot update database", sqle);
	} catch (IOException ioe) {
	    throw new InternalSpaceException("Cannot write blob", ioe);
	}
	//review: **ERROR** must return a sequence number
	return 0;
    }

    //See javadoc in the interface
    public XId[] findTemplates(Object lock, String group, FieldKey[] fields, 
	long txnId, String type) 
    {
	Connection con = (Connection) lock;

	XId[] results = null;

	/* Build query */
	String select = "SELECT Id FROM T" + group + 
	    " WHERE (" + fields[0].name + "Field = " + fields[0].key + 
	    " OR " + fields[0].name + "Field = 0";
	for (int i = 1; i < fields.length; i++) {
	    select = select + ") AND (" + fields[i].name + "Field = " + 
		fields[i].key + " OR " + fields[i].name + "Field = 0";
	}
	select = select + ") AND (Type = '" + type + "')";
	if (txnId != 0) {
	    select = select + " AND (TxnId = '" + txnId + "')";
	}
	//System.out.println(select);//debug

	try {
            Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery(select);

	    if (rs.next()) {
		if (type == "T") {
		    results = new XId[1];
		    results[0] = new XId(group, rs.getLong(1));
		} else {
		    int resultSize = rs.getFetchSize();
		    results = new XId[resultSize];
		    for (int i = 0; i < resultSize; i++, rs.next()) {
			results[i] = new XId(group, rs.getLong(1));
		    }
		}
	    }
            st.close();

	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot query database", e);
	}

	return results;
    }

    //See javadoc in the interface
    public TemplateData getTemplateData(Object lock, XId xid) {
	Connection con = (Connection) lock;

	TemplateData result = null;

	/* Build query */
	String select = "SELECT Type, Id, Number, Obj1, Obj2 FROM E" + 
	    xid.group + " WHERE Id = " + xid.id;

	try {
            Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery(select);

	    /* Analysis of result */
	    if (rs.next()) { 
		result = new TemplateData();
	    	result.type = rs.getString(1);
		result.xid = xid; // need some refactoring here
		result.number = rs.getLong(3);
		InputStream is = rs.getBinaryStream(4);
		ObjectInputStream ois = new ObjectInputStream(is);
		result.obj1 = ois.readObject();
		is = rs.getBinaryStream(5);
		ois = new ObjectInputStream(is);
		result.obj2 = ois.readObject();
	    	ois.close();
	    } 
            st.close();

	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot query database", e);
	} catch (IOException ioe) {
	    throw new InternalSpaceException("Cannot read blob", ioe);
	} catch (ClassNotFoundException cnfe) {
	    throw new InternalSpaceException("Cannot read blob", cnfe);
	}

	return result;
    }

    //See javadoc in the interface
    public void removeTemplate(Object lock, XId xid) {
	Connection con = (Connection) lock;
	
	String d = "DELETE FROM E" + xid.group + " WHERE Id = " + xid.id; 

        try {
	    Statement st = con.createStatement();
	    st.executeUpdate(d);
	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot update database", e);
	}

    }

    //See javadoc in the interface
    public long[] getExpiredTemplates(Object lock, String group) {
	Connection con = (Connection) lock;

	long[] results = null;

	String q = "SELECT Id FROM T" + group + " WHERE Time + Expiration < " + 
	    System.currentTimeMillis();

	try {
	    Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery(q);
	    int resultSize = rs.getFetchSize();
	    results = new long[resultSize];
	    rs.next();
	    for (int i = 0; i < resultSize; i++, rs.next()) {
		results[i] = rs.getLong(1);
	    }
	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot query database", sqle);
	}

	return results;
    }


    //See javadoc in the interface
    public void registerTransaction(Object lock, long txnId) {
	Connection con = (Connection) lock;

	String i = "INSERT INTO Txns (" + txnId + ", 'ACTIVE', 'N')";

	try {
	    Statement st = con.createStatement();
	    st.executeUpdate(i);
	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot update database", e);
	}
    }

    //See javadoc in the interface
    public void unregisterTransaction(Object lock, long txnId) {
	Connection con = (Connection) lock;

	String i = "DELETE FROM Txns WHERE TxnId = " + txnId;

	try {
	    Statement st = con.createStatement();
	    st.executeUpdate(i);
	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot update database", e);
	}
    }

    //See javadoc in the interface
    public String getTransactionState(Object lock, long txnId) {
	Connection con = (Connection) lock;

	String result = null;

	String s = "SELECT State FROM Txns WHERE TxnId = " + txnId;

	try {
	    Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery(s);
	    if (rs.next()) {
		result = rs.getString(1);
	    }
	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot query database", e);
	}
	return result;
    } //review: it's bad to return a null...

    //See javadoc in the interface
    public void setTransactionState(Object lock, long txnId, String state) {
	Connection con = (Connection) lock;
	
	String s = "UPDATE Txns SET State = " + state + 
	    " WHERE TxnId = " + txnId;

	try {
	    Statement st = con.createStatement();
	    st.executeUpdate(s);
	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot update database", e);
	}
    }

    //See javadoc in the interface
    public boolean isTransactionRegistered(Object lock, long txnId) {
	Connection con = (Connection) lock;

	String s = "SELECT Status FROM Txns WHERE TxnId = " + txnId; 

	try {
	    Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery(s);
	    if (rs.next()) {
		return true;
	    } 
	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot query database", e);
	}

	return false;
    }

    //See javadoc in the interface
    public boolean isTransactionActive(Object lock, long txnId) {
	Connection con = (Connection) lock;

	String s = "SELECT Status FROM Txns WHERE TxnId = " + txnId; 

	try {
	    Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery(s);
	    if (rs.next()) {
	    	String status = rs.getString(1);
		if (status == "ACTIVE") { 
		    return true;
		}
	    }
	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot query database", e);
	}

	return false;
    }

    //See javadoc in the interface
    public void putTakenMark(Object lock, XId xid, long txnId) {
	String sentence = "UPDATE E" + xid.group + " SET TTxn = " + txnId + 
	    "  WHERE Id = " + xid.id;
	removeMarkBySentence(lock, sentence);
    }

    //See javadoc in the interface
    public void putReadMark(Object lock, XId xid, long txnId) {
	Connection con = (Connection) lock;

	String update = "DELETE FROM R" + xid.group + " WHERE RId = " 
	    + xid.id + " AND RTxn = 0";
	try {
	    Statement st = con.createStatement();
	    st.executeUpdate(update);
	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot update database", sqle);
	}

	String sentence = "INSERT INTO R" + xid.group + 
	    " VALUES (" + xid.id + ", " + txnId + " )";
	removeMarkBySentence(lock, sentence);
    }

    //See javadoc in the interface
    public void removeWrittenMark(Object lock, XId xid) {
	String sentence = 
	    "UPDATE E" + xid.group + " SET WTxn = 0 WHERE Id = " + xid.id;
	removeMarkBySentence(lock, sentence);
    }

    //See javadoc in the interface
    public void removeTakenMark(Object lock, XId xid) {
	String sentence = 
	    "UPDATE E" + xid.group + " SET TTxn = 0 WHERE Id = " + xid.id;
	removeMarkBySentence(lock, sentence);
    }

    //See javadoc in the interface
    public void removeReadMark(Object lock, XId xid, long txnId) {
	Connection con = (Connection) lock;

	String q = "SELECT RTxn FROM R" + xid.group + " WHERE RId = " +
	    xid.id + " AND RTxn <> " + txnId;
	try {
	    Statement st = con.createStatement();
	    ResultSet rs = st.executeQuery(q);
	    if (rs.next()) {
		String ins = "INSERT INTO R" + xid.group + " VALUES (" + 
		    xid.id + ", 0)";
		st.executeUpdate(ins);
	    }
	    st.close();
	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot update database", sqle);
	}

	String sentence = "DELETE FROM R" + xid.group + " WHERE RId = " + 
	    xid.id + " AND RTxn = " + txnId;
	removeMarkBySentence(lock, sentence);
    }

    /** Missing javadoc. */
    protected void removeMarkBySentence(Object lock, String sentence) {
	Connection con = (Connection) lock;

	try {
	    Statement st = con.createStatement();
	    st.executeUpdate(sentence);
	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot update database", sqle);
	}
    }


/*
    public EventRegistration notify(String type, FieldKey[] fields, 
	Transaction txn, RemoteEventListener listener, long lease,
	MarshalledObject handback) throws TransactionException
    {
	EventRegistration result = null;
	type = "N" + type.replace('-','M').substring(0,4);
	//review: filter sql prohibited characters in fields
	if (lease == Lease.ANY) {
	    lease = 24 * 60 * 60 * 1000;
	}
        try {
	    // Transaction preamble 
	    TransactionData td = null;
	    Connection con = null;
	    if (txn != null) {
	        td = getTransactionData(txn);
		if (td  == null) {
		    td = newTransactionData(txn);
		}
		con = td.con;
	    } else {
	        con = DriverManager.getConnection(url, uid, password);
		con.setTransactionIsolation(
		    Connection.TRANSACTION_SERIALIZABLE);
		con.setAutoCommit(false);
	    }

	    // Insert the template into the table
	    String insertInto = "INSERT INTO " + type + 
	        " (Time, Lease, Listener, Handback, Number";
	    for (int i = 0; i < fields.length; i++) {
	        insertInto = insertInto + ", " + fields[i].name + "Field";
	    }
	    insertInto = insertInto + ")  VALUES (?, ?, ?, ?, ?";
	    for (int i = 0; i < fields.length; i++) {
	        insertInto = insertInto + ", ?";
	    }
	    insertInto = insertInto + ");";
	    PreparedStatement pstmt = con.prepareStatement(insertInto);
	    long evID = System.currentTimeMillis();
	    pstmt.setLong(1, evID);
	    pstmt.setLong(2, lease);
	    ByteArrayOutputStream bottom = new ByteArrayOutputStream();
	    ObjectOutputStream top = new ObjectOutputStream(bottom);
	    top.writeObject(listener);
	    byte[] mem = bottom.toByteArray();
	    ByteArrayInputStream in = new ByteArrayInputStream(mem);
	    pstmt.setBinaryStream(3, in, mem.length);
	    bottom = new ByteArrayOutputStream();
	    top = new ObjectOutputStream(bottom);
	    top.writeObject(handback);
	    mem = bottom.toByteArray();
	    in = new ByteArrayInputStream(mem);
	    pstmt.setBinaryStream(4, in, mem.length);
	    pstmt.setLong(5, 1);
	    for (int i = 0; i < fields.length; i++) {
	        pstmt.setLong(i + 6, fields[i].key);
	    }
	    pstmt.executeUpdate();
	    pstmt.close();
	    // Build result
	    result = new EventRegistration(evID , null, null, 1);
	    // Transaction epilogue
	    if (td != null) {
	        td.hasChanged = true;
	    } else {
	        con.commit();
		con.close();
	    }
	} catch (SQLException sqle) {
	    throw new InternalSpaceException("Cannot store the template", sqle);
	} catch (IOException ioe) {
	    throw new InternalSpaceException("Cannot store the template", ioe);
	}
	return result;
    }

    public EventData[] readTemplateNotify(String type, FieldKey[] fields, 
        Transaction txn) throws TransactionException
    {
	EventData[] results = null;
	type = "N" + type.replace('-','M').substring(0,4);
        try {
	    // Transaction preamble
	    TransactionData td = null;
	    Connection con = null;
	    if (txn != null) {
	        td = getTransactionData(txn);
		if (td  == null) {
		    td = newTransactionData(txn);
		}
		con = td.con;
	    } else {
	        con = DriverManager.getConnection(url, uid, password);
		con.setTransactionIsolation(
		    Connection.TRANSACTION_SERIALIZABLE);
		con.setAutoCommit(false);
	    }
	    // Executes query
            String select = "SELECT Time, Number, Listener, Handback FROM " + 
		type + " WHERE (" + fields[0].name + "Field = " + 
		fields[0].key + " OR " + fields[0].name + "Field = 0";
	    for (int i = 1; i < fields.length; i++) {
		select = select + ") AND (" + fields[i].name + "Field = " + 
		    fields[i].key + " OR " + fields[i].name + "Field = 0";
	    }
	    select = select + ");";
            PreparedStatement pstmt = con.prepareStatement(select);
	    ResultSet rs = pstmt.executeQuery();
	    // Analysis of result
	    int j = 0;
	    while (rs.next()) {
		j++;
	    }
	    System.out.println(j);
	    if (j != 0) {
		rs.first();
		results = new EventData[j];
	    }
	    for (int k = 0; k < j; rs.next(), k++) { 
	        try {
		    long evID = rs.getLong(1);
		    long seqNo = rs.getLong(2);
		    InputStream is = rs.getBinaryStream(3);
		    ObjectInputStream ois = new ObjectInputStream(is);
		    RemoteEventListener listener = 
			(RemoteEventListener) ois.readObject();
		    is = rs.getBinaryStream(4);
		    ois = new ObjectInputStream(is);
		    MarshalledObject handback = 
			(MarshalledObject) ois.readObject();
		    results[k] = new EventData(listener, evID, seqNo,
			handback);
		    seqNo++;
		    String u = "UPDATE " + type + 
			" SET Number = ?  WHERE Time = ?;"; 
		    PreparedStatement ups = con.prepareStatement(u);
		    ups.setLong(1, seqNo);
		    ups.setLong(2, evID);
		    ups.executeUpdate();
		} catch (IOException ex) {
		    ex.printStackTrace(); //review
		} catch (ClassNotFoundException cnfe) {
		    cnfe.printStackTrace(); //review
		}
	    }
	    // Transaction epilogue
	    if (td != null) {
	        td.hasChanged = true;
	    } else {
		con.commit();
		con.close();
	    }
	} catch (SQLException e) {
	    throw new InternalSpaceException("Cannot retrieve the template", e);
	}
	return results;
    }*/

}
