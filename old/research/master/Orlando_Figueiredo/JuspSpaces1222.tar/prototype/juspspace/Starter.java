
package juspspace;

//import acidchoir.*;
import madleaser.*;

import java.net.*;
import java.io.*;
//import java.util.*;

//import net.jini.core.entry.*;
//import net.jini.core.lease.*;

/** 
 * Starts the JuspSpaces service. Syntax: Starter <space> <port>.
 * Initializes ports, repository, server and leasing services.
 *
 * @author Agents Research
 */
public class Starter {

    public static void main (String args[]) throws Exception {
        if (args.length != 2) {
	    throw new RuntimeException("Syntax: Starter <space> <port>");
	}
	/* Initializing ports */
	ServerSocket listener; 
	ServerSocket leaseListener;
	int port = Integer.parseInt(args[1]);
	int leasePort = port + 1;
	try {
	    listener = new ServerSocket(port);
	    leaseListener = new ServerSocket(leasePort);
	} catch (IOException ioe) {
	    throw new RuntimeException("Port is already in use");
	}
	/* Initializing repository */
	String hostName = InetAddress.getLocalHost().getHostName();
        Repository rep = new SqlRepository("org.postgresql.Driver",
	    "jdbc:postgresql://192.168.1.114/" + args[0],
	    "orlando", "mypsql");
	/* Initializing server */
	Space space = new Space(rep, hostName, leasePort, listener);
	space.start();
	/* Initializing leasing services */
	MadDoor d = new MadDoor(leaseListener, space);
	Collector c = new Collector(space);
	d.start();
	c.start();
    }
}
