
package juspspace;

/**
 * Protocol between Proxy and Handler.
 *
 * @author Agents Research
 */
interface JuspConstants {
    static final int END_OF_SECTION = -1;
    static final int WRITE = 1;
    static final int READ = 2;
    static final int READ_DEL = 3;
    static final int READ_WAIT = 4;
    static final int READ_DEL_WAIT = 5;
    static final int FATAL_ERROR = 6;
    static final int SUCCEEDED = 7;
    static final int TRANSACTION_EXCEPTION = 8;
    static final int EXTRACT = 9;
    static final int TRANSACTION_NULL = 10;
    static final int TRANSACTION_NOT_NULL = 11;
    static final int NOTIFY = 12;
    static final int READ_BLOCK = 30;
    static final int TAKE = 35;
    static final int TAKE_BLOCK = 40;
    static final int GET_ENTRY = 45;
    static final int WAIT = 50;
    static final int NO_WAIT = 55;
    static final int NO_ENTRY= 60;
}
