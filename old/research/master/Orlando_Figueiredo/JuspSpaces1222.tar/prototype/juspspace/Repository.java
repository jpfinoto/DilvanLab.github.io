
package juspspace;

/** 
 * A persistent repository for entries.  
 * Entries are partitioned in fields, written in FieldData format.
 * Entries are grouped according to their Java classes.
 * Each group has a string identifier.
 * The entries are written/taken under transactions and leased.
 * 
 * @author Agents Research
 */
public interface Repository extends JuspConstants {

    /** 
     * Data structure that contains the complete data to address an entry
     * in the repository, that is, the group and the id of the entry. XId
     * stands for "extended id."
     */
    public class XId {
	public String group;
	public long id;

	public XId(String group, long id) {
	    this.group = group;
	    this.id = id;
	}
    }

    public class TemplateData {
	public String type;
	public XId xid;
	public long number;
	public Object obj1;
	public Object obj2;
    }

    // ---------- lock methods ----------
    // See javadoc in the interface
    public Object getLock();

    // See javadoc in the interface
    public void releaseLock(Object lock);


    // ---------- group methods ----------
    // See javadoc in the interface
    public String getGroup(Object lock, Class entryClass);

    // See javadoc in the interface
    public String[] getAllGroups(Object lock);

    // See javadoc in the interface
    public String[] getGroupsForClassAndSuperclasses(Object lock, 
	Class entryClass);

    // See javadoc in the interface
    public String[] getGroupsForClassAndSubclasses(Object lock, 
	Class entryClass);


    // ---------- entry methods ----------
    // See javadoc in the interface
    public void insertEntryAndMark(Object lock, XId xid, FieldData[] fields, 
	long txnId, long lease);

    // See javadoc in the interface
    public XId findEntry(Object lock, String group, FieldKey[] fields, 
	long txnId, boolean free, int mode);

    // See javadoc in the interface
    public FieldData[] getFields(Object lock, XId xid, String[] wildcards);

    // See javadoc in the interface
    public void removeEntry(Object lock, XId xid);

    // See javadoc in the interface
    public long [] getEntriesWrittenUnderTransaction(Object lock,
	String group, long txnId);

    // See javadoc in the interface
    public long [] getEntriesTakenUnderTransaction(Object lock,
	String group, long txnId);

    // See javadoc in the interface
    public long [] getEntriesReadUnderTransaction(Object lock,
	String group, long txnId);

    //See javadoc in the interface
    public void putTakenMark(Object lock, XId xid, long txnId);

    //See javadoc in the interface
    public void putReadMark(Object lock, XId xid, long txnId);

    //See javadoc in the interface
    public void removeWrittenMark(Object lock, XId xid);

    //See javadoc in the interface
    public void removeTakenMark(Object lock, XId xid);

    //See javadoc in the interface
    public void removeReadMark(Object lock, XId xid, long txnId);

    //See javadoc in the interface
    public void incrementEntryLease(Object lock, XId xid, long duration);

    //See javadoc in the interface
    public void removeExpiredEntries(Object lock, String group);


    // ---------- template methods ----------
    // See javadoc in the interface
    public long insertTemplate(Object lock, XId xid, FieldKey[] fields, 
	long txnId, long expiration, Object obj1, Object obj2, String tmplType);

    //See javadoc in the interface
    public XId[] findTemplates(Object lock, String group, FieldKey[] fields, 
	long txnId, String type);

    //See javadoc in the interface
    public TemplateData getTemplateData(Object lock, XId xid);

    //See javadoc in the interface
    public void removeTemplate(Object lock, XId xid);

    //See javadoc in the interface
    public long[] getExpiredTemplates(Object lock, String group);
/*
    //See javadoc in the interface
    public XId findTakeTemplate(Object lock, String group, 
	FieldKey[] fields, long txnId);

    //See javadoc in the interface
    public XId[] findReadTemplates(Object lock, String group, 
	FieldKey[] fields, long txnId);

    //See javadoc in the interface
    public XId[] findNotifyTemplates(Object lock, String group, 
	FieldKey[] fields, long txnId);
*/

    // ---------- transaction methods ----------
    //See javadoc in the interface
    public void registerTransaction(Object lock, long txnId);

    //See javadoc in the interface
    public void unregisterTransaction(Object lock, long txnId);

    //See javadoc in the interface
    public String getTransactionState(Object lock, long txnId);

    //See javadoc in the interface
    public void setTransactionState(Object lock, long txnId, String state);

    //See javadoc in the interface
    public boolean isTransactionRegistered(Object lock, long txnId);

    //See javadoc in the interface
    public boolean isTransactionActive(Object lock, long txnId);
}
