
package juspspace;

import acidchoir.*;
import madleaser.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.rmi.MarshalledObject;

import net.jini.core.entry.*;
import net.jini.core.event.*;
import net.jini.core.lease.*;
import net.jini.core.transaction.*;
import net.jini.space.InternalSpaceException;

/**
 * Thread that handles client messages. Unmarshals the message and calls
 * the proper routine on space. Marshals the results and send back to the
 * client.
 *
 * @author Agents Research
 */
class Handler extends Thread implements JuspConstants {

    protected Socket s;
    protected Space space;

    Handler(Socket s, Space space) {
	this.s = s;
	this.space = space;
    }

    /** Waits for a request and calls the proper routine. */
    public void run() {
	ObjectOutputStream o = null;
	ObjectInputStream i = null;

	try {
	    o = new ObjectOutputStream(
		new BufferedOutputStream(s.getOutputStream()));
	    o.flush();
	    i = new ObjectInputStream(s.getInputStream());

	    //System.out.println("% Waiting for request");
	    int request = i.readInt();

	    switch (request) {

	    case WRITE: {
		//System.out.println("% WRITE requested");
		/* Receiving entry */
		Class entryClass = (Class) i.readObject();
		FieldData[] fields = (FieldData[]) i.readObject();
		/* Receiving transaction */
		int statusTransaction = i.readInt();
		Transaction txn = null;
		if (statusTransaction == TRANSACTION_NOT_NULL) {
		    String host = i.readUTF();
		    int port = i.readInt();
		    long id = i.readLong();
		    txn = new AcidTransaction(host, port, id);
		}
		/* Receiving lease request */
		long lease = i.readLong();

		/* Performs operations and returns ack */
		Lease result = null;
		try {
		    result = space.write(entryClass, fields, txn, lease);
		    o.writeInt(SUCCEEDED);
		    o.writeObject(result);
		    o.flush();
		} catch (TransactionException te) {
		    o.writeInt(TRANSACTION_EXCEPTION);
		    o.writeObject(te);
		    o.flush();
		}
		break;
	    }

	    case GET_ENTRY: {
		//System.out.println("% GET_ENTRY requested");
		int mode = i.readInt();
		/* Receiving template */
		Class tmplClass = (Class) i.readObject();
		FieldKey[] fields = (FieldKey[]) i.readObject();
		/* Receiving transaction */
		int statusTransaction = i.readInt();
		Transaction txn = null;
		if (statusTransaction == TRANSACTION_NOT_NULL) {
		    String host = i.readUTF();
		    int port = i.readInt();
		    long id = i.readLong();
		    txn = new AcidTransaction(host, port, id);
		}
		/* Receiving timeout */
		long timeout = i.readLong();
		/* Receiving callback */
		Callback callback = (Callback) i.readObject();

		/* Performs operation and returns results */
		Space.FieldPackage result = null;
		try {
		    result = space.getEntry(mode, tmplClass, fields, txn,
			timeout, callback);
		} catch (TransactionException te) {
		    o.writeInt(TRANSACTION_EXCEPTION);
		    o.writeObject(te);
		    o.flush();
		    break;
		}
		if (result.status == WAIT) {
		    o.writeInt(WAIT);
		} else if (result.status == NO_ENTRY) {
		    o.writeInt(NO_ENTRY);
		} else {
		    o.writeInt(SUCCEEDED);
		    o.writeObject(result.fields);
		}
		o.flush();
		break;
	    }

	    case NOTIFY: {
		System.out.println("% NOTIFY requested");
		/* Receiving template */
		Class tmplClass = (Class) i.readObject();
		FieldKey[] fields = (FieldKey[]) i.readObject();
		String[] wildcards = (String[]) i.readObject();
		/* Receiving transaction */
		int statusTransaction = i.readInt();
		Transaction txn = null;
		if (statusTransaction == TRANSACTION_NOT_NULL) {
		    String host = i.readUTF();
		    int port = i.readInt();
		    long id = i.readLong();
		    txn = new AcidTransaction(host, port, id);
		}
		/* Receiving listener */
		RemoteEventListener listener = 
		    (RemoteEventListener) i.readObject();
		/* Receiving lease */
		long lease = i.readLong();
		/* Receiving handback */
		MarshalledObject handback = 
		    (MarshalledObject) i.readObject();

		/* Performs operation and returns results */
		EventRegistration result = null;
		try {
	    	    result = space.notify(tmplClass, fields, txn, 
			listener, lease, handback);
		    o.writeInt(SUCCEEDED);
		    o.writeObject(result);
		} catch (TransactionException te) {
		    o.writeInt(TRANSACTION_EXCEPTION);
		    o.writeObject(te);
		}
		o.flush();
		break;
	    }

	    default:
		System.out.println("% Request not supported");
	    }
		
	} catch (EOFException eofe) {
	    return;
	} catch (IOException ioe) {
	    throw new InternalSpaceException(
		"Proxy/Handler communication error", ioe);
	} catch (ClassNotFoundException cnfe) {
	    throw new InternalSpaceException(
		"Proxy/Handler communication error", cnfe);
	} catch (Exception ex) {
	    try {
		o.writeInt(FATAL_ERROR);
		o.flush();
	    } catch (IOException ioe) {}
	    throw new InternalSpaceException("Handler error", ex);
	} finally {
	    try {
		o.close();
		i.close();
		s.close();
	    } catch (Exception e) {}
	}
    }
}
