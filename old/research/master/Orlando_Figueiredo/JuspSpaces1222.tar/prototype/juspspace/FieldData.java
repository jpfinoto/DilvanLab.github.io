
package juspspace;

import java.rmi.MarshalledObject;
import java.lang.reflect.*;

import net.jini.core.entry.Entry;
import net.jini.space.InternalSpaceException;

/**
 * The field key and the field data of an entry instance, and the field name.
 * 
 * @author Agents Research
 */
public class FieldData extends FieldKey {
    public MarshalledObject marshal;

    public FieldData(Field field, Entry entry) {
	super(field, entry);
	try {
	    marshal = new MarshalledObject(field.get(entry));
	} catch (Exception e) {
	    throw new InternalSpaceException("Cannot marshal entry", e);
	}
    }

    public FieldData(String name, MarshalledObject marshal) {
	super(name);
	this.marshal = marshal;
    }

}
