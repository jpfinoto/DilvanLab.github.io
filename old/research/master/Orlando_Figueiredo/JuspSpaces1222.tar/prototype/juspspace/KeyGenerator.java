
package juspspace;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import net.jini.space.InternalSpaceException;

/**
 * Generates a key for a given object.
 *
 * @author Agents Research
 */
class KeyGenerator {

    static long getKey(Object obj) throws IOException
    {
	ByteArrayOutputStream serializerOut = new ByteArrayOutputStream();
	ObjectOutputStream serializerIn = new ObjectOutputStream(serializerOut);
	MessageDigest shuffler;
	try {
	    shuffler = MessageDigest.getInstance("MD5");
	} catch (NoSuchAlgorithmException ex) {
	    throw new InternalSpaceException("Server instalation trouble", ex);
	}

	serializerIn.reset();
	serializerOut.reset();
	serializerIn.writeObject(obj);
	serializerIn.flush();
	byte[] pad = serializerOut.toByteArray();
	shuffler.reset();
	shuffler.update(pad);
	byte[] bytes = shuffler.digest();
	long[] longs = new long[8];
	for (int k = 0; k < 8; k++) {
	    longs[k] = bytes[k] & 0xFF;
	}
	return  longs[0]       | longs[1] << 8  | longs[2] << 16 | 
		longs[3] << 24 | longs[4] << 32 | longs[5] << 40 | 
		longs[6] << 48 | longs[7] << 56;
    }

    long[] getKeys(Object[] objs) throws IOException 
    {
        long[] keys = new long[objs.length];
        for (int i = 0; i < objs.length; i++) {
	    keys[i] = getKey(objs[i]);
	}
	return keys;
    }
 
} 
