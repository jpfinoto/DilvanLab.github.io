
package madleaser;

import java.io.*;
import java.net.*;

import net.jini.core.lease.*;

/**
 * Thread that handles lease requests.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
class MadHandler extends Thread implements MadConstants {
    protected Socket s;
    protected ObjectInputStream i;
    protected ObjectOutputStream o;
    protected MadGrantor grantor;

    MadHandler(Socket s, MadGrantor grantor) throws IOException {
	this.s = s;
	this.grantor = grantor;
	o = new ObjectOutputStream(new BufferedOutputStream(
	    s.getOutputStream()));
	o.flush();
	i = new ObjectInputStream(s.getInputStream());
    }

    /** Waits for a request and calls the proper routine. */
    public void run() {
	try {
	    System.out.println("l Waiting for a request");
	    int request = i.readInt();
	    switch (request) {
	    case RENEW: {
		System.out.println("l RENEW requested");
		String type = i.readUTF();
		long id = i.readLong();
		long duration = i.readLong();
		try {
		    long result = grantor.renew(type, id, duration);
		    o.writeInt(SUCCEEDED);
		    o.writeLong(result);
		} catch (LeaseDeniedException lde) {
		    o.writeInt(LEASE_DENIED_EXCEPTION);
		} catch (UnknownLeaseException ute) {
		    o.writeInt(UNKNOWN_LEASE_EXCEPTION);
		}
		o.flush();
		break;
	    }

	    case CANCEL: {
		System.out.println("l CANCEL requested");
		String type = i.readUTF();
		long id = i.readLong();
		try {
		    grantor.cancel(type, id);
		    o.writeInt(SUCCEEDED);
		} catch (UnknownLeaseException ule) {
		    o.writeInt(UNKNOWN_LEASE_EXCEPTION);
		}
		o.flush();
		break;
	    }

	    default:
		System.out.println("l Request not supported: " + request);
	    }
	    i.close();
	    o.close();
	    s.close();

	} catch (EOFException eofe) {
	} catch (Exception e) {
	    e.printStackTrace(); //debug
	    // should reply an error to the client
	}
    }
}
