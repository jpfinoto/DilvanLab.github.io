
package madleaser;

import java.io.*;
import java.net.*;

/**
 * Listens for lease connections.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
public class MadDoor extends Thread {
    protected ServerSocket listener;
    protected MadGrantor grantor;

    public MadDoor(ServerSocket listener, MadGrantor grantor) {
	this.listener = listener;
	this.grantor = grantor;
    }
    
    public void run() {
	while (true) {
	    try {
		Socket client = listener.accept();
		MadHandler mh = new MadHandler(client, grantor);
		mh.start();
	    } catch (IOException ioe) {
	        ioe.printStackTrace();//debug
	    }
	}
    }
}
