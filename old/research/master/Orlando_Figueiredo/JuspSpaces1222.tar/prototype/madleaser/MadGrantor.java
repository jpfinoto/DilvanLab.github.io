
package madleaser;

import net.jini.core.lease.*;

/**
 * A lease grantor.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
public interface MadGrantor {

    /** 
     * Cancel the service.
     * @param type the type of the service
     * @param id the service to be canceled
     * @throws UnknownLeaseException this id is unknown
     */
    public void cancel(String type, long id) throws UnknownLeaseException;

    /**
     * Renew the service.
     * @param type the type of the service
     * @param id the service to be renewed
     * @param duration the requested duration in milliseconds
     * @return the increment of time applied to the lease
     * @throws LeaseDeniedException couldn't renew the lease
     * @throws UnknownLeaseException this id is unknown
     */
    public long renew(String type, long id, long duration) 
	throws LeaseDeniedException, UnknownLeaseException;

    /**
     * Removes all entities whose lease has expired.
     */
    public void collect() throws Exception;
}
