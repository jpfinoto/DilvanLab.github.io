
package madleaser;

/**
 * Collector that calls collect method on a MadGrantor, at a fixed rate.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
public class Collector extends Thread {
    protected long tic;
    protected MadGrantor grantor;

    public Collector(MadGrantor grantor) {
	this(grantor, 60 * 1000); // 1 minute
    }

    public Collector(MadGrantor grantor, long period) {
	tic = period;
	this.grantor = grantor;
    }
    
    public void run() {
	while (true) {
	    try { 
		sleep(tic); 
		grantor.collect();
	    } catch (Exception e) {
		System.out.println("The lease collector is in trouble. " +
		    "But it is still alive.");
		e.printStackTrace();
	    };
	}
    }
}
