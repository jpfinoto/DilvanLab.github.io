
package madleaser;

import java.io.Serializable;
import net.jini.core.lease.*;

/**
 * Data structure that holds information about a lease.
 * 
 * @author Agents Research
 */
public class MadLeaseData implements Serializable {
    public String host;
    public int port;
    public String type;
    /** The id of the service being leased. */
    public long id;
    public long lease;

    public MadLeaseData(String host, int port, String type, long id, 
	long lease)
    { 
	this.host = host;
	this.port = port;
	this.type = type;
	this.id = id;
	this.lease = lease;
    }
}
