
package madleaser;

/**
 * For handshaking between MatLease and service.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
interface MadConstants {
    static final int GET_EXPIRATION = 1;
    static final int RENEW = 2;
    static final int CANCEL = 3;
    static final int SUCCEEDED = 4;
    static final int LEASE_DENIED_EXCEPTION = 5;
    static final int UNKNOWN_LEASE_EXCEPTION = 6;
}
