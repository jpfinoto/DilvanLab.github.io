
package madleaser;

import java.io.*;
import java.net.*;
import java.rmi.RemoteException;

import net.jini.core.lease.*;

/**
 * Lease implementation to be used with JuspSpaces and AcidChoir.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
public class MadLease implements Lease, Serializable, MadConstants {
    protected MadLeaseData seed;
    protected long birthday;

    public MadLease(MadLeaseData seed){
	this.seed = seed;
	birthday = System.currentTimeMillis();
    }
    
    public MadLease(String host, int port, String type, long id, 
	long lease)
    {
	this.seed = new MadLeaseData(host, port, type, id, lease);
	birthday = System.currentTimeMillis();
    }
    
    public boolean canBatch(Lease lease) {
        return false;
    }

    public void cancel () throws UnknownLeaseException, RemoteException {
	try {
	    Socket s = new Socket(seed.host, seed.port);
	    ObjectOutputStream o = new ObjectOutputStream(
		new BufferedOutputStream(s.getOutputStream()));
	    ObjectInputStream i = new ObjectInputStream(s.getInputStream());
	    o.writeInt(CANCEL);
	    o.writeUTF(seed.type);
	    o.writeLong(seed.id);
	    o.flush();
	    int status = i.readInt();
	    i.close();
	    o.close();
	    s.close();
	    if (status == UNKNOWN_LEASE_EXCEPTION) {
	        throw new UnknownLeaseException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("Cannot access lease", ioe);
	}
    }

    public LeaseMap createLeaseMap(long duration) {
    	return null;
    }

    public long getExpiration() {
        return seed.lease + birthday;
    }

    public int getSerialFormat() {
        return 0;
    }

    public void renew(long duration) throws LeaseDeniedException,
	UnknownLeaseException, RemoteException
    {
	try {
	    Socket s = new Socket(seed.host, seed.port);
	    ObjectOutputStream o = new ObjectOutputStream(
		new BufferedOutputStream(s.getOutputStream()));
	    ObjectInputStream i = new ObjectInputStream(s.getInputStream());
	    o.writeInt(RENEW);
	    o.writeUTF(seed.type);
	    o.writeLong(seed.id);
	    o.writeLong(duration);
	    o.flush();
	    int status = i.readInt();
	    long increment = 0;
	    if (status == SUCCEEDED) {
		increment = i.readLong();
	    }
	    i.close();
	    o.close();
	    s.close();
	    if (status == LEASE_DENIED_EXCEPTION) {
		throw new LeaseDeniedException();
	    } else if (status == UNKNOWN_LEASE_EXCEPTION) {
	        throw new UnknownLeaseException();
	    }
	    seed.lease += increment;
	} catch (IOException ioe) {
	    throw new RemoteException("Cannot access lease", ioe);
	}
    }

    public void setSerialFormat(int format) {

    }

}
