
package juspspacetest;

import junit.framework.Test;
import junit.framework.TestSuite;

public class RepositorySuite {

    public static Test suite() {
	TestSuite suite = new TestSuite();
	suite.addTest(new RepositoryTest("testLockOperations"));
	suite.addTest(new RepositoryTest("testGroupOperations"));
	return suite;
    }
}
