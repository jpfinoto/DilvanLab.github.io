
package juspspacetest;

import junit.framework.TestCase;
import juspspace.Repository;
import juspspace.SqlRepository;

/**
 * Tests a repository.
 *
 * @author Agents Research
 */
public class RepositoryTest extends TestCase {
    /** A repository that is used in all tests. The real repository 
	implementation is hardcoded in the protected method setUp(). */
    protected Repository rep;
    /** An entry that is used in all tests.*/
    protected BasicEntry anEntry;

    public RepositoryTest(String name) {
	super(name);
    }

    protected void setUp () {
	rep = new SqlRepository("org.postgresql.Driver", 
	    "jdbc:postgresql://192.168.1.114/juspspace", "orlando","");
	anEntry = new BasicEntry("Testing...");
    }

    /** Create and release a lock. */
    public void testLockOperations() {
	Object lock = rep.getLock();
	rep.releaseLock(lock);
	assertTrue(true);
    }

    /** Get a group from repository.*/
    public void testGroupOperations() {
	Object lock = rep.getLock();
	rep.getGroup(lock, anEntry.getClass());
	rep.releaseLock(lock);
	assertTrue(true);
    }

}
