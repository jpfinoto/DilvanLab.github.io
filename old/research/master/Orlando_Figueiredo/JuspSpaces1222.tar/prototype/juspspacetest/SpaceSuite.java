
package juspspacetest;

import junit.framework.Test;
import junit.framework.TestSuite;

public class SpaceSuite {

    public static Test suite() {
	TestSuite suite = new TestSuite();
//	suite.addTest(new SimpleSpaceTest("testWriteAndTake"));
//	suite.addTest(new SimpleSpaceTest("testTakeIfExists"));
	suite.addTest(new SimpleSpaceTest("testNWriteReadAndTake"));
	return suite;
    }
}
