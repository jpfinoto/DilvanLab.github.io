
package juspspacetest;

import net.jini.core.entry.Entry;

/** A basic entry that contains a string. The string is the only
 * field of the entry.
 *
 * @author Agents Research
 */
public class BasicEntry implements Entry {
    public String foo;

    public BasicEntry() {
	foo = null;
    }

    public BasicEntry(String name) {
	foo = name;
    }
}
