
package juspspacetest;

import junit.framework.TestCase;
import net.jini.space.JavaSpace;
import juspspace.Proxy;
import net.jini.core.lease.Lease;
import net.jini.core.entry.Entry;
import java.io.IOException;
import jsbook.util.SpaceAccessor;

/**
 * A set of basic test on a JavaSpaces.
 *
 * @author Agents Research
 */
public class SimpleSpaceTest extends TestCase {
    /** A space that is used in all tests. The real space is a proxy
	that is accessible in the client classpath. The proxy creation
	is in the protected method setUp(). */
    protected JavaSpace space;
    /** An entry that is used in all tests.*/
    protected BasicEntry entry1;
    protected BasicEntry template1;

    public SimpleSpaceTest(String name) {
	super(name);
    }

    protected void setUp () {
	try {
	    space = new Proxy("192.168.1.114", 5757);
	} catch (IOException e) {
	    fail("Cannot setup the test");
	}
//	space = SpaceAccessor.getSpace("JavaSpace");
	entry1 = new BasicEntry("Testing...");
	template1 = new BasicEntry();
    }

    /** Write and take an entry.*/
    public void testWriteAndTake() {
	try {
	    space.write(entry1, null, Lease.FOREVER);
	    Entry result = space.take(entry1, null, Lease.FOREVER);
	    assertNotNull("The retrieved entry is null", result);
	    assertSame("The retrived entry is not same", result, entry1);
	} catch (Exception e) {
	    fail("Cannot write and take a simple entry");
	}
    }

    /** Write, read and take an entry.*/
    public void testWriteReadAndTake(int i) {
	try {
	    BasicEntry number = new BasicEntry(Integer.toString(i));
	    space.write(number, null, Lease.FOREVER);

	    Entry result = space.read(number, null, Lease.FOREVER);
//	    assertNotNull("The retrieved entry is null", result);
//	    assertSame("The retrived entry is not same", result, entry1);

	    result = space.take(number, null, Lease.FOREVER);
//	    assertNotNull("The retrieved entry is null", result);
//	    assertSame("The retrived entry is not same", result, entry1);
	} catch (Exception e) {
	    fail("Cannot write and take a simple entry");
	}
    }

    /** Repeat N times the Write, read and take test */
    public void testNWriteReadAndTake() {
	for (int i = 0; i < 50; i++) {
	    testWriteReadAndTake(i);
	}
    }

    /** TakeIfExists an entry.*/
    public void testTakeIfExists() {
	try {
	    Entry result = space.takeIfExists(entry1, null, Lease.FOREVER);
	    assertNull("Null expected.", result);
	} catch (Exception e) {
	}
    }
}
