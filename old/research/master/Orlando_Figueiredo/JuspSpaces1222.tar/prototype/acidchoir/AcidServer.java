
package acidchoir;

import java.net.*;
import java.io.*;
import java.util.*;
import net.jini.core.lease.*;
import net.jini.core.transaction.*;
import net.jini.core.transaction.server.*;
import madleaser.*;

/**
 * This class starts the AcidServer. 
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
public class AcidServer implements TransactionManager, TransactionConstants,
    MadGrantor
{
    protected String hostName;
    protected int port;
    protected int leasePort;
    protected int counter;
    protected Hashtable txns;
    
    protected AcidServer(String hostName, int port, int leasePort) {
	this.hostName = hostName;
	this.port = port;
	this.leasePort = leasePort;
	counter = 1;
	txns = new Hashtable(); //review: capacity and increment
    }

    class TransactionData {
	int state;
	LinkedList parts;
	LinkedList counts;
	long birthday;
	long lease;

	TransactionData(long lease) {
	    state = ACTIVE;
	    parts = new LinkedList();
	    counts = new LinkedList();
	    birthday = System.currentTimeMillis();
	    this.lease = lease;
	}

	void addParticipant(TransactionParticipant part, long crashCount) {
	    parts.add(part);
	    counts.add(new Long(crashCount));
	}

	/** For debug purposes. */
	void print() {
	    System.out.println("s=" + state + ";p=" + parts.size() +
	        ";b=" + birthday + ";l=" + lease);
	}
    }

    /** For debug purposes. */
    protected void print() {
        for (int i = 1; i < counter; i++) {
	    if (txns.containsKey(new Long(i))) {
	        System.out.print("m T=" + i + ":");
	        ((TransactionData) txns.get(new Long(i))).print();    
	    }
	}
    }
    
    /** @see createAlt */
    public TransactionManager.Created create(long lease) throws 
        LeaseDeniedException
    {
	return null;
    }

    public MadLeaseData createAlt(long lease) throws LeaseDeniedException {
	if (lease < 0) {
	    lease = 24 * 60 * 60 * 1000; //one day
	}
    	long id = counter++;
	TransactionData td = new TransactionData(lease);
	txns.put(new Long(id), td);
	MadLeaseData ld = new MadLeaseData(hostName, leasePort, "txn", id, 
	    lease);
	return ld;
    }

    public void join(long id, TransactionParticipant part, long crashCount) 
        throws UnknownTransactionException, CannotJoinException,
	CrashCountException
    {
	System.out.print("m Trying join... ");//debug
	if (!txns.containsKey(new Long(id))) {
	    System.out.println("impossible.");//debug
	    throw new UnknownTransactionException();
	}
	TransactionData txn = (TransactionData) txns.get(new Long(id));
	int partIndex = txn.parts.indexOf(part);
	if (partIndex != -1) {
	    if (! txn.counts.get(partIndex).equals(new Long(crashCount))) {
	        throw new CrashCountException();
	    }
	} else {
	    if (txn.state != ACTIVE) {
	        throw new CannotJoinException();
	    }
	    txn.addParticipant(part, crashCount);
	}
	System.out.println("done.");//debug
    }

    public int getState(long id) throws UnknownTransactionException {
	if (!txns.containsKey(new Long(id))) {
	    throw new UnknownTransactionException();
	}
	TransactionData txn = (TransactionData) txns.get(new Long(id));
        return txn.state;
    }

    public void commit(long id) throws UnknownTransactionException, 
        CannotCommitException
    {
	System.out.println("m Trying to commit...");//debug
	if (!txns.containsKey(new Long(id))) {
	    throw new UnknownTransactionException();
	}
	TransactionData txn = (TransactionData) txns.get(new Long(id));
	if (txn.state != ACTIVE) {
	    throw new CannotCommitException();
	}
	/* Polling */
	txn.state = VOTING;
	int size = txn.parts.size();
	int[] states = new int[size];
	for (int i = 0; i < size; i++) {
	    try {
		states[i] = ((TransactionParticipant) txn.parts.get(i)).prepare(
		    this, id);
	    } catch (Exception ex) {
	        states[i] = ABORTED;
	    }
	}
	/* Analisys */
	for (int i = 0; i < size; i++) {
	    if (states[i] == ABORTED) {
	        txn.state = ABORTED;
		print();//debug
	    }
	}
	/* Committing or aborting */
	if (txn.state != ABORTED) {
	    txn.state = COMMITTED;
	    print();//debug
	    for (int i = 0; i < size; i++) {
	        if (states[i] == PREPARED) {
		    try {
		        ((TransactionParticipant) txn.parts.get(i)).commit(
			    this,id);
		    } catch (Exception ex) {}
		}
	    }
	} else {
	    for (int i = 0; i < size; i++) {
	        try {
		    ((TransactionParticipant) txn.parts.get(i)).abort(this, id);
		} catch (Exception ex) {}
	    }
	}
	/* Clean up */
	txns.remove(new Long(id));
	System.out.println("m done!");//debug
    }

    public void commit(long id, long waitFor) {
	//review:to do
    }

    public void abort(long id) throws UnknownTransactionException,
        CannotAbortException
    {
	System.out.println("m Trying to abort...");//debug
	if (!txns.containsKey(new Long(id))) {
	    throw new UnknownTransactionException();
	}
	TransactionData txn = (TransactionData) txns.get(new Long(id));
	print();//debug
	if (txn.state == COMMITTED) {
	    throw new CannotAbortException();
	}
	/* Aborting */
	txn.state = ABORTED;
	print();
	int size = txn.parts.size();
	for (int i = 0; i < size; i++) {
	    try {
	        ((TransactionParticipant) txn.parts.get(i)).abort(this, id);
	    } catch (Exception ex) {}
	}
	/* Clean up */
	txns.remove(new Long(id));
	System.out.println("m Aborted!");//debug
    }

    public void abort(long id, long waitFor) {
	//review: to do
    }

    public void cancel(String type, long id) throws UnknownLeaseException {
	if (!txns.containsKey(new Long(id))) {
	    throw new UnknownLeaseException();
	}
	txns.remove(new Long(id));//review: should abort instead?
    }
    
    public long renew(String type, long id, long duration) 
	throws LeaseDeniedException, UnknownLeaseException
    {
	if (!txns.containsKey(new Long(id))) {
	    throw new UnknownLeaseException();
	}
	TransactionData txn = (TransactionData) txns.get(new Long(id));
	if (duration < 0) {
	    duration = 24 * 60 * 60 * 1000;
	}
	txn.lease += duration;
	return duration;
    }

    public void collect() {
	TransactionData td = null;
        for (int i = 1; i < counter; i++) {
	    if (txns.containsKey(new Long(i))) {
		td = (TransactionData) txns.get(new Long(i));
		td.print();//debug
		if (td.birthday + td.lease < System.currentTimeMillis()) {
		    txns.remove(new Long(i));//review: should abort instead?
		}
	    }
	}
    }

    /** 
     * Starts the AcidServer, when invoked by a line command and
     * listens for connections. Syntax: AcidServer <port>
     */
    public static void main (String args[]) throws IOException {
        if (args.length != 1) {
	    throw new RuntimeException("Syntax: AcidServer <port>");
	}
	ServerSocket listener;
	ServerSocket leaseListener;
	int port = Integer.parseInt(args[0]);
	int leasePort = port + 1;
	try {
	    listener = new ServerSocket(port);
	    leaseListener = new ServerSocket(leasePort);
	} catch (IOException ioe) {
	    throw new RuntimeException("Port is already in use");
	}
	String hostName = InetAddress.getLocalHost().getHostName();
	AcidServer mgr = new AcidServer(hostName, port, leasePort);
	MadDoor leaser = new MadDoor(leaseListener, mgr);
	leaser.start();
	Collector c = new Collector(mgr);
	c.start();

	while (true) {
	    Socket client = listener.accept();
	    System.out.println("m Accepted from " + client.getInetAddress());
	    ClientHandler h = new ClientHandler(client, mgr);
	    h.start();
	}
    }
}
