
package acidchoir;

/**
 * Constants for the protocol between AcidProxy and Handler.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
interface AcidConstants {
    /** The client asks to the manager to create a transaction. */
    static final int CREATE = 1;
    /** The participant asks to the manager to join in a transaction. */
    static final int JOIN = 2;
    /** The client cancels its transaction proxy. (So do the Handler.) */
    static final int END_OF_SECTION = -1;
    static final int PREPARE = 3;
    static final int PREPARE_AND_COMMIT = 4;
    static final int ABORT = 5;
    static final int COMMIT = 6;
    static final int GET_STATE = 7;
    static final int SUCCEEDED = 10;
    static final int UNKNOWN_TRANSACTION_EXCEPTION = 20;
    static final int LEASE_DENIED_EXCEPTION = 21;
    static final int CANNOT_COMMIT_EXCEPTION = 22;
    static final int CANNOT_ABORT_EXCEPTION = 22;
    static final int CANNOT_JOIN_EXCEPTION = 23;
    static final int CRASH_COUNT_EXCEPTION = 24;
}
