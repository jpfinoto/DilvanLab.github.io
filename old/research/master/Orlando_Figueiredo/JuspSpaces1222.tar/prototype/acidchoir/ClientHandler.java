
package acidchoir;

import java.net.*;
import java.io.*;
import net.jini.core.lease.*;
import net.jini.core.transaction.*;
import net.jini.core.transaction.server.*;
import java.rmi.RemoteException;
import madleaser.*;

/**
 * Thread that handles client and participant messages.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
class ClientHandler extends Thread implements AcidConstants, 
    TransactionParticipant 
{
    protected Socket s;
    protected ObjectInputStream i;
    protected ObjectOutputStream o;
    protected AcidServer mgr;

    ClientHandler(Socket s, AcidServer mgr) throws IOException {
	this.s = s;
	this.mgr = mgr;
	o = new ObjectOutputStream(new BufferedOutputStream(
	    s.getOutputStream()));
	o.flush();
	i = new ObjectInputStream(s.getInputStream());
    }

    /** Waits for a request and calls the proper routine. */
    public void run() {
	while (true) {
	    try {
	        System.out.println("c Waiting for a request.");
	        int request = i.readInt();
		long id;
		switch (request) {
		case CREATE:
		    System.out.println("c CREATE requested.");
		    long lease = i.readLong();
		    try {
			MadLeaseData result = mgr.createAlt(lease);
			o.writeInt(SUCCEEDED);
		        o.writeObject(result);
		    } catch (LeaseDeniedException lde) {
		        o.writeInt(LEASE_DENIED_EXCEPTION);
		    }
		    o.flush();
		    break;

		case GET_STATE:
		    System.out.println("c GET_STATE requested.");
		    id = i.readLong();
		    try {
		        int result = mgr.getState(id);
			o.writeInt(SUCCEEDED);
			o.writeInt(result);
		    } catch (UnknownTransactionException ute) {
		        o.writeInt(UNKNOWN_TRANSACTION_EXCEPTION);
		    }
		    o.flush();
		    break;

		case COMMIT:
		    System.out.println("c COMMIT requested.");
		    id = i.readLong();
		    try {
		        mgr.commit(id);
			o.writeInt(SUCCEEDED);
		    } catch (UnknownTransactionException ute) {
		        o.writeInt(UNKNOWN_TRANSACTION_EXCEPTION);
		    } catch (CannotCommitException cce) {
		        o.writeInt(CANNOT_COMMIT_EXCEPTION);
		    }
		    o.flush();
		    break;

		case ABORT:
		    System.out.println("c ABORT requested.");
		    id = i.readLong();
		    try {
		        mgr.abort(id);
			o.writeInt(SUCCEEDED);
		    } catch (UnknownTransactionException ute) {
		        o.writeInt(UNKNOWN_TRANSACTION_EXCEPTION);
		    } catch (CannotAbortException cce) {
		        o.writeInt(CANNOT_ABORT_EXCEPTION);
		    }
		    o.flush();
		    break;

		case JOIN:
		    System.out.println("c JOIN requested.");
		    id = i.readLong();
		    long crashCount = i.readLong();
		    try {
		        mgr.join(id, this, crashCount);
			o.writeInt(SUCCEEDED);
		    } catch (UnknownTransactionException ute) {
		        o.writeInt(UNKNOWN_TRANSACTION_EXCEPTION);
		    } catch (CannotJoinException cje) {
		        o.writeInt(CANNOT_JOIN_EXCEPTION);
		    } catch (CrashCountException cce) {
		        o.writeInt(CRASH_COUNT_EXCEPTION);
		    }
		    o.flush();
		    return;

		case END_OF_SECTION:
		    System.out.println("c END_OF_SECTION requested.");
		    return;

		default:
		    System.out.println("c Request not supported: " + request);
		}
		
	    } catch (EOFException eofe) {
	        return;
	    } catch (Exception e) {
	        e.printStackTrace(); //debug
		// should reply an error to the client
		break;
	    }
	} 
    }

    public void abort(TransactionManager mgr, long id) throws RemoteException,
        UnknownTransactionException
    {
	try {
	    o.writeInt(ABORT);
	    o.writeLong(id);
	    o.flush();
	    int status = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
    }

    public void commit(TransactionManager mgr, long id) throws RemoteException,
        UnknownTransactionException 
    {
        try {
	    o.writeInt(COMMIT);
	    o.writeLong(id);
	    o.flush();
	    int status = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
    }

    public int prepare(TransactionManager mgr, long id) throws RemoteException,
        UnknownTransactionException 
    {
	int result = -1;
	try {
	    o.writeInt(PREPARE);
	    o.writeLong(id);
	    o.flush();
	    int status = i.readInt();
	    result = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
	return result;
    }

    public int prepareAndCommit(TransactionManager mgr, long id) throws
        RemoteException, UnknownTransactionException 
    {
	int result = -1;
	try {
	    o.writeInt(PREPARE_AND_COMMIT);
	    o.writeLong(id);
	    o.flush();
	    int status = i.readInt();
	    result = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
	return result;
    }

    protected void finalize() throws Throwable {
        o.close();
	i.close();
	s.close();
    }
}
