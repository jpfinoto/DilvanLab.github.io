
package acidchoir;

import java.net.*;
import java.io.*;
import net.jini.core.transaction.*;
import net.jini.core.transaction.server.*;
import java.rmi.RemoteException;

/**
 * Thread that handles participant messages.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
class ParticipantHandler extends Thread implements AcidConstants, 
    TransactionParticipant 
{
    protected Socket s;
    protected ObjectInputStream i;
    protected ObjectOutputStream o;
    protected TransactionManager mgr;

    ParticipantHandler(Socket s, TransactionManager mgr) throws IOException {
	this.s = s;
	o = new ObjectOutputStream(new BufferedOutputStream(
	    s.getOutputStream()));
	o.flush();
	i = new ObjectInputStream(s.getInputStream());
	this.mgr = mgr;
    }

    /** Waits for a request and calls the proper routine. */
    public void run() {
	for (int k = 0; k < 2; k++) { //review: while (true) {
	    try {
	        System.out.println("Waiting for participant request.");
	        int request = i.readInt();
		switch (request) {
		case JOIN:
		    System.out.print("JOIN requested.");
		    long id = i.readLong();
		    long crashCount = i.readLong();
		    try {
		        mgr.join(id, this, crashCount);
			o.writeInt(SUCCEEDED);
		    } catch (UnknownTransactionException ute) {
		        o.writeInt(UNKNOWN_TRANSACTION_EXCEPTION);
		    } catch (CannotJoinException cje) {
		        o.writeInt(CANNOT_JOIN_EXCEPTION);
		    } catch (CrashCountException cce) {
		        o.writeInt(CRASH_COUNT_EXCEPTION);
		    }
		    o.flush();
		    break;

		case END_OF_SECTION:
		    System.out.println("END_OF_SECTION requested.");
		    return;

		default:
		    System.out.println("Request not supported: " + request);
		}
	    } catch (IOException ioe) {
	        ioe.printStackTrace(); //debug
		// should reply an error to the client
	    }
	} 
    } 

    public void abort(TransactionManager mgr, long id) throws RemoteException,
        UnknownTransactionException
    {
	try {
	    o.writeInt(ABORT);
	    o.writeLong(id);
	    o.flush();
	    int status = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
    }

    public void commit(TransactionManager mgr, long id) throws RemoteException,
        UnknownTransactionException 
    {
        try {
	    o.writeInt(COMMIT);
	    o.writeLong(id);
	    o.flush();
	    int status = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
    }

    public int prepare(TransactionManager mgr, long id) throws RemoteException,
        UnknownTransactionException 
    {
	int result = -1;
	try {
	    o.writeInt(PREPARE);
	    o.writeLong(id);
	    o.flush();
	    int status = i.readInt();
	    result = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
	return result;
    }

    public int prepareAndCommit(TransactionManager mgr, long id) throws
        RemoteException, UnknownTransactionException 
    {
	int result = -1;
	try {
	    o.writeInt(PREPARE_AND_COMMIT);
	    o.writeLong(id);
	    o.flush();
	    int status = i.readInt();
	    result = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
	return result;
    }

    protected void finalize() throws Throwable {
        o.close();
	i.close();
	s.close();
    }
}
