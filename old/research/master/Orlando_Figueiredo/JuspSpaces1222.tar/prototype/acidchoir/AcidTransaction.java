
package acidchoir;

import java.io.Serializable;
import java.rmi.RemoteException;
import net.jini.core.transaction.*;
import net.jini.core.transaction.server.*;

/**
 * An implementation for the Jini Transaction Interface.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
public class AcidTransaction implements Transaction, Serializable {

    public long id;
    public String host;
    public int port;
    public TransactionManager mgr;

    public AcidTransaction(TransactionManager mgr, long id) {
	this.id = id;
	this.mgr = mgr;
	AcidProxy acidmgr = (AcidProxy) mgr;
	host = acidmgr.host;
	port = acidmgr.port;
    }

    public AcidTransaction(String host, int port, long id) {
        this.host = host;
	this.port = port;
	this.id = id;
    }

    public void commit() throws UnknownTransactionException,
	CannotCommitException, RemoteException
    {
	mgr.commit(id);
    }

    public void commit(long waitFor) throws UnknownTransactionException,
	CannotCommitException, TimeoutExpiredException, RemoteException
    {
	mgr.commit(id, waitFor);
    }

    public void abort() throws UnknownTransactionException,
	CannotAbortException, RemoteException
    {
	mgr.abort(id);
    }

    public void abort(long waitFor) throws UnknownTransactionException,
	CannotAbortException, TimeoutExpiredException, RemoteException
    {
	mgr.abort(id, waitFor);
    }

    public void join(TransactionParticipant part, long crashCount) throws
	UnknownTransactionException, CannotJoinException, CrashCountException,
	RemoteException
    {
        ParticipantProxy proxy = new ParticipantProxy(host, port);
	proxy.join(id, part, crashCount);
	proxy.start();
    }

    public int getState() throws UnknownTransactionException, RemoteException {
	return mgr.getState(id);
    }

    public boolean equals(Object o) {
	/* Recipe from BLOCH, J. "Effective Java", p. 33*/
	if (!(o instanceof AcidTransaction)) {
	    return false;
	}
	AcidTransaction a = (AcidTransaction) o;
	return (id == a.id && host.equals(a.host) && port == a.port);
    }

    public int hashCode() {
	/* Recipe from BLOCH, J. "Effective Java", p. 37*/
	int result = 17;
	result = 37 * result + port;
	result = 37 * result + host.hashCode();
	result = 37 * result + (int) (id ^ (id >>> 32));
        return result;
    }
}
