
package acidchoir; 

import java.net.*;
import java.io.*;
import java.rmi.RemoteException;
import net.jini.core.transaction.*;
import net.jini.core.transaction.server.*;

/**
 * Participant proxy that provides access to the transaction server.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
public class ParticipantProxy extends Thread implements TransactionManager, 
    AcidConstants 
{
    public String host;
    public int port;
    protected ObjectInputStream i;
    protected ObjectOutputStream o;
    protected TransactionParticipant part;

    public ParticipantProxy(String host, int port) throws RemoteException {
	this.host = host;
	this.port = port;
	try {
	    Socket s = new Socket (host, port);
	    o = new ObjectOutputStream(
	        new BufferedOutputStream(s.getOutputStream()));
	    o.flush();
	    i = new ObjectInputStream(s.getInputStream());
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
    }

    public TransactionManager.Created create(long lease) {
        //review: unsupported operation
	return null;
    }

    public void join(long id, TransactionParticipant part, long crashCount) 
	throws UnknownTransactionException, CannotJoinException,
	CrashCountException, RemoteException
    {
        this.part = part;
        try {
            o.writeInt(JOIN);
	    o.writeLong(id);
	    o.writeLong(crashCount);
	    o.flush();
	    int status = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    } else if (status == CANNOT_JOIN_EXCEPTION) {
	        throw new CannotJoinException();
	    } else if (status == CRASH_COUNT_EXCEPTION) {
	        throw new CrashCountException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
    }

    public int getState(long id) {
        return 0;
    }

    public void commit(long id) {

    }

    public void commit(long id, long waitFor) {

    }

    public void abort(long id) {

    }

    public void abort(long id, long waitFor) {

    }

    public void run() {
	for (int k = 0; k < 2; k++) { //review: while (true) {
	    try {
	        int request = i.readInt();
	        long id = i.readLong();
	        switch (request) {
	        case ABORT:
		    try {
		        part.abort(this, id);
			o.writeInt(SUCCEEDED);
		    } catch (UnknownTransactionException ute) {
		        o.writeInt(UNKNOWN_TRANSACTION_EXCEPTION);
		    } catch (RemoteException re) {}
		    o.flush();
		    break;

	        case COMMIT:
		    try {
		        part.commit(this, id);
			o.writeInt(SUCCEEDED);
		    } catch (UnknownTransactionException ute) {
		        o.writeInt(UNKNOWN_TRANSACTION_EXCEPTION);
		    } catch (RemoteException re) {}
		    o.flush();
		    break;

	        case PREPARE:
		    try {
			int result = part.prepare(this, id);
			o.writeInt(SUCCEEDED);
		        o.writeInt(result);
		    } catch (UnknownTransactionException ute) {
		        o.writeInt(UNKNOWN_TRANSACTION_EXCEPTION);
		    } catch (RemoteException re) {}
		    o.flush();
		    break;

	        case PREPARE_AND_COMMIT:
		    try {
			int result = part.prepareAndCommit(this, id);
			o.writeInt(SUCCEEDED);
		        o.writeInt(result);
		    } catch (UnknownTransactionException ute) {
		        o.writeInt(UNKNOWN_TRANSACTION_EXCEPTION);
		    } catch (RemoteException re) {}
		    o.flush();
	    	    break;

	        default:
	            System.out.println("Request not supported.");
	        }
	    } catch (EOFException eofe) {
	        return;
	    } catch (IOException ioe) {
	        ioe.printStackTrace(); //review 
	    }	
	}
    }

    protected void finalize() throws Throwable {
	o.close();
	i.close();
    }
}
