
package acidchoir; 

import java.net.*;
import java.io.*;
import java.rmi.RemoteException;
import net.jini.core.lease.*;
import net.jini.core.transaction.*;
import net.jini.core.transaction.server.*;
import madleaser.*;

/**
 * Client proxy that provides access to the transaction server.
 *
 * @author Orlando Figueiredo
 * @version $Revision$
 */
public class AcidProxy implements TransactionManager, AcidConstants {

    protected String host;
    protected int port;
    protected Socket s;
    protected ObjectInputStream i;
    protected ObjectOutputStream o;

    public AcidProxy(String host, int port) throws IOException {
	this.host = host;
	this.port = port;
	s = new Socket(host, port);
	o = new ObjectOutputStream(
	    new BufferedOutputStream(s.getOutputStream()));
	o.flush();
	i = new ObjectInputStream(s.getInputStream());
    }

    public TransactionManager.Created create(long lease) throws 
        LeaseDeniedException, RemoteException
    {
	TransactionManager.Created created = null;
        try {
            o.writeInt(CREATE);
	    o.writeLong(lease);
	    o.flush();
	    int status = i.readInt();
	    if (status == LEASE_DENIED_EXCEPTION) {
	        throw new LeaseDeniedException();
	    }
	    MadLeaseData ld = (MadLeaseData) i.readObject();
            created = new TransactionManager.Created(ld.id, new MadLease(ld));
	} catch (Exception e) {
	    throw new RemoteException("IO error", e);
	}
	return created;
    }

    public void join(long id, TransactionParticipant part, long crashCount) {
        //review: throw unsupported operation exception
    }

    public int getState(long id) throws UnknownTransactionException, 
        RemoteException
    {
	int result = -1;
	try {
	    o.writeInt(GET_STATE);
	    o.writeLong(id);
	    o.flush();
	    int status = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    }
	    result = i.readInt();
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
        return result;
    }

    public void commit(long id) throws UnknownTransactionException,
        CannotCommitException, RemoteException
    {
	try {
	    o.writeInt(COMMIT);
	    o.writeLong(id);
	    o.flush();
	    int status = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    } else if (status == CANNOT_COMMIT_EXCEPTION) {
	        throw new CannotCommitException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
    }

    public void commit(long id, long waitFor) {

    }

    public void abort(long id) throws UnknownTransactionException,
        CannotAbortException, RemoteException
    {
	try {
	    o.writeInt(ABORT);
	    o.writeLong(id);
	    o.flush();
	    int status = i.readInt();
	    if (status == UNKNOWN_TRANSACTION_EXCEPTION) {
	        throw new UnknownTransactionException();
	    } else if (status == CANNOT_ABORT_EXCEPTION) {
	        throw new CannotAbortException();
	    }
	} catch (IOException ioe) {
	    throw new RemoteException("IO error", ioe);
	}
    }

    public void abort(long id, long waitFor) {

    }

    protected void finalize() throws Throwable {
        o.close();
	i.close();
	s.close();
    }
}
