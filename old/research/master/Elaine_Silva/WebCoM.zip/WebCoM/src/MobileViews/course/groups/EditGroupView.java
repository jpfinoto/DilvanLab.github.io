/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.groups;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;

/** Class for edition of student groups.*/
public class EditGroupView implements View, Serializable, ActionListener {
    Vector projects;
    Vector members;
    Vector membersOld;
    String username;
    String resource;
    String project;
    String group = null;
    int min_students = 0;
    int max_students = 0;
    int numberAssignment;
    public static int classGroup;
    public static int assignmentSelected;
    
    transient Choice projectsList;
    transient TextField groupName;
    transient TextField newMember;
    transient java.awt.List membersList;
    transient Button add,remove;
    transient TextField assignmentID;
    
    /** Method for creation of new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.username = tic.username.toLowerCase();
        this.resource = tic.resource;
        
        ResultSet rs, rs1;
        java.util.Date date = new java.util.Date();
        membersOld = new Vector();
        projects = new Vector();
        
        sql.init(resource);
        // Get the name of the user's group
        rs = sql.executeQuery("SELECT group_name FROM activities WHERE username='" + username + "' AND type='groups'" +
        " AND id='" + assignmentSelected + "' AND class=" + classGroup);
        if (!rs.next()) throw new RuntimeException("You are not member of any groups in this class.");
        group = rs.getString(1);
        
        //Get all members of the group
        rs = sql.executeQuery("SELECT username FROM activities WHERE type='groups' AND group_name='" +
        group + "' AND id='" + assignmentSelected + "' AND class=" + classGroup);
        for (;rs.next();)
            membersOld.addElement(rs.getString(1));
        
        //Get the project of the user's group
        rs = sql.executeQuery("SELECT project FROM groups WHERE name='" + group + "' AND assignment='" + assignmentSelected + "'");
        rs.next();
        project = rs.getString(1);
        
        // Get the information to each projects
        rs = sql.executeQuery("SELECT name,min_users,max_users FROM projects WHERE assignment='" + assignmentSelected +
        "' AND class='" + classGroup + "' ORDER BY name");
        for (;rs.next();) {
            if (rs.getString(1).equals(project))
                projects.addElement("*selected" + rs.getString(1) + "  Min_Students= " + rs.getString(2) + "  Max_Students= " + rs.getString(3));
            else
                projects.addElement(rs.getString(1) + "  Min_Students= " + rs.getString(2) + "  Max_Students= " + rs.getString(3));
        }
        sql.close();
        numberAssignment = assignmentSelected;
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        ImageLoader jImage = new ImageLoader();
        Canvas canvas = new Canvas();
        Image icon;
        
        assignmentID = new TextField("Assignment " + numberAssignment);
        assignmentID.setForeground(Color.blue);
        assignmentID.setFont(new Font("Helvetica",Font.BOLD,12));
        assignmentID.setEditable(false);
        
        groupName = new TextField(group);
        groupName.setEditable(false);
        
        newMember = new TextField(5);
        newMember.addActionListener(this);
        
        add = new Button("Add");
        add.addActionListener(this);
        remove = new Button("Remove");
        remove.addActionListener(this);
        
        projectsList = new Choice();
        String element;
        for (int count =0; count < projects.size(); count++) {
            element = (String) projects.elementAt(count);
            if (element.indexOf("*selected") != -1) {
                // project of this group
                projects.setElementAt(element.substring(9,element.length()),count);
                projectsList.addItem((String) projects.elementAt(count));
                projectsList.select(count);
            } else
                projectsList.addItem(element);
        }
        
        membersList = new java.awt.List(3,false);
        for (int count = 0;count < membersOld.size();count++)
            membersList.addItem((String) membersOld.elementAt(count));
        
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        //label Group for
        Label label = new Label("Group Creation for  ");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label Group Name
        label = new Label("Group Name");
        constraints.gridx = 0;
        constraints.gridy = 2;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label projects
        label = new Label("Projetcs");
        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.insets = new Insets(0,10,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label New Student
        label = new Label("New Member");
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label List of Members
        label = new Label("List of Members");
        constraints.gridx = 2;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,10,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //Textfield assignmentID
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(assignmentID,constraints);
        form.add(assignmentID);
        
        //Textfield groupName
        constraints.gridx = 0;
        constraints.gridy = 3;
        gridBag.setConstraints(groupName,constraints);
        form.add(groupName);
        
        //Textfield newMember
        constraints.gridx = 0;
        constraints.gridy = 5;
        gridBag.setConstraints(newMember,constraints);
        form.add(newMember);
        
        //Choice projectsList
        constraints.gridx = 1;
        constraints.gridy = 3;
        constraints.gridwidth = 3;
        constraints.insets = new Insets(0,10,0,0);
        gridBag.setConstraints(projectsList,constraints);
        form.add(projectsList);
        
        //Button add
        constraints.gridx = 1;
        constraints.gridy = 5;
        constraints.gridwidth = 1;
        gridBag.setConstraints(add,constraints);
        form.add(add);
        
        //Button remove
        constraints.gridx = 1;
        constraints.gridy = 6;
        gridBag.setConstraints(remove,constraints);
        form.add(remove);
        
        //List of Members
        constraints.gridx = 2;
        constraints.gridy = 5;
        constraints.gridwidth = 2;
        constraints.gridheight = 3;
        gridBag.setConstraints(membersList,constraints);
        form.add(membersList);
        
        groupForm.add(form,BorderLayout.CENTER);
        
        icon = jImage.loadImage("groups.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(430,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas, BorderLayout.NORTH);
        
        principal.add(groupForm);
        return principal;
    }
    
    /** Method for validation of graphic interface objects.*/
    public boolean validateView() {
        ErrorWindow errorWindow;
        String token;
        StringTokenizer stoken;
        int countList;
        
        // Verify the number of members of the project and of the list
        stoken = new StringTokenizer(projectsList.getSelectedItem(), " ");
        project = stoken.nextToken();
        try {
            token = stoken.nextToken();
            if (token.equals("Min_Students=")) {
                token = stoken.nextToken();
                min_students = Integer.parseInt(token);
            }
            token = stoken.nextToken();
            if (token.equals("Max_Students=")) {
                token = stoken.nextToken();
                max_students = Integer.parseInt(token);
            }
        } catch (NoSuchElementException e) {}
        countList = membersList.getItemCount();
        if ((countList > max_students) || (countList < min_students)) {
            errorWindow = new ErrorWindow("Incorrect number of members.");
            errorWindow.show();
            return false;
        }
        members = new Vector();
        for (int c=0;c<countList;c++)
            members.addElement(membersList.getItem(c));
        return true;
    }
    
    /** Method for management of the database information.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        int numGroups;
        int id_class = 0;
        ResultSet rs;
        java.util.Date date = new java.util.Date();
        
        sql.init(resource);
        
        for (int count = 0;count< members.size(); count++) {
            // Test if each name is a student of this course
            rs = sql.executeQuery("SELECT username FROM students WHERE username='" + members.elementAt(count) +
            "' AND class='" + classGroup + "'");
            if (!rs.next()) throw new RuntimeException("The name " + members.elementAt(count) + " is not a student of your class.");
            // Test if the username is not of another group
            rs = sql.executeQuery("SELECT group_name FROM activities WHERE type='groups' AND id='" +
            assignmentSelected +"' AND username='" + members.elementAt(count) + "' AND class=" + classGroup);
            if (rs.next())
                if (!rs.getString(1).equals(group)) throw new RuntimeException("The user " + members.elementAt(count) + " is registred in another group.");
            
        }
        
        //  Test the number of projects already locked
        rs = sql.executeQuery("SELECT max_groups FROM projects WHERE assignment='" + assignmentSelected +
        "' AND name='" + project + "' AND class='" + classGroup + "'");
        rs.next();
        // get the max groups for this project
        numGroups = rs.getInt(1);
        // get the number of groups for this project
        rs = sql.executeQuery("SELECT DISTINCT groups.name FROM groups,activities WHERE groups.project='" + project +
        "' AND activities.class='" + classGroup + "' AND assignment='" + assignmentSelected +
        "' AND groups.name=activities.group_name");
        
        for(;rs.next();)
            if (!rs.getString(1).equals(group))
                numGroups--;
        
        if (numGroups <= 0) throw new RuntimeException("Too many groups got this project already, choose another.");
        
        //Update the values in DB
        for (int count=0;count < membersOld.size();count++)
            // delete of the activities table all of the members
            sql.executeUpdate("DELETE FROM activities WHERE username='" + membersOld.elementAt(count) +
            "' AND type='groups' AND id='" + assignmentSelected + "' AND class=" + classGroup);
        
        for (int count=0;count < members.size();count++)
            // create the members in activities table
            sql.executeUpdate("INSERT INTO activities VALUES ('" + members.elementAt(count) + "', 'groups'," +
            assignmentSelected + ", '" + group + "', 0,'" + classGroup + "')");
        
        // update the groups table to set the new project
        sql.executeUpdate("UPDATE groups SET project='" + project + "' WHERE name='" + group +
        "' and assignment='" + assignmentSelected + "'");
        
        sql.close();
        
        return "Success";
    }
    
    /** Method for controlling of the operation over the student group (add or remove students).*/
    public void actionPerformed(ActionEvent ev){
        Object source = ev.getSource();
        if ((source == newMember) || (source == add)) {
            addItem(newMember.getText().toLowerCase());
        }
        if (source == remove) {
            // the group creator student can't be removed
            if (membersList.getSelectedItem().equals(username)) {
                ErrorWindow errorWindow = new ErrorWindow("This user can't be removed because he is the group editor.");
                errorWindow.show();
            } else
                membersList.delItem(membersList.getSelectedIndex());
        }
        
    }
    
    /** Method for controlling the addition of itens into de members list.*/
    void addItem(String item) {
        boolean error = false;
        int numberItens = membersList.getItemCount();
        ErrorWindow errorWindow;
        
        if (item.equals("")) {
            errorWindow = new ErrorWindow("Invalid Member.");
            errorWindow.show();
            error = true;
        }
        if (item.indexOf(' ') != -1) {
            errorWindow = new ErrorWindow("Spaces not allowed in the member name.");
            errorWindow.show();
            error = true;
        }
        for (int c=0; c < numberItens; c++) {
            if(item.equals(membersList.getItem(c))) {
                errorWindow = new ErrorWindow("This user already is in the list.");
                errorWindow.show();
                error = true;
            }
        }
        if (!error) {
            membersList.addItem(item);
            newMember.setText("");
            newMember.requestFocus();
        }
    }
    
}
