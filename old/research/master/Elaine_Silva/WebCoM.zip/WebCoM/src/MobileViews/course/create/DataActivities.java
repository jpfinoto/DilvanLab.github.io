/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.create;

import java.io.Serializable;

/** Class for storing information about activities.*/
public class DataActivities implements Serializable {
    public int numberAssignments = 0;
    public int numberReports = 0;
    public int numberTests = 0;
    public int indexAssignments = 0;
    public int indexReports = 0;
    public int indexTests = 0;
    public int idClass = 0;
    public int weightAssignments = 0;
    public int weightReports = 0;
    public int weightTests = 0;
    public String expireClass = null;
    public Assignment assig[] = new Assignment[10];
    public ReportTest report[] = new ReportTest[10];
    public ReportTest test[] = new ReportTest[10];
    
    
    /** Method for creation of a new instance from this class.*/
    public DataActivities() {
        for (int aux1=0; aux1<10; aux1++) {
            assig[aux1]= new Assignment();
            report[aux1] = new ReportTest();
            test[aux1] = new ReportTest();
        }
    }
}


