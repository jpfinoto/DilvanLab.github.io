/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents.security;

import java.io.*;
import cryptix.*;

/** Method for codification of messages.*/
public class ObjectOutputCrypt {
    private String passwd;
    private ObjectOutput out;
    
    /** Method for creating a new instance of the class.*/
    public ObjectOutputCrypt(String passwd, ObjectOutput out) {
        this.passwd= passwd;
        this.out= out;
    }
    
    /** Method for codifying a object using a password.*/
    public void writeObject(Object obj) throws IOException {
        out.writeObject(writeObject(passwd, obj));
    }
    
    /** Method to execute the cryptography of the buffer using a password.*/
    public static byte[] writeObject(String passwd, Object obj) throws IOException {
        IDEA idea= new IDEA( MessageDigest.hash( passwd, new MD5()));
        ByteArrayOutputStream outBuffer= new ByteArrayOutputStream();
        ObjectOutputStream out= new ObjectOutputStream(outBuffer);
        out.writeObject(obj);
        byte[] buf1= outBuffer.toByteArray();
        
        int blocks= buf1.length / idea.blockLength();
        if ((buf1.length % idea.blockLength()) > 0) blocks++;
        byte[] buffer= new byte[blocks*idea.blockLength()];
        
        System.arraycopy(buf1, 0, buffer, 0, buf1.length);
        
        for (int aux1=0; aux1<blocks; aux1++)
            idea.encrypt(buffer, aux1*idea.blockLength(), buffer, aux1*idea.blockLength());
        
        return buffer;
    }
}