/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents.sql;

import java.sql.*;
import java.util.*;
import java.io.File;
import java.io.IOException;
import agents.*;
import agents.agent.Defaults;
import java.io.InputStream;

/** Class for implementation of the methods for manipulating the databases.*/
public class SQLDatabase implements SQL {
    Connection con;
    
    public final static String ASSIGNMENT_ACCESS= "Assignment";
    public final static String REVIEW_ACCESS= "Review";
    public final static String REPORT_ACCESS= "Report";
    public final static String MONITOR_ACCESS= "Monitor";
    
    /** Method for creating a new instance of this class.*/
    public SQLDatabase() throws SQLException, ClassNotFoundException {
        if (!Defaults.PROPERTIES_OK) {
            InputStream in = getClass().getResourceAsStream("/server.properties");
            Defaults.setPropertiesDefaults(in);  // read the properties file
        }
        Defaults.initSQLDrivers(); //Openning SQL connection
    }
    
    /** Method for deleting a database.*/
    public void drop(String database) throws IOException {
        Process p= Runtime.getRuntime().exec("mysqladmin -f drop " + database);
        try {p.waitFor();}catch(Exception e) {}
    }
    
    /** Method for creating a database.*/
    public void create(String database) throws IOException {
        Process p= Runtime.getRuntime().exec("mysqladmin create " + database);
        try {p.waitFor();}
        catch(Exception e) {}
    }
    
    /** Method for connecting to one database.*/
    public void init(String database) throws SQLException {
        if (con!=null) con.close();
        con = DriverManager.getConnection(Defaults.SQL_URL + database);
    }
    
    /** Method for executing query in a connected database.*/
    public ResultSet executeQuery(String query) throws SQLException {
        Statement stmt= con.createStatement();
        return stmt.executeQuery(query);
    }
    
    /** Method for executing update in a connected database.*/
    public synchronized int executeUpdate(String query) throws SQLException {
        Statement stmt= con.createStatement();
        return stmt.executeUpdate(query);
    }
    
    /** Method for closing connection with a database.*/
    public void close() throws SQLException {
        con = null;
    }
    
    /** Method for getting the password of the student in the database.*/
    public String getPassword(String username) throws SQLException{
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT password FROM users WHERE username='" + username + "'");
        rs.next();
        return rs.getString(1);
    }
    
    /** Method for getting the email of the student in the database.*/
    public String getEmail(String username) throws SQLException{
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT email FROM users WHERE username='" + username + "'");
        rs.next();
        return rs.getString(1);
    }
    
    /** Method for getting the user type of the student in the database.*/
    public String getUserType(String username) throws SQLException{
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT type FROM users WHERE username='" + username + "'");
        rs.next();
        return rs.getString(1);
    }
    
    /** Method for getting the log options for the FTP. This method return a list of activities (assignment, reviews and reports).*/
    public String [] getLogOptions(int classSelected) throws SQLException {
        int count = 0;
        int positions = 0;
        
        // get all of the assignments to one class
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT id,use_review FROM assignments WHERE class='" + classSelected + "'");
        for (;rs.next();) {
            positions++;
            if (rs.getString(2).equals("true")) {
                // if there are reviews
                positions++;
            }
        }
        // get all of the reports to one class
        rs = stmt.executeQuery("SELECT id FROM reports WHERE class='" + classSelected + "'");
        for (;rs.next();)
            positions++;
        
        // create the options vector
        String[] options = new String[positions+1];
        
        // set each position of the vector with one activity
        rs = stmt.executeQuery("SELECT id,use_review FROM assignments WHERE class='" + classSelected + "'");
        
        for (;rs.next();) {
            options[count] = ASSIGNMENT_ACCESS + " " + rs.getString(1);
            count++;
            if (rs.getString(2).equals("true")) {
                options[count] = REVIEW_ACCESS + " " + rs.getString(1);
                count++;
            }
        }
        
        rs = stmt.executeQuery("SELECT id FROM reports WHERE class='" + classSelected + "'");
        for (;rs.next();count++)
            options[count] = REPORT_ACCESS + " " + rs.getString(1);
        
        // set the last position to monitor access.
        options[count]= MONITOR_ACCESS;
        
        return options;
    }
    
    /** Method for getting the directory of the student or group for the FTP.*/
    public String getDirectory(String username, String dir, java.util.Date exp_date, String directoryCourse, int classSelected) throws SQLException {
        //	Get accessType and subType fields
        StringTokenizer analex= new StringTokenizer(dir); // type of activity
        String accessType= analex.nextToken();
        int subType= 0;
        try {
            subType= Integer.parseInt(analex.nextToken()); // id of the activity
        } catch (Exception e) {}
        
        return getDirectory(username, accessType, subType, exp_date,directoryCourse, classSelected);
    }
    
    /** Method for returning the access directory to the user.*/
    public String getDirectory(String username, String accessType, int subType, java.util.Date exp_date, String directoryCourse, int classSelected) throws SQLException {
        String query;
        ResultSet rs;
        String directory = directoryCourse;
        Statement stmt= con.createStatement();
        
        // select the group name of the user (login)
        if (accessType.equalsIgnoreCase(ASSIGNMENT_ACCESS)) {
            query = "SELECT groups.name FROM groups,activities WHERE activities.username='" +
            username + "' AND activities.type= 'groups' AND " +
            "activities.group_name = groups.name AND groups.assignment = " + subType + " AND activities.id=" + subType;
            rs = stmt.executeQuery(query);
            rs.next();
            directory= directory + File.separator + "homework" + File.separator + classSelected + File.separator + "assignments" + File.separator +  subType + File.separator + rs.getString(1);
            
            //	Get expiration date
            query = "SELECT date FROM assignments WHERE id='" + subType + "' AND class='" + classSelected + "'";
            rs = stmt.executeQuery(query);
            rs.next();
            
            // Set time and add 23h 59m 59 sec, because the getDate returns
            // at 0 am
            exp_date.setTime(rs.getDate(1).getTime() + SQL.MS_23H59M59S);
            return directory;
        } else
            // select the group name of the user (login)
            if (accessType.equalsIgnoreCase(REVIEW_ACCESS)) {
                query= "SELECT groups.reviews FROM groups,activities WHERE activities.username='" +
                username + "' AND activities.type= 'groups' AND " +
                "activities.group_name = groups.name AND groups.assignment = " + subType + " AND activities.id=" + subType;
                rs = stmt.executeQuery(query);
                rs.next();
                
                if (rs.getString(1).equals("")) throw new RuntimeException("Review group not determined.");
                directory= directory + File.separator + "homework"+ File.separator + classSelected  + File.separator + "reviews" + File.separator + subType + File.separator +  rs.getString(1);
                
                //	Get expiration date
                query = "SELECT review_date FROM assignments WHERE id='" + subType + "' AND class='" + classSelected + "'";
                rs = stmt.executeQuery(query);
                rs.next();
                exp_date.setTime(rs.getDate(1).getTime() + SQL.MS_23H59M59S);
                return directory;
            } else
                // set the directory to the name of the user (login)
                if (accessType.equalsIgnoreCase(REPORT_ACCESS)) {
                    directory= directory + File.separator + "homework"+ File.separator + classSelected  + File.separator + "reports" + File.separator + subType + File.separator + username;
                    //	Get expiration date
                    query = "SELECT date FROM reports WHERE id='" + subType + "' AND class='" + classSelected + "'";
                    rs = stmt.executeQuery(query);
                    rs.next();
                    exp_date.setTime(rs.getDate(1).getTime() + SQL.MS_23H59M59S);
                    return directory;
                } else
                    // get the directory to the monitor.
                    if (accessType.equalsIgnoreCase(MONITOR_ACCESS)) {
                        query = "SELECT directory, expire FROM monitors WHERE username='" + username +"'";
                        rs = stmt.executeQuery(query);
                        rs.next();
                        if (!rs.getString(1).equals("/"))
                            directory= directory + File.separator + rs.getString(1);
                        
                        //	Get expiration date
                        exp_date.setTime(rs.getDate(2).getTime() + SQL.MS_23H59M59S);
                        return directory;
                    } throw new RuntimeException("Unknown Access Type");
    }
}

