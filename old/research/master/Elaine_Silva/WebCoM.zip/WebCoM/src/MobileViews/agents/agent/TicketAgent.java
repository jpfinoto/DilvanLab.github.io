/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents.agent;

import java.awt.*;
import java.io.*;
import java.util.Date;
import java.sql.*;

import agents.*;
import agents.sql.*;
import agents.security.*;

/** Class for management of the user ticket.*/
public class TicketAgent implements agents.query.ObjectStream {
    protected String passwd;
    
    /** Method for creating a new instance of the class.*/
    public TicketAgent() {
        passwd= Defaults.PASSWD;
    }
    
    /** Method for creating a new instance of the class.
     * The parameter password is used for crypt the ticket.*/
    public TicketAgent(String passwd) {
        this.passwd= passwd;
    }
    
    /** Method for receiving the request and sending the response to the database servlet.*/
    public void query(ObjectInput in, ObjectOutput out) throws Exception {
        out.writeObject(query(in.readObject()));
    }
    
    /** Method for executing the request.*/
    public Object query(Object msg1) throws Exception {
        Message msg= (Message) msg1;
        String queryType= (String) msg.body.elementAt(0);
        
        // generate the ticket
        if (queryType.equals("ticket")) {
            Ticket ticket= generateTicket(msg);
            return encodeTicket(ticket);
        } throw new RuntimeException("Unknown query");
    }
    
    /** Method for generating ticket to login.*/
    public Ticket generateTicket(Message msg) throws Exception {
        String passwordUserLogin = null, typeUserLogin = null;
        String message;
        SQLDatabase sql;
        String directory;
        ResultSet rs;
        
        String resource= (String) msg.body.elementAt(1);
        String username= (String) msg.body.elementAt(2);
        
        if (resource==null || username==null) throw new RuntimeException("Null reading");
        sql = new SQLDatabase();
        sql.init(Defaults.WEBCOMDATABASE);
        // get the password and type of the user
        rs = sql.executeQuery("SELECT password, type FROM users WHERE username='" + username + "'");
        rs.next();
        passwordUserLogin = rs.getString(1);
        typeUserLogin = rs.getString(2);
        sql.close();
        
        if (!typeUserLogin.equals("administrator")) {
            // Verify if he is monitor
            sql.init(resource);
            rs = sql.executeQuery("SELECT username FROM monitors WHERE username='" + username + "'");
            if (rs.next())
                typeUserLogin = "monitor";
            else
                typeUserLogin = "student";
            sql.close();
        }
        
        // create the ticket
        Ticket ticket= new Ticket(resource, username, passwordUserLogin, typeUserLogin);
        
        //	Validate the user
        byte[] userTicket= (byte[]) msg.body.elementAt(3);
        validateUserTicket(ticket.password, resource, username, userTicket);
        
        //	If password verified
        return ticket;
    }
    
    /** Method for decoding the ticket with defaults password.*/
    public static Ticket decodeTicket(byte[] tic) throws IOException, ClassNotFoundException {
        return (Ticket) ObjectInputCrypt.readObject(Defaults.PASSWD,tic);
    }
    
    /** Method for encode the ticket with defaults password.*/
    public static byte[] encodeTicket(Ticket ticket) throws IOException {
        return ObjectOutputCrypt.writeObject(Defaults.PASSWD, ticket);
    }
    
    /** Method for validating the user ticket.*/
    public static void validateUserTicket(String passwd, String resource, String username, byte[] userTicket)
    throws IOException, ClassNotFoundException {
        // decode the ticket
        String[] buf= (String[]) ObjectInputCrypt.readObject(passwd, userTicket);
        // test the information
        if (buf[0].equals(resource) && buf[1].equals(username)) return;
        throw new RuntimeException("Can't validate password.");
    }
    
    /** Method for decoding the message (which is the ticket).
     *  It decodes the ticket and verifies if the time is not expired.*/
    public static void decode(Message msg) throws IOException, ClassNotFoundException {
        byte[] encTic= (byte[]) msg.ticket;
        msg.ticket= decodeTicket(encTic);
        Ticket tic= (Ticket) msg.ticket;
        Date now = new Date();
        if ((now.getTime() - tic.date.getTime()) > Defaults.TICKET_TIMEOUT)
            throw new RuntimeException("Ticket timed out.");
        //	For registration Tickets
        if (tic.username==null && (now.getTime() - tic.date.getTime()) > Defaults.TICKET_TIMEOUT/5)
            throw new RuntimeException("Ticket timed out.");
        
        msg.decode(((Ticket)msg.ticket).password);
    }
}