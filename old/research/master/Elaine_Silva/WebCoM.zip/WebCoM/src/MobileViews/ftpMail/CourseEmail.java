/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package ftpMail;

import java.util.*;
import java.io.*;
import java.net.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import agents.agent.Defaults;

/** Class for sending emails with response of the FTP email.*/
public class CourseEmail {
    static public String FROM;
    static public String HOST;
    
    private Address[] to;
    private String msg2;
    
    /** Method constructor with only one email.*/
    public CourseEmail(String emailto) throws AddressException {
        try {
            to = InternetAddress.parse(emailto);
        }catch(AddressException e){}
    }
    
    /** Method constructor with more than one email.*/
    public CourseEmail(Address[] emailto) {
        to=emailto;
    }
    
    /** Method for setting one message.*/
    public void setMsg2(String msg) { msg2=msg;}
    
    /** Method for sending the email message.*/
    public void envia(String msgText) throws AddressException, MessagingException {
        if (!Defaults.PROPERTIES_OK) {
            InputStream in = getClass().getResourceAsStream("/server.properties");
            Defaults.setPropertiesDefaults(in);
        }
        FROM = Defaults.FROM;
        HOST = Defaults.HOST;
        
        String subject = "File Upload";
        
        Properties props = System.getProperties();
        props.put("mail.smtp.host", HOST);
        Session session = Session.getDefaultInstance(props, null);
        session.setDebug(false);
        MimeMessage msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(FROM));
        msg.setRecipients(Message.RecipientType.TO, to);
        msg.setSubject(subject);
        MimeBodyPart mbp1 = new MimeBodyPart();
        mbp1.setText(msgText);
        Multipart mp = new MimeMultipart();
        mp.addBodyPart(mbp1);
        if (msg2!=null) {
            MimeBodyPart mbp2 = new MimeBodyPart();
            mbp2.setText(msg2);
            mp.addBodyPart(mbp2);
        }
        msg.setContent(mp); //adiciona as 2 partes do e-mail ao contexto
        //que ser� enviado
        msg.setSentDate(new Date()); //Seta a data
        Transport.send(msg);   //Manda o e-mail
    }
}


