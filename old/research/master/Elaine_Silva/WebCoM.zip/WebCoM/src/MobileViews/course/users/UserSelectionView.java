/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.users;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class for management of users. There is options to select the user type (administrator, monitor and student) 
 * and to select the operation (add, edit or remove).*/
public class UserSelectionView implements View, Serializable, ItemListener {
    Ticket tic;
    int userTypeSelected = -1;
    String operationSelected = null;
    String classSelected = null;
    
    transient Choice type;
    transient Choice actions1;
    transient Choice actions2;
    transient Choice classSelection;
    Vector listClass;
    
    /** Method for creation of a new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.tic = tic;
        sql.init(tic.resource);
        // test the user type
        if (!tic.type.equals("administrator") && !tic.type.equals("monitor"))
            throw new RuntimeException("You don't have permissions to access this tool.");
        listClass = new Vector();
        int contList = 0;
        
        // Select all of the classes to manage users
        ResultSet rs = sql.executeQuery("SELECT id,expire FROM class");
        java.util.Date date = new java.util.Date();
        for(;rs.next();) {
            if (UtilFunctions.verifyDate(date,rs.getDate(2)) >= 0) {
                listClass.addElement("Class " + rs.getString(1));
                contList++;
            }
        }
        if (contList == 0) throw new RuntimeException("Don't have any class.");
        sql.close();
        
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,0));
        
        type = new Choice();
        type.addItem("Student");
        type.addItem("Monitor");
        type.addItem("Administrator");
        type.addItemListener(this);
        
        Panel listOptions = new Panel();
        listOptions.setLayout(new FlowLayout());
        listOptions.add(new Label("Select a type of system user:"));
        listOptions.add(type);
        
        Panel actions1Panel = new Panel();
        actions1Panel.setLayout(new FlowLayout());
        actions1 = new Choice();
        actions1.addItem("Add");
        actions1.addItem("Edit");
        actions1.addItem("Remove");
        actions1Panel.add(actions1);
        actions1.addItemListener(this);
        
        Panel listActions = new Panel();
        listActions.setLayout(new FlowLayout());
        listActions.add(new Label("Select an operation to the user: "));
        listActions.add(actions1Panel);
        
        Panel classPanel = new Panel();
        classPanel.setLayout(new FlowLayout());
        classPanel.add(new Label("List Students from:"));
        
        classSelection = new Choice();
        for (int count = 0; count < listClass.size(); count++)
            classSelection.addItem((String) listClass.elementAt(count));
        
        classSelection.setEnabled(false);
        
        classPanel.add(classSelection);
        
        principal.add(listOptions,BorderLayout.NORTH);
        principal.add(listActions,BorderLayout.CENTER);
        principal.add(classPanel, BorderLayout.SOUTH);
        
        return principal;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        userTypeSelected = type.getSelectedIndex();
        operationSelected = actions1.getSelectedItem();
        classSelected = classSelection.getSelectedItem();
        return true;
    }
    
    /** Method that invokes the class for execution of the selected operation.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        
        // user type : student
        if (userTypeSelected == 0) {
            if (operationSelected.equals("Add")) {
                StudentView student = new StudentView();
                return student.createView(tic,sql);
            } else if (operationSelected.equals("Edit")) {
                EditRemoveStudentView editRemoveStudentView = new EditRemoveStudentView();
                editRemoveStudentView.setVariable(classSelected,"edit");
                return editRemoveStudentView.createView(tic, sql);
            } else {
                EditRemoveStudentView editRemoveStudentView = new EditRemoveStudentView();
                editRemoveStudentView.setVariable(classSelected,"remove");
                return editRemoveStudentView.createView(tic, sql);
            }
        }
        // user type : monitor
        if (userTypeSelected == 1) {
            if (operationSelected.equals("Add")) {
                MonitorView monitor = new MonitorView();
                return monitor.createView(tic,sql);
            } else if (operationSelected.equals("Edit")) {
                EditRemoveMonitorAdminView editRemoveMonitorAdminView = new EditRemoveMonitorAdminView();
                editRemoveMonitorAdminView.setVariable("monitor","edit");
                return editRemoveMonitorAdminView.createView(tic, sql);
            } else {
                EditRemoveMonitorAdminView editRemoveMonitorAdminView = new EditRemoveMonitorAdminView();
                editRemoveMonitorAdminView.setVariable("monitor","remove");
                return editRemoveMonitorAdminView.createView(tic,sql);
            }
        }
        // user type : administrator
        if (userTypeSelected == 2) {
            if (!tic.type.equals("administrator")) throw new RuntimeException("You don't have permissions to execute this function.");
            
            if (operationSelected.equals("Add")) {
                AdminView admin = new AdminView();
                return admin.createView(tic,sql);
            } else if (operationSelected.equals("Edit")) {
                EditRemoveMonitorAdminView editRemoveMonitorAdminView = new EditRemoveMonitorAdminView();
                editRemoveMonitorAdminView.setVariable("administrator","edit");
                return editRemoveMonitorAdminView.createView(tic, sql);
            } else {
                EditRemoveMonitorAdminView editRemoveMonitorAdminView = new EditRemoveMonitorAdminView();
                editRemoveMonitorAdminView.setVariable("administrator","remove");
                return editRemoveMonitorAdminView.createView(tic,sql);
            }
        }
        return "";
    }
    
    /** Method for controlling of the users action over the operations and users list.*/
    public void itemStateChanged(ItemEvent e) {
        Object source = e.getSource();
        int typeSelected = type.getSelectedIndex(); // get selected user type
        int actionSelected = actions1.getSelectedIndex(); // get selected operation
        
        // event over user type selecttion
        if (source==type) {
            // if edit or remove student
            if ((typeSelected == 0) && ((actionSelected == 1) || (actionSelected == 2)))
                classSelection.setEnabled(true);  // enable class selection
            else
                classSelection.setEnabled(false); // disabel class selection
        }
        
        // event over operations selection
        if (source == actions1) {
            // if edit or remove student
            if ((typeSelected == 0) && ((actionSelected == 1) || (actionSelected == 2))) {
                classSelection.setEnabled(true);      // enable class selection
            } else
                classSelection.setEnabled(false);     // disable class selection
        }
        
    }
    
}
