/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import course.create.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class to create a new class. Here are defined the types of activities and dates for each activity.*/
public class ClassViewInterface implements View, Serializable, ActionListener {
    transient Label message;
    transient course.create.ClassPanel classPanel;
    transient ActivitiesPanel activitiesPanel;
    transient AssignmentPanel assignmentsPanel;
    transient ReportPanel reportsPanel;
    transient TestPanel testsPanel;
    transient EndPanel endPanel;
    transient Button buttonNext, buttonBack;
    transient Panel p1,p2,p3,p4,p5,p6,principal,steps, buttons;
    
    String resource;
    int controlInterface = 0;
    int idNewClass = 0,classSelectedToCopy;
    boolean okViews = false;
    CardLayout card = new CardLayout();
    DataActivities dataActivities;
    Ticket tic;
    
    /* Method for setting variables.*/    
    public void setVariable(int idNewClass, int classSelectedToCopy){
        this.idNewClass = idNewClass;
        this.classSelectedToCopy = classSelectedToCopy;
    }
    
    /** Method for creation new instance from the View class. If the new class was equals other one (copying from another class), the data will be got here.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.resource = tic.resource;
        this.tic = tic;
        
        if (!tic.type.equals("administrator")) throw new RuntimeException("You don't have permissions to access this tool");
        dataActivities = new DataActivities(); // class to store the course basic information
        if (classSelectedToCopy != -1) {
            // get date for class selected
            sql.init(resource);
            ResultSet rs = sql.executeQuery("SELECT expire, weight_assignment, weight_report, weight_test FROM class WHERE id='" + classSelectedToCopy + "'");
            rs.next();
            dataActivities.expireClass=UtilFunctions.deconvertDate(rs.getString(1));
            dataActivities.weightAssignments = Integer.parseInt(rs.getString(2));
            dataActivities.weightReports = Integer.parseInt(rs.getString(3));
            dataActivities.weightTests = Integer.parseInt(rs.getString(4));
            
            // get the tests of the other class
            rs = sql.executeQuery("SELECT id,date,weight FROM tests WHERE class='" + classSelectedToCopy + "'");
            for (;rs.next();) {
                dataActivities.test[dataActivities.indexTests].id = rs.getInt(1);
                dataActivities.test[dataActivities.indexTests].deliveryDate = UtilFunctions.deconvertDate(rs.getString(2));
                dataActivities.test[dataActivities.indexTests].weight = String.valueOf(rs.getInt(3));
                dataActivities.numberTests++;
                dataActivities.indexTests++;
            }
            dataActivities.indexTests = 0;
            
            // get the reports of the other class
            rs = sql.executeQuery("SELECT id,date,weight FROM reports WHERE class='" + classSelectedToCopy + "'");
            for (;rs.next();) {
                dataActivities.report[dataActivities.indexReports].id = rs.getInt(1);
                dataActivities.report[dataActivities.indexReports].deliveryDate = UtilFunctions.deconvertDate(rs.getString(2));
                dataActivities.report[dataActivities.indexReports].weight = String.valueOf(rs.getInt(3));
                dataActivities.numberReports++;
                dataActivities.indexReports++;
            }
            dataActivities.indexReports = 0;
            
            // get the assignments of the other class
            rs = sql.executeQuery("SELECT id,date,review_date,weight,use_review FROM assignments WHERE class='" + classSelectedToCopy + "'");
            ResultSet rs1;
            for (;rs.next();) {
                dataActivities.assig[dataActivities.indexAssignments].idAssignment = rs.getInt(1);
                dataActivities.assig[dataActivities.indexAssignments].deliveryDate = UtilFunctions.deconvertDate(rs.getString(2));
                if (rs.getString(5).equals("true"))
                    dataActivities.assig[dataActivities.indexAssignments].reviewDate = UtilFunctions.deconvertDate(rs.getString(3));
                else
                    dataActivities.assig[dataActivities.indexAssignments].reviewDate = "";
                dataActivities.assig[dataActivities.indexAssignments].weight = String.valueOf(rs.getInt(4));
                
                rs1 = sql.executeQuery("SELECT name, max_groups, min_users, max_users FROM projects WHERE assignment='" + rs.getInt(1) +
                "' AND class='" + classSelectedToCopy + "'");
                int positionProject;
                for (positionProject=0;rs1.next();positionProject++) {
                    dataActivities.assig[dataActivities.indexAssignments].projects[positionProject] = "Project " +
                    rs1.getString(1) + " MaxGroup " + rs1.getInt(2) + " MinStudents " + rs1.getInt(3) + " MaxStudents " +
                    rs1.getInt(4);
                }
                dataActivities.assig[dataActivities.indexAssignments].numberProjects = positionProject;
                dataActivities.numberAssignments++;
                dataActivities.indexAssignments++;
            }
            dataActivities.indexAssignments = 0;
        }
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        principal = new Panel();
        message = new Label();
        
        principal.setLayout(new BorderLayout(0,0));
        principal.setFont(new Font("Helvetica", Font.PLAIN, 12));
        
        buttonNext = new Button("  NEXT >> ");
        buttonNext.setBackground(Color.lightGray);
        buttonNext.addActionListener(this);
        
        buttonBack = new Button(" << BACK  ");
        buttonBack.setBackground(Color.lightGray);
        buttonBack.addActionListener(this);
        
        classPanel = new course.create.ClassPanel(idNewClass+1,classSelectedToCopy,dataActivities);
        p1 = classPanel.initView();
        
        activitiesPanel = new ActivitiesPanel();
        p2 = activitiesPanel.initView();
        
        assignmentsPanel = new AssignmentPanel();
        p3 = assignmentsPanel.initView();
        
        reportsPanel = new ReportPanel();
        p4 = reportsPanel.initView();
        
        testsPanel = new TestPanel();
        p5 = testsPanel.initView();
        
        endPanel = new EndPanel();
        p6 = endPanel.initView();
        
        steps = new Panel();
        steps.setLayout(card);
        steps.add(p1,"Class");
        steps.add(p2,"Activities");
        steps.add(p3,"Assignments");
        steps.add(p4,"Reports");
        steps.add(p5,"Tests");
        steps.add(p6,"End");
        
        buttons = new Panel();
        buttons.setLayout(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        buttons.add(buttonBack);
        buttons.add(buttonNext);
        
        card.first(steps);
        buttonBack.setEnabled(false);
        principal.add(steps,BorderLayout.NORTH);
        principal.add(buttons, BorderLayout.CENTER);
        principal.add(message, BorderLayout.SOUTH);
        
        return principal;
    }
    
    /** Method for managemento of the actions over the graphic interface buttons.*/
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        int errorView;
        ErrorWindow er = null;
        boolean endAssignment = false;
        
        if (source == buttonNext) {
            if (controlInterface == 0) {
                errorView = classPanel.validateView();
                if (errorView == 0) {
                    dataActivities = classPanel.update(dataActivities);
                    controlInterface = 1;
                    buttonBack.setEnabled(true);
                } else {
                    er = new ErrorWindow("Invalid date.");
                }
            } else if (controlInterface == 1) {
                errorView = activitiesPanel.validateView();
                if (errorView == 0) {
                    dataActivities = activitiesPanel.update(dataActivities);
                    if (dataActivities.numberAssignments > 0) {
                        controlInterface = 2;
                    } else if (dataActivities.numberReports > 0)
                        controlInterface = 3;
                    else if (dataActivities.numberTests > 0)
                        controlInterface = 4;
                } else {
                    er = new ErrorWindow("The number and weight of the activities can not be zero (0)");
                    er.show();
                }
                
            } else if (controlInterface == 2) {
                errorView = assignmentsPanel.validateView(dataActivities);
                if (errorView == 0) {
                    dataActivities = assignmentsPanel.update(dataActivities);                                   // Record the data of assignment
                    if (dataActivities.indexAssignments >= dataActivities.numberAssignments)
                        if (dataActivities.numberReports > 0)                               // if there is reports
                            controlInterface = 3;
                        else if (dataActivities.numberTests > 0)                              // if there is tests
                            controlInterface = 4;
                        else
                            controlInterface = 5;
                } else {
                    if (errorView == 1)
                        er = new ErrorWindow("The review date is before of the assignment date.");
                    if (errorView == 2)
                        er = new ErrorWindow("Missign projects.");
                    if (errorView == 3)
                        er = new ErrorWindow("Invalid date to assignment.");
                    if (errorView == 4)
                        er = new ErrorWindow("Some date is after the class's expire date.");
                    if (errorView == 5)
                        er = new ErrorWindow("The assignment delivery date should be ordered.");
                    if (errorView == 6)
                        er = new ErrorWindow("The weight should be bigger than 0 (zero).");
                    er.show();
                }
            } else if (controlInterface == 3) {
                errorView = reportsPanel.validateView(dataActivities);
                if (errorView == 0) {
                    dataActivities = reportsPanel.update(dataActivities);
                    if (dataActivities.indexReports >= dataActivities.numberReports)
                        if (dataActivities.numberTests > 0)
                            controlInterface = 4;
                        else
                            controlInterface = 5;
                } else {
                    if (errorView == 1)
                        er = new ErrorWindow("Invalid Information.");
                    if (errorView == 2)
                        er = new ErrorWindow("The report date is after the class's expire date.");
                    if (errorView == 3)
                        er = new ErrorWindow("The report delivery date should be orderer.");
                    if (errorView == 4)
                        er = new ErrorWindow("The weight should be bigger than 0.");
                    er.show();
                }
            } else if (controlInterface == 4) {
                errorView = testsPanel.validateView(dataActivities);
                if (errorView == 0) {
                    dataActivities = testsPanel.update(dataActivities);
                    if (dataActivities.indexTests >= dataActivities.numberTests)
                        controlInterface = 5;
                } else {
                    if (errorView == 1)
                        er = new ErrorWindow("Invalid Information.");
                    if (errorView == 2)
                        er = new ErrorWindow("The test date is after the class's expire date.");
                    if (errorView == 3)
                        er = new ErrorWindow("The test delivery date should be orderer .");
                    if (errorView == 4)
                        er = new ErrorWindow("The weight should be bigger than 0.");
                    er.show();
                }
            }
            if (controlInterface == 1) {
                if (classSelectedToCopy != -1)
                    activitiesPanel.atualizeView(dataActivities);
                card.show(steps,"Activities");
            }
            if (controlInterface == 2) {
                assignmentsPanel.atualizeView(dataActivities);
                card.show(steps,"Assignments");
            }
            if (controlInterface == 3) {
                reportsPanel.atualizeView(dataActivities);
                card.show(steps,"Reports");
            }
            if (controlInterface == 4) {
                testsPanel.atualizeView(dataActivities);
                card.show(steps,"Tests");
            }
            if (controlInterface == 5) {
                card.show(steps,"End");
                okViews = true;
                buttonNext.setEnabled(false);
            }
            return;
        }
        if (source == buttonBack) {
            if (controlInterface == 5) {
                okViews = false;
                buttonNext.setEnabled(true);
                if (dataActivities.indexTests > 0) {
                    dataActivities.indexTests--;
                    controlInterface = 4;
                } else if (dataActivities.indexReports > 0) {
                    dataActivities.indexReports--;
                    controlInterface = 3;
                } else if (dataActivities.indexAssignments > 0) {
                    dataActivities.indexAssignments--;
                    controlInterface = 2;
                }
            } else if (controlInterface == 4) {
                if (dataActivities.indexTests > 0) {
                    dataActivities.indexTests--;
                } else {
                    if (dataActivities.indexReports > 0) {
                        dataActivities.indexReports--;
                        controlInterface = 3;
                    } else if (dataActivities.indexAssignments > 0) {
                        dataActivities.indexAssignments--;
                        controlInterface = 2;
                    } else
                        controlInterface = 1;
                }
            } else if (controlInterface == 3) {
                if (dataActivities.indexReports > 0) {
                    dataActivities.indexReports--;
                } else {
                    if (dataActivities.indexAssignments > 0) {
                        dataActivities.indexAssignments--;
                        controlInterface = 2;
                    } else
                        controlInterface = 1;
                }
            } else if (controlInterface == 2) {
                if (dataActivities.indexAssignments > 0)
                    dataActivities.indexAssignments--;
                else
                    controlInterface = 1;
            } else if (controlInterface == 1) {
                controlInterface = 0;
                buttonBack.setEnabled(false);
            }
            if (controlInterface == 4) {
                testsPanel.atualizeView(dataActivities);
                card.show(steps,"Tests");
            }
            if (controlInterface == 3) {
                reportsPanel.atualizeView(dataActivities);
                card.show(steps,"Reports");
            }
            if (controlInterface == 2){
                assignmentsPanel.atualizeView(dataActivities);
                card.show(steps,"Assignments");
            }
            if (controlInterface == 1)
                card.show(steps,"Activities");
            
            if (controlInterface == 0)
                card.show(steps,"Class");
            
            return;
        }
    }
    
    /** Method for validation of the graphic interface information. */
    public boolean validateView() {
        ErrorWindow er;
        //Test if the user made all of the tasks
        if (!okViews) {
            er = new ErrorWindow("Incomplete configuration.");
            er.show();
            return false;
        }
        return true;
    }
    
    /** Method for storing information into the database and for creation of directories.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        String instruction = null;
        
        // get the root directory of this course
        sql.init(Defaults.WEBCOMDATABASE);
        ResultSet rs = sql.executeQuery("SELECT directory FROM basic_info WHERE database_name='" + resource + "'");
        rs.next();
        String directory = rs.getString(1);
        sql.close();
        
        sql.init(resource);
        // insert the new class in the database
        sql.executeUpdate("INSERT INTO class VALUES('" + dataActivities.idClass + "','" + UtilFunctions.convertDate(dataActivities.expireClass) + "','" + dataActivities.weightAssignments + "','" + dataActivities.weightReports + "','" + dataActivities.weightTests + "',CURDATE())");
        // make directories for the activities
        try {
            UtilFunctions.createDirectoryClass(directory, dataActivities.numberAssignments, dataActivities.numberReports, dataActivities.idClass);
        } catch (Exception e) {return "Error generating directory /homework. Directories not created.";};
        
        // insert the data about the assignments
        if (dataActivities.numberAssignments > 0) {
            String name_project = null;
            String max_groups = null;
            String max_students = null;
            String min_students = null;
            StringTokenizer stoken;
            String token;
            String use_review;
            String date_review;
            
            boolean endToken = true;
            for (int cont=0; cont < dataActivities.numberAssignments; cont++){
                if (!dataActivities.assig[cont].reviewDate.equals("")) {
                    use_review = "true";
                    date_review = dataActivities.assig[cont].reviewDate;
                } else {
                    use_review = "false";
                    date_review = "";
                }
                instruction = new String("INSERT INTO assignments VALUES ('" +
                dataActivities.assig[cont].idAssignment + "','" +
                UtilFunctions.convertDate(dataActivities.assig[cont].deliveryDate) + "','" +
                UtilFunctions.convertDate(date_review) + "','" +
                dataActivities.assig[cont].weight + "','" + use_review + "','" +
                dataActivities.idClass + "')");
                sql.executeUpdate(instruction);
                
                for (int cont2 = 0; cont2 < dataActivities.assig[cont].numberProjects; cont2++) {
                    stoken = new StringTokenizer(dataActivities.assig[cont].projects[cont2], " ");
                    while (endToken) {
                        try {
                            token = stoken.nextToken();
                            if (token.equals("Project"))
                                name_project = stoken.nextToken();
                            if (token.equals("MaxGroup"))
                                max_groups = stoken.nextToken();
                            if (token.equals("MaxStudents"))
                                max_students = stoken.nextToken();
                            if (token.equals("MinStudents"))
                                min_students = stoken.nextToken();
                        } catch (NoSuchElementException e) {endToken = false;}
                    }
                    instruction = new String("INSERT INTO projects VALUES ('" +
                    name_project + "','" +
                    dataActivities.assig[cont].idAssignment + "','" +
                    max_groups + "','" +
                    min_students + "','" +
                    max_students + "','" +
                    dataActivities.idClass + "')");
                    sql.executeUpdate(instruction);
                    endToken = true;
                }
            }
        }
        // insert data about the reports
        if (dataActivities.numberReports > 0) {
            for (int cont=0; cont < dataActivities.numberReports; cont++){
                instruction = new String("INSERT INTO reports VALUES ('" +
                dataActivities.report[cont].id + "','" +
                UtilFunctions.convertDate(dataActivities.report[cont].deliveryDate) + "','" +
                dataActivities.report[cont].weight + "','" +
                dataActivities.idClass + "')");
                sql.executeUpdate(instruction);
            }
        }
        // insert data about the tests
        if (dataActivities.numberTests > 0) {
            for (int cont=0; cont < dataActivities.numberTests; cont++) {
                instruction = new String("INSERT INTO tests VALUES ('" +
                dataActivities.test[cont].id + "','" +
                UtilFunctions.convertDate(dataActivities.test[cont].deliveryDate) + "','" +
                dataActivities.test[cont].weight + "','" +
                dataActivities.idClass + "')");
                sql.executeUpdate(instruction);
            }
        }
        sql.close();
        
        ClassSelection classSelection = new ClassSelection();
        return classSelection.createView(tic,sql);
    }
}