/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents.util;

import java.util.*;
import java.io.*;
import java.net.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

/** Class for sending e-mail.*/
public class CourseEmail {
    private Address[] to = new Address[10];
    String msg="";
    
    /** Method for creating a new instance of this class passing one email.*/
    public CourseEmail(String emailto) {
        try {
            to = InternetAddress.parse(emailto);
        }catch(AddressException e){}
    }
    
    /** Method for creating a new instance of this class passing a list of emails.*/
    public CourseEmail(Address[] emailto) {
        to=emailto;
    }
    
    /** Method for sending one message.*/
    public void envia(String from, String host, String subject, String msgText){
        
        Properties props = System.getProperties();
        props.put("mail.smtp.host", host);
        
        Session session = Session.getDefaultInstance(props, null);
        session.setDebug(false);
        
        try {
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            msg.setRecipients(Message.RecipientType.TO, to);
            msg.setSubject(subject);
            
            MimeBodyPart mbp1 = new MimeBodyPart();
            mbp1.setText(msgText);
            
            Multipart mp = new MimeMultipart();
            mp.addBodyPart(mbp1);
            
            msg.setContent(mp); //adiciona as 2 partes do e-mail ao contexto que ser� enviado
            msg.setSentDate(new Date()); //Seta a data
            Transport.send(msg);   //Manda o e-mail
        } catch (Exception e) {
            System.err.println("An error ocurred " + e);
        }
    }
}


