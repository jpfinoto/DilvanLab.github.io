/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package ftpApplet;

import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.List;
import java.awt.*;
import java.awt.event.*;

import agents.*;
import agents.util.*;

/** Class that implements the clien of a FTP Server.*/
public class Client extends JavaInterface implements ActionListener {
    String CURDIR;
    String SVCURDIR;
    String FILESEPARATOR = System.getProperty("file.separator");
    String SQL_DATABASE;
    
    boolean isConnected = false;
    boolean isApplet;
    
    byte[] ticket;
    String passwd;
    String agent= "FTPAgent";
    
    MkdirDialog mkdirDialog;
    public LogDialog logDialog;
    
    //	Create menu options
    MenuItem menuConn;
    MenuItem menuClose;
    MenuItem menuQuit;
    
    // Create pushbuttons
    Button bt_put;
    Button bt_get;
    Button bt_del;
    Button bt_mkdir;
    Button bt_rmdir;
    
    // Create the lists
    List lista_cl;
    List lista_sv;
    
    // Create a one-line text field, and multi-line text area.
    TextField dir_cl = new TextField(25);
    TextField dir_sv = new TextField(25);
    
    // Create a area to messages
    Label lbl_msg = new Label("Messages:");
    TextArea msg = new TextArea(6,50);
    
    public Client(String title, String host, boolean isApplet, String resource) {
        super(host);
       
        CURDIR = System.getProperty("user.dir");
        setTitle(title);
        this.isApplet= isApplet;
        SQL_DATABASE= resource;
        init();
        writedir(dir_cl,CURDIR);
        Execlls("");
        
        logDialog= new LogDialog(this, host, resource);
        mkdirDialog= new MkdirDialog(this);
        // Resize the window to the preferred size of its components
        pack();
    }
    
    public void init() {
        
        setBackground(Color.lightGray);
        
        bt_put = new Button(" >> ");
        bt_put.addActionListener(this);
        bt_get = new Button(" << ");
        bt_get.addActionListener(this);
        bt_del = new Button(" Del ");
        bt_del.addActionListener(this);
        bt_mkdir = new Button(" MkDir ");
        bt_mkdir.addActionListener(this);
        bt_rmdir = new Button(" RmDir ");
        bt_rmdir.addActionListener(this);
        
        // Create the lists
        lista_cl = new List(20, true);
        lista_cl.addActionListener(this);
        lista_sv = new List(20, true);
        lista_sv.addActionListener(this);
        
        dir_cl = new TextField(25);
        dir_cl.addActionListener(this);
        dir_sv = new TextField(25);
        dir_sv.addActionListener(this);
        dir_sv.setEditable(false);
        
        Panel pan_dir = new Panel();
        Panel pan_bt = new Panel();
        Panel pan_msg = new Panel();
        Panel pan_cmd = new Panel();
        
        Panel aux_pan= new Panel();
        
        // Create the labels
        Label DIR_CL = new Label("Local:");
        Label DIR_SV = new Label("Remote:");
        
        MenuBar menubar = new MenuBar();
        setMenuBar(menubar);
        
        // Create the file menu.  Add two items to it.  Add to menubar.
        //
        menuConn= new MenuItem("New connection");
        menuConn.addActionListener(this);
        menuClose= new MenuItem("Close connection");
        menuClose.addActionListener(this);
        menuQuit= new MenuItem("Quit");
        menuQuit.addActionListener(this);
        
        Menu file = new Menu("Connection Menu");
        file.add(menuConn);
        file.add(menuClose);
        file.add(menuQuit);
        menubar.add(file);
        
        // Create Help menu; add an item; add to menubar
        //    help = new Menu("Help");
        //    help.add(new MenuItem("About Ftp"));
        //    help.add(new MenuItem("Commands"));
        //    menubar.add(help);
        // Display the help menu in a special reserved place.
        //    menubar.setHelpMenu(help);
        
        pan_bt.setLayout(new GridLayout(2, 1, 1, 0));
        pan_bt.add(bt_put);
        pan_bt.add(bt_get);
        
        pan_cmd.setLayout(new GridLayout(3, 1, 1, 0));
        pan_cmd.add(bt_del);
        pan_cmd.add(bt_mkdir);
        //      pan_cmd.add(bt_rmdir);
        
        pan_dir.add(DIR_CL);
        pan_dir.add(dir_cl);
        pan_dir.add(DIR_SV);
        pan_dir.add(dir_sv);
        
        pan_msg.add(lbl_msg);
        pan_msg.add(msg);
        
        aux_pan.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 5));
        aux_pan.add(lista_cl);
        aux_pan.add(pan_bt);
        aux_pan.add(lista_sv);
        aux_pan.add(pan_cmd);
        
        setLayout(new BorderLayout());
        add("North",pan_dir);
        add("Center", aux_pan);
        add("South", pan_msg);
        
        msg.setEditable(false);
        
        //	Window destructor
        //
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                clientExit();
            }
        });
    }
    
    public void writemsg(String stringmsg) {
        msg.append(stringmsg + "\n");
    }
    
    public void writedir(TextField text, String stringdir) {
        text.setText(stringdir);
    }
    
    void unconnect() {
        isConnected= false;
        if (lista_sv.getItemCount()!=0) lista_sv.removeAll();
        SVCURDIR= null;
        writedir(dir_sv,"");
        dir_sv.setEditable(false);
        ticket= null;
        passwd= null;
    }
    
    ObjectInput getStream(String p1, String p2) throws Exception {
        writemsg("Request ...");
        Message m= new Message(ticket);
        m.body.addElement(p1);
        m.body.addElement(SVCURDIR);
        m.body.addElement(p2);
        return getStream(agent, m, passwd);
    }
    
    String sendStream(String p1, String p2, InputStream source, long length)
    throws Exception {
        byte[] buffer = new byte[4096];
        int bytes_read;
        
        URLConnection con= getConnection();
        ObjectOutputStream out = new ObjectOutputStream(con.getOutputStream());
        out.writeObject(agent);
        Message m= new Message(ticket);
        m.body.addElement(p1);
        m.body.addElement(SVCURDIR);
        m.body.addElement(p2);
        m.encode(passwd);
        out.writeObject(m);
        
        //	Send file
        //
        out.writeLong(length);
        out.flush();
        while(true) {
            bytes_read = source.read(buffer);
            if (bytes_read == -1) break;
            out.write(buffer, 0, bytes_read);
            out.flush();
        }
        source.close();
        out.close();
        
        //	From the server
        //
        
        ObjectInputStream in = new ObjectInputStream(con.getInputStream());
        
        Object resp= in.readObject();
        
        in.close();
        
        if (resp instanceof Exception) throw (Exception) resp;
        
        return (String) resp;
    }
    
    String[] Execlogoptions(byte[] ticket, String passwd)
    throws Exception {
        String resp;
        
        Message msg= new Message(ticket);
        msg.body.addElement("LOGOPTIONS");
        
        return (String[]) sendRequest("FTPAgent", msg, passwd);
    }
    
    
    void Execlogin(byte[] ticket, String passwd, String directory)
    throws Exception {
        String resp;
        
        Message msg= new Message(ticket);
        msg.body.addElement("LOGIN");
        msg.body.addElement(directory);
        
        this.ticket = (byte[]) sendRequest("FTPAgent", msg, passwd);
        this.passwd= passwd;
        
        isConnected= true;
        SVCURDIR = "";
        dir_sv.setEditable(true);
        Execcd("");
    }
    
    void Execls(String complemento) throws Exception {
        
        String line;
        int count = 0;
        int filenumber;
        
        ObjectInput SIN= getStream("NLST", complemento);
        
        //	SVCURDIR = SIN.readLine();
        // 	le linha de controle do server.
        filenumber = SIN.read();
        if (lista_sv.getItemCount()!=0) lista_sv.removeAll();
        lista_sv.addItem("..");
        lista_sv.addItem(".");
        while(count < filenumber) {
            line = (String) SIN.readObject();
            lista_sv.addItem(line);
            count = count + 1;
        }
        line = (String) SIN.readObject();
        writemsg(line);
    }
    
    void Execget(String dest_name) throws Exception {
        
        //try {
        //   netscape.security.PrivilegeManager.enablePrivilege("UniversalFileAccess");
        //} catch (netscape.security.ForbiddenTargetException e) {
        //   System.out.println("\tFailed! Permission to read system properties denied by user.");
        //} catch (Throwable e) {}
        
        if (!isConnected) return;
        
        FileOutputStream destination = null;
        long file_len, total_len;
        int read_len;
        byte[] buffer = new byte[4096];
        File dir = new File(CURDIR);
        File destination_file = new File(dir, dest_name);
        
        
        // Caso destino exista e seja nao writeable ou nao arquivo, OU
        // caso o destino nao exista e nao possa ser criado gera uma
        // excecao FileCopyException
        if (destination_file.exists()) {
            if (destination_file.isFile()) {
                if (!destination_file.canWrite())
                    throw new FileCopyException(" destination file is unwriteable: " + dest_name);
            } else
                throw new FileCopyException(" destination is not a file: " +  dest_name);
        } else {
            File parentdir = parent(destination_file);
            if (!parentdir.exists())
                throw new FileCopyException(" directory doesn't exist: " + dest_name);
            if (!parentdir.canWrite())
                throw new FileCopyException(" directory is unwriteable: " + dest_name);
        }
        
        ObjectInput SIN= getStream("RETR", dest_name);
        
        // le o tamanho do arquivo e, em seguida, o arquivo
        file_len = SIN.readLong();
        if (file_len == -1) {
            writemsg("no regular file or can't read file " + dest_name);
        } else {
            destination = new FileOutputStream(destination_file);
            read_len = 0;
            total_len = 0;
            
            while (total_len < file_len) {
                read_len = SIN.read(buffer);
                destination.write(buffer, 0, read_len);
                total_len += read_len;
            }
            destination.close();
            writemsg("Transfer completed for " + dest_name + " (" + file_len + " bytes transfered).");
        }
    }
    
    void Execmget() throws Exception {
        
        // try {
        //    netscape.security.PrivilegeManager.enablePrivilege("UniversalFileAccess");
        //} catch (netscape.security.ForbiddenTargetException e) {
        //   System.out.println("\tFailed! Permission to read system properties denied by user.");
        // } catch (Throwable e) {}
        
        File dir;
        
        if (!isConnected) return;
        
        if (CURDIR==null) return;
        dir = new File(CURDIR);
        if (dir==null) return;
        
        if (lista_sv.getSelectedIndexes().length == 0) {
            writemsg("No selected files");
            return;
        }
        if (dir.canWrite()) {
            for (int i=0; i < lista_sv.getSelectedIndexes().length ; i++)
                Execget(lista_sv.getSelectedItems()[i]);
            Execlls("");
        } else
            writemsg("Can't write in local directory");
    }
    
    
    void Execput(String source_name) throws Exception {
        
        // try {
        //    netscape.security.PrivilegeManager.enablePrivilege("UniversalFileAccess");
        //} catch (netscape.security.ForbiddenTargetException e) {
        //   System.out.println("\tFailed! Permission to read system properties denied by user.");
        //} catch (Throwable e) {}
        
        if (!isConnected) return;
        
        File dir;
        File source_file;
        FileInputStream source = null;
        String line;
        
        dir = new File(CURDIR);
        source_file = new File(dir, source_name);
        
        // Verifica se o source_name existe, e' um arquivo e readable
        if (!source_file.exists() || !source_file.isFile() || !source_file.canRead()) {
            writemsg("no such file or can't read file " + source_name);
            return;
        } else {
            source = new FileInputStream(source_file);
            
            //		Send file
            //
            line = (String) sendStream("STOR", source_name, source, source_file.length());
            if (line.equals("NOT OK")) {
                writemsg("Server can't write file " + source_name);
                return;
            }
            writemsg(line);
        }
    }
    
    void Execcd(String complemento) throws Exception {
        String line;
        
        if (!isConnected) return;
        
        ObjectInput SIN= getStream("CWD", complemento);
        
        String aux1= (String) SIN.readObject();
        line = (String) SIN.readObject();
        
        if (!line.equals("CWD unsuccessful")) {
            SVCURDIR= aux1;
            Execls("");
        } else
            writemsg(complemento + " isn't a directory");
        writedir(dir_sv,SVCURDIR);
    }
    
    void Execpwd(String complemento) throws Exception {
        if (!isConnected) return;
        
        String line;
        
        ObjectInput sin= getStream("PWD", complemento);
        line = (String) sin.readObject();
    }
    
    void Execlls(String complemento) {
        
        //try {
        //   netscape.security.PrivilegeManager.enablePrivilege("UniversalFileAccess");
        //} catch (netscape.security.ForbiddenTargetException e) {
        //   System.out.println("\tFailed! Permission to read system properties denied by user.");
        //} catch (Throwable e) {}
        
        String line;
        File dir;
        String[] entries;
        SimpleFilter filtro;
        filtro = new SimpleFilter(complemento);
        
        if (isRoot(CURDIR))
            dir = new File(CURDIR + ".");
        else
            dir = new File(CURDIR);
        
        lista_cl.removeAll();
        lista_cl.addItem("..");
        lista_cl.addItem(".");
        if (dir.canRead()) {
            try {
                entries = dir.list(filtro);
                for (int i = 0; i < entries.length; i++)
                    lista_cl.addItem(entries[i]);
                writemsg("NLLST successful");
            } catch (Exception e) {
                writemsg("NLLST broken");
            }
        } else
            writemsg("Can't read directory !!!");
    }
    
    void Execmput() throws Exception {
        
        //try {
        //   netscape.security.PrivilegeManager.enablePrivilege("UniversalFileAccess");
        //} catch (netscape.security.ForbiddenTargetException e) {
        //    System.out.println("\tFailed! Permission to read system properties denied by user.");
        // } catch (Exception e) {}
        
        File dir;
        
        if (!isConnected) return;
        
        if (lista_cl.getSelectedIndexes().length == 0) {
            writemsg("No selected files");
            return;
        }
        dir = new File(CURDIR);
        if (dir.canRead()) {
            for (int i=0; i < lista_cl.getSelectedIndexes().length ; i++)
                Execput(lista_cl.getSelectedItems()[i]);
            Execls("");
        } else
            writemsg("Can't read local directory");
        
    }
    
    void Execdel() throws Exception {
        String line;
        boolean ls_flag= false;
        
        if (!isConnected) return;
        
        if (lista_sv.getSelectedIndexes().length == 0) {
            writemsg("No selected files");
            return;
        }
        for (int i=0; i < lista_sv.getSelectedIndexes().length ; i++) {
            
            ObjectInput SIN= getStream("DELE", lista_sv.getSelectedItems()[i]);
            
            line = (String) SIN.readObject();
            if (!line.equals("DELE unsuccessful")) ls_flag=true;
            writemsg(line);
        }
        if (ls_flag) Execls("");
    }
    
    void Execrmdir() throws Exception {
        String line;
        boolean ls_flag= false;
        
        if (!isConnected) return;
        
        if (lista_sv.getSelectedIndexes().length == 0) {
            writemsg("No selected directories");
            return;
        }
        for (int i=0; i < lista_sv.getSelectedIndexes().length ; i++) {
            ObjectInput SIN= getStream("RMD", lista_sv.getSelectedItems()[i]);
            
            line = (String) SIN.readObject();
            if (!line.equals("RMD unsuccessful")) ls_flag=true;
            writemsg(line);
        }
        if (ls_flag) Execls("");
    }
    
    void Execmkdir() throws Exception {
        String line, dirname;
        
        if (!isConnected) return;
        
        mkdirDialog.show();
        while (mkdirDialog.isShowing()) ;
        dirname= mkdirDialog.dirname.getText();
        if (dirname.equals("")) return;
        
        ObjectInput SIN= getStream("MKD", dirname);
        
        line = (String) SIN.readObject();
        if (!line.equals("MKD unsuccessful"))
            Execcd("");
        writemsg(line);
    }
    
    boolean isRoot(String dir) {
        if (dir.equals("/")) return true;
        if (dir.equalsIgnoreCase("A:\\")) return true;
        if (dir.equalsIgnoreCase("B:\\")) return true;
        if (dir.equalsIgnoreCase("C:\\")) return true;
        if (dir.equalsIgnoreCase("D:\\")) return true;
        if (dir.equalsIgnoreCase("E:\\")) return true;
        if (dir.equalsIgnoreCase("F:\\")) return true;
        if (dir.equalsIgnoreCase("G:\\")) return true;
        if (dir.equalsIgnoreCase("H:\\")) return true;
        return false;
    }
    
    boolean isRooted(String dir) {
        dir= dir.toUpperCase();
        if (dir.startsWith("/")) return true;
        if (dir.startsWith("A:\\")) return true;
        if (dir.startsWith("B:\\")) return true;
        if (dir.startsWith("C:\\")) return true;
        if (dir.startsWith("D:\\")) return true;
        if (dir.startsWith("E:\\")) return true;
        if (dir.startsWith("F:\\")) return true;
        if (dir.startsWith("G:\\")) return true;
        if (dir.startsWith("H:\\")) return true;
        return false;
    }
    
    void Execlcd(String complemento) {
        
        //try {
        //   netscape.security.PrivilegeManager.enablePrivilege("UniversalFileAccess");
        //} catch (netscape.security.ForbiddenTargetException e) {
        //   System.out.println("\tFailed! Permission to read system properties denied by user.");
        //} catch (Exception e) {}
        
        String dirto = CURDIR;
        if (complemento.equals("")) return;
        if (complemento.equals(".")) return;
        if (complemento.equals("..") && isRoot(CURDIR)) return;
        if (isRooted(complemento))         {dirto = complemento; }
        else if (complemento.equals("..")) {dirto = parent(new File(CURDIR)).toString(); }
        else if (isRoot(CURDIR))           {dirto = CURDIR + complemento; }
        else                               {dirto = CURDIR + FILESEPARATOR + complemento; }
        
        // se tem FILESEPARATOR no final elimina
        if (!isRoot(dirto))
            while (dirto.endsWith(FILESEPARATOR))
                dirto = dirto.substring(0,dirto.length()-1);
        
        File dir = new File(dirto);
        if (dir.isDirectory()) {
            CURDIR = dirto;
            Execlls("");
            // writemsg("LCWD successful " + CURDIR);
        } else {
            // writemsg("LCWD unsuccessful");
            writemsg(dirto + " isn't a directory");
        }
        writedir(dir_cl,CURDIR);
    }
    
    public void Execlpwd(String complemento) {
        
        //System.out.println("LPWD successful " + CURDIR + " is your current local directory");
        
    }
    
    // O metodo File.getParent retorna null se o arquivo e' especificado sem
    // diretorio ou esta no root dir; o metodo parent abaixo trata desses casos
    private File parent(File f) {
        String dirname = f.getParent();
        if (dirname == null) {
            if (f.isAbsolute()) return new File(File.separator);
            else return new File(System.getProperty("user.dir"));
        }
        return new File(dirname);
    }
    
    protected void clientExit() {
        if (isApplet) setVisible(false);
        else System.exit(0);
    }
    
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        try{
            if (source == bt_put)
                Execmput();
            else if (source == bt_get)
                Execmget();
            else if (source == bt_del)
                Execdel();
            else if (source == bt_mkdir)
                Execmkdir();
            else if (source == bt_rmdir)
                Execrmdir();
            else if (source == lista_cl)
                Execlcd(e.getActionCommand());
            else if (source == lista_sv)
                Execcd(e.getActionCommand());
            else if (source == dir_cl)
                Execlcd(e.getActionCommand());
            else if (source == dir_sv)
                Execcd(e.getActionCommand());
            else if (source == menuConn)
                logDialog.show();
            else if (source == menuClose)
                unconnect();
            else if (source == menuQuit)
                clientExit();
            
        }
        catch (Exception exc) {
            writemsg("Connection broken.");
            unconnect();
        }
    }
}
