/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import course.create.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class for edition of information about one class. */
public class EditClassView implements View, Serializable {
    transient course.create.ClassPanel classPanel;
    transient Panel p1;
    
    String resource;
    int idClass;
    Ticket tic;
    DataActivities dataActivities;
    
    /** Method to update variables.*/
    public void setVariable(int idClass){
        this.idClass = idClass;
    }
    
    /** Method for creation of new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.resource = tic.resource;
        this.tic = tic;
        dataActivities = new DataActivities(); // class to store the course basic information
        // get date for class selected
        sql.init(resource);
        ResultSet rs = sql.executeQuery("SELECT expire FROM class WHERE id='" + idClass + "'");
        rs.next();
        dataActivities.expireClass=UtilFunctions.deconvertDate(rs.getString(1));
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,0));
        principal.setFont(new Font("Helvetica", Font.PLAIN, 12));
        
        classPanel = new ClassPanel(idClass,0,dataActivities);
        p1 = classPanel.initView();
        principal.add(p1, BorderLayout.CENTER);
        return principal;
    }
    
    /** Method for validation of the graphic interface information.*/
    public boolean validateView() {
        ErrorWindow er = null;
        int error = classPanel.validateView();
        if (error != 0) {
            er = new ErrorWindow("Invalid date.");
            er.show();
            return false;
        }
        dataActivities = classPanel.update(dataActivities);
        return true;
    }
    
    /** Method for updating information about one class. The information is stored into the DataActivities class.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        
        java.util.Date dateActivity;
        sql.init(resource);
        java.util.Date dateExpireClass = new java.util.Date(dataActivities.expireClass);
        ResultSet rs = sql.executeQuery("SELECT date FROM assignments ORDER BY date DESC");
        if (rs.next()) {
            dateActivity = new java.util.Date(UtilFunctions.deconvertDate(rs.getString(1)));
            if (dateActivity.after(dateExpireClass)) throw new RuntimeException("Expire Date before Assignment date.");
        }
        
        rs = sql.executeQuery("SELECT use_review,review_date FROM assignments ORDER BY review_date DESC");
        if (rs.next()) {
            if (rs.getString(1).equals("true")) {
                dateActivity = new java.util.Date(UtilFunctions.deconvertDate(rs.getString(2)));
                if (dateActivity.after(dateExpireClass)) throw new RuntimeException("Expire Date before Assignment's Review date.");
            }
        }
        
        rs = sql.executeQuery("SELECT date FROM reports ORDER BY date DESC");
        if (rs.next()) {
            dateActivity = new java.util.Date(UtilFunctions.deconvertDate(rs.getString(1)));
            if (dateActivity.after(dateExpireClass)) throw new RuntimeException("Expire Date before Report date.");
        }
        
        rs = sql.executeQuery("SELECT date FROM tests ORDER BY date DESC");
        if (rs.next()) {
            dateActivity = new java.util.Date(UtilFunctions.deconvertDate(rs.getString(1)));
            if (dateActivity.after(dateExpireClass)) throw new RuntimeException("Expire Date before Test date.");
        }
        
        sql.executeUpdate("UPDATE class SET expire='" + UtilFunctions.convertDate(dataActivities.expireClass) + "' WHERE id='" + idClass + "'");
        sql.close();
        EditClassSelection editClassSelection = new EditClassSelection();
        editClassSelection.setVariable("Class "+ idClass);
        return editClassSelection.createView(tic,sql);
    }
}
