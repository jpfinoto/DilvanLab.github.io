/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.grades;

import java.awt.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.security.Ticket;
import course.util.UtilFunctions;

/** Class for management of the students classes. */
public class ClassGradeSelection implements View, Serializable {
    Ticket tic;
    String classSelected = null;
    Vector listClass;
    
    transient Choice classList;
    
    /** Method for creation of new instance form the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        sql.init(tic.resource);
        // test the type of user
        if (!tic.type.equals("administrator") &&
        !tic.type.equals("monitor")) throw new RuntimeException("You don't have permissions to access this tool.");
        
        listClass = new Vector();
        // Select all active classes
        ResultSet rs = sql.executeQuery("SELECT id, expire FROM class ORDER BY id ASC");
        java.util.Date date = new java.util.Date();
        for(;rs.next();)
            if (UtilFunctions.verifyDate(date,rs.getDate(2)) >= 0)
                listClass.addElement("Class " + rs.getString(1));
        sql.close();
        
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel classPanel = new Panel();
        Label label = new Label("Select one Class:");
        classList = new Choice();
        for (int count = 0; count < listClass.size(); count++)
            classList.addItem((String) listClass.elementAt(count));
        
        classPanel.setLayout(new FlowLayout());
        classPanel.add(label);
        classPanel.add(classList);
        
        principal.add(classPanel);
        return principal;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        classSelected = classList.getSelectedItem();
        return true;
    }
    
    /** Method that invokes the class for execution of the selected operation.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        ActivityGradeSelection activityGradeSelection = new ActivityGradeSelection();
        activityGradeSelection.setVariable(classSelected);
        return activityGradeSelection.createView(tic,sql);
    }
}
