/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.reviews;
import java.awt.*;
import java.util.*;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;

/** Class that presents the selected class and a list of assignments. 
  * This class is used for the reviews allocation.*/
public class AssignmentSelectionInterface extends Component {
    Label label;
    TextField classField;
    public Choice assignmentList;
    Panel assignmentPanel;
    
    /** Method for creation of a new instance from this class. 
      * It sets the assignments vector with the assignments options and the selected class.*/
    public AssignmentSelectionInterface(Vector assignmentListVector, String classSelected) {
        classField = new TextField(classSelected);
        classField.setEditable(false);
        classField.setFont(new Font("SansSerif", Font.BOLD, 14));
        classField.setForeground(Color.blue);
        
        Panel aux1 = new Panel();
        aux1.setLayout(new FlowLayout());
        aux1.add(new Label("Class Selected:"));
        aux1.add(classField);
        
        Panel aux2 = new Panel();
        label = new Label("Select one Assignment:");
        assignmentList = new Choice();
        for (int count = 0; count < assignmentListVector.size(); count++)
            assignmentList.addItem((String) assignmentListVector.elementAt(count));
        
        aux2.setLayout(new FlowLayout());
        aux2.add(label);
        aux2.add(assignmentList);
        
        assignmentPanel = new Panel();
        assignmentPanel.setLayout(new BorderLayout(0,0));
        assignmentPanel.add(aux1, BorderLayout.NORTH);
        assignmentPanel.add(aux2, BorderLayout.SOUTH);
    }
    
    /** Method for showing the panel.*/
    public Panel showInterface() {
        return assignmentPanel;
    }
}
