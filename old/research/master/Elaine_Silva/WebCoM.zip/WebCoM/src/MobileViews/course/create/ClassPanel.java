/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.create;

import java.awt.*;
import java.io.*;
import agents.*;
import agents.ImageLoader;
import agents.ImageCanvas;
import course.util.UtilFunctions;

/** Class with a graphic interface and some methods to manage information about students class.*/
public class ClassPanel extends Panel {
    int classSelectedToCopy, idClass;
    TextField classField;
    TextField expireDateField;
    TextField statusField;
    TextField classSelectedToCopyField;
    
    /** Method for creation of new instance from this class.*/
    public ClassPanel(int idClass, int classSelectedToCopy, DataActivities dataActivities) {
        this.idClass = idClass;
        this.classSelectedToCopy = classSelectedToCopy;
        classField = new TextField(5);
        expireDateField = new TextField("mm/dd/yyyy");
        statusField = new TextField("Active");
        classSelectedToCopyField = new TextField(5);
        
        // without copying information from other class
        if (classSelectedToCopy != -1) {
            classField.setText("Class " + idClass);
            statusField.setText("Active");
            expireDateField.setText(dataActivities.expireClass);
            classSelectedToCopyField.setText("Class " + classSelectedToCopy);
        } else {
            // copy information from the selected class.
            classField.setText("Class " + idClass);
            statusField.setText("Active");
            classSelectedToCopyField.setText("");
        }
    }
    
    /** Method for atualizing the dataActivities object with the graphic interface information.*/
    public DataActivities update(DataActivities dataActivities) {
        dataActivities.idClass = idClass;
        dataActivities.expireClass = expireDateField.getText();
        return dataActivities;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Image icon;
        ImageLoader jImage = new ImageLoader();
        Canvas canvas = new Canvas();
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
               
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout(0,10));
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        // Label Class Identification
        Label label = new Label("Class Identification");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.gridheight = 1;
        constraints.weightx = 1;
        constraints.weighty = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // Label Class Status
        label = new Label("Class Status");
        constraints.gridx = 0;
        constraints.gridy = 2;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // Label Replicate
        label = new Label("Replicate Activities From");
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.gridwidth = 2;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // field classId
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        classField.setEditable(false);
        classField.setFont(new Font("SansSerif", Font.BOLD, 14));
        classField.setForeground(Color.blue);
        constraints.anchor = GridBagConstraints.WEST;
        gridBag.setConstraints(classField,constraints);
        form.add(classField);
        
        // field status
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        statusField.setEditable(false);
        statusField.setFont(new Font("SansSerif", Font.BOLD, 14));
        if (statusField.getText().equals("Active"))
            statusField.setForeground(Color.blue);
        else
            statusField.setForeground(Color.red);
        gridBag.setConstraints(statusField,constraints);
        form.add(statusField);
        
        // field class toCopy
        constraints.gridx = 0;
        constraints.gridy = 5;
        constraints.gridwidth = 2;
        if (classSelectedToCopyField.getText().equals(""))
            classSelectedToCopyField.setEditable(false);
        classSelectedToCopyField.setFont(new Font("SansSerif", Font.BOLD, 14));
        classSelectedToCopyField.setForeground(Color.blue);
        gridBag.setConstraints(classSelectedToCopyField,constraints);
        form.add(classSelectedToCopyField);
        
        groupForm.add(form,BorderLayout.CENTER);
        
        icon = jImage.loadImage("clock.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(35,35);
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        constraints.gridheight = 2;
        constraints.weightx = 0.3;
        constraints.weighty = 1;
        constraints.insets = new Insets(0,10,0,0);
        constraints.fill = GridBagConstraints.HORIZONTAL;
        gridBag.setConstraints(canvas,constraints);
        form.add(canvas);
        
        // label Expire Date
        label = new Label("Expire Date");
        constraints.gridx = 3;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        constraints.weightx = 1;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // Field expire date
        constraints.gridx = 3;
        constraints.gridy = 3;
        constraints.gridwidth = 1;
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.WEST;
        gridBag.setConstraints(expireDateField,constraints);
        form.add(expireDateField);
        
        groupForm.add(form,BorderLayout.SOUTH);
        
        icon = jImage.loadImage("newclass.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(380,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
    
    /** Method for validating the graphic interface objects.*/
    public int validateView() {
        try {
            java.util.Date test = new java.util.Date(expireDateField.getText());
        } catch (Exception e) {return 1;}
        return 0;
    }
}
