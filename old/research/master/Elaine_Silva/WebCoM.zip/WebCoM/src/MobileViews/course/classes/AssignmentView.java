/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import course.create.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class for creation of new assignment. */
public class AssignmentView implements View, Serializable{
    transient AssignmentPanel assignmentsPanel;
    transient Panel p1;
    
    String resource;
    DataActivities dataActivities;
    int idClass;
    int idAssignment = 0;
    Ticket tic;
    
    /** Method to update variables.*/
    public void setVariable(int idClass){
        this.idClass = idClass;
    }
    
    /** Method for creation of new instance from the View class. The next assignment id will be the last + 1.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.resource = tic.resource;
        this.tic = tic;
        dataActivities = new DataActivities();
        sql.init(this.resource);
        ResultSet rs = sql.executeQuery("SELECT expire FROM class WHERE id='" + idClass + "'");
        rs.next();
        dataActivities.expireClass = UtilFunctions.deconvertDate(rs.getString(1));
        rs = sql.executeQuery("SELECT id FROM assignments WHERE class='" + idClass + "' ORDER BY id DESC");
        if (rs.next()) {
            int id = rs.getInt(1);
            idAssignment = id;
        } else
            idAssignment = 0;
        dataActivities.numberAssignments = idAssignment;
        dataActivities.indexAssignments = idAssignment;
        dataActivities.idClass = idClass;
        sql.close();
                 /* The DataActivities class was projected to groups a lot of activities. Thus, to add only one activity, the index of
                         the activity have to be fixed. */
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout());
        principal.setFont(new Font("Helvetica", Font.PLAIN, 12));
        
        assignmentsPanel = new AssignmentPanel();
        p1 = assignmentsPanel.initView();
        assignmentsPanel.atualizeView(dataActivities);
        principal.add(p1, BorderLayout.CENTER);
        return principal;
    }
    
    /** Method for validation of the graphic interface information. */
    public boolean validateView() {
        ErrorWindow er = null;
        int errorView = assignmentsPanel.validateView(dataActivities);
        if (errorView != 0) {
            if (errorView == 1)
                er = new ErrorWindow("The review date is before of the assignment date.");
            if (errorView == 2)
                er = new ErrorWindow("Missign projects.");
            if (errorView == 3)
                er = new ErrorWindow("Invalid date to assignment.");
            if (errorView == 4)
                er = new ErrorWindow("Some date is after the class's expire date.");
            if (errorView == 5)
                er = new ErrorWindow("The assignment delivery date should be ordered.");
            if (errorView == 6)
                er = new ErrorWindow("The weight should be bigger than 0 (zero).");
            er.show();
            return false;
        }
        dataActivities = assignmentsPanel.update(dataActivities);
        dataActivities.indexAssignments--; // it have to do the same position because there is only one assigment to insert
        return true;
    }
    
    /**Method to storing information about the new assignment into the database*/
    public synchronized Object updateView(SQL sql) throws Exception {
        String instruction = null;
        // get the directory of this course
        sql.init(Defaults.WEBCOMDATABASE);
        ResultSet rs = sql.executeQuery("SELECT directory FROM basic_info WHERE database_name='" + resource + "'");
        rs.next();
        String directory = rs.getString(1);
        sql.close();
        // make directories for this assignment
        try {
            UtilFunctions.createDirectoryAssignment(directory, dataActivities.assig[dataActivities.indexAssignments].idAssignment, dataActivities.idClass);
        } catch (Exception e) {
            return "Error generating directory /homework. Directory was not created.";
        }
        
        // get the data about this assignment
        String name_project = null;
        String max_groups = null;
        String max_students = null;
        String min_students = null;
        StringTokenizer stoken;
        String token;
        String use_review;
        String date_review;
        
        boolean endToken = true;
        
        if (!dataActivities.assig[dataActivities.indexAssignments].reviewDate.equals("")) {
            use_review = "true";
            date_review = dataActivities.assig[dataActivities.indexAssignments].reviewDate;
        } else {
            use_review = "false";
            date_review = "";
        }
        
        sql.init(resource);
        // insert the data in the database
        instruction = new String("INSERT INTO assignments VALUES ('" +
        dataActivities.assig[dataActivities.indexAssignments].idAssignment + "','" +
        UtilFunctions.convertDate(dataActivities.assig[dataActivities.indexAssignments].deliveryDate) + "','" +
        UtilFunctions.convertDate(date_review) + "','" +
        dataActivities.assig[dataActivities.indexAssignments].weight + "','" + use_review + "','" +
        dataActivities.idClass + "')");
        sql.executeUpdate(instruction);
        for (int cont2 = 0; cont2 < dataActivities.assig[dataActivities.indexAssignments].numberProjects; cont2++) {
            stoken = new StringTokenizer(dataActivities.assig[dataActivities.indexAssignments].projects[cont2], " ");
            while (endToken) {
                try {
                    token = stoken.nextToken();
                    if (token.equals("Project"))
                        name_project = stoken.nextToken();
                    if (token.equals("MaxGroup"))
                        max_groups = stoken.nextToken();
                    if (token.equals("MaxStudents"))
                        max_students = stoken.nextToken();
                    if (token.equals("MinStudents"))
                        min_students = stoken.nextToken();
                } catch (NoSuchElementException e) {endToken = false;}
            }
            // insert the projects of this assignment in the database
            instruction = new String("INSERT INTO projects VALUES ('" +
            name_project + "','" +
            dataActivities.assig[dataActivities.indexAssignments].idAssignment + "','" +
            max_groups + "','" +
            min_students + "','" +
            max_students + "','" +
            dataActivities.idClass + "')");
            sql.executeUpdate(instruction);
            endToken = true;
        }
        sql.close();
        EditClassSelection editClassSelection = new EditClassSelection();
        editClassSelection.setVariable("Class "+ idClass);
        return editClassSelection.createView(tic,sql);
    }
}
