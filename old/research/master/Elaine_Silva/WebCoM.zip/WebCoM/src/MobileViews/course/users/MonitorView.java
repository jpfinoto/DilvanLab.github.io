/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.users;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.io.File;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import agents.util.CourseEmail;
import course.util.UtilFunctions;

/** Class for addition of monitor user.*/
public class MonitorView extends Panel implements View {
    String username;
    String FirstName, LastName, Password, dateExpire;
    String email;
    String directory, directoryAux;
    String separator;
    Ticket tic;
    
    transient Canvas canvas = new Canvas();
    transient TextField fMonitor,lMonitor,userName;
    transient TextField passwdMonitor,passwdMonitor2;
    transient TextField accessDirectory, expireDate;
    transient TextField emailMonitor;
    transient Label text;
    transient Image icon;
    
    /** Method for creation of a new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        if (!tic.type.equals("administrator")) throw new RuntimeException("You don't have permissions to access this tool.");
        sql.init(Defaults.WEBCOMDATABASE);
        ResultSet rs = sql.executeQuery("SELECT directory FROM basic_info WHERE database_name='" + tic.resource + "'");
        rs.next();
        directory = rs.getString(1);
        sql.close();
        separator = new String(File.separator);
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        fMonitor = new TextField(5);
        lMonitor = new TextField(5);
        userName = new TextField(5);
        passwdMonitor = new TextField(5);
        passwdMonitor2 = new TextField(5);
        expireDate = new TextField("mm/dd/aaaa");
        emailMonitor = new TextField(5);
        
        int indexLast = directory.lastIndexOf(separator);
        directoryAux = directory.substring(indexLast,directory.length());
        
        accessDirectory = new TextField(directoryAux);
        
        setFont(new Font("Helvetica",Font.PLAIN,11));
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        // label username
        Label label = new Label("Username");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label first name
        constraints.gridx = 0;
        constraints.gridy = 2;
        label = new Label("First Name");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label last name
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.insets = new Insets(0,5,0,0);
        label = new Label("Last Name");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label password
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,0,0,5);
        label = new Label("Type Password");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label retype password
        constraints.gridx = 2;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,5,0,0);
        label = new Label("Retype Password");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label accessDirectory
        constraints.gridx = 0;
        constraints.gridy = 6;
        constraints.gridwidth = 4;
        constraints.insets = new Insets(0,0,0,5);
        label = new Label("Access Directory (ex.:" + directoryAux + " or " + directoryAux + separator + "homework)");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label email
        constraints.gridx = 0;
        constraints.gridy = 8;
        constraints.gridwidth=1;
        label = new Label("E-mail");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label expireDate
        constraints.gridx = 0;
        constraints.gridy = 10;
        constraints.gridwidth=1;
        label = new Label("Expire Date");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label Class
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        label = new Label("          ");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        label = new Label("          ");
        constraints.gridx = 3;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // field username
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        gridBag.setConstraints(userName,constraints);
        form.add(userName);
        
        // field first name Monitor
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.insets = new Insets(0,0,0,5);
        gridBag.setConstraints(fMonitor,constraints);
        form.add(fMonitor);
        
        // field last name Monitor
        constraints.gridx = 2;
        constraints.gridy = 3;
        constraints.insets = new Insets(0,5,0,0);
        gridBag.setConstraints(lMonitor,constraints);
        form.add(lMonitor);
        
        // field password
        constraints.gridx = 0;
        constraints.gridy = 5;
        constraints.insets = new Insets(0,0,0,5);
        passwdMonitor.setEchoChar('*');
        gridBag.setConstraints(passwdMonitor,constraints);
        form.add(passwdMonitor);
        
        // field retype password
        constraints.gridx = 2;
        constraints.gridy = 5;
        constraints.insets = new Insets(0,5,0,0);
        passwdMonitor2.setEchoChar('*');
        gridBag.setConstraints(passwdMonitor2,constraints);
        form.add(passwdMonitor2);
        
        // field accessDirectory
        constraints.gridx = 0;
        constraints.gridy = 7;
        constraints.gridwidth = 4;
        constraints.insets = new Insets(0,0,0,5);
        gridBag.setConstraints(accessDirectory,constraints);
        form.add(accessDirectory);
        
        // field email
        constraints.gridx = 0;
        constraints.gridy = 9;
        constraints.gridwidth = 4;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(emailMonitor,constraints);
        form.add(emailMonitor);
        
        // field expireDate
        constraints.gridx = 0;
        constraints.gridy = 11;
        constraints.gridwidth = 2;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(expireDate,constraints);
        form.add(expireDate);
        
        groupForm.add(form,BorderLayout.CENTER);
        
        ImageLoader jImage = new ImageLoader();
        icon = jImage.loadImage("monitor.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(380,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        ErrorWindow er;
        // Test the username field
        if (userName.getText().equals("")) {
            er = new ErrorWindow("Missing username.");
            er.show();
            return false;
        } else if (!UtilFunctions.validateField(userName.getText().toLowerCase(), "abcdefghijklmnopqrstuvxzwy0123456789-_")) {
            er = new ErrorWindow("Invalid character in Username.");
            er.show();
            return false;
        } else if ((userName.getText().length() < 5) || (userName.getText().length() > 16)){
            er = new ErrorWindow("Username should be bigger than 5 and smaller than 16 characters.");
            er.show();
            return false;
        } else if ((userName.getText().indexOf(' ') != -1) &&
        (userName.getText().indexOf(' ') != userName.getText().length())) {
            er = new ErrorWindow("Spaces are not allowed in Username.");
            er.show();
            return false;
        }
        
        // Test the first and last fields.
        if ((!fMonitor.getText().equals("")) || (!lMonitor.getText().equals(""))) {
            if ((fMonitor.getText().indexOf("'") != -1) || (lMonitor.getText().indexOf("'") != -1)) {
                er = new ErrorWindow("Invalid character in First Name or Last Name");
                er.show();
                return false;
            } else if ((fMonitor.getText().length() > 32) || (lMonitor.getText().length() > 32)) {
                er = new ErrorWindow("First Name and Last Name should be smaller than 32 characters");
                er.show();
                return false;
            } else if ((fMonitor.getText().indexOf(' ') != -1) || (lMonitor.getText().indexOf(' ') != -1)){
                if ((fMonitor.getText().indexOf(' ') != fMonitor.getText().length()) ||
                (lMonitor.getText().indexOf(' ') != lMonitor.getText().length())){
                    er = new ErrorWindow("Spaces are not allowed in First an Last Name.");
                    er.show();
                    return false;
                }
            }
        }
        
        // Test the password field.
        if (passwdMonitor.getText().equals("")) {
            er = new ErrorWindow("Missign password.");
            er.show();
            return false;
        } else if (passwdMonitor.getText().toLowerCase().indexOf("'") != -1) {
            er = new ErrorWindow("Invalid character in Password.");
            er.show();
            return false;
        } else if ((passwdMonitor.getText().length() < 5) || (passwdMonitor.getText().length() > 16)) {
            er = new ErrorWindow("Password should be bigger than 5 and smaller than 16 characters.");
            er.show();
            return false;
        } else if ((passwdMonitor.getText().indexOf(' ') != -1) &&
        (passwdMonitor.getText().indexOf(' ') != passwdMonitor.getText().length())) {
            er = new ErrorWindow("Spaces are not allowed in Password.");
            er.show();
            return false;
        } else if (!passwdMonitor.getText().equals(passwdMonitor2.getText())) {
            er = new ErrorWindow("Two Passwords different.");
            er.show();
            return false;
        }
        
        // Test the email field
        if (emailMonitor.getText().indexOf('@') == -1) {
            er = new ErrorWindow("Wrong email format: name@site.");
            er.show();
            return false;
        }
        
        // Test the access directory to the monitor
        if (accessDirectory.getText().indexOf(' ') != -1) {
            er = new ErrorWindow("Spaces are not allowed in the field Access Directory.");
            er.show();
            return false;
        } else if (accessDirectory.getText().lastIndexOf(separator) == accessDirectory.getText().length()-1) {
            er = new ErrorWindow("The / or \\ is not allowed in the last position of Access Directory.");
            er.show();
            return false;
        } else if (!accessDirectory.getText().substring(0,directoryAux.length()).equals(directoryAux)) {
            er = new ErrorWindow("Invalid Access Directory.");
            er.show();
            return false;
        }
        if (accessDirectory.getText().length() > directoryAux.length())
            directory = accessDirectory.getText().substring(directoryAux.length()+1, accessDirectory.getText().length());
        else
            directory = "/";
        
        // Test the expire date for the monitor
        try {
            java.util.Date test = new java.util.Date(expireDate.getText());
        } catch (Exception e) {
            er = new ErrorWindow("Invalid Date.");
            er.show();
            return false;
        }
        
        email = emailMonitor.getText();
        username = userName.getText().toLowerCase();
        FirstName = fMonitor.getText();
        LastName = lMonitor.getText();
        Password = passwdMonitor.getText().toLowerCase();
        dateExpire = expireDate.getText();
        return true;
    }
    
    /** Method for management of the database information.*/
    public Object updateView(SQL sql) throws Exception {
        ResultSet rs,rs1;
        String courseName;
        boolean monitorOtherCourse = false;
        
        // Search in the course database
        sql.init(Defaults.WEBCOMDATABASE);
        
        rs = sql.executeQuery("SELECT course_date FROM basic_info WHERE database_name='" + tic.resource + "'");
        rs.next();
        if (rs.getDate(1).after(new java.util.Date(dateExpire))) throw new RuntimeException("The expire date is before of the course date");
        
        rs= sql.executeQuery("SELECT username,email  FROM users WHERE username='" + username+"' OR email='" + email + "'");
        if (rs.next()) {
            if ((!rs.getString(1).equals(username)) || (!rs.getString(2).equals(email))) {
                if (rs.getString(1).equals(username)) throw new RuntimeException("This username already is used.");
                if (rs.getString(2).equals(email)) throw new RuntimeException("This e-mail already is used.");
            } else {
                monitorOtherCourse = true;
            }
        }
        rs = sql.executeQuery("SELECT course_name, directory FROM basic_info WHERE database_name='" + tic.resource + "'");
        rs.next();
        courseName = rs.getString(1);
        
        rs = sql.executeQuery("SELECT database_name FROM basic_info WHERE database_name!='" + tic.resource + "'");
        sql.close();
        // Search username and email in candidates table of another courses
        for (;rs.next();) {
            sql.init(rs.getString(1));
            rs1 = sql.executeQuery("SELECT username,email FROM candidates WHERE accepted='n' and (username='" +
            username + "' OR email='" + email + "')");
            if (rs1.next()) {
                if (rs1.getString(1).equals(username)) throw new RuntimeException("This username already is used.");
                if (rs1.getString(2).equals(email)) throw new RuntimeException("This e-mail already is used.");
            }
            sql.close();
        }
        if (!monitorOtherCourse) {
            sql.init(Defaults.WEBCOMDATABASE);
            // new monitor
            sql.executeUpdate("INSERT INTO users VALUES('" + username + "','" + Password + "','monitor','" +
            LastName + "','" + FirstName + "','','"+ email +"','',CURDATE(),'','')");
            sql.close();
            // Send e-mail with alert
            try {
                CourseEmail courseEmail = new CourseEmail(email);
                courseEmail.envia(Defaults.FROM, Defaults.HOST, "Course Manager",
                "Message from Course Administrator: \n" +
                "You was inserted in the course " + courseName + " as monitor.\n" +
                "Your information are:\n" +
                " username = " + username +"\n" +
                " password = " + Password +"\n" +
                " Please, change your password.");
            }catch (Exception e) {};
            sql.close();
        } else {
            sql.init(tic.resource);
            // monitor of another course
            rs = sql.executeQuery("SELECT username FROM monitors WHERE username='" + username + "'");
            if (rs.next()) throw new RuntimeException("Monitor already registred in this course.");
            
            // test if is student of this course
            rs = sql.executeQuery("SELECT username FROM students WHERE username='" + username + "'");
            if (rs.next()) throw new RuntimeException("Student registred in this course.");
            sql.close();
            
            sql.init(Defaults.WEBCOMDATABASE);
            sql.executeUpdate("UPDATE users SET password='" + Password + "' WHERE username='" + username + "'");
            sql.close();
            try {
                CourseEmail courseEmail = new CourseEmail(email);
                courseEmail.envia(Defaults.FROM, Defaults.HOST, "Course Manager",
                "Message from Course Administrator: \n" +
                "You was inserted in the course " + courseName + " as monitor.\n" +
                "Your information:\n" +
                " username = " + username +"\n" +
                " password = " + Password.toLowerCase() +"\n" +
                " Note: Your password was changed, and now you have to use it or change it in Change Password Tool.\n");
            }catch (Exception e) {};
        }
        String directoryAux = "";
        for (int i=0; i<directory.length();i++) {
            if (directory.charAt(i) == 92)
                directoryAux = directoryAux + "\\\\";
            else
                directoryAux = directoryAux + directory.charAt(i);
        }
        sql.init(tic.resource);
        
        sql.executeUpdate("INSERT INTO monitors VALUES('" + username + "','" + directoryAux + "','" + UtilFunctions.convertDate(dateExpire) + "')");
        sql.close();
        
        UserSelectionView userSelectionView = new UserSelectionView();
        return userSelectionView.createView(tic,sql);
    }
    
}
