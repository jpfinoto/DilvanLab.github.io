/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.net.*;

import agents.security.*;

/** Class for login.*/
public class TicketJavaInterface extends JavaInterface implements Serializable, ActionListener {
    protected byte[] ticket;
    protected Button    buttonOK;
    protected Button    buttonCancel;
    protected TextField username;
    protected TextField passwd;
    public    Label     message;
    protected String resource;
    
    
    /** Method for creation of a new instance from this class.*/
    public TicketJavaInterface(String host, String resource) {
        super(host);
        this.resource= resource;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public void init() {
        Image icon;
        Canvas canvas = new Canvas();
        ImageLoader jImage = new ImageLoader();
        
        ticket= null;
        
        // Create and use a BorderLayout manager with specified margins
        setLayout(new BorderLayout(15, 15));
        setFont(new Font("Helvetica", Font.PLAIN, 12));
        setBackground(Color.lightGray);
        
        //	Create userid, passwd, directory fields
        username= new TextField(20);
        passwd= new TextField(20);
        message= new Label();
        message.setForeground(Color.red);
        buttonOK= new Button("     Ok     ");
        buttonOK.addActionListener(this);
        buttonCancel= new Button("  Cancel  ");
        buttonCancel.addActionListener(this);
        
        Panel p2;
        Panel p = new Panel();
        p.setLayout(new GridLayout(0,1));
        p2= new Panel();
        p2.add( new Label("User Name:"));
        p2.add( username);
        p.add(p2);
        
        p2= new Panel();
        p2.add( new Label("  Password:"));
        passwd.setEchoChar('*');
        p2.add( passwd);
        p.add(p2);
        
        p2= new Panel();
        p2.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        p2.add(buttonOK);
        p2.add(buttonCancel);
        p.add(p2);
        
        // Image from top of the window
        icon = jImage.loadImage("login.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        
        canvas.setSize(215,45);
        canvas.setBackground(Color.lightGray);
        
        add("North",canvas);
        add("Center", p);
        add("South",message);
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                setVisible(false);
            }
        });
        
        // Resize the window to the preferred size of its components
        pack();
    }
    
    /** Method for pop downing the window when the ok or the cancel button is clicked.*/
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        if (source == buttonOK) {
            //	Try loging
            message.setText("Processing user authentication ...");
            // Test if the user is valid and generate a ticket
            if (generateTicket()) {
                message.setText("User OK !");
                processAction(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ""));
            }
            else message.setText("Authentication failed !");
            return;
        }
        // Close the window
        if (source == buttonCancel) setVisible(false);
    }
    
    /** Method for generation of the ticket for the user.*/
    public boolean generateTicket() {
        try {
            // Create message
            Message msg= new Message();
            msg.body.addElement("ticket");
            msg.body.addElement(resource);
            msg.body.addElement(username.getText());
            String[] buf= new String[2];
            buf[0]= resource;
            buf[1]= username.getText();
            msg.body.addElement(ObjectOutputCrypt.writeObject(passwd.getText(), buf));
            // Send a Message for the TicketAgent passing by Class JavaInterface and Servlet Database
            ticket= (byte[]) sendRequest("TicketAgent", msg);
        } catch (Exception e3) {
            System.out.println(e3);
            return false;
        }
        return true;
    }
    
    /** Method for getting the ticket.*/
    public byte[] getTicket() {
        return ticket;
    }
    
    /** Method for getting the username from the ticket.*/
    public String getUsername() { return username.getText();}
    
    /** Method for getting the password from the ticket.*/
    public String getPassword() { return passwd.getText();}
}
