/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents.security;

import java.io.*;
import cryptix.*;

/** Class for decodification of messages.*/
public class ObjectInputCrypt {
    private String passwd;
    private ObjectInput in;
    
    /** Method for creating a new instance of the class.*/
    public ObjectInputCrypt(String passwd, ObjectInput in) {
        this.passwd= passwd;
        this.in= in;
    }
    
    /** Method for decodifying object using a password.*/
    public Object readObject() throws IOException, ClassNotFoundException {
        byte[] buffer= (byte[]) in.readObject();
        return readObject(passwd, buffer);
    }
    
    /** Method for decodifying buffer using a password.*/
    public static Object readObject(String passwd, byte[] buffer) throws IOException, ClassNotFoundException {
        IDEA idea= new IDEA( MessageDigest.hash( passwd, new MD5()));
        int blocks= buffer.length / idea.blockLength();
        
        for (int aux1=0; aux1<blocks; aux1++)
            idea.decrypt(buffer, aux1*idea.blockLength(), buffer, aux1*idea.blockLength());
        
        ObjectInputStream inp= new ObjectInputStream(new ByteArrayInputStream(buffer));
        return inp.readObject();
    }
    
    /** Method main for stand alone aplications.*/
    public static void main(String[] arg) {
        String lixo= "The big garbage";
        //System.out.println("Original: " + lixo);
        String passwd= "kklkuhhtgfh";
        try {
            byte[] buf= ObjectOutputCrypt.writeObject(passwd, lixo);
            //System.out.println("Crypt: " + buf);
            //System.out.println("Decrypt: " + ObjectInputCrypt.readObject(passwd, buf));
        } catch (Exception e) {}
    }
}