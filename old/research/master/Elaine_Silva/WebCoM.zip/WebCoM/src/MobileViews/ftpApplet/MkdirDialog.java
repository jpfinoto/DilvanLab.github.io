/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package ftpApplet;

import java.awt.*;
import java.awt.event.*;

public class MkdirDialog extends Dialog implements ActionListener{
   protected Button    buttonOK;
   protected Button    buttonCancel;
   protected TextField dirname;
   protected Label     message;

   public MkdirDialog(Client parent)
   {
      // Create a dialog with the specified title
      super(parent, "New directory", true);
        
      // Create and use a BorderLayout manager with specified margins
      setLayout(new BorderLayout(15, 15));
       
      //	Create s
      //
      dirname= new TextField("", 20);
      message= new Label("Write the name of the new directory:");
      buttonOK= new Button("  OK  "); 
      buttonCancel= new Button("  Cancel  ");

      buttonOK.addActionListener(this);
      buttonCancel.addActionListener(this);

      Panel p= new Panel();
      p.add( new Label("Name:"));
      p.add( dirname);
 
      add("North", message);
      add("Center", p);
      p= new Panel();
      p.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 5));
      p.add(buttonOK);
      p.add(buttonCancel);
      add("South", p);

      // Resize the window to the preferred size of its components
      pack();
   }

   // Pop down the window when the button is clicked.
   public void actionPerformed(ActionEvent e) 
   {
      if (e.getSource() == buttonOK) {
         //	Try loging
         //
         setVisible(false);
         return;
      }
      if (e.getSource() == buttonCancel) {
         dirname.setText("");
         setVisible(false);
         return;
      }
   }
}

