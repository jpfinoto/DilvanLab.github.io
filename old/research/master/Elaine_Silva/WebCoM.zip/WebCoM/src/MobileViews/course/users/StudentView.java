/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.users;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.io.File;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import agents.util.CourseEmail;
import course.util.UtilFunctions;

/** Class for addition of student user.*/
public class StudentView extends Panel implements View {
    String username;
    String FirstName, LastName, Password;
    String email;
    String classSelected = null;
    int idNumber;
    Vector listClass;
    Ticket tic;
    
    transient TextField fStudent,lStudent,userName;
    transient TextField passwdStudent,passwdStudent2;
    transient TextField emailStudent;
    transient TextField idNumberStudent;
    transient Choice listClassChoice;
    
    /** Method for creation of a new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        
        sql.init(tic.resource);
        listClass = new Vector();
        int contList = 0;
        
        // Select all classes to insert new student
        ResultSet rs = sql.executeQuery("SELECT id,expire FROM class");
        java.util.Date date = new java.util.Date();
        for(;rs.next();) {
            if (UtilFunctions.verifyDate(date,rs.getDate(2)) >= 0) {
                listClass.addElement("Class " + rs.getString(1));
                contList++;
            }
        }
        if (contList == 0) throw new RuntimeException("Don't have any class to add Student.");
        sql.close();
        
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Image icon;
        Canvas canvas = new Canvas();
        
        fStudent = new TextField(5);
        lStudent = new TextField(5);
        userName = new TextField(5);
        passwdStudent = new TextField(5);
        passwdStudent2 = new TextField(5);
        emailStudent = new TextField(5);
        idNumberStudent = new TextField(5);
        
        listClassChoice = new Choice();
        for (int count=0; count < listClass.size(); count++)
            listClassChoice.addItem((String) listClass.elementAt(count));
        
        setFont(new Font("Helvetica",Font.PLAIN,11));
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        // label username
        Label label = new Label("Username");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label first name
        constraints.gridx = 0;
        constraints.gridy = 2;
        label = new Label("First Name");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label last name
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.insets = new Insets(0,5,0,0);
        label = new Label("Last Name");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label password
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,0,0,5);
        label = new Label("Type Password");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label retype password
        constraints.gridx = 2;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,5,0,0);
        label = new Label("Retype Password");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label e-mail
        constraints.gridx = 0;
        constraints.gridy = 6;
        constraints.insets = new Insets(0,0,0,5);
        label = new Label("E-mail");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label Id Number
        label = new Label("Id Number");
        constraints.gridx = 0;
        constraints.gridy = 8;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label class
        label = new Label("Class     ");
        constraints.gridx = 2;
        constraints.gridy = 8;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label
        label = new Label("          ");
        constraints.gridx = 1;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        label = new Label("          ");
        constraints.gridx = 3;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // field username
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        gridBag.setConstraints(userName,constraints);
        form.add(userName);
        
        // field first name Student
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        constraints.insets = new Insets(0,0,0,5);
        gridBag.setConstraints(fStudent,constraints);
        form.add(fStudent);
        
        // field last name Student
        constraints.gridx = 2;
        constraints.gridy = 3;
        constraints.insets = new Insets(0,5,0,0);
        gridBag.setConstraints(lStudent,constraints);
        form.add(lStudent);
        
        // field password
        constraints.gridx = 0;
        constraints.gridy = 5;
        constraints.insets = new Insets(0,0,0,5);
        passwdStudent.setEchoChar('*');
        gridBag.setConstraints(passwdStudent,constraints);
        form.add(passwdStudent);
        
        // field retype password
        constraints.gridx = 2;
        constraints.gridy = 5;
        constraints.insets = new Insets(0,5,0,0);
        passwdStudent2.setEchoChar('*');
        gridBag.setConstraints(passwdStudent2,constraints);
        form.add(passwdStudent2);
        
        // field email
        constraints.gridx = 0;
        constraints.gridy = 7;
        constraints.gridwidth = 4;
        constraints.insets = new Insets(0,0,0,5);
        gridBag.setConstraints(emailStudent,constraints);
        form.add(emailStudent);
        
        // field Id Number
        constraints.gridx = 0;
        constraints.gridy = 9;
        constraints.gridwidth = 2;
        gridBag.setConstraints(idNumberStudent,constraints);
        form.add(idNumberStudent);
        
        // field class
        constraints.gridx = 2;
        constraints.gridy = 9;
        constraints.gridwidth = 2;
        gridBag.setConstraints(listClassChoice,constraints);
        form.add(listClassChoice);
        
        groupForm.add(form,BorderLayout.CENTER);
        
        ImageLoader jImage = new ImageLoader();
        icon = jImage.loadImage("student.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(380,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        ErrorWindow er;
        
        // Test the username field
        if (userName.getText().equals("")) {
            er = new ErrorWindow("Missing username.");
            er.show();
            return false;
        } else if (!UtilFunctions.validateField(userName.getText().toLowerCase(), "abcdefghijklmnopqrstuvxzwy0123456789-_")) {
            er = new ErrorWindow("Invalid character in Username.");
            er.show();
            return false;
        } else if ((userName.getText().length() < 5) || (userName.getText().length() > 16)){
            er = new ErrorWindow("Username should be bigger than 5 and smaller than 16 characters.");
            er.show();
            return false;
        } else if ((userName.getText().indexOf(' ') != -1) &&
        (userName.getText().indexOf(' ') != userName.getText().length())) {
            er = new ErrorWindow("Spaces are not allowed in Username.");
            er.show();
            return false;
        }
        
        // Test the first and last name fields
        if ((!fStudent.getText().equals("")) || (!lStudent.getText().equals(""))) {
            if ((fStudent.getText().indexOf("'") != -1) || (lStudent.getText().indexOf("'") != -1)) {
                er = new ErrorWindow("Invalid character in First Name or Last Name");
                er.show();
                return false;
            } else if ((fStudent.getText().length() > 32) || (lStudent.getText().length() > 32)) {
                er = new ErrorWindow("First Name and Last Name should be smaller than 32 characters");
                er.show();
                return false;
            } else if ((fStudent.getText().indexOf(' ') != -1) || (lStudent.getText().indexOf(' ') != -1)){
                if ((fStudent.getText().indexOf(' ') != fStudent.getText().length()) ||
                (lStudent.getText().indexOf(' ') != lStudent.getText().length())){
                    er = new ErrorWindow("Spaces are not allowed in First an Last Name.");
                    er.show();
                    return false;
                }
            }
        }
        // Test the password field
        if (passwdStudent.getText().equals("")) {
            er = new ErrorWindow("Missign password.");
            er.show();
            return false;
        } else if (passwdStudent.getText().toLowerCase().indexOf("'") != -1) {
            er = new ErrorWindow("Invalid character in Password.");
            er.show();
            return false;
        } else if ((passwdStudent.getText().length() < 5) || (passwdStudent.getText().length() > 16)) {
            er = new ErrorWindow("Password should be bigger than 5 and smaller than 16 characters.");
            er.show();
            return false;
        } else if ((passwdStudent.getText().indexOf(' ') != -1) &&
        (passwdStudent.getText().indexOf(' ') != passwdStudent.getText().length())) {
            er = new ErrorWindow("Spaces are not allowed in Password.");
            er.show();
            return false;
        } else if (!passwdStudent.getText().equals(passwdStudent2.getText())) {
            er = new ErrorWindow("Two Passwords different.");
            er.show();
            return false;
        }
        // Test the email field
        if (emailStudent.getText().indexOf('@') == -1) {
            er = new ErrorWindow("Wrong email format: name@site.");
            er.show();
            return false;
        }
        
        // Test the id number field
        if (!idNumberStudent.getText().equals("")) {
            if (!UtilFunctions.validateField(idNumberStudent.getText(),"0123456789")) {
                er = new ErrorWindow("Invalid Charactere to Id Number.");
                er.show();
                return false;
            }
            idNumber = Integer.parseInt(idNumberStudent.getText());
        } else
            idNumber = 0;
        
        
        // get the selected class
        StringTokenizer analex= new StringTokenizer((String) listClassChoice.getSelectedItem());
        String token = analex.nextToken();
        try {
            classSelected = analex.nextToken();
        } catch (Exception e) {}
        
        
        email = emailStudent.getText();
        username = userName.getText().toLowerCase();
        FirstName = fStudent.getText();
        LastName = lStudent.getText();
        Password = passwdStudent.getText().toLowerCase();
        
        return true;
    }
    
    /** Method for management of the database information.*/
    public Object updateView(SQL sql) throws Exception {
        ResultSet rs,rs1;
        boolean studentOfOtherCourse = false;
        String directory, courseName;
        
        // Search username and email in the course database
        sql.init(Defaults.WEBCOMDATABASE);
        rs= sql.executeQuery("SELECT username,email FROM users WHERE username='" + username+"' OR email='" + email + "'");
        if (rs.next()) {
            if ((!rs.getString(1).equals(username)) || (!rs.getString(2).equals(email))) {
                if (rs.getString(1).equals(username))
                    throw new RuntimeException("This username already is used.");
                if (rs.getString(2).equals(email))
                    throw new RuntimeException("This e-mail already is used.");
            } else
                studentOfOtherCourse = true;
        }
        // get the course name
        rs = sql.executeQuery("SELECT course_name, directory FROM basic_info WHERE database_name='" + tic.resource + "'");
        rs.next();
        directory = rs.getString(2);
        courseName = rs.getString(1);
        
        // get database name of another courses
        rs = sql.executeQuery("SELECT database_name FROM basic_info WHERE database_name!='" + tic.resource + "'");
        sql.close();
        
        // Search username and email in candidates table of another courses
        for (;rs.next();) {
            sql.init(rs.getString(1));
            rs1 = sql.executeQuery("SELECT username,email FROM candidates WHERE accepted='n' and (username='" +
            username + "' OR email='" + email + "')");
            if (rs1.next()) {
                if ((!rs1.getString(1).equals(username)) || (!rs1.getString(2).equals(email))) {
                    if (rs1.getString(1).equals(username))
                        throw new RuntimeException("This username already is used.");
                    if (rs1.getString(2).equals(email))
                        throw new RuntimeException("This e-mail already is used.");
                } else
                    studentOfOtherCourse = true;
                for(;rs.next(););
            }
            sql.close();
        }
        
        sql.init(tic.resource);
        //Test if already exists this id Number
        rs = sql.executeQuery("SELECT username,id FROM students WHERE class='" + classSelected + "'AND ( username='" +
        username + "' OR id='" + idNumber + "')");
        for (;rs.next();) {
            if (!rs.getString(1).equals("")) throw new RuntimeException("This username already registred in this course.");
            if (!rs.getString(2).equals("")) throw new RuntimeException("This id number already registred in this course.");
        }
        
        // Insert the student in the course database
        sql.executeUpdate("INSERT INTO students VALUES('" + username + "','" + idNumber + "','" + classSelected + "')");
        
        // insert activities for reports
        rs1 = sql.executeQuery("SELECT id FROM reports WHERE class=" + classSelected);
        for (; rs1.next();) {
            sql.executeUpdate("INSERT INTO activities VALUES('" + username + "','reports'," + rs1.getInt(1) +
            ",'',0,'"+ classSelected +"')");
            UtilFunctions.createDirectoriesStudent(directory, rs1.getInt(1), username, Integer.parseInt(classSelected));
        }
        
        // insert activities for tests
        rs1 = sql.executeQuery("SELECT id FROM tests WHERE class=" + classSelected);
        for (; rs1.next();)
            sql.executeUpdate("INSERT INTO activities VALUES('" + username + "','tests'," + rs1.getInt(1) +
            ",'',0,'"+ classSelected +"')");
        
        sql.close();
        
        sql.init(Defaults.WEBCOMDATABASE);
        if (!studentOfOtherCourse) {
            // Insert the student in the users base
            sql.executeUpdate("INSERT INTO users VALUES('" + username + "','" + Password.toLowerCase() + "','student','" +
            LastName + "','" + FirstName + "','','"+ email + "','',CURDATE(),'','')");
            try {
                CourseEmail courseEmail = new CourseEmail(email);
                courseEmail.envia(Defaults.FROM, Defaults.HOST, "Course Manager",
                "Message from Course Administrator: \n" +
                "You was inserted in the course" + courseName + ".\n" +
                "Your information:\n" +
                " username = " + username +"\n" +
                " password = " + Password.toLowerCase() +"\n" +
                " Identification number = " + idNumber +"\n" +
                " Class = " + classSelected + "\n" +
                " Please, change your password.");
            }catch (Exception e) {};
            
        } else {
            // the student already is in another course
            sql.executeUpdate("UPDATE users SET password='" + Password.toLowerCase() + "' WHERE username='" + username + "'");
            try {
                // send email with the new password
                CourseEmail courseEmail = new CourseEmail(email);
                courseEmail.envia(Defaults.FROM, Defaults.HOST, "Course Manager",
                "Message from Course Administrator: \n" +
                "You was inserted in the course " + courseName + ".\n" +
                "Your information:\n" +
                " username = " + username +"\n" +
                " password = " + Password.toLowerCase() +"\n" +
                " Identification number = " + idNumber +"\n" +
                " Class = " + classSelected + "\n" +
                " Note: Your password was changed, and now you have to use it or change it in Change Password Tool.\n");
            }catch (Exception e) {};
            
        }
        sql.close();
        UserSelectionView userSelectionView = new UserSelectionView();
        return userSelectionView.createView(tic,sql);
    }
    
}
