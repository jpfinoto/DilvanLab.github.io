/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import agents.*;

/** Class with an interface and some methods for the management of the assignment's projects.*/
public class ProjectPanel extends Panel{
    transient Image icon;
    transient TextField idAssignment;
    transient TextField maxGroups, minStudents, maxStudents;
    transient TextField nameProject;
    
    /** Method for creation of new instance from this class.*/
    public ProjectPanel(int idAssignment) {
        this.idAssignment = new TextField(String.valueOf(idAssignment));
        this.idAssignment.setEditable(false);
        maxGroups = new TextField("1");
        minStudents = new TextField("1");
        maxStudents = new TextField("1");
        nameProject = new TextField("");
    }
    
    /** Method for storing the interface's objects in a structure.*/
    public DataProject update(DataProject dataProject) {
        dataProject.name = nameProject.getText();
        dataProject.maxGroups = maxGroups.getText();
        dataProject.minStudents = minStudents.getText();
        dataProject.maxStudents = maxStudents.getText();
        return dataProject;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public int validateView() {
        if (nameProject.getText().equals(""))
            return 1; // missing project name
        if ((nameProject.getText().indexOf(' ') != -1) && (nameProject.getText().indexOf(' ') != nameProject.getText().length()-1))
            return 2; // spaces are not allowed in  field project name
        try {
            if (Integer.parseInt(maxGroups.getText()) > 0)
                if (Integer.parseInt(minStudents.getText()) > 0)
                    if ((Integer.parseInt(maxStudents.getText()) > 0) &&
                    (Integer.parseInt(maxStudents.getText()) >= Integer.parseInt(minStudents.getText())))
                        return 0;
                    else
                        return 4; // minStudents is bigger maxStudents
                else
                    return 3;
            else
                return 3;  // values min and max have to be more than 0
        } catch (Exception e) {
            return 5; // missing values
        }
    }
    
    /** Method for update the graphic interface objects with information from the structure.*/
    public void atualizeView(DataProject dataProject) {
        nameProject.setText(dataProject.name);
        maxGroups.setText(dataProject.maxGroups);
        minStudents.setText(dataProject.minStudents);
        maxStudents.setText(dataProject.maxStudents);
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        ImageLoader jImage = new ImageLoader();
        Canvas canvas = new Canvas();
        idAssignment.setForeground(Color.blue);
        idAssignment.setFont(new Font("Helvetica",Font.PLAIN,11));
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout(0,20));
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        // Label Assignment
        Label label = new Label("Assignment");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        label.setFont(new Font("Helvetica",Font.BOLD,12));
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label white
        label = new Label("                  ");
        constraints.gridx = 1;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // field id Assignment
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.WEST;
        gridBag.setConstraints(idAssignment,constraints);
        form.add(idAssignment);
        
        // label Name Project
        label = new Label("Name Project");
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label Number Max of Groups
        label = new Label("Number Max of Groups ");
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.gridwidth = 1;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label Min Students for Group
        label = new Label("Min Students for Group ");
        constraints.gridx = 0;
        constraints.gridy = 5;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label Max Students for Group
        label = new Label("Max Students for Group ");
        constraints.gridx = 0;
        constraints.gridy = 6;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        
        // field Name Project
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        gridBag.setConstraints(nameProject,constraints);
        form.add(nameProject);
        
        // field max groups
        constraints.gridx = 1;
        constraints.gridy = 4;
        constraints.gridwidth = 1;
        gridBag.setConstraints(maxGroups,constraints);
        form.add(maxGroups);
        
        // field min students
        constraints.gridx = 1;
        constraints.gridy = 5;
        gridBag.setConstraints(minStudents,constraints);
        form.add(minStudents);
        
        // field max students
        constraints.gridx = 1;
        constraints.gridy = 6;
        gridBag.setConstraints(maxStudents,constraints);
        form.add(maxStudents);
        
        groupForm.add(form,BorderLayout.CENTER);
        
        icon = jImage.loadImage("assignments.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(380,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
}
