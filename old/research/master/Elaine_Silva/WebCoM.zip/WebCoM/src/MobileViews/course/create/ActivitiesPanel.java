/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.create;

import java.awt.*;
import java.awt.event.*;
import agents.*;

/** Class with a graphic interface and some methods to manage activities information.*/
public class ActivitiesPanel extends Panel implements ItemListener {
    transient Checkbox assignment,report,test;
    transient TextArea description;
    transient TextField numberAssignments, numberReports, numberTests;
    transient TextField weightAssignments, weightReports, weightTests;
    transient Image icon;
    
    /** Method for creation of new instance from this class. There is a checkbox to select the activities types and its
     * numbers and weights.There is too a text area to explain each activity.*/
    public ActivitiesPanel() {
        numberAssignments = new TextField(5);
        numberReports = new TextField(5);
        numberTests = new TextField(5);
        weightAssignments = new TextField(5);
        weightReports = new TextField(5);
        weightTests = new TextField(5);
        
        assignment = new Checkbox("Assignments", false);
        report = new Checkbox("Reports",false);
        test = new Checkbox("Tests",false);
        numberAssignments.setEditable(false);
        numberReports.setEditable(false);
        numberTests.setEditable(false);
        
        weightAssignments.setEditable(false);
        weightReports.setEditable(false);
        weightTests.setEditable(false);
        
        numberAssignments.setText("0");
        numberReports.setText("0");
        numberTests.setText("0");
        
        weightAssignments.setText("0");
        weightReports.setText("0");
        weightTests.setText("0");
    }
    
    /** Method for validation of the graphic interface objects.*/
    public int validateView() {
        try {
            // if assignment is selected
            if (assignment.getState()){
                // if there is number of assignments
                if (numberAssignments.getText().equals("")) return 1;
                if (Integer.parseInt(numberAssignments.getText()) <= 0)
                    return 1;
                // if there is weight of assignments
                if (weightAssignments.getText().equals("")) return 1;
                if (Integer.parseInt(weightAssignments.getText()) <= 0)
                    return 1;
                
            }
            // if report is selected
            if (report.getState()) {
                // if there is number of reports
                if (numberReports.getText().equals("")) return 1;
                if (Integer.parseInt(numberReports.getText()) <= 0)
                    return 1;
                // if there is weigh of reports
                if (weightReports.getText().equals("")) return 1;
                if (Integer.parseInt(weightReports.getText()) <= 0)
                    return 1;
                
            }
            // if test is selected
            if (test.getState()){
                // if there is number of tests
                if (numberTests.getText().equals("")) return 1;
                if (Integer.parseInt(numberTests.getText()) <= 0)
                    return 1;
                // if there is weight of tests
                if (weightTests.getText().equals("")) return 1;
                if (Integer.parseInt(weightTests.getText()) <= 0)
                    return 1;
            }
        } catch (Exception e) {return 1;}
        return 0;
    }
    
    /** Method for atualize the information into the dataActivities object.*/
    public DataActivities update(DataActivities dataActivities) {
        // if there is assignment
        if (assignment.getState()) {
            dataActivities.numberAssignments = Integer.parseInt(numberAssignments.getText());
            dataActivities.weightAssignments = Integer.parseInt(weightAssignments.getText());
        } else {
            dataActivities.numberAssignments = 0;
            dataActivities.weightAssignments = 0;
        }
        
        // if there is report
        if (report.getState()) {
            dataActivities.numberReports = Integer.parseInt(numberReports.getText());
            dataActivities.weightReports = Integer.parseInt(weightReports.getText());
        } else {
            dataActivities.numberReports = 0;
            dataActivities.weightReports = 0;
        }
        
        // if there is test
        if (test.getState()) {
            dataActivities.numberTests = Integer.parseInt(numberTests.getText());
            dataActivities.weightTests = Integer.parseInt(weightTests.getText());
        } else {
            dataActivities.numberTests = 0;
            dataActivities.weightTests = 0;
        }
        return dataActivities;
    }
    
    /** Method for getting information from the dataActivities object and for setting the graphic interface objects.*/
    public void atualizeView(DataActivities dataActivities) {
        
        numberAssignments.setText(String.valueOf(dataActivities.numberAssignments));
        numberReports.setText(String.valueOf(dataActivities.numberReports));
        numberTests.setText(String.valueOf(dataActivities.numberTests));
        
        weightAssignments.setText(String.valueOf(dataActivities.weightAssignments));
        weightReports.setText(String.valueOf(dataActivities.weightReports));
        weightTests.setText(String.valueOf(dataActivities.weightTests));
        
        // if there is assignments
        if (dataActivities.numberAssignments > 0) {
            numberAssignments.setEditable(true);
            weightAssignments.setEditable(true);
            assignment.setState(true);
        } else {
            numberAssignments.setEditable(false);
            weightAssignments.setEditable(false);
            assignment.setState(false);
        }
        // if there is reports
        if (dataActivities.numberReports > 0){
            numberReports.setEditable(true);
            weightReports.setEditable(true);
            report.setState(true);
        } else {
            numberReports.setEditable(false);
            weightReports.setEditable(false);
            report.setState(false);
        }
        // if there is tests
        if (dataActivities.numberTests > 0) {
            numberTests.setEditable(true);
            weightTests.setEditable(true);
            test.setState(true);
        } else {
            numberTests.setEditable(false);
            weightTests.setEditable(false);
            test.setState(false);
        }
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        
        ImageLoader jImage = new ImageLoader();
        Canvas canvas = new Canvas();
        
        assignment.addItemListener(this);
        report.addItemListener(this);
        test.addItemListener(this);
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        icon = jImage.loadImage("doc06.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        
        canvas.setSize(35,30);
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        constraints.gridheight = 2;
        constraints.weightx = 0.3;
        constraints.weighty = 1;
        constraints.insets = new Insets(15,5,0,0);
        constraints.fill = GridBagConstraints.BOTH;
        gridBag.setConstraints(canvas,constraints);
        form.add(canvas);
        
        icon = jImage.loadImage("doc11.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        
        canvas.setSize(35,30);
        constraints.gridx = 0;
        constraints.gridy = 6;
        gridBag.setConstraints(canvas,constraints);
        form.add(canvas);
        
        icon = jImage.loadImage("doc10.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        
        canvas.setSize(35,30);
        constraints.gridx = 0;
        constraints.gridy = 10;
        gridBag.setConstraints(canvas,constraints);
        form.add(canvas);
        
        // label Type of activities
        Label label = new Label("Type of Activities");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.gridheight = 1;
        constraints.weightx = 1;
        constraints.weighty = 1;
        constraints.insets = new Insets(0,5,0,0);
        constraints.fill = GridBagConstraints.HORIZONTAL;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        Panel aux = new Panel();
        aux.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
        
        // label Number
        label = new Label("Number");
        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.EAST;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        label = new Label("Number");
        constraints.gridx = 1;
        constraints.gridy = 6;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        label = new Label("Number");
        constraints.gridx = 1;
        constraints.gridy = 10;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label Weight
        label = new Label("Weight");
        constraints.gridx = 1;
        constraints.gridy = 3;
        constraints.gridwidth = 1;
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.EAST;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        label = new Label("Weight");
        constraints.gridx = 1;
        constraints.gridy = 7;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        label = new Label("Weight");
        constraints.gridx = 1;
        constraints.gridy = 11;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //Field Number Assignment
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.ipadx = 3;
        constraints.anchor = GridBagConstraints.WEST;
        gridBag.setConstraints(numberAssignments,constraints);
        form.add(numberAssignments);
        
        //Field Number Report
        constraints.gridx = 2;
        constraints.gridy = 6;
        gridBag.setConstraints(numberReports,constraints);
        form.add(numberReports);
        
        //Field Number Test
        constraints.gridx = 2;
        constraints.gridy = 10;
        gridBag.setConstraints(numberTests,constraints);
        form.add(numberTests);
        
        //Field Weight Assignment
        constraints.gridx = 2;
        constraints.gridy = 3;
        constraints.ipadx = 3;
        constraints.anchor = GridBagConstraints.WEST;
        gridBag.setConstraints(weightAssignments,constraints);
        form.add(weightAssignments);
        
        //Field Weight Report
        constraints.gridx = 2;
        constraints.gridy = 7;
        gridBag.setConstraints(weightReports,constraints);
        form.add(weightReports);
        
        //Field Weight Test
        constraints.gridx = 2;
        constraints.gridy = 11;
        gridBag.setConstraints(weightTests,constraints);
        form.add(weightTests);
        
        
        // Checkbox Assignments
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        constraints.ipadx = 0;
        assignment.setFont(new Font("Helvetica", Font.BOLD, 12));
        gridBag.setConstraints(assignment,constraints);
        form.add(assignment);
        
        //Checkbox Reports
        constraints.gridx = 0;
        constraints.gridy = 5;
        report.setFont(new Font("Helvetica", Font.BOLD, 12));
        gridBag.setConstraints(report,constraints);
        form.add(report);
        
        // CheckBox Tests
        constraints.gridx = 0;
        constraints.gridy = 9;
        test.setFont(new Font("Helvetica", Font.BOLD, 12));
        gridBag.setConstraints(test,constraints);
        form.add(test);
        
        String text;
        
        // description about assignments
        text = new String("Description:  this activity is done by groups.\n" + "Each assignment can have one or more\n" +
        "projects which can be accomplished by one or\n" + "more groups. It can have diferent weights.\n" +
        "Administrator can add peer review\n" + "or not. Groups must carry out the final \n" +
        "results until the defined date.\n");
        description = new TextArea(text ,3,35);
        description.setEditable(false);
        description.setBackground(Color.white);
        constraints.gridx = 3;
        constraints.gridy = 2;
        constraints.gridwidth = 3;
        constraints.gridheight = 2;
        constraints.ipady = 5;
        constraints.insets = new Insets(0,0,10,5);
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(description,constraints);
        form.add(description);
        
        // description about reports
        text = new String("Description:  this activity is done by only one\n" +
        "student. Each report is one project, but one project\n" +
        "can be accomplished by two or more students.\n" +
        "There is not review for reports. Students must \n" +
        "carry out their reports until the defined date.\n");
        description = new TextArea(text,3,35);
        description.setEditable(false);
        description.setBackground(Color.white);
        constraints.gridx = 3;
        constraints.gridy = 6;
        gridBag.setConstraints(description,constraints);
        form.add(description);
        
        // description about test
        text = new String("Description:  this activity is done by only one\n" +
        "student and he does not carry out any reports.\n" +
        "This activity can be an exercise, or a test or another\n" +
        "didactic activity which does not require reports.\n");
        description = new TextArea(text,3,35);
        description.setEditable(false);
        description.setBackground(Color.white);
        constraints.gridx = 3;
        constraints.gridy = 10;
        gridBag.setConstraints(description,constraints);
        form.add(description);
        
        groupForm.add(form,BorderLayout.SOUTH);
        
        icon = jImage.loadImage("activities.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        
        canvas.setSize(430,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
    
    /** Method for controlling the users action in the checkbox.*/
    public void itemStateChanged(ItemEvent evt) {
        Object source = evt.getSource();
        if (source == assignment) {
            if (assignment.getState() == false) {
                numberAssignments.setText("0");
                weightAssignments.setText("0");
                numberAssignments.setEditable(false);
                weightAssignments.setEditable(false);
            }
            else {
                numberAssignments.setEditable(true);
                weightAssignments.setEditable(true);
            }
        }
        if (source == report) {
            if (report.getState() == false) {
                numberReports.setText("0");
                weightReports.setText("0");
                numberReports.setEditable(false);
                weightReports.setEditable(false);
            }
            else {
                numberReports.setEditable(true);
                weightReports.setEditable(true);
            }
        }
        if (source == test) {
            if (test.getState() == false) {
                numberTests.setText("0");
                weightTests.setText("0");
                numberTests.setEditable(false);
                weightTests.setEditable(false);
            }
            else {
                numberTests.setEditable(true);
                weightTests.setEditable(true);
            }
        }
        
    }
}
