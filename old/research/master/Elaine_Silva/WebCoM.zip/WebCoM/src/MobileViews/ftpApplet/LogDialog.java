/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/


package ftpApplet;

import java.awt.*;
import java.awt.event.*;

import agents.*;

public class LogDialog extends Dialog implements ActionListener{
   protected Button    buttonOK;
   protected Button    buttonCancel;
   protected TextField username;
   protected TextField passwd;
   protected Choice    directory;
   protected Label     message;
   protected Client    client;

   TicketJavaInterface log;

   public LogDialog(Client parent, String host, String resource)
   {
      // Create a dialog with the specified title
      super(parent, "Logging to Directory", false);

      client= parent;
        
      // Create and use a BorderLayout manager with specified margins
      setLayout(new BorderLayout(15, 15));
       
      //	Create directory fields
      //

      directory= new Choice();
      message= new Label("");
      buttonOK= new Button("  OK  "); 
      buttonOK.addActionListener(this); 
      buttonCancel= new Button("  Cancel  ");
      buttonCancel.addActionListener(this); 

      Panel p2;
      Panel p= new Panel();
      p.setLayout(new GridLayout(0,1));
 
      p2= new Panel();
      p2.add( new Label("Directory:"));
      p2.add( directory);
      p.add(p2);

      p2= new Panel();
      p2.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 5));
      p2.add(buttonOK);
      p2.add(buttonCancel);
      p.add(p2);

      add("North", new Label("Please, choose a directory:"));
      add("Center", p);
      add("South", message);

      // Resize the window to the preferred size of its components
      //pack();

      //	Window destructor
      //
      addWindowListener(new WindowAdapter () {
         public void windowClosing(WindowEvent e) {
            setVisible(false);
         }
      });

      log= new TicketJavaInterface(host, resource);
      log.addActionListener(this);
      log.init(); 
    }

   public void show(){ log.show();}

   public void actionPerformed(ActionEvent e) 
   {
      Object source = e.getSource();
                 
      if (source == log) {
         //    Try get directories logging options
         //
         log.message.setText("Getting logging options ...");
         try {
            String [] options = client.Execlogoptions(log.getTicket(), log.getPassword());
            directory.removeAll();
            for (int aux1=0; aux1<options.length; aux1++) 
               directory.addItem(options[aux1]);
            pack();
            super.show();
            log.setVisible(false);
            log.message.setText("");
            return;
         } catch (Exception e2) {
            message.setText(e2.getMessage());
            log.message.setText("Failed to get options.");
            return;
         }
        
      }
      if (source == buttonOK) {
         //	Try loging
         //
         message.setText("Sending data ...");
         try {
            client.Execlogin(log.getTicket(), log.getPassword(), directory.getSelectedItem());
         } catch (Exception e1) { 
            message.setText(e1.getMessage()); 
            return;
         }
         setVisible(false);
         message.setText("");
         return;
      }

      if (e.getSource() == buttonCancel) 
         setVisible(false);
   }
}

