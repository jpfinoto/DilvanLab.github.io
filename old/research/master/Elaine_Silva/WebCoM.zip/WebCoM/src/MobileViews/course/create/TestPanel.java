/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.create;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import agents.ImageLoader;
import agents.ImageCanvas;

/** Class with a graphic interface and some methods to manage information about tests.*/
public class TestPanel extends Panel {
    transient int contReports;
    transient Image icon;
    transient TextField deliveryDate;
    transient TextField idTest;
    transient TextField weight;
    
    /** Method for creation of a new instance from this class.*/
    public TestPanel() {
        idTest = new TextField(5);
        idTest.setEditable(false);
        deliveryDate = new TextField("mm/dd/yyyy");
        weight = new TextField("1");
    }
    
    /** Method for updating the dataActivities object with the graphic interface information.*/
    public DataActivities  update(DataActivities dataActivities) {
        dataActivities.test[dataActivities.indexTests].id = dataActivities.indexTests + 1;
        dataActivities.test[dataActivities.indexTests].deliveryDate = deliveryDate.getText();
        dataActivities.test[dataActivities.indexTests].weight = weight.getText();
        dataActivities.indexTests = dataActivities.indexTests + 1;
        return dataActivities;
        
    }
    
    /** Method for validating the graphic interface objects.*/
    public int validateView(DataActivities dataActivities) {
        try {
            Date delivery = new Date(deliveryDate.getText());
            int number = Integer.parseInt(weight.getText());
            if (number <= 0)
                return 4;
            Date dateClass = new Date(dataActivities.expireClass);
            if (dateClass.before(delivery))
                return 2;
            try {
                // if there is other tests
                if (dataActivities.indexTests > 0) {
                    // test if the date test is after the date of the other tests
                    Date testAnt = new Date(dataActivities.test[dataActivities.indexTests-1].deliveryDate);
                    if (delivery.before(testAnt))
                        return 3;
                }
            } catch (Exception e) {}; // create new test in the class
        } catch (Exception e) {return 1;};
        return 0;
    }
    
    /** Method for getting information from the dataActivities object and for atualizing the graphic interface objects.*/
    public void atualizeView(DataActivities dataActivities) {
        idTest.setText("  " + (dataActivities.indexTests+1) + "  of  " + dataActivities.numberTests);
        if (dataActivities.test[dataActivities.indexTests].id != 0) {
            weight.setText(dataActivities.test[dataActivities.indexTests].weight);
            deliveryDate.setText(dataActivities.test[dataActivities.indexTests].deliveryDate);
        } else {                                                                 //dont' have elements in this test
            deliveryDate.setText("mm/dd/yyyy");
        }
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        ImageLoader jImage = new ImageLoader();
        Canvas canvas = new Canvas();
        idTest.setForeground(Color.blue);
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout(0,0));
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        // Label Test
        Label label = new Label("Test");
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        constraints.weightx = 1;
        constraints.weighty = 1;
        constraints.insets = new Insets(0,10,0,0);
        constraints.fill = GridBagConstraints.HORIZONTAL;
        label.setFont(new Font("Helvetica",Font.BOLD,12));
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label deliver date
        label = new Label("DeadLine Date");
        constraints.gridx = 2;
        constraints.gridy = 3;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label weight
        label = new Label("Weight");
        Panel aux = new Panel();
        aux.setLayout(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        aux.add(label);
        aux.add(weight);
        constraints.gridx = 3;
        constraints.gridy = 4;
        constraints.gridwidth = 1;
        constraints.insets = new Insets(0,10,0,0);
        constraints.anchor = GridBagConstraints.EAST;
        gridBag.setConstraints(aux,constraints);
        form.add(aux);
        
        // label " "
        label = new Label("     ");
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        label = new Label("             ");
        constraints.gridx = 5;
        constraints.gridy = 2;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        
        // field id Test
        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.insets = new Insets(0,10,0,0);
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(idTest,constraints);
        form.add(idTest);
        
        // field delivery date
        constraints.gridx = 2;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(deliveryDate,constraints);
        form.add(deliveryDate);
        
        groupForm.add(form, BorderLayout.CENTER);
        
        icon = jImage.loadImage("tests.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(430,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas, BorderLayout.NORTH);
        
        principal.add(groupForm);
        return principal;
    }
}


