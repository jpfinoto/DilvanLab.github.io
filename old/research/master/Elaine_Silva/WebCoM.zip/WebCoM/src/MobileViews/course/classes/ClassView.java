/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import agents.*;
import agents.ErrorWindow;
import agents.security.Ticket;
import course.util.UtilFunctions;

/** Class for creation of new classes. It allows two options: to create new class or to copy information from other class.*/
public class ClassView implements View, Serializable{
    transient Choice classChoice;
    
    Ticket tic;
    Vector listClass;
    int idNewClass, classSelectedToCopy;
    
    /** Method for creation of new instace from the View class. The next assignment id will be the last + 1.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.tic = tic;
        int count = 0;
        listClass = new Vector();
        
        // Get the last id class
        sql.init(tic.resource);
        ResultSet rs = sql.executeQuery("SELECT id FROM class ORDER BY id DESC");
        if(rs.next()) {
            idNewClass = rs.getInt(1);
        }
        // Select the other class
        rs = sql.executeQuery("SELECT id FROM class");
        for (;rs.next();)
            listClass.addElement(rs.getString(1));
        
        sql.close();
        return this;
    }
    
    /** Method for creation of graphic interface for this class.*/
    public Panel initView() {
        classChoice = new Choice();
        classChoice.addItem("No Class");
        for (int count=0;count<listClass.size();count++)
            classChoice.addItem("Class " + (String) listClass.elementAt(count));
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        principal.add(new Label("Copy actvities from:"));
        principal.add(classChoice);
        return principal;
    }
    
    /** Method for validation of the new class information.*/
    public boolean validateView() {
        if (classChoice.getSelectedItem().equals("No Class"))
            classSelectedToCopy = -1;
        else {
            // get the id of the selected class
            StringTokenizer analex = new StringTokenizer(classChoice.getSelectedItem());
            String token = analex.nextToken();
            try {
                classSelectedToCopy = Integer.parseInt(analex.nextToken());
            } catch (Exception e) {}
        }
        return true;
    }
    
    /** Method for initialize the creation of the class.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        ClassViewInterface classViewInterface = new ClassViewInterface();
        classViewInterface.setVariable(idNewClass,classSelectedToCopy);
        return classViewInterface.createView(tic,sql);
    }
}
