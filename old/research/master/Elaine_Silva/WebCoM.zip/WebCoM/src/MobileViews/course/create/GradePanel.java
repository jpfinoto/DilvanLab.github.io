/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.create;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import agents.*;
import course.util.UtilFunctions;

/** Class with a graphic interface and some methods to manage information about grade scales.*/
public class GradePanel extends Panel implements ActionListener, ItemListener {
    transient Image icon;
    transient Checkbox gradeStep;
    transient Checkbox average;
    transient CheckboxGroup checkGroup;
    transient TextArea description;
    transient TextField nameGrade;
    transient TextField limitGrade;
    transient Button add, remove;
    transient java.awt.List listGrades;
    transient TextField averageGrade;
    
    /** Method for atualizing the dataCourse object with the graphic interface information.*/
    public void update(DataCourse dataCourse) {
        StringTokenizer stoken;
        String token;
        // if the evaluation is by grade scale
        if (gradeStep.getState()) {
            dataCourse.course.useGradeStep = true;
            for (int cont=0; cont < listGrades.getItemCount(); cont++) {
                stoken = new StringTokenizer(listGrades.getItem(cont), " ");
                token = stoken.nextToken();  // Name Grade
                token = stoken.nextToken();  // Value Name Grade
                dataCourse.grade[cont].nameGrade = token.toUpperCase();
                token = stoken.nextToken();  // Limit Grade
                token = stoken.nextToken();  // Value Limit Grade
                dataCourse.grade[cont].limitGrade = new Float(token).floatValue();
                dataCourse.numberGradeSteps++;
            }
        }
        // if the evaluation is by average
        if (average.getState()) {
            dataCourse.course.useGradeStep = false;
            dataCourse.course.average = new Float(averageGrade.getText()).floatValue();
        }
    }
    
    /** Method for validation of the graphic interface objects.*/
    public int validateView() {
        if (average.getState()) {
            String averageValue = averageGrade.getText();
            if (!UtilFunctions.validateField(averageValue,"0123456789."))
                return 1; //Invalid character in Average Value.
            else try {
                float teste = new Float(averageValue).floatValue();
                if (teste > 10.0) return 2; //Value should be smaller than 10.0
            } catch (Exception e) { return 4;}; // Invalid Average Value
        } else // Use Grade Step
            if (listGrades.getItemCount() == 0)
                return 3; //Missing Grades.
        return 0;
    }
    
    /** Method for validation of the grade scale name and limit.*/
    public int validateGrade() {
        if (gradeStep.getState()) {
            if (nameGrade.getText().equals(""))
                return 1; // Missign Label
            else if (!UtilFunctions.validateField(nameGrade.getText().toUpperCase(),"ABCDEFGHIJKLMNOPQRSTUVXYZW"))
                return 2; // Invalid character in Label
            else if (limitGrade.getText().equals(""))
                return 1; // Missing limit
            else if (!UtilFunctions.validateField(limitGrade.getText(),"0123456789."))
                return 2; // Invalid character in Limit
            else try {
                float teste = new Float(limitGrade.getText()).floatValue();
                if (teste > 10.0)
                    return 3; // Value should be smaller than 10.0
            } catch (Exception e) {return 4;};
        }
        return 0;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        ImageLoader jImage = new ImageLoader();
        String desc = new String("Using the Grade Step option, the teacher can grade students in steps, like: A, B, C, etc.\n" +
                                 "Using the Average option, the teacher can grade students by average and set a minimum grade for approval.\n");
        description = new TextArea(desc, 3,40);
        nameGrade = new TextField(5);
        limitGrade = new TextField(5);
        averageGrade = new TextField(5);
        listGrades = new java.awt.List(3,false);
        add = new Button   (" Add  ");
        add.addActionListener(this);
        remove = new Button("Remove");
        remove.addActionListener(this);
        
        checkGroup = new CheckboxGroup();
        gradeStep = new Checkbox("Use Grade Step", checkGroup,false);
        average = new Checkbox("Use Average", checkGroup,true);
        gradeStep.addItemListener(this);
        average.addItemListener(this);
        
        nameGrade.setEditable(false);
        limitGrade.setEditable(false);
        add.setEnabled(false);
        remove.setEnabled(false);
        listGrades.setEnabled(false);
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        // checkbox use grade steps
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        gridBag.setConstraints(gradeStep,constraints);
        form.add(gradeStep);
        
        // checkbox use average
        constraints.gridx = 0;
        constraints.gridy = 2;
        gridBag.setConstraints(average,constraints);
        form.add(average);
        
        //TextArea description
        constraints.gridx = 2;
        constraints.gridy = 0;
        constraints.gridwidth = 4;
        constraints.gridheight = 3;
        gridBag.setConstraints(description,constraints);
        form.add(description);
        
        //label GRADE STEP
        Label label = new Label("Grade Step Info:");
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 3;
        constraints.gridheight = 1;
        label.setFont(new Font("Helvetica",Font.BOLD,12));
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label nameGrade
        label = new Label("Label");
        constraints.gridx = 1;
        constraints.gridy = 5;
        constraints.gridwidth = 1;
        constraints.anchor = GridBagConstraints.WEST;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label limitGrade
        label = new Label("Limit");
        constraints.gridx = 1;
        constraints.gridy = 6;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //Textfield Name Grade
        constraints.gridx = 2;
        constraints.gridy = 5;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(nameGrade,constraints);
        form.add(nameGrade);
        
        //Textfield Limit Grade
        constraints.gridx = 2;
        constraints.gridy = 6;
        gridBag.setConstraints(limitGrade,constraints);
        form.add(limitGrade);
        
        //Button add
        constraints.gridx = 3;
        constraints.gridy = 5;
        constraints.insets = new Insets(0,10,0,10);
        gridBag.setConstraints(add,constraints);
        form.add(add);
        
        //Button remove
        constraints.gridx = 3;
        constraints.gridy = 6;
        constraints.insets = new Insets(5,10,0,10);
        gridBag.setConstraints(remove,constraints);
        form.add(remove);
        
        //label listGrades
        label = new Label("Grade Steps");
        constraints.gridx = 4;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //List of Grades
        constraints.gridx = 4;
        constraints.gridy = 5;
        constraints.gridheight = 2;
        gridBag.setConstraints(listGrades,constraints);
        form.add(listGrades);
        
        //label white
        label = new Label("    ");
        constraints.gridx = 0;
        constraints.gridy = 7;
        constraints.gridheight = 1;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label AverageGrade
        label = new Label("Average Info:");
        constraints.gridx = 0;
        constraints.gridy = 8;
        constraints.gridwidth = 3;
        label.setFont(new Font("Helvetica",Font.BOLD,12));
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label white
        label = new Label("   ");
        constraints.gridx = 0;
        constraints.gridy = 9;
        constraints.gridwidth = 1;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //Label Value
        label = new Label("Aproval Grade:");
        constraints.gridx = 1;
        constraints.gridy = 10;
        constraints.anchor = GridBagConstraints.WEST;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //Textfield Average Grade
        constraints.gridx = 2;
        constraints.gridy = 10;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(averageGrade,constraints);
        form.add(averageGrade);
        
        groupForm.add(form,BorderLayout.CENTER);
        Canvas canvas = new Canvas();
        
        icon = jImage.loadImage("grade.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        
        canvas.setSize(430,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas, BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
    
    /** Method for controlling the users action in the checkbox (to use grade scale or average).*/
    public void itemStateChanged(ItemEvent evt) {
        Object source = evt.getSource();
        if (source == gradeStep) {
            if (gradeStep.getState()) {
                nameGrade.setEditable(true);
                limitGrade.setEditable(true);
                add.setEnabled(true);
                remove.setEnabled(true);
                listGrades.setEnabled(true);
                averageGrade.setEditable(false);
            }
        }
        if (source == average) {
            if (average.getState()) {
                averageGrade.setEditable(true);
                nameGrade.setEditable(false);
                limitGrade.setEditable(false);
                add.setEnabled(false);
                remove.setEnabled(false);
                listGrades.setEnabled(false);
            }
        }
    }
    
    /** Method for controlling the users action in the button "add" and "remove" for the grade scale.*/
    public void actionPerformed(ActionEvent evt) {
        Object source = evt.getSource();
        int validate;
        if (source == add) {
            validate = validateGrade();
            if (validate == 0) {
                listGrades.add("Grade " + nameGrade.getText() + " Limit " + limitGrade.getText());
                nameGrade.setText("");
                limitGrade.setText("");
            } else {
                ErrorWindow er = null;
                if (validate == 1)
                    er = new ErrorWindow("Missign Label or Limit.");
                if (validate == 2)
                    er = new ErrorWindow("Invalid character in Label or Limit.");
                if (validate == 3)
                    er = new ErrorWindow("Value should be smaller than 10.0.");
                if (validate == 4)
                    er = new ErrorWindow("Error.");
                er.show();
            }
        }
        if (source == remove) {
            int index = listGrades.getSelectedIndex();
            listGrades.delItem(index);
        }
    }
}
