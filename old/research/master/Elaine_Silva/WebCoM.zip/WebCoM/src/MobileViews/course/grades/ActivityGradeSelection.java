/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.grades;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import agents.security.Ticket;

/** Class for selection of an activity (for setting the grades).*/
public class ActivityGradeSelection implements View, Serializable, ItemListener{
    Ticket tic;
    Vector activitiesVector;
    String typeActivitySelected;
    int setGradeBy = -1;                         // set the grade by students or groups for assignments
    int idActivitySelected, classSelected;
    
    CardLayout card;
    
    public final static String ASSIGNMENT_ACCESS= "Assignment";
    public final static String REPORT_ACCESS= "Report";
    public final static String TEST_ACCESS= "Test";
    
    transient Choice activities;
    transient Choice options;
    transient TextField classField;
    transient Panel cardActivities;
    
    /** Method for setting variables.*/
    public void setVariable(String classSelected) {
        StringTokenizer analex = new StringTokenizer(classSelected);
        String token = analex.nextToken();
        try {
            this.classSelected = Integer.parseInt(analex.nextToken());
        } catch (Exception e) {}
    }
    
    /** Method for creation of a new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        int countList = 0;
        
        // test the type of users
        ResultSet rs;
        if ((!tic.type.equals("administrator")) && (!tic.type.equals("monitor")))
            throw new RuntimeException("You don't have permissions to execute this function.");
        
        sql.init(tic.resource);
        
        // select all of the assignments
        activitiesVector = new Vector();
        rs = sql.executeQuery("SELECT id FROM assignments WHERE class='" + classSelected + "' ORDER BY id");
        for (;rs.next();)
            activitiesVector.addElement(ASSIGNMENT_ACCESS + " " + rs.getString(1));
        
        // select all of the reports
        rs = sql.executeQuery("SELECT id FROM reports WHERE class='" + classSelected + "' ORDER BY id");
        for (;rs.next();)
            activitiesVector.addElement(REPORT_ACCESS + " " + rs.getInt(1));
        
        // select all of the tests
        rs = sql.executeQuery("SELECT id FROM tests WHERE class='" + classSelected + "' ORDER BY id");
        for (;rs.next();)
            activitiesVector.addElement(TEST_ACCESS + " " + rs.getInt(1));
        
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,0));
        
        // list of activities
        activities = new Choice();
        for (int count=0; count < activitiesVector.size();count++)
            activities.addItem((String) activitiesVector.elementAt(count));
        activities.addItemListener(this);
        
        classField = new TextField("Class " + classSelected);
        classField.setEditable(false);
        classField.setFont(new Font("SansSerif", Font.BOLD, 14));
        classField.setForeground(Color.blue);
        
        // label class selected
        Panel aux = new Panel();
        aux.setLayout(new FlowLayout());
        aux.add(new Label("Class Selected:"));
        aux.add(classField);
        
        // label select one activity
        Panel listActivities = new Panel();
        listActivities.setLayout(new FlowLayout());
        listActivities.add(new Label("Select one Activity:"));
        listActivities.add(activities);
        
        // label set grade by
        Panel optionsGroupStudent = new Panel();
        optionsGroupStudent.setLayout(new FlowLayout());
        optionsGroupStudent.add(new Label("Set grade by:"));
        options = new Choice();
        options.addItem("Groups");
        options.addItem("Students");
        optionsGroupStudent.add(options);
        
        // card panel
        card = new CardLayout();
        cardActivities = new Panel();
        cardActivities.setLayout(card);
        
        cardActivities.add(optionsGroupStudent, "selection");
        cardActivities.add(new Panel(),"nothing");
        
        card.first(cardActivities);
        
        principal.add(aux,BorderLayout.NORTH);
        principal.add(listActivities,BorderLayout.CENTER);
        principal.add(cardActivities,BorderLayout.SOUTH);
        
        return principal;
    }
    
    /** Method for showing menus when the activities list is changed.*/
    public void itemStateChanged(ItemEvent e) {
        Object source = e.getSource();
        String activitySelected;
        
        // Test the activity selected
        if (source == activities){
            StringTokenizer analex = new StringTokenizer(activities.getSelectedItem()," ");
            // Get the activity and id selected
            activitySelected = analex.nextToken();
            
            if (activitySelected.equals(ASSIGNMENT_ACCESS))
                card.show(cardActivities, "selection");
            else
                card.show(cardActivities,"nothing");
        }
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        StringTokenizer analex = new StringTokenizer(activities.getSelectedItem()," ");
        // Get the activity and id selected
        typeActivitySelected = analex.nextToken();
        try {
            idActivitySelected = Integer.parseInt(analex.nextToken());  // id of the activity
        } catch (Exception e) {}
        if (typeActivitySelected.equals(ASSIGNMENT_ACCESS))            // if type of the activity is assignment
            setGradeBy = options.getSelectedIndex();	                // set grade by this
        return true;
    }
    
    /** Method that invokes the class for management of the grades of the selected activity.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        if (typeActivitySelected.equals(ASSIGNMENT_ACCESS)) {  // assignments
            if (setGradeBy == 0) { // grade by groups
                GradeGroupView gradeGroupView = new GradeGroupView();
                gradeGroupView.setVariable(typeActivitySelected, idActivitySelected,classSelected);
                return gradeGroupView.createView(tic,sql);
            } else { // grade by students
                GradeGroupStudentView gradeGroupStudentView = new GradeGroupStudentView();
                gradeGroupStudentView.setVariable(typeActivitySelected, idActivitySelected,classSelected);
                return gradeGroupStudentView.createView(tic,sql);
            }
        } else { // tests or reports
            GradeStudentView gradeStudentView = new GradeStudentView();
            gradeStudentView.setVariable(typeActivitySelected, idActivitySelected, classSelected);
            return gradeStudentView.createView(tic,sql);
        }
    }
}
