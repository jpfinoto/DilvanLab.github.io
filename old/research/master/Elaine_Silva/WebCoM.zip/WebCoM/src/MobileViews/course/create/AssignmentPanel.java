/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.create;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import agents.*;

/** Class with a graphic interface and some methods to manage assignments information.*/
public class AssignmentPanel extends Panel implements ActionListener,ItemListener {
    transient Image icon;
    transient int numberAssignment;
    transient int contAssignment;
    transient int contProjects;
    transient TextField idAssignment;
    transient TextField maxGroups, minStudents, maxStudents;
    transient TextField nameProject;
    transient TextField deliveryDate, reviewDate;
    transient TextField weight;
    transient Checkbox reviewOk;
    transient java.awt.List listProjects;
    transient Button add, remove;
    transient Label alert;
    
    /** Method for creation of new instance from this class.*/
    public AssignmentPanel() {
        idAssignment = new TextField(5);
        idAssignment.setEditable(false);
        reviewOk = new Checkbox("Use Review", false);
        maxGroups = new TextField("1");
        minStudents = new TextField("1");
        maxStudents = new TextField("1");
        nameProject = new TextField("");
        weight = new TextField("1");
        deliveryDate = new TextField("mm/dd/yyyy");
        reviewDate = new TextField("mm/dd/yyyy");
        reviewDate.setEditable(false);
        
    }
    
    /** Method for atualizing the dataActivities object.*/
    public DataActivities update(DataActivities dataActivities) {
        dataActivities.assig[dataActivities.indexAssignments].idAssignment = dataActivities.indexAssignments+1;
        dataActivities.assig[dataActivities.indexAssignments].deliveryDate = deliveryDate.getText();
        dataActivities.assig[dataActivities.indexAssignments].weight = weight.getText();
        // if there is review
        if(reviewOk.getState()) {
            try {
                // test the review date
                Date test = new Date(reviewDate.getText());
                dataActivities.assig[dataActivities.indexAssignments].reviewDate = reviewDate.getText();
            } catch (Exception e) {}
        } else
            dataActivities.assig[dataActivities.indexAssignments].reviewDate = "";
        int cont;
        // get the projects
        for (cont = 0; cont < listProjects.getItemCount(); cont++) {
            dataActivities.assig[dataActivities.indexAssignments].projects[cont] = listProjects.getItem(cont);
        }
        dataActivities.assig[dataActivities.indexAssignments].numberProjects = cont;
        // remove all of projects from the list
        listProjects.removeAll();
        // set the assignment index
        dataActivities.indexAssignments = dataActivities.indexAssignments + 1;
        return dataActivities;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public int validateView(DataActivities dataActivities) {
        try {
            // test the assignment weight
            int number = Integer.parseInt(weight.getText());
            if (number <= 0)
                return 6;
            // test the assignment date
            Date delivery = new Date();
            delivery = new Date(deliveryDate.getText());
            // if there is review
            if (reviewOk.getState()) {
                // test the review date
                Date review = new Date(reviewDate.getText());
                if (delivery.after(review))
                    return 1;
            }
            // test the class date
            Date dateClass = new Date(dataActivities.expireClass);
            if (delivery.after(dateClass)) return 4;
            // if there is other assignments
            if (dataActivities.indexAssignments > 0) {
                try {
                    // verify if the assignment date is after the other assignments
                    Date assignmentAnt = new Date(dataActivities.assig[dataActivities.indexAssignments-1].deliveryDate);
                    if (delivery.before(assignmentAnt))
                        return 5;
                } catch (Exception e) {}; // create new assignment in the class;
            }
            if (listProjects.getItemCount() <= 0)
                return 2;
        } catch (Exception e) {return 3;}                         // deliver date or review date invalid
        return 0;
    }
    
    /** Method for validating the projects.*/
    public boolean validateProject() {
        // test project name
        if (nameProject.getText().equals(""))
            return false;
        // test if there is white spaces in the project name
        if ((nameProject.getText().indexOf(' ') != -1) && (nameProject.getText().indexOf(' ') != nameProject.getText().length()-1))
            return false;
        try {
            if (Integer.parseInt(maxGroups.getText()) > 0)
                if (Integer.parseInt(minStudents.getText()) > 0)
                    if ((Integer.parseInt(maxStudents.getText()) > 0) &&
                    (Integer.parseInt(maxStudents.getText()) >= Integer.parseInt(minStudents.getText())))
                        return true;
                    else
                        return false;
                else
                    return false;
            else
                return false;
        } catch (Exception e) {return false;}
    }
    
    /** Method for getting information from the dataActivities object and for atualizing the graphic interface objects.*/
    public void atualizeView(DataActivities dataActivities) {
        boolean okProject = true;
        
        numberAssignment = dataActivities.numberAssignments;
        this.contAssignment = dataActivities.indexAssignments + 1;
        idAssignment.setText("   " + contAssignment + "  of  " + numberAssignment);
        
        // if there are a assignment to present
        if (dataActivities.assig[dataActivities.indexAssignments].idAssignment != 0) {
            weight.setText(dataActivities.assig[dataActivities.indexAssignments].weight);
            deliveryDate.setText(dataActivities.assig[dataActivities.indexAssignments].deliveryDate);
            
            // there is not reviews
            if (dataActivities.assig[dataActivities.indexAssignments].reviewDate.equals("")) {
                reviewDate.setText("mm/dd/yyyy");
                reviewOk.setState(false);
                reviewDate.setEditable(false);
            } else {
                // there is reviews
                reviewDate.setText(dataActivities.assig[dataActivities.indexAssignments].reviewDate);
                reviewOk.setState(true);
                reviewDate.setEditable(true);
            }
            // remove all projects from the projects list
            listProjects.removeAll();
            
            // add projects in the projects list
            for (int cont = 0; cont < dataActivities.assig[dataActivities.indexAssignments].numberProjects; cont++) {
                listProjects.add(dataActivities.assig[dataActivities.indexAssignments].projects[cont]);
            }
        } else {
            // there is not assignments
            deliveryDate.setText("mm/dd/yyyy");
            reviewDate.setText("mm/dd/yyyy");
            reviewOk.setState(false);
            reviewDate.setEditable(false);
        }
        maxGroups.setText("1");
        minStudents.setText("1");
        maxStudents.setText("1");
        nameProject.setText("");
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        ImageLoader jImage = new ImageLoader();
        Canvas canvas = new Canvas();
        idAssignment.setForeground(Color.blue);
        idAssignment.setFont(new Font("Helvetica",Font.PLAIN,11));
        add = new Button("  Add   ");
        remove = new Button("Remove");
        listProjects = new java.awt.List(4,false);
        
        reviewOk.addItemListener(this);
        add.addActionListener(this);
        remove.addActionListener(this);
        
        setFont(new Font("Helvetica",Font.PLAIN,11));
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout(0,20));
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        // Label Assignment
        Label label = new Label("Assignment");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        constraints.weightx = 1;
        constraints.weighty = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        label.setFont(new Font("Helvetica",Font.BOLD,12));
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label deliver date
        label = new Label("Deadline Date");
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.insets = new Insets(0,10,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label review date
        label = new Label("Review Date  ");
        constraints.gridx = 4;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // field id Assignment
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        constraints.insets = new Insets(0,0,0,0);
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(idAssignment,constraints);
        form.add(idAssignment);
        
        // checkbox use review
        constraints.gridx = 3;
        constraints.gridy = 0;
        constraints.insets = new Insets(0,10,0,0);
        gridBag.setConstraints(reviewOk,constraints);
        form.add(reviewOk);
        
        // field deliver date
        constraints.gridx = 1;
        constraints.gridy = 1;
        gridBag.setConstraints(deliveryDate,constraints);
        form.add(deliveryDate);
        
        // field review date
        constraints.gridx = 4;
        constraints.gridy = 1;
        gridBag.setConstraints(reviewDate,constraints);
        form.add(reviewDate);
        
        Panel aux = new Panel();
        aux.setLayout(new FlowLayout(FlowLayout.RIGHT,0,0));
        
        // label Weight (1-9)
        label = new Label("Weight");
        aux.add(label);
        aux.add(weight);
        constraints.gridx = 3;
        constraints.gridy = 1;
        gridBag.setConstraints(aux,constraints);
        form.add(aux);
        
        groupForm.add(form,BorderLayout.CENTER);
        
        form = new Panel();
        gridBag = new GridBagLayout();
        constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        // label Projects
        label = new Label("Assignments Projects:");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 4;
        constraints.insets = new Insets(0,0,0,0);
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.CENTER;
        label.setFont(new Font("Helvetica",Font.BOLD,12));
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label Name Project
        label = new Label("Project Name");
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label List of Projects
        label = new Label("Projects List");
        constraints.gridx = 3;
        constraints.gridy = 1;
        constraints.insets = new Insets(0,10,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label Number Max of Groups
        label = new Label("Max. Number of Groups");
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label Min Students for Group
        label = new Label("Min. Students per Group");
        constraints.gridx = 0;
        constraints.gridy = 4;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label Max Students for Group
        label = new Label("Max. Students per Group");
        constraints.gridx = 0;
        constraints.gridy = 5;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // field Name Project
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 3;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(nameProject,constraints);
        form.add(nameProject);
        
        // field max groups
        constraints.gridx = 2;
        constraints.gridy = 3;
        constraints.gridwidth = 1;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(maxGroups,constraints);
        form.add(maxGroups);
        
        // field min students
        constraints.gridx = 2;
        constraints.gridy = 4;
        gridBag.setConstraints(minStudents,constraints);
        form.add(minStudents);
        
        // field max students
        constraints.gridx = 2;
        constraints.gridy = 5;
        gridBag.setConstraints(maxStudents,constraints);
        form.add(maxStudents);
        
        // Button add
        constraints.gridx = 2;
        constraints.gridy = 6;
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.EAST;
        constraints.insets = new Insets(5,0,0,0);
        gridBag.setConstraints(add,constraints);
        form.add(add);
        
        // Button remove
        constraints.gridx = 5;
        constraints.gridy = 6;
        gridBag.setConstraints(remove,constraints);
        form.add(remove);
        
        // Label visible only when the assignment is being edited
        alert = new Label("USE 'EDIT PROJECT' TO EDIT ASSIGNMENTS PROJECTS");
        constraints.gridx = 0;
        constraints.gridy = 7;
        constraints.gridwidth = 5;
        constraints.insets = new Insets(0,0,0,0);
        alert.setFont(new Font("Helvetica",Font.BOLD,10));
        alert.setForeground(Color.red);
        alert.setVisible(false);
        gridBag.setConstraints(alert,constraints);
        form.add(alert);
        
        // list of projects
        constraints.gridx = 3;
        constraints.gridy = 2;
        constraints.gridwidth = 3;
        constraints.gridheight = 4;
        constraints.ipady = 20;
        constraints.ipadx = 10;
        constraints.insets = new Insets(0,10,0,0);
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(listProjects,constraints);
        form.add(listProjects);
        
        groupForm.add(form,BorderLayout.SOUTH);
        
        icon = jImage.loadImage("assignments.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(430,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        return principal;
    }
    
    /** Method to define if the "add" and "remove" buttons are active or not.This is used to edit assignments.*/
    public void setEditionMode() {
        add.setEnabled(false);
        remove.setEnabled(false);
        maxGroups.setEnabled(false);
        minStudents.setEnabled(false);
        maxStudents.setEnabled(false);
        nameProject.setEnabled(false);
        alert.setVisible(true);
    }
    
    /** Method for controlling the users action over the graphic interface objects.*/
    public void actionPerformed(ActionEvent event){
        Object source = event.getSource();
        // add projects in the projects list
        if (source == add) {
            if (validateProject()) {
                String option = "Project " + nameProject.getText() + " MaxGroup " + maxGroups.getText()
                + " MinStudents " + minStudents.getText() + " MaxStudents " + maxStudents.getText();
                listProjects.add(option);
                contProjects++;
                nameProject.setText("");
                maxGroups.setText("1");
                minStudents.setText("1");
                maxStudents.setText("1");
            } else {
                ErrorWindow er = new ErrorWindow("Error in your project information!");
                er.show();
            }
        }
        // remove projects from the projects list.
        if (source == remove) {
            int index = listProjects.getSelectedIndex();
            listProjects.delItem(index);
        }
    }
    
    /** Method for controlling the users action in the checkbox (to set use of the review).*/
    public void itemStateChanged(ItemEvent evt) {
        Object source = evt.getSource();
        if (source == reviewOk) {
            if (reviewOk.getState() == false)
                reviewDate.setEditable(false);
            else
                reviewDate.setEditable(true);
        }
    }
}


