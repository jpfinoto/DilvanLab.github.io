/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.groups;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import agents.security.Ticket;
import agents.util.CourseEmail;
import course.util.UtilFunctions;
import agents.agent.Defaults;

/** Class for selection of one assignment and one operation for students groups .*/
public class GroupSelectionView implements View, Serializable{
    Ticket tic;
    Vector assignments;
    int classGroup = 0;
    int operationSelected;
    int assignmentSelected;
    
    transient Choice operations;
    transient Choice assignmentsList;
    
    /** Method for creation of new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        int count = 0;
        ResultSet rs,rs1;
        java.util.Date realDate = new java.util.Date();
        assignments = new Vector();
        boolean classExpired = false;
        
        // Validate the user and his class
        sql.init(tic.resource);
        rs = sql.executeQuery("SELECT DISTINCT students.class, class.expire from students,class " +
        "where students.username='" + tic.username + "' and students.class=class.id");
        // Verify the class of the student
        for (;rs.next();) {
            if (UtilFunctions.verifyDate(realDate,rs.getDate(2)) < 0)
                classExpired = true;
            else {
                classGroup = rs.getInt(1);
                classExpired = false;
                for (;rs.next(););
            }
        }
        if (classExpired) throw new RuntimeException("Your class is expired.");
        if ((classGroup == 0) && (!classExpired)) throw new RuntimeException("You are not registred in any class");
        
        // get all of the active assignments
        rs = sql.executeQuery("SELECT id,date FROM assignments WHERE class='" + classGroup + "'");
        for (;rs.next();) {
            if (UtilFunctions.verifyDate(realDate, rs.getDate(2)) >= 0) {
                assignments.addElement(rs.getString(1));
                count++;
            } 
        }
        if (count == 0) throw new RuntimeException("There is not assignments to be made.");
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        operations = new Choice();
        operations.addItem("Create New Group");
        operations.addItem("Edit Your Group");
        operations.addItem("Delete Your Group");
        
        assignmentsList = new Choice();
        for (int count=0; count < assignments.size(); count++) {
            assignmentsList.addItem("Assignment " + assignments.elementAt(count));
            if (count == 0)
                assignmentsList.select(count);
        }
        
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,0));
        
        Panel listGroups = new Panel();
        listGroups.setLayout(new BorderLayout(0,0));
        
        Panel aux1 = new Panel();
        aux1.setLayout(new FlowLayout());
        aux1.add(new Label("Select an assignment:"));
        aux1.add(assignmentsList);
        
        Panel aux2 = new Panel();
        aux2.setLayout(new FlowLayout());
        aux2.add(new Label("Select an operation:"));
        aux2.add(operations);
        
        principal.add(aux1,BorderLayout.NORTH);
        principal.add(aux2,BorderLayout.CENTER);
        principal.add(listGroups,BorderLayout.SOUTH);
        
        return principal;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        StringTokenizer analex= new StringTokenizer(assignmentsList.getSelectedItem()," ");
        String token = analex.nextToken();
        try {
            assignmentSelected = Integer.parseInt(analex.nextToken()); // get the selected assignment id
        } catch (Exception e) {}
        operationSelected = operations.getSelectedIndex();           // get the selected operation
        return true;
    }
    
    /** Method that invokes the class for executing the action over the student group.
     * This method also manages the database information in case of removing groups.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        View newView = new GroupSelectionView();
        // create new group
        if (operationSelected == 0) {
            CreationGroupView cgv = new CreationGroupView();
            cgv.assignmentSelected = assignmentSelected;
            cgv.classGroup = classGroup;
            return cgv.createView(tic,sql);
        }
        // edit a group
        if (operationSelected == 1) {
            EditGroupView egv = new EditGroupView();
            egv.assignmentSelected = assignmentSelected;
            egv.classGroup = classGroup;
            return egv.createView(tic,sql);
        }
        // delete a group
        if (operationSelected == 2) {
            String nameCourse;
            sql.init(tic.resource);
            // get the user's group
            ResultSet rs = sql.executeQuery("SELECT group_name FROM activities WHERE username='" + tic.username +
            "' AND id='" + assignmentSelected + "' AND type='groups' AND class=" + classGroup);
            if (!rs.next()) throw new RuntimeException("You are not a member of any group in this class.");
            
            String group = rs.getString(1);
            Vector membersGroup = new Vector();
            // get all of the members for this group
            rs = sql.executeQuery("SELECT username FROM activities WHERE group_name='" + group + "' AND id='" +
            assignmentSelected + "' AND type='groups'");
            for(;rs.next();)
                membersGroup.addElement(rs.getString(1));
            
            // delete all of the members for this group
            sql.executeUpdate("DELETE FROM activities WHERE group_name='" + group + "' AND id='" +
            assignmentSelected + "' AND type='groups' AND class='" + classGroup + "'");
            
            // delete the user's group
            sql.executeUpdate("DELETE FROM groups WHERE name='" + group + "' AND assignment='" + assignmentSelected + "'");
            
            sql.close();
            sql.init(Defaults.WEBCOMDATABASE);
            // get basic directory of this course
            rs = sql.executeQuery("SELECT directory FROM basic_info WHERE database_name='" + tic.resource + "'");
            rs.next();
            
            // delete directories for the user's group
            UtilFunctions.deleteDirectoriesGroup(rs.getString(1), assignmentSelected, group, classGroup);
            
            String emails = null;
            // send email for all of the members of the deleted group
            int numberElements = membersGroup.size();
            for(int count=0;count < numberElements;count++) {
                rs = sql.executeQuery("SELECT email FROM users WHERE username='" + membersGroup.elementAt(count) + "'");
                rs.next();
                if (!rs.getString(1).equals(""))
                    if(count == 0)
                        emails = rs.getString(1);
                    else
                        emails = emails + "," + rs.getString(1);
            }
            sql.close();
            
            try {
                CourseEmail email = new CourseEmail(emails);
                email.envia(Defaults.FROM, Defaults.HOST, "Course Manager",
                "Message from Course Administrator: \n" + "Your group was removed by " + tic.username + ".\n" +
                "If you want, you can to enter in another group.\n");
            }catch (Exception e) {};
            
        }
        return "Success";
    }
}
