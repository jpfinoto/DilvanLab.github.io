/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.lang.reflect.*;

/** Applet for management of the course */
public class ContactStudent extends Applet implements ActionListener{
    
    static public final String WEBMODULE_DIR= "/manager_files";
    
    JavaInterface infoI, groupsI, changePasswordI, ftpI;
    JavaInterface newClassI, usersI, gradesI, reviewsI;
    LoginJSP loginJSPI;
    
    Frame frameTeacher;
    
    String host, resource, paramCandidate, paramHelp;

    String main_host, main_resource;
    boolean useCandidate = false, useHelp = false;
    
    private Button candidateB;
    private Button infoB;
    private Button groups;
    private Button changePasswordB;
    private Button rememberPasswordB;
    private Button helpB;
    /*private Button viewGroupsB;
    private Button viewStudentsB;*/
    private Button ftpformB;
    private Button ftpB;
    private Button teacherPageB;
    
    private Button newClass;
    private Button acceptCandidatesB;
    private Button usersB;
    private Button gradesB;
    private Button reviewsB;
    
    private Color corback;
    
    /**
     * Initialize the graphic part of the Client.
     */
    public void init() {
        
        try {
            host = getCodeBase().getHost();
            resource= getParameter("resource");
            paramCandidate = getParameter("candidate");
            paramHelp = getParameter("help");
        } catch (Exception e) {}
       
        if ((paramCandidate != null) && (paramCandidate.toUpperCase().equals("YES")))
            useCandidate = true;
        else
            useCandidate = false;
        
        if ((paramHelp != null) && (paramHelp.toUpperCase().equals("YES")))
            useHelp = true;
        else
            useHelp = false;
        
        corback= Color.lightGray;
        setBackground(new Color(255, 204, 102));
        
        //  Statis buttons
        if (useCandidate) {
            candidateB = new Button("Join Candidate");
            candidateB.setBackground(corback);
            candidateB.addActionListener(this);
        }
        
        infoB = new Button("Info about you");
        infoB.setBackground(corback);
        infoB.addActionListener(this);
        
        groups = new Button("Manage Groups");
        groups.setBackground(corback);
        groups.addActionListener(this);
        
        changePasswordB = new Button("Change Password");
        changePasswordB.setBackground(corback);
        changePasswordB.addActionListener(this);
        
        rememberPasswordB = new Button("Forgot Password?");
        rememberPasswordB.setBackground(corback);
        rememberPasswordB.addActionListener(this);
        
        /*viewGroupsB = new Button("Groups");
        viewGroupsB.setBackground(corback);
        viewGroupsB.addActionListener(this);
         
        viewStudentsB = new Button("Students");
        viewStudentsB.setBackground(corback);
        viewStudentsB.addActionListener(this);*/
        
        ftpformB = new Button("Upload Files");
        ftpformB.setBackground(corback);
        ftpformB.addActionListener(this);
        
        ftpB = new Button("      FTP Tool      ");
        ftpB.setBackground(corback);
        ftpB.addActionListener(this);
        
        if (useHelp) {
            helpB = new Button("Help");
            helpB.setBackground(corback);
            helpB.addActionListener(this);
        }
        
        teacherPageB = new Button("Teachers tools");
        teacherPageB.setBackground(corback);
        teacherPageB.addActionListener(this);
        
        setFont(new Font("Helvetica", Font.BOLD, 12));
        
        Panel p = new Panel();
        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        p.setLayout(grid);
        
        c.gridwidth = GridBagConstraints.REMAINDER; //end row
        c.fill = GridBagConstraints.HORIZONTAL;
        /*c.insets = new Insets(7, 5, 3, 5);
         
        Label lab = new Label("Student's Info:");
        grid.setConstraints(lab, c);
        p.add(lab);
         
        c.insets = new Insets(3, 5, 3, 5);
         
        grid.setConstraints(viewGroupsB, c);
        p.add(viewGroupsB);
         
        grid.setConstraints(viewStudentsB, c);
        p.add(viewStudentsB);*/
        
        c.insets = new Insets(7, 5, 3, 5);
        Label lab = new Label("Course Controls:");
        grid.setConstraints(lab, c);
        p.add(lab);
        
        c.insets = new Insets(3, 5, 3, 5);
        if (useCandidate) {
            grid.setConstraints(candidateB, c);
            p.add(candidateB);
        }
        grid.setConstraints(infoB, c);
        p.add(infoB);
        
        grid.setConstraints(groups, c);
        p.add(groups);
        
        grid.setConstraints(changePasswordB, c);
        p.add(changePasswordB);
        
        grid.setConstraints(rememberPasswordB, c);
        p.add(rememberPasswordB);
        
        grid.setConstraints(ftpformB, c);
        p.add(ftpformB);
        
        grid.setConstraints(ftpB, c);
        p.add(ftpB);
        
        if (useHelp) {
            grid.setConstraints(helpB, c);
            p.add(helpB);
        }
        
        c.insets = new Insets(7, 5, 3, 5);
        lab = new Label("        ");
        grid.setConstraints(lab, c);
        p.add(lab);
        
        c.insets = new Insets(3, 5, 3, 5);
        grid.setConstraints(teacherPageB, c);
        p.add(teacherPageB);
        
        add(p);
        validate();
    }
    
    /** Method for creation of a window with options for the teacher.*/
    public Panel init2() {
        newClass = new Button("Manage Class");
        newClass.setBackground(corback);
        newClass.addActionListener(this);
        
        if (useCandidate) {
            acceptCandidatesB = new Button("Accept Candidates");
            acceptCandidatesB.setBackground(corback);
            acceptCandidatesB.addActionListener(this);
        }
        
        usersB = new Button("Manage Users");
        usersB.setBackground(corback);
        usersB.addActionListener(this);
        
        gradesB = new Button("Manage Grades");
        gradesB.setBackground(corback);
        gradesB.addActionListener(this);
        
        reviewsB = new Button("Manage Reviewers");
        reviewsB.setBackground(corback);
        reviewsB.addActionListener(this);
        
        Panel p = new Panel();
        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        p.setLayout(grid);
        
        c.gridwidth = GridBagConstraints.REMAINDER; //end row
        c.insets = new Insets(7,5,3,5);
        c.fill = GridBagConstraints.HORIZONTAL;
        
        Label lab = new Label("Teachers Tools:");
        grid.setConstraints(lab,c);
        p.add(lab);
        
        c.insets = new Insets(5,5,3,5);
        
        grid.setConstraints(newClass, c);
        p.add(newClass);
        if (useCandidate) {
            grid.setConstraints(acceptCandidatesB, c);
            p.add(acceptCandidatesB);
        }
        grid.setConstraints(usersB, c);
        p.add(usersB);
        grid.setConstraints(gradesB, c);
        p.add(gradesB);
        
        grid.setConstraints(reviewsB, c);
        p.add(reviewsB);
        
        p.setFont(new Font("Helvetica", Font.BOLD, 12));
        p.setBackground(new Color(255, 204, 102));
        return p;
    }
    
    /**
     * Listenner of Events.
     */
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == candidateB) {
            try {
                URL url= new URL("http://" + getCodeBase().getHost() + WEBMODULE_DIR + "/add_candidate.jsp?database=" + resource);
                getAppletContext().showDocument(url, "candidate");
            } catch (Exception e4) {
                ErrorWindow ew= new ErrorWindow("Page not available.");
                ew.show();
            }
            return;
        }
        
        if (source == infoB) {
            if (infoI!=null) infoI.setVisible(false);
            infoI= new ViewInterface(host, resource, "UsersAgent", "course.InfoView");
            infoI.setBackground(corback);
            infoI.init();
            return;
        }
        if (source == groups) {
            if (groupsI!=null) groupsI.setVisible(false);
            groupsI= new ViewInterface(host,resource, "UsersAgent", "course.groups.GroupSelectionView");
            groupsI.setBackground(corback);
            groupsI.init();
            return;
        }
        if (source == changePasswordB) {
            if (changePasswordI!=null) changePasswordI.setVisible(false);
            changePasswordI= new ViewInterface(host, resource, "UsersAgent", "agents.ChangePasswordView");
            changePasswordI.setBackground(corback);
            changePasswordI.init();
            return;
        }
        if (source == rememberPasswordB) {
            try {
                URL url= new URL("http://" + getCodeBase().getHost() + WEBMODULE_DIR + "/remember_password.html");
                getAppletContext().showDocument(url, "_blank");
            } catch (Exception e4) {
                ErrorWindow ew= new ErrorWindow("Page not available.");
                ew.show();
            }
            return;
        }
            /* if (source == viewGroupsB) {
                try {
                    URL url= new URL("http://" + getCodeBase().getHost() + "/manager_files/frameJSP.jsp?database=" + resource +
                                                                                          "&typeOperation=groups");
             
                    getAppletContext().showDocument(url, "groups");
                } catch (Exception e4) {
                    ErrorWindow ew= new ErrorWindow("Page not available.");
                    ew.show();
                }
                return;
            }
            if (source == viewStudentsB) {
                try {
                    URL url= new URL("http://" + getCodeBase().getHost() + "/manager_files/frameJSP.jsp?database=" +
                                          resource + "&type=student&typeOperation=students");
                    getAppletContext().showDocument(url, "students");
                } catch (Exception e4) {
                    ErrorWindow ew= new ErrorWindow("Page not available.");
                    ew.show();
                }
                return;
            }
             */
        if (source == ftpformB) {
            try {
                if (loginJSPI!=null) loginJSPI.setVisible(false);
                loginJSPI = new LoginJSP(host, resource, "http://" + getCodeBase().getHost() + WEBMODULE_DIR+"/ftpForm.jsp?database=" +
                resource,getAppletContext());
                loginJSPI.show();
            } catch (Exception e4) {
                ErrorWindow ew= new ErrorWindow("Page not available.");
                ew.show();
            }
            return;
        }
        
        if (source == ftpB) {
            if (ftpI==null) {
                try{
                    ftpI= new ftpApplet.Client(" File Transfer ",host,true,resource);
                    ftpI.setBackground(corback);
                } catch (Throwable ef) {
                    ftpI = null;
                    ErrorWindow ew= new ErrorWindow("FTP not enabled: Contact Monitor.");
                    ew.show();
                    return;
                }
            }
            ftpI.show();
            ((ftpApplet.Client)ftpI).logDialog.show();
            return;
        }
        
        if (source == helpB) {
            try {
                URL url= new URL(getCodeBase(),"questions.html");
                getAppletContext().showDocument(url);
            } catch (Exception e3) {
                ErrorWindow ew= new ErrorWindow("Can't find help file.");
                ew.show();
            }
            return;
        }
        if (source == teacherPageB) {
            frameTeacher = new Frame();
            frameTeacher.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    frameTeacher.dispose();
                }
            });
            frameTeacher.add(init2());
            frameTeacher.pack();
            frameTeacher.show();
            return;
        }
        if (source == newClass) {
            if (newClassI!=null) newClassI.setVisible(false);
            newClassI= new ViewInterface(host,resource, "UsersAgent", "course.classes.ClassSelection");
            newClassI.setBackground(corback);
            newClassI.init();
            return;
        }
        if (source == acceptCandidatesB) {
            if (loginJSPI != null) loginJSPI.setVisible(false);
            try {
                loginJSPI = new LoginJSP(host, resource, "http://" + getCodeBase().getHost() + WEBMODULE_DIR+"/candidate.jsp?database=" +
                resource,getAppletContext());
                loginJSPI.show();
            } catch (Exception e3) {
                ErrorWindow ew= new ErrorWindow("Can't find help file.");
                ew.show();
            }
            return;
        }
        if (source == usersB) {
            if (usersI!=null) usersI.setVisible(false);
            usersI= new ViewInterface(host,resource, "UsersAgent", "course.users.UserSelectionView");
            usersI.setBackground(corback);
            usersI.init();
            return;
        }
        if (source == gradesB) {
            if (gradesI!=null) gradesI.setVisible(false);
            gradesI= new ViewInterface(host,resource, "UsersAgent", "course.grades.ClassGradeSelection");
            gradesI.setBackground(corback);
            gradesI.init();
            return;
        }
        if (source == reviewsB) {
            if (reviewsI!=null) reviewsI.setVisible(false);
            reviewsI= new ViewInterface(host,resource, "UsersAgent", "course.reviews.ClassReviewSelection");
            reviewsI.setBackground(corback);
            reviewsI.init();
            return;
        }
    }

    /** Method principal from the class.*/
    public static void main(String[] args) {
        ContactStudent contact= new ContactStudent();
        contact.host="dilvan";
        contact.resource= "javaCourse";
        contact.paramCandidate= "yes";
        contact.paramHelp= "yes";
        
        Frame frame= new Frame("WebCom: " + contact.resource);
        frame.add(contact, BorderLayout.CENTER);

        //	Window destructor
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        contact.init();
        contact.start();
        frame.pack();
        frame.setVisible(true);
    }
}
