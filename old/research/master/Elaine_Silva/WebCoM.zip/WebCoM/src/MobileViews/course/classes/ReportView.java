/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.classes;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import course.create.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class for creation of new report. */
public class ReportView implements View, Serializable{
    transient ReportPanel reportsPanel;
    transient Panel p1;
    
    String resource;
    DataActivities dataActivities;
    int idClass;
    int idReport = 0;
    Ticket tic;
    
    /** Method for setting variables.*/
    public void setVariable(int idClass){
        this.idClass = idClass;
    }
    
    /** Method for creation of new instance from the View class. The next report id will be the last + 1.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.resource = tic.resource;
        this.tic = tic;
        dataActivities = new DataActivities();
        sql.init(this.resource);
        ResultSet rs = sql.executeQuery("SELECT expire FROM class WHERE id='" + idClass + "'");
        rs.next();
        dataActivities.expireClass = UtilFunctions.deconvertDate(rs.getString(1));
        rs = sql.executeQuery("SELECT id FROM reports WHERE class='" + idClass + "' ORDER BY id DESC");
        if (rs.next()) {
            int id = rs.getInt(1);
            idReport = id;
        } else
            idReport = 0;
        dataActivities.numberReports = idReport;
        dataActivities.indexReports = idReport;
        dataActivities.idClass = idClass;
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        principal.setFont(new Font("Helvetica", Font.PLAIN, 12));
        
        reportsPanel = new ReportPanel();
        p1 = reportsPanel.initView();
        reportsPanel.atualizeView(dataActivities);
        principal.add(p1);
        return principal;
    }
    
    /** Method to validate the information of the graphic interface */
    public boolean validateView() {
        ErrorWindow er = null;
        int errorView = reportsPanel.validateView(dataActivities);
        if (errorView != 0) {
            if (errorView == 1)
                er = new ErrorWindow("Invalid Information.");
            if (errorView == 2)
                er = new ErrorWindow("The report date is after the class's expire date.");
            if (errorView == 3)
                er = new ErrorWindow("The report delivery date should be orderer.");
            if (errorView == 4)
                er = new ErrorWindow("The weight should be bigger than 0.");
            er.show();
            return false;
        }
        dataActivities = reportsPanel.update(dataActivities);
        dataActivities.indexReports--; // it have to do the same position because there is only one report to insert
        return true;
    }
    
    /** Method for management of the database information about the report.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        String instruction = null;
        
        // get the directory of this course
        sql.init(Defaults.WEBCOMDATABASE);
        ResultSet rs = sql.executeQuery("SELECT directory FROM basic_info WHERE database_name='" + resource + "'");
        rs.next();
        String directory = rs.getString(1);
        sql.close();
        sql.init(resource);
        // create the directories to the students
        try {
            UtilFunctions.createDirectoryReport(directory, dataActivities.report[dataActivities.indexReports].id, idClass);
        } catch (Exception e) {return "Error generating directory /homework. Directory was not created.";};
        
        // insert the data about the reports in the database
        rs = sql.executeQuery("SELECT username FROM students WHERE class='" + idClass + "'");
        for (;rs.next();) {
            UtilFunctions.createDirectoriesStudent(directory,dataActivities.report[dataActivities.indexReports].id,rs.getString(1), idClass);
            sql.executeUpdate("INSERT INTO activities VALUES('" + rs.getString(1) + "','reports'," +
            dataActivities.report[dataActivities.indexReports].id + ",'',0,'" + idClass + "')");
        }
        
        instruction = new String("INSERT INTO reports VALUES (" +
        dataActivities.report[dataActivities.indexReports].id + ",'" +
        UtilFunctions.convertDate(dataActivities.report[dataActivities.indexReports].deliveryDate) + "','" +
        dataActivities.report[dataActivities.indexReports].weight + "','" +
        dataActivities.idClass + "')");
        sql.executeUpdate(instruction);
        sql.close();
        EditClassSelection editClassSelection = new EditClassSelection();
        editClassSelection.setVariable("Class "+ idClass);
        return editClassSelection.createView(tic,sql);
    }
}
