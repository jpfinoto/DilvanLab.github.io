/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course;

import java.awt.*;
import java.io.*;
import java.util.*;
import java.sql.*;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class for management of general information about one user.*/
public class InfoView extends Panel implements View {
    String resource;
    String username;
    String lastName;
    String firstName;
    String middleNames;
    String email, emailOld;
    String homepage;
    
    transient TextField pUsername;
    transient TextField pLastName;
    transient TextField pFirstName;
    transient TextField pMiddleNames;
    transient TextField pEmail;
    transient TextField pHomepage;
    
    /** Method for creation of new instances from this class.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.resource = tic.resource;
        this.username = tic.username.toLowerCase();
        ResultSet rs;
        
        if (!tic.type.equals("administrator")) {
            sql.init(resource);
            // get information about the user
            rs = sql.executeQuery("SELECT id FROM students WHERE username='" + username + "'");
            if (!rs.next()) {
                if (tic.type.equals("monitor")) {
                    rs = sql.executeQuery("SELECT username FROM monitors WHERE username='" + username + "'");
                    if (!rs.next()) throw new RuntimeException("You are not monitor of this course.");
                } else
                    throw new RuntimeException("You are not registred in any class.");
            }
            sql.close();
        }
        
        sql.init(Defaults.WEBCOMDATABASE);
        rs = sql.executeQuery("SELECT last_name,first_name,middle_names,email,homepage FROM users WHERE username='"
        + username + "'");
        rs.next();
        lastName = rs.getString(1);
        firstName = rs.getString(2);
        middleNames = rs.getString(3);
        emailOld = rs.getString(4);
        homepage = rs.getString(5);
        sql.close();
        return this;
    }
    
    /** Method for creation of graphic interface for this class.*/
    public Panel initView() {
        Image icon;
        ImageLoader jImage = new ImageLoader();
        Canvas canvas = new Canvas();
        pUsername = new TextField(username,5);
        pLastName = new TextField(lastName,5);
        pFirstName = new TextField(firstName,5);
        pMiddleNames = new TextField(middleNames,5);
        pEmail = new TextField(emailOld,5);
        pHomepage = new TextField(homepage,5);
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        Panel form = new Panel();
        form.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();;
        
        Label label = new Label("Username");
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 1.0;
        constraints.weighty = 1.0;
        form.add(label, constraints);
        
        label = new Label("First Name");
        constraints.gridx = 0;
        constraints.gridy = 3;
        form.add(label, constraints);
        
        label = new Label("LastName");
        constraints.gridx = 2;
        constraints.gridy = 3;
        form.add(label, constraints);
        
        label = new Label("Middle Names");
        constraints.gridx = 0;
        constraints.gridy = 5;
        form.add(label, constraints);
        
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        pUsername.setEditable(false);
        form.add(pUsername, constraints);
        
        constraints.gridx = 0;
        constraints.gridy = 4;
        form.add(pFirstName, constraints);
        
        constraints.gridx = 2;
        constraints.gridy = 4;
        form.add(pLastName, constraints);
        
        constraints.gridx = 0;
        constraints.gridy = 6;
        constraints.gridwidth = 4;
        form.add(pMiddleNames, constraints);
        
        groupForm.add(form,BorderLayout.CENTER);
        
        form = new Panel();
        form.setLayout(new GridBagLayout());
        constraints = new GridBagConstraints();
        
        icon = jImage.loadImage("email01.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(25,30);
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 2;
        constraints.weightx = 0.3;
        constraints.weighty = 1;
        constraints.insets = new Insets(15,10,0,0);
        constraints.fill = GridBagConstraints.BOTH;
        form.add(canvas,constraints);
        
        icon = jImage.loadImage("www1.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(25,30);
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.insets = new Insets(15,10,10,0);
        form.add(canvas,constraints);
        
        // label e-mail
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        constraints.weightx = 9;
        constraints.insets = new Insets(0,10,0,0);
        constraints.fill = GridBagConstraints.HORIZONTAL;
        label = new Label("e-mail");
        form.add(label,constraints);
        
        // label homepage
        constraints.gridx = 1;
        constraints.gridy = 2;
        label = new Label("homepage");
        form.add(label,constraints);
        
        // field e-mail
        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        constraints.insets = new Insets(0,10,0,10);
        form.add(pEmail,constraints);
        
        // field homepage
        constraints.gridx = 1;
        constraints.gridy = 3;
        constraints.gridwidth = 1;
        constraints.insets = new Insets(0,10,0,10);
        form.add(pHomepage,constraints);
        
        groupForm.add(form,BorderLayout.SOUTH);
        
        icon = jImage.loadImage("info2.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(430,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        ErrorWindow er;
        
        if ((!pFirstName.getText().equals("")) || (!pLastName.getText().equals(""))) {
            if ((pFirstName.getText().indexOf("'") != -1) || (pLastName.getText().indexOf("'") != -1)) {
                er = new ErrorWindow("Invalid character in First Name or Last Name");
                er.show();
                return false;
            } else if ((pFirstName.getText().length() > 32) || (pLastName.getText().length() > 32)) {
                er = new ErrorWindow("First Name and Last Name should be smaller than 32 characters");
                er.show();
                return false;
            } else if ((pFirstName.getText().indexOf(' ') != -1) || (pLastName.getText().indexOf(' ') != -1)){
                if ((pFirstName.getText().indexOf(' ') != pFirstName.getText().length()) ||
                (pLastName.getText().indexOf(' ') != pFirstName.getText().length())){
                    er = new ErrorWindow("Spaces are not allowed in First an Last Name.");
                    er.show();
                    return false;
                }
            }
        }
        if (!pMiddleNames.getText().equals("")) {
            if (pMiddleNames.getText().indexOf("'") != -1) {
                er= new ErrorWindow("Invalid character in Middle Names");
                er.show();
                return false;
            }
        }
        
        if (pEmail.getText().indexOf('@')==-1) {
            er= new ErrorWindow("Wrong email format: name@site.");
            er.show();
            return false;
        }
        
        if (!pHomepage.getText().startsWith("http://")) {
            er= new ErrorWindow("Wrong homepage format: http://site.");
            er.show();
            return false;
        }
        
        lastName= pLastName.getText();
        firstName= pFirstName.getText();
        middleNames = pMiddleNames.getText();
        email= pEmail.getText();
        homepage= pHomepage.getText();
        
        return true;
    }
    
    /** Method for management of the database information.*/
    public Object updateView(SQL sql) throws Exception {
        sql.init(Defaults.WEBCOMDATABASE);
        sql.executeUpdate("UPDATE users SET last_name='" + lastName + "', " +
        "first_name='" + firstName + "', " +
        "middle_names='" + middleNames + "', " +
        "email='" + email + "', " +
        "homepage='" + homepage + "' " +
        "WHERE username='" + username + "'");
        sql.close();
        return "Success";
    }
    
}


