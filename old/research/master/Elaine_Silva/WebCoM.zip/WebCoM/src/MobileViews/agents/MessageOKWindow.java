/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents;

import java.awt.*;
import java.awt.event.*;

/** Class for presentation of a message to the user.*/
public class MessageOKWindow extends Frame implements ActionListener{
    
    /** Method for creation of a new instance from this class. The graphic interface presents a message and a ok button.*/
    public MessageOKWindow(String message) {
        ImageLoader jImage = new ImageLoader();
        Canvas canvas = new Canvas();
        Image icon;
        
        // Image
        icon = jImage.loadImage("warning.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(40,40);
        
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.lightGray);
        setTitle("Operation Success");
        
        Panel principal = new Panel();
        principal.setLayout(new GridLayout(0,1));
        
        Panel messagePanel = new Panel();
        messagePanel.setLayout(new FlowLayout());
        
        Label m= new Label("  " + message + "  ");
        m.setFont(new Font("Helvetica", Font.BOLD, 12));
        
        messagePanel.add(canvas);
        messagePanel.add(m);
        
        principal.add(messagePanel);
        add("Center", principal);
        
        Button buttonOk = new Button("    OK    ");
        buttonOk.addActionListener(this);
        buttonOk.setBackground(Color.lightGray);
        
        principal = new Panel();
        principal.add(buttonOk);
        add("South", principal);
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                setVisible(false);
            }
        });
        
        pack();
    }
    
    /** Method for controlling the events when the ok button is pressed.*/
    public void actionPerformed(ActionEvent e) {
        setVisible(false);
    }
}



