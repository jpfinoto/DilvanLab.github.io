/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.users;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.io.File;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import agents.util.CourseEmail;
import course.util.UtilFunctions;

/** Class for removing or edittion of students user.*/
public class EditRemoveStudentView extends Panel implements View {
    Ticket tic;
    String username;
    
    public String operationSelected = null;
    public int classSelected = -1;
    
    Vector listUsers;
    transient java.awt.List user;
    
    /** Method for setting variable. It sets the selected class and the operation (edit or remove). */
    public void setVariable(String classSelected, String operation) {
        this.operationSelected = operation;                              // selected operation
        int classSelectedStudents = -1;
        
        StringTokenizer analex = new StringTokenizer(classSelected);
        String token = analex.nextToken();
        try {
            classSelectedStudents = Integer.parseInt(analex.nextToken());  // selected class id
        } catch (Exception e) {}
        this.classSelected = classSelectedStudents;
    }
    
    /** Method for creation of a new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.tic = tic;
        ResultSet rs;
        listUsers = new Vector();
        // test the user type (user of the login)
        if ((!tic.type.equals("administrator")) &&
        (!tic.type.equals("monitor"))) throw new RuntimeException("You don't have permissions to access this tool.");
        
        // Select all students from class selected
        sql.init(tic.resource);
        rs = sql.executeQuery("SELECT username FROM students WHERE class='" + classSelected + "' ORDER BY username");
        sql.close();
        
        // get first_name and last_name from users for each student selected
        ResultSet rs1;
        sql.init(Defaults.WEBCOMDATABASE);
        for (;rs.next();) {
            if (!rs.getString(1).equals("")) {
                rs1 = sql.executeQuery("SELECT first_name, last_name FROM users WHERE username='" + rs.getString(1) + "'");
                rs1.next();
                listUsers.addElement(rs.getString(1) + "  ->  " + rs1.getString(1) + " " + rs1.getString(2));
            }
        }
        
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Image icon;
        Canvas canvas = new Canvas();
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        // present the students selected
        user = new java.awt.List(10,false);
        for (int count = 0; count < listUsers.size(); count++)
            user.add((String) listUsers.elementAt(count));
        user.setBackground(Color.white);
        
        groupForm.add(new Label("Select one Student:"), BorderLayout.CENTER);
        groupForm.add(user, BorderLayout.SOUTH);
        
        ImageLoader jImage = new ImageLoader();
        icon = jImage.loadImage("student.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(380,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        // get the student selected
        String aux = user.getSelectedItem();
        username = aux.substring(0,aux.indexOf(' '));
        return true;
    }
    
    /** Method that invokes the class for execution of the operation selected.
      * If the operation selected is edit, thant other class is invoked,
      * else, it removes the selected student managing the database information.*/
    public Object updateView(SQL sql) throws Exception {
        
        if (operationSelected.equals("edit")) {
            EditStudentView editStudentView = new EditStudentView();
            editStudentView.setVariable(classSelected, username);
            return editStudentView.createView(tic, sql);
        }
        
        if (operationSelected.equals("remove")) {
            ResultSet rs, rs1,rs2;
            int countNumberMembers;
            String courseDirectory;
            String function;
            Vector group = new Vector();
            Vector report = new Vector();
            Vector studentsFromGroup = new Vector();
            int minUsersGroup;
            String instruction;
            boolean studentOtherCourse = false;
            String emailStudent;
            String courseName;
            
            // Get informations about the course
            sql.init(Defaults.WEBCOMDATABASE);
            rs = sql.executeQuery("SELECT course_name,directory FROM basic_info WHERE database_name='" + tic.resource + "'");
            rs.next();
            courseDirectory = rs.getString(2);
            courseName = rs.getString(1);
            sql.close();
            
            // Check informations about students activities
            sql.init(tic.resource);
            // verify if the student is in other class
            rs = sql.executeQuery("SELECT COUNT(*) FROM students WHERE username='" + username + "'");
            rs.next();
            if (rs.getInt(1) > 1)
                studentOtherCourse = true;
                        
            // Select all of activities of this user
            rs = sql.executeQuery("SELECT type,group_name,id FROM activities WHERE username='" + username + "' AND class=" + classSelected);
            // get each activity of the student
            for(;rs.next();) {
                if (rs.getString(1).equals("groups")) {
                    group.addElement(rs.getString(2));
                    group.addElement(String.valueOf(rs.getInt(3)));
                }
                if (rs.getString(1).equals("reports")) {
                    report.addElement(String.valueOf(rs.getInt(3)));
                }
            }
            for (int counter=0; counter < group.size(); counter+=2) {
                // count the number of members of this group
                rs= sql.executeQuery("SELECT username FROM activities WHERE type='groups' AND group_name='" +
                    group.elementAt(counter) + "' AND username!='" + username + "' AND id='" +
                    group.elementAt(counter+1) + "' AND class=" + classSelected);
                for(countNumberMembers = 1; rs.next(); countNumberMembers++) {
                    if (studentsFromGroup.indexOf(rs.getString(1)) == -1)
                        studentsFromGroup.addElement(rs.getString(1));
                }
                
                // Select the project of this group
                rs1 = sql.executeQuery("SELECT project FROM groups WHERE name='" + group.elementAt(counter) + "'");
                rs1.next();
                
                // Select the min users for this group
                rs2 = sql.executeQuery("SELECT min_users FROM projects WHERE name='" + rs1.getString(1) + "'");
                rs2.next();
                minUsersGroup = rs2.getInt(1);
                
                if (countNumberMembers <= minUsersGroup) {
                    sql.executeUpdate("DELETE FROM activities WHERE group_name='" + group.elementAt(counter) + "' AND id='" +
                                        group.elementAt(counter+1) + "'");
                    sql.executeUpdate("DELETE FROM groups WHERE name='" + group.elementAt(counter) + "' AND assignment='" +
                                        group.elementAt(counter+1) + "'");
                    UtilFunctions.deleteDirectoriesGroup(courseDirectory,
                        Integer.parseInt((String) group.elementAt(counter+1)),
                        (String) group.elementAt(counter),
                        classSelected
                    );
                }
            }
            // delete directories
            for (int count=0; count < report.size(); count++) {
                UtilFunctions.deleteDirectoriesStudent(courseDirectory, Integer.parseInt((String) report.elementAt(count)),username, classSelected);
            }
            
            sql.executeUpdate("DELETE FROM activities WHERE username='" + username + "' AND class=" + classSelected);
            sql.executeUpdate("DELETE FROM students WHERE username='" + username + "' AND class=" + classSelected);
            sql.close();
            
            sql.init(Defaults.WEBCOMDATABASE);
            // if the group have to be removed, then send email for all members
            if (studentsFromGroup.size() > 0) {
                instruction = "SELECT email FROM users WHERE username='";
                for(int count=0;count<studentsFromGroup.size();count++) {
                    if (count == studentsFromGroup.size()-1)
                        instruction = instruction + studentsFromGroup.elementAt(count) + "'";
                    else
                        instruction = instruction + studentsFromGroup.elementAt(count) + "' AND username='";
                }
                rs = sql.executeQuery(instruction);
                for(;rs.next();) {
                    try {
                        CourseEmail courseEmail = new CourseEmail(rs.getString(1));
                        courseEmail.envia(Defaults.FROM, Defaults.HOST, "Course Manager",
                        "Message from Course Administrator: \n" +
                        "Your work group in the course " + courseName + " was removed.\n" +
                        "If you have diferent groups for each assignment, verify if all your groups was removed.\n" + "After, try to enter in another group or create a new group.");
                    }catch (Exception e) {};
                }
            }
            
            rs = sql.executeQuery("SELECT email FROM users WHERE username='" + username + "'");
            rs.next();
            emailStudent = rs.getString(1);
            
            // Verify in others courses if the student is registred
            rs = sql.executeQuery("SELECT database_name FROM basic_info WHERE database_name!='" + tic.resource + "'");
            sql.close();
            
            // Verify in each database
            if (rs.next()) {
                do {
                    sql.init(rs.getString(1));
                    rs1 = sql.executeQuery("SELECT username FROM students WHERE username='" + username + "'");
                    if (rs1.next()) {
                        studentOtherCourse = true;
                        for(;rs.next(););
                    }
                    rs1 = sql.executeQuery("SELECT username FROM monitors WHERE username='" + username + "'");
                    if (rs1.next()) {
                        studentOtherCourse = true;
                        for(;rs.next(););
                    }
                    sql.close();
                } while (rs.next());
            }
            if (!studentOtherCourse) {
                sql.init(Defaults.WEBCOMDATABASE);
                sql.executeUpdate("DELETE FROM users WHERE username='" + username + "'");
                sql.close();
            }
        }
        UserSelectionView userSelectionView = new UserSelectionView();
        return userSelectionView.createView(tic,sql);
    }
}
