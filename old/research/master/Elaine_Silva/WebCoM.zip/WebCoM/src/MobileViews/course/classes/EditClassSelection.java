/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import agents.security.Ticket;
import agents.agent.Defaults;

/** Class for edition of students classes. Activities can be changed, added, removed; the class's date can be changed; 
 * the assignment's project can be managed.*/
public class EditClassSelection implements View, Serializable, ItemListener {
    Ticket tic;
    String activitySelected = null;
    String typeActivitySelected = null;
    String assignmentSelected = null;
    int idClass;
    int operationSelected;
    Vector reportsTests, assignments;
    
    public static String ASSIGNMENT_ACCESS = "Assignment";
    public static String REPORT_ACCESS = "Report";
    public static String TEST_ACCESS = "Test";
    
    transient Choice operations;
    transient Choice activitySelection;
    transient Choice assignmentSelection;
    transient Choice newActivitySelection;
    transient Panel cardActivities;
    CardLayout card;
    
    /** Method for setting variables. */
    public void setVariable(String classSelected) {
        StringTokenizer analex = new StringTokenizer(classSelected);
        String token = analex.nextToken();
        try {
            idClass = Integer.parseInt(analex.nextToken());
        } catch (Exception e) {}
    }
    
    /** Method for creation of new instance from the View class. All activities from the selected class are recovered.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        sql.init(tic.resource);
        
        reportsTests = new Vector();
        assignments = new Vector();
        // get all activities from the selected class
        ResultSet rs = sql.executeQuery("SELECT id FROM assignments WHERE class='" + idClass + "' ORDER BY id");
        for(;rs.next();)
            assignments.addElement(ASSIGNMENT_ACCESS + " " + rs.getString(1));
        
        rs = sql.executeQuery("SELECT id FROM reports WHERE class='" + idClass + "' ORDER BY id");
        for(;rs.next();)
            reportsTests.addElement(REPORT_ACCESS + " " + rs.getString(1));
        
        rs = sql.executeQuery("SELECT id FROM tests WHERE class='" + idClass + "' ORDER BY id");
        for(;rs.next();)
            reportsTests.addElement(TEST_ACCESS + " " + rs.getString(1));
        
        sql.close();
        
        return this;
    }
    
    /** Method for creation of a graphic interface. In this interface, the user can decide what type of operation he intend to do.
     * The operations are : change the class's expire date, add activity, edit activity or remove activity. If the selected
     * operation was with some activity (add, edit or remove it), the user can choose one activity to use it.
     */
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,0));
        
        Panel actionsPanel = new Panel();
        actionsPanel.setLayout(new FlowLayout());
        operations = new Choice();
        operations.addItem("Change the class's expire date");
        operations.addItem("Add Activity");
        operations.addItem("Edit Activity");
        operations.addItem("Remove Activity");
        operations.addItem("Manage Assignment's Projects");
        actionsPanel.add(operations);
        operations.addItemListener(this);
        
        Panel listActions = new Panel();
        listActions.setLayout(new FlowLayout());
        listActions.add(new Label("Select an operation: "));
        listActions.add(actionsPanel);
        
        // Panel to edit or remove activities
        Panel activitiesPanel = new Panel();
        activitiesPanel.setLayout(new FlowLayout());
        activitiesPanel.add(new Label("Select an Activity:"));
        
        activitySelection = new Choice();
        for (int count = 0; count < assignments.size(); count++)
            activitySelection.addItem((String) assignments.elementAt(count));
        for (int count = 0; count < reportsTests.size(); count++)
            activitySelection.addItem((String) reportsTests.elementAt(count));
        activitiesPanel.add(activitySelection);
        
        // Panel to add new activities
        Panel newActivitiesPanel = new Panel();
        newActivitiesPanel.setLayout(new FlowLayout());
        newActivitiesPanel.add(new Label("Select a type of Activity:"));
        
        newActivitySelection = new Choice();
        newActivitySelection.addItem(ASSIGNMENT_ACCESS);
        newActivitySelection.addItem(REPORT_ACCESS);
        newActivitySelection.addItem(TEST_ACCESS);
        
        newActivitiesPanel.add(newActivitySelection);
        
        // Panel to manage assignment's projects
        Panel assignmentsPanel = new Panel();
        assignmentsPanel.setLayout(new FlowLayout());
        assignmentsPanel.add(new Label("Edit projects from:"));
        
        assignmentSelection = new Choice();
        for (int count = 0; count < assignments.size(); count++)
            assignmentSelection.addItem((String) assignments.elementAt(count));
        assignmentsPanel.add(assignmentSelection);
        
        card = new CardLayout();
        cardActivities = new Panel();
        cardActivities.setLayout(card);
        
        cardActivities.add(new Panel(),"nothing");
        cardActivities.add(activitiesPanel, "classActivities");
        cardActivities.add(newActivitiesPanel, "typeActivities");
        cardActivities.add(assignmentsPanel, "assignmentProjects");
        card.first(cardActivities);
        
        principal.add(listActions,BorderLayout.NORTH);
        principal.add(cardActivities, BorderLayout.CENTER);
        
        return principal;
    }
    
    /** Method for showing menus when the operations list is changed.*/
    public void itemStateChanged(ItemEvent e) {
        Object source = e.getSource();
        int actionSelected = operations.getSelectedIndex();
        
        // Test the operation selected
        if (source == operations){
            if (actionSelected == 1) // Add Activities
                card.show(cardActivities, "typeActivities");
            else if (((actionSelected == 2) || (actionSelected == 3)) && (activitySelection.getSelectedItem() != null)) // Edit or Remove Activities
                card.show(cardActivities,"classActivities");
            else if (actionSelected == 4) // Manage Projects
                card.show(cardActivities, "assignmentProjects");
            else
                card.show(cardActivities,"nothing"); // Change assignment's project
        }
    }
    
    /** Method for validation of the graphic interface information.*/
    public boolean validateView() {
        operationSelected = operations.getSelectedIndex();
        if (operationSelected == 1)
            typeActivitySelected = newActivitySelection.getSelectedItem();
        if ((operationSelected == 2) || (operationSelected == 3))
            activitySelected = activitySelection.getSelectedItem();
        if (operationSelected == 4)
            assignmentSelected = assignmentSelection.getSelectedItem();
        
        if ((operationSelected == 2 || operationSelected==3) && (activitySelected == null)) {
            ErrorWindow er = new ErrorWindow("Don't have any activity.");
            er.show();
            return false;
        }
        if ((operationSelected == 4) && (assignmentSelected == null)) {
            ErrorWindow er = new ErrorWindow("Don't have any assignment.");
            er.show();
            return false;
        }
        
        return true;
    }
    
    /** Method for invoke the class that executes the selected operation . */
    public synchronized Object updateView(SQL sql) throws Exception {
        if (operationSelected == 0) { // Change class's information
            EditClassView editClassView = new EditClassView();
            editClassView.setVariable(idClass); // edit
            return editClassView.createView(tic,sql);
            
        } else if (operationSelected == 1) { // Add Activity
            if (typeActivitySelected.equals(ASSIGNMENT_ACCESS)) { // Add Assignment
                AssignmentView assignmentView = new AssignmentView();
                assignmentView.setVariable(idClass);
                return assignmentView.createView(tic, sql);
            }
            if (typeActivitySelected.equals(REPORT_ACCESS)) { // Add Report
                ReportView reportView = new ReportView();
                reportView.setVariable(idClass);
                return reportView.createView(tic, sql);
            }
            if (typeActivitySelected.equals(TEST_ACCESS)) { // Add Test
                TestView testView = new TestView();
                testView.setVariable(idClass);
                return testView.createView(tic, sql);
            }
            
        } else if (operationSelected==2) { // Edit Activity
            StringTokenizer analex = new StringTokenizer(activitySelected);
            String nameActivitySelected = analex.nextToken(); // Assignment, Report or Test
            int idActivitySelected = 0;
            try {
                idActivitySelected = Integer.parseInt(analex.nextToken()); // id of the activity
            } catch (Exception e) {}
            
            if (nameActivitySelected.equals(ASSIGNMENT_ACCESS)) {
                EditRemoveAssignmentView editRemoveAssignmentView = new EditRemoveAssignmentView();
                editRemoveAssignmentView.setVariable(idActivitySelected,idClass,1); // Edit the assignment
                return editRemoveAssignmentView.createView(tic, sql);
            }
            if (nameActivitySelected.equals(REPORT_ACCESS)) {
                EditRemoveReportView editRemoveReportView = new EditRemoveReportView();
                editRemoveReportView.setVariable(idActivitySelected,idClass,1); // Edit the report
                return editRemoveReportView.createView(tic, sql);
            }
            if (nameActivitySelected.equals(TEST_ACCESS)) {
                EditRemoveTestView editRemoveTestView = new EditRemoveTestView();
                editRemoveTestView.setVariable(idActivitySelected, idClass, 1); // Edit the test
                return editRemoveTestView.createView(tic, sql);
            }
        } else if (operationSelected == 3) { // Remove Activity
            StringTokenizer analex = new StringTokenizer(activitySelected);
            String nameActivitySelected = analex.nextToken(); // Assignment, Report or Test
            int idActivitySelected = 0;
            try {
                idActivitySelected = Integer.parseInt(analex.nextToken()); // id of the activity
            } catch (Exception e) {}
            
            if (nameActivitySelected.equals(ASSIGNMENT_ACCESS)) {
                EditRemoveAssignmentView editRemoveAssignmentView = new EditRemoveAssignmentView();
                editRemoveAssignmentView.setVariable(idActivitySelected,idClass,2); // remove the assignment
                return editRemoveAssignmentView.createView(tic, sql);
            }
            if (nameActivitySelected.equals(REPORT_ACCESS)) {
                EditRemoveReportView editRemoveReportView = new EditRemoveReportView();
                editRemoveReportView.setVariable(idActivitySelected,idClass,2); // remove the report
                return editRemoveReportView.createView(tic, sql);
            }
            if (nameActivitySelected.equals(TEST_ACCESS)) {
                EditRemoveTestView editRemoveTestView = new EditRemoveTestView();
                editRemoveTestView.setVariable(idActivitySelected, idClass,2); // remove the test
                return editRemoveTestView.createView(tic, sql);
            }
            
        } else if (operationSelected == 4) { // Manage assignment's projects
            StringTokenizer analex = new StringTokenizer(assignmentSelected);
            String nameAssignmentSelected = analex.nextToken(); // Assignment
            int idAssignmentSelected = 0;
            try {
                idAssignmentSelected = Integer.parseInt(analex.nextToken()); // id of the activity
            } catch (Exception e) {}
            ProjectsSelection projectsSelection = new ProjectsSelection();
            projectsSelection.setVariable(idAssignmentSelected, idClass);
            return projectsSelection.createView(tic, sql);
        }
        return "";
    }
}
