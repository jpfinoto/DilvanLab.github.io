/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.grades;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;

/** Class for setting assignment grades for each student.*/
public class GradeGroupStudentView extends Panel implements View {
    Ticket tic;
    Vector listUsers;
    String activitySelected;
    int idActivitySelected, classSelected;
    Vector students[];
    int numberStudents;
    
    transient LineTableGradesGroupStudent[] lines;
    transient TextField classField,activityField;
    transient TextField numberStudentsField;
    
    /** Method for setting variables.*/
    public void setVariable(String activitySelected, int idActivitySelected, int classSelected) {
        this.activitySelected = activitySelected;
        this.idActivitySelected = idActivitySelected;
        this.classSelected = classSelected;
    }
    
    /** Method for creation of a new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        ResultSet rs,rs1;
        sql.init(tic.resource);
        
        // Count the number of students
        rs = sql.executeQuery("SELECT COUNT(*) FROM students WHERE class=" + classSelected);
        rs.next();
        numberStudents = rs.getInt(1);
        students = new Vector[numberStudents];
        
        // start the students vector
        for (int count = 0; count < numberStudents; count++)
            students[count] = new Vector();
        
        numberStudents = 0;
        // get the username and id of the students
        rs = sql.executeQuery("SELECT username,id FROM students WHERE class='" + classSelected + "' ORDER BY username");
        for (int position = 0; rs.next(); position++) {
            
            // get the groups grade for each student
            rs1 = sql.executeQuery("SELECT group_name, grade FROM activities WHERE type='groups' AND id='" +
            idActivitySelected + "' AND username='" + rs.getString(1) + "' AND class=" + classSelected);
            if (rs1.next()) {
                students[numberStudents].addElement(rs.getString(1)); // username
                students[numberStudents].addElement(rs.getString(2)); // id
                
                students[numberStudents].addElement(String.valueOf(rs1.getFloat(2))); // grade
                students[numberStudents].addElement(rs1.getString(1));    // group name
                numberStudents++;
            }
        }
        sql.close();
        sql.init(Defaults.WEBCOMDATABASE);
        for (int count=0; count < numberStudents; count++) {
            // get the name of the students
            rs = sql.executeQuery("SELECT first_name, last_name FROM users WHERE username='" +  students[count].elementAt(0) + "'");
            rs.next();
            students[count].addElement(rs.getString(1) + " " + rs.getString(2));
        }
        sql.close();
        
        return this;
    }
    
    /** Method for cration of a graphic interface for this class.*/
    public Panel initView() {
        ImageLoader jImage;
        Canvas canvas = new Canvas();
        Image icon;
        classField = new TextField("Class " + classSelected);
        activityField = new TextField(activitySelected + " " + idActivitySelected);
        numberStudentsField = new TextField(String.valueOf(numberStudents));
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,10));
        
        Panel top = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        top.setLayout(gridBag);
        
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        Label label = new Label("Class                   ");
        gridBag.setConstraints(label, constraints);
        top.add(label);
        
        label = new Label("Activity                 ");
        constraints.gridx = 1;
        constraints.gridy = 0;
        gridBag.setConstraints(label, constraints);
        top.add(label);
        
        label = new Label("Number of Students");
        constraints.gridx = 2;
        constraints.gridy = 0;
        gridBag.setConstraints(label, constraints);
        top.add(label);
        
        constraints.gridx = 0;
        constraints.gridy = 1;
        classField.setFont(new Font("SansSerif", Font.BOLD, 14));
        classField.setForeground(Color.blue);
        classField.setEditable(false);
        gridBag.setConstraints(classField, constraints);
        top.add(classField);
        
        constraints.gridx = 1;
        constraints.gridy = 1;
        activityField.setFont(new Font("SansSerif", Font.BOLD, 14));
        activityField.setForeground(Color.blue);
        activityField.setEditable(false);
        gridBag.setConstraints(activityField, constraints);
        top.add(activityField);
        
        constraints.gridx = 2;
        constraints.gridy = 1;
        numberStudentsField.setFont(new Font("SansSerif", Font.BOLD, 14));
        numberStudentsField.setForeground(Color.blue);
        numberStudentsField.setEditable(false);
        gridBag.setConstraints(numberStudentsField, constraints);
        top.add(numberStudentsField);
        
        // spaces to make bigger the window
        label = new Label("                                   ");
        constraints.gridx = 3;
        constraints.gridy = 1;
        gridBag.setConstraints(label, constraints);
        top.add(label);
        
        ScrollPane scrollPane = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);
        
        Panel linesPane = new Panel();
        linesPane.setLayout(new GridLayout(0,1));
        
        // vector of names and grades
        lines = new LineTableGradesGroupStudent[numberStudents+1];
        int position;
        int count = 0;
        for (position = 0; position <= numberStudents; position++) {
            if (position == 0) // labels
                lines[position] = new LineTableGradesGroupStudent();
            else { // each group
                lines[position] = new LineTableGradesGroupStudent((String) students[count].elementAt(3),(String) students[count].elementAt(1),
                (String) students[count].elementAt(0),(String) students[count].elementAt(4),
                (String) students[count].elementAt(2));
                count++;
            }
            linesPane.add(lines[position].showLine());
        }
        scrollPane.add(linesPane);
        scrollPane.setSize(350,300);
        
        jImage = new ImageLoader();
        icon = jImage.loadImage("studentgrade.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(380,45);
        canvas.setBackground(Color.lightGray);
        
        principal.add(canvas,BorderLayout.NORTH);
        principal.add(top,BorderLayout.CENTER);
        principal.add(scrollPane,BorderLayout.SOUTH);
        return principal;
        
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        ErrorWindow errorWindow;
        
        // verify and get the grades of each line
        for (int count=0, position = 1; position <= numberStudents; position++) {
            try {
                float test = new Float((String) lines[position].grade.getText()).floatValue();
            } catch (Exception e) {
                errorWindow = new ErrorWindow("Invalid Value in Grade.");
                errorWindow.show();
                return false;
            }
            students[count].setElementAt(lines[position].grade.getText(),2);
            count++;
        }
        return true;
    }
    
    /** Method for management of the database information.*/
    public Object updateView(SQL sql) throws Exception {
        sql.init(tic.resource);
        for (int count=0;count < numberStudents; count++) {
            sql.executeUpdate("Update activities SET grade=" + new Float((String) students[count].elementAt(2)).floatValue() +
            " WHERE username='" + students[count].elementAt(0) + "' AND type='groups' AND id='" +
            idActivitySelected + "' AND class=" + classSelected);
        }
        sql.close();
        ActivityGradeSelection activityGradeSelection = new ActivityGradeSelection();
        activityGradeSelection.setVariable("Class " + classSelected);
        return activityGradeSelection.createView(tic,sql);
    }
}

/** Class for showing each line of the students table.*/
class LineTableGradesGroupStudent extends Component{
    Label id, name, username, group;
    TextField grade;
    Panel line;
    
    /** Method for creation of new instance from this class. There is only one line with labels.*/
    public LineTableGradesGroupStudent(){
        line = new Panel();
        line.add(new Label("ID"));
        line.add(new Label("Name"));
        line.add(new Label("Group"));
        line.add(new Label("Username"));
        line.add(new Label("Grade"));
        line.setLayout(new GridLayout(1,0));
        line.setBackground(new Color(220,220,220));
    }
    
    /** Method for creation of new instance from this class. Each line has id, name, group name, username and grade (and review grade) */
    public LineTableGradesGroupStudent(String groupName, String idStudent, String usernameStudent, String nameStudent,
    String  gradeStudent) {
        line = new Panel();
        id = new Label(idStudent);
        name = new Label(nameStudent);
        username = new Label(usernameStudent);
        group = new Label(groupName);
        grade = new TextField(gradeStudent);
        line.setLayout(new GridLayout(1,0));
        line.add(id);
        line.add(name);
        line.add(group);
        line.add(username);
        line.add(grade);
    }
    
    /** Method for showing one line.*/
    public Panel showLine() {
        return line;
    }
    
}
