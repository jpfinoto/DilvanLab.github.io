/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.grades;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;

/** Class for setting assignment grade for each group.*/
public class GradeGroupView extends Panel implements View {
    Ticket tic;
    Vector listGroups;
    String activitySelected;
    int idActivitySelected, classSelected;
    Vector groups, grades, reviewGrades, upgradeStudentsGroup;
    boolean useReview;
    transient LineTableGroupGrades[] lines;
    transient TextField classField,activityField;
    
    /** Method for setting variables.*/
    public void setVariable(String activitySelected, int idActivitySelected, int classSelected) {
        this.activitySelected = activitySelected;
        this.idActivitySelected = idActivitySelected;
        this.classSelected = classSelected;
    }
    
    /** Method for creation of new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        ResultSet rs,rs1;
        
        groups = new Vector();
        grades = new Vector();
        reviewGrades = new Vector();
        sql.init(tic.resource);
        
        // Select all of the groups for this assignment
        
        rs = sql.executeQuery("SELECT DISTINCT group_name FROM activities WHERE type='groups' AND id='" +
        idActivitySelected + "' AND class='" + classSelected + "' ORDER BY group_name");
        for (;rs.next();) {
            groups.addElement(rs.getString(1));
            // Selecte the grade of the groups
            rs1 = sql.executeQuery("SELECT grade,review_grade FROM groups WHERE name='" + rs.getString(1) + "' AND assignment='"+ idActivitySelected + "'");
            rs1.next();
            // store the grades
            grades.addElement(String.valueOf(rs1.getDouble(1)));
            reviewGrades.addElement(String.valueOf(rs1.getDouble(2)));
        }
        // verify if this assignment have review
        rs = sql.executeQuery("SELECT use_review FROM assignments WHERE id='" + idActivitySelected + "' AND class=" + classSelected);
        rs.next();
        if (rs.getString(1).equals("true"))
            useReview = true;
        else
            useReview = false;
        if (grades.size() == 0) throw new RuntimeException("There is no group to this activity");
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        ImageLoader jImage;
        Canvas canvas = new Canvas();
        Image icon;
        classField = new TextField("Class " + classSelected);
        activityField = new TextField(activitySelected + " " + idActivitySelected);
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,10));
        Panel top = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        top.setLayout(gridBag);
        
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        Label label = new Label("Class                   ");
        
        gridBag.setConstraints(label, constraints);
        top.add(label);
        
        label = new Label("Activity");
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        
        gridBag.setConstraints(label, constraints);
        top.add(label);
        
        label = new Label("                                               ");
        constraints.gridx = 2;
        constraints.gridy = 1;
        
        gridBag.setConstraints(label, constraints);
        top.add(label);
        
        constraints.gridx = 0;
        constraints.gridy = 1;
        classField.setFont(new Font("SansSerif", Font.BOLD, 14));
        classField.setForeground(Color.blue);
        classField.setEditable(false);
        
        gridBag.setConstraints(classField, constraints);
        
        top.add(classField);
        
        constraints.gridx = 1;
        constraints.gridy = 1;
        activityField.setFont(new Font("SansSerif", Font.BOLD, 14));
        activityField.setForeground(Color.blue);
        activityField.setEditable(false);
        gridBag.setConstraints(activityField, constraints);
        
        top.add(activityField);
        
        ScrollPane scrollPane = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);
        
        Panel titles = new Panel();
        
        titles.setLayout(new GridLayout(1,0));
        titles.add(new Label("Group Name  "));
        titles.add(new Label("Grade       "));
        if (useReview)
            titles.add(new Label("Review Grade"));
        titles.add(new Label("            "));
        titles.setBackground(new Color(220,220,220));
        
        Panel linesPane = new Panel();
        linesPane.setLayout(new GridLayout(0,1));
        linesPane.add(titles);
        
        lines = new LineTableGroupGrades[groups.size()];
        
        for (int count=0; count < groups.size();count++) {
            lines[count] = new LineTableGroupGrades((String) groups.elementAt(count),
            (String) grades.elementAt(count),false,useReview,(String) reviewGrades.elementAt(count));
            linesPane.add(lines[count].showLine());
        }
        
        scrollPane.add(linesPane);
        scrollPane.setSize(300,300);
        
        Panel gradesPanel = new Panel();
        gradesPanel.setLayout(new BorderLayout());
        gradesPanel.add(scrollPane, BorderLayout.CENTER);
        gradesPanel.add(new Label("Mark the checkbox to upgrade students grades."),BorderLayout.SOUTH);
        
        jImage = new ImageLoader();
        icon = jImage.loadImage("groupgrade.gif");
        
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(380,45);
        canvas.setBackground(Color.lightGray);
        principal.add(canvas,BorderLayout.NORTH);
        principal.add(top,BorderLayout.CENTER);
        principal.add(gradesPanel,BorderLayout.SOUTH);
        return principal;
    }
    
    /** Method for validation of the graphic interface information.*/
    public boolean validateView() {
        ErrorWindow errorWindow;
        // create new instances to store the new information
        grades = new Vector();
        
        if (useReview)
            reviewGrades = new Vector();
        
        upgradeStudentsGroup = new Vector();
        
        // get the grades of each group.
        for (int count=0; count < groups.size(); count++) {
            try {
                float test = new Float((String) lines[count].grade.getText()).floatValue();
                if (useReview)
                    test = new Float((String) lines[count].gradeR.getText()).floatValue();
            } catch (Exception e) {
                errorWindow = new ErrorWindow("Invalid Value in Grade.");
                errorWindow.show();
                return false;
            };
            grades.addElement(lines[count].grade.getText());
            if (useReview)
                reviewGrades.addElement(lines[count].gradeR.getText());
            if (lines[count].upgrade.getState())
                upgradeStudentsGroup.addElement(groups.elementAt(count));
        }
        return true;
    }
    
    /** Method for management of database information.*/
    public Object updateView(SQL sql) throws Exception {
        ResultSet rs;
        sql.init(tic.resource);
        
        // Upgrade the grades of the groups
        
        for (int count=0;count < groups.size(); count++) {
            sql.executeUpdate("UPDATE groups SET grade=" + new Float((String) grades.elementAt(count)).floatValue() +
            ", review_grade=" + new Float((String) reviewGrades.elementAt(count)).floatValue() +
            " WHERE name='" + groups.elementAt(count) + "' AND assignment=" + idActivitySelected);
        }
        for (int count=0; count < upgradeStudentsGroup.size();count++) {
            // upgrade the grade of each student of the group
            rs = sql.executeQuery("SELECT grade, review_grade FROM groups WHERE name='" + upgradeStudentsGroup.elementAt(count) +
            "' AND assignment=" + idActivitySelected );
            rs.next();
            sql.executeUpdate("Update activities SET grade=" + (rs.getFloat(1) + rs.getFloat(2)) +
            " WHERE group_name='" + upgradeStudentsGroup.elementAt(count) + "' AND type='groups' AND id=" +
            idActivitySelected + " AND class=" + classSelected);
        }
        sql.close();
        ActivityGradeSelection activityGradeSelection = new ActivityGradeSelection();
        activityGradeSelection.setVariable("Class " + classSelected);
        return activityGradeSelection.createView(tic,sql);
    }
}

/** Class for showing each line of the groups table.*/
class LineTableGroupGrades extends Component{
    Label group;
    TextField grade;
    TextField gradeR;
    Checkbox upgrade;
    Panel line;
    
    /** Method for creation of new instance of this class. Each line has group name, group grade (and review grade) a checkbox
     * to set if upgrade the students grade. When this checkbox is selected the student receive the assignment grade + review grade.*/
    public LineTableGroupGrades(String groupName, String  gradeGroup, boolean upgradeStudent, boolean review, String gradeReview) {
        line = new Panel();
        group = new Label(groupName);
        grade = new TextField(gradeGroup);
        if (review)
            gradeR = new TextField(gradeReview);
        
        upgrade = new Checkbox("Upgrade", upgradeStudent);
        line.setLayout(new GridLayout(1,0));
        line.add(group);
        line.add(grade);
        if (review)
            line.add(gradeR);
        line.add(upgrade);
    }
    
    /** Method for showing one line.*/
    public Panel showLine() {
        return line;
    }
}
