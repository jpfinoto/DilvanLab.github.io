/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import course.create.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class for edition or removing one assignment from the class. */
public class EditRemoveAssignmentView implements View, Serializable{
    transient AssignmentPanel assignmentsPanel;
    transient Panel p1;
    
    String resource;
    DataActivities dataActivities;
    int idClass;
    int idAssignment;
    int action;  // edit or remove
    Ticket tic;
    
    /** Method for setting variables.*/
    public void setVariable(int idAssignment, int idClass, int action){
        this.idClass = idClass;
        this.idAssignment = idAssignment;
        this.action = action;
    }
    
    /** Method for creation of new instance from the View class. The data about the selected assignment will be got.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.resource = tic.resource;
        this.tic = tic;
        dataActivities = new DataActivities();
        sql.init(this.resource);
        ResultSet rs = sql.executeQuery("SELECT expire FROM class WHERE id='" + idClass + "'");
        rs.next();
        dataActivities.expireClass = UtilFunctions.deconvertDate(rs.getString(1));
        dataActivities.idClass = idClass;
        
        rs = sql.executeQuery("SELECT date,review_date,weight,use_review FROM assignments WHERE id='" + idAssignment +
        "' AND class='" + idClass + "'");
        ResultSet rs1;
        rs.next();
        dataActivities.indexAssignments = 0;
        dataActivities.assig[dataActivities.indexAssignments].idAssignment = idAssignment;
        dataActivities.assig[dataActivities.indexAssignments].deliveryDate = UtilFunctions.deconvertDate(rs.getString(1));
        if (rs.getString(4).equals("true"))
            dataActivities.assig[dataActivities.indexAssignments].reviewDate = UtilFunctions.deconvertDate(rs.getString(2));
        else
            dataActivities.assig[dataActivities.indexAssignments].reviewDate = "";
        dataActivities.assig[dataActivities.indexAssignments].weight = String.valueOf(rs.getInt(3));
        
        rs1 = sql.executeQuery("SELECT name, max_groups, min_users, max_users FROM projects WHERE assignment='" + idAssignment +
        "' AND class='" + idClass + "'");
        int positionProject;
        for (positionProject=0;rs1.next();positionProject++) {
            dataActivities.assig[dataActivities.indexAssignments].projects[positionProject] = "Project " +
            rs1.getString(1) + " MaxGroup " + rs1.getInt(2) + " MinStudents " + rs1.getInt(3) + " MaxStudents " +
            rs1.getInt(4);
        }
        dataActivities.assig[dataActivities.indexAssignments].numberProjects = positionProject;
        dataActivities.numberAssignments=1;
        
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,0));
        principal.setFont(new Font("Helvetica", Font.PLAIN, 12));
        
        assignmentsPanel = new AssignmentPanel();
        p1 = assignmentsPanel.initView();
        assignmentsPanel.atualizeView(dataActivities);
        assignmentsPanel.setEditionMode();
        principal.add(p1, BorderLayout.CENTER);
        
        if (action == 2) { // remove
            Label message = new Label("PRESS SEND BUTTON TO REMOVE ALL OF INFORMATION ABOUT THIS ACTIVITY.");
            message.setForeground(Color.red);
            message.setFont(new Font("Helvetica", Font.BOLD, 10));
            principal.add(message, BorderLayout.SOUTH);
        }
        return principal;
    }
    
    /** Method for validation of the graphic interface information. */
    public boolean validateView() {
        if (action == 1) { // edit
            ErrorWindow er = null;
            int errorView = assignmentsPanel.validateView(dataActivities);
            if (errorView != 0) {
                if (errorView == 1)
                    er = new ErrorWindow("The review date is before of the assignment date.");
                if (errorView == 2)
                    er = new ErrorWindow("Missign projects.");
                if (errorView == 3)
                    er = new ErrorWindow("Invalid date to assignment.");
                if (errorView == 4)
                    er = new ErrorWindow("Some date is after the class's expire date.");
                if (errorView == 5)
                    er = new ErrorWindow("The assignment delivery date should be ordered.");
                if (errorView == 6)
                    er = new ErrorWindow("The weight should be bigger than 0 (zero).");
                er.show();
                return false;
            }
            dataActivities = assignmentsPanel.update(dataActivities);
            dataActivities.indexAssignments--; // it have to do the same position because there is only one assigment to edit
        }
        return true;
    }
    
    /** Method for management of the database information.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        String instruction = null;
        if (action == 1) {	// edit
            String name_project = null;
            String max_groups = null;
            String max_students = null;
            String min_students = null;
            StringTokenizer stoken;
            String token;
            String use_review;
            String date_review;
            
            boolean endToken = true;
            
            if (!dataActivities.assig[dataActivities.indexAssignments].reviewDate.equals("")) {
                use_review = "true";
                date_review = dataActivities.assig[dataActivities.indexAssignments].reviewDate;
            } else {
                use_review = "false";
                date_review = "";
            }
            
            // atualize the data about the assignment in the database
            sql.init(resource);
            instruction = new String("UPDATE assignments SET date='" + UtilFunctions.convertDate(dataActivities.assig[dataActivities.indexAssignments].deliveryDate) +
            "',review_date='" + UtilFunctions.convertDate(date_review) +
            "', weight='" + dataActivities.assig[dataActivities.indexAssignments].weight +
            "', use_review='" + use_review + "' WHERE id='" + idAssignment +
            "' AND class='" + idClass + "'");
            sql.executeUpdate(instruction);
            sql.close();
        } else if (action == 2) { // remove
            // get directory of this course
            sql.init(Defaults.WEBCOMDATABASE);
            ResultSet rs = sql.executeQuery("SELECT directory FROM basic_info WHERE database_name='" + resource + "'");
            rs.next();
            String directory = rs.getString(1);
            sql.close();
            
            // Create new directories in trash
            // Transfer the directory of the assignment for the trash
           
            sql.init(resource);
            
            //Select all groups of this class to remove yours directories
            rs = sql.executeQuery("SELECT group_name FROM activities WHERE type='groups' AND id='" + idAssignment +
            "' AND class='" + idClass + "'");
            
            // Delete each directory from the groups
            for (;rs.next();) {
                try {
                    UtilFunctions.deleteDirectoriesGroup(directory,idAssignment,rs.getString(1),idClass);
                } catch (Exception e) {return "Error deleting directory /homework/assignment. Directories not removed.";};
            }
            
            // if there's not other assignments, remove the assignmentDirectory
            rs = sql.executeQuery("SELECT id FROM assignments WHERE id='" + idAssignment + "' AND class !='" + idClass + "'");
            if (!rs.next()) {
                try {
                    UtilFunctions.deleteDirectoryAssignment(directory,idAssignment,idClass);
                } catch (Exception e) {return "Error deleting directory /homework/assignment. Directories not removed.";};
            }
            
            // Delete the information from database
            sql.executeUpdate("DELETE FROM assignments WHERE id='" + idAssignment + "' AND class='" + idClass + "'");
            sql.executeUpdate("DELETE FROM projects WHERE assignment='" + idAssignment + "' AND class='" + idClass + "'");
            rs = sql.executeQuery("SELECT group_name FROM activities WHERE type='groups' AND id='" + idAssignment +
            "' AND class='" + idClass + "'");
            for (;rs.next();)
                sql.executeUpdate("DELETE FROM groups WHERE name='" + rs.getString(1) + "'");
            sql.executeUpdate("DELETE FROM activities WHERE type='groups' AND id='" + idAssignment + "' AND class='" +
            idClass + "'");
            
            sql.close();
            
        }
        EditClassSelection editClassSelection = new EditClassSelection();
        editClassSelection.setVariable("Class "+ idClass);
        return editClassSelection.createView(tic,sql);
    }
}
