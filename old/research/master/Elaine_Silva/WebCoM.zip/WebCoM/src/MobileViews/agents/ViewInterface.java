/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.net.*;
import agents.security.*;

/** Class extended of JavaInterface for creating a GUI for the view.
 * This class implements the comunication with the server side.*/
public class ViewInterface extends JavaInterface implements Serializable, ActionListener {
    View view;
    TicketJavaInterface ticketInterface;
    
    Button    buttonOK;
    Button    buttonCancel;
    Label     message;
    
    String resource;
    String viewName;
    String agent;
    
    Panel buttons;
    Panel views;
    
    /** Method for creation of a new instance from this class.*/
    public ViewInterface(String host, String resource, String agent, String viewName) {
        super(host);
        this.resource= resource;
        this.agent= agent;
        this.viewName= viewName;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public void init() {
        //Create a window for user login
        ticketInterface= new TicketJavaInterface(host, resource);
        ticketInterface.init();
        ticketInterface.addActionListener(this);
        ticketInterface.show();
    }
    
    /** Method for controlling the events on the objects of the graphic interface.*/
    public void actionPerformed(ActionEvent e){
        Object source = e.getSource();
        // after getting the ticket, try create a new instace of the view
        if (source == ticketInterface) {
            try {
                // send request to the Database servlet. The servlet send message to the users agent. The users agent create a new instance
                // of the view requested, and return the view serialized.
                Message msg= new Message(ticketInterface.getTicket());
                msg.body.addElement(viewName);
                view = (View) sendRequest(agent, msg, ticketInterface.getPassword());
                // call the method to present the view in the ViewInterface window
                init2();
                ticketInterface.setVisible(false);
            } catch (Exception ex) {
                ErrorWindow er= new ErrorWindow(ex.toString());
                er.show();
            }
            return;
        }
        // Send the data of the view for the server side when the SEND button is pressed.
        if (source == buttonOK) {
            // Validate the view data
            if (!view.validateView()) {
                message.setText("Error in data !");
                return;
            }
            message.setText("  Sending data ...");
            try {
                // send requesto to the database servlet. The servlet send the message to the users agent. The users agent
                // execute the method update of the view and return a string or a new view.
                Message msg= new Message(ticketInterface.getTicket());
                msg.body.addElement("update");
                msg.body.addElement(view);
                // Send data for the server side passing by JavaInterface and Database Servlet
                Object resp= sendRequest(agent, msg, ticketInterface.getPassword());
                // Test the type of the response
                if (resp instanceof String) {
                    // present a message window with the message
                    String res = (String) resp;
                    MessageOKWindow messageWindow = new MessageOKWindow(res);
                    messageWindow.show();
                    dispose();
                } else {
                    // change the old view to the new
                    remove(views);
                    view = (View) resp;
                    views = view.initView();
                    add("North", views);
                    message.setText("");
                    pack();
                    show();
                }
            } catch (Exception e2) {
                message.setText("  Communication Error !");
                ErrorWindow er= new ErrorWindow(e2.getMessage());
                er.show();
            }
            return;
        }
        // close the window if the CANCEL button is pressed
        if (source == buttonCancel) {
            dispose();
        }
    }
    
    /** Method for creation of a window for the views.*/
    void init2() {
        // Create and use a BorderLayout manager with specified margins
        setLayout(new BorderLayout(15, 15));
        
        //  Create
        setTitle("Data View");
        setFont(new Font("Helvetica", Font.PLAIN, 12));
        
        message= new Label("");
        buttonOK= new Button("   Send   ");
        buttonOK.addActionListener(this);
        buttonCancel= new Button("  Cancel  ");
        buttonCancel.addActionListener(this);
        
        Panel buttons = new Panel();
        buttons.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 5));
        buttons.add(buttonOK);
        buttons.add(buttonCancel);
        
        //  Init view
        views = view.initView();
        add("North", views);
        add("Center", buttons);
        add("South",message);
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
        
        // Resize the window to the preferred size of its components
        pack();
        show();
    }
}
