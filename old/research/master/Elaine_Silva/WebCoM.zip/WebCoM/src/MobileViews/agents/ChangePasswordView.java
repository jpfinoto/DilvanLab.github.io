/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents;

import java.awt.*;
import java.io.*;
import java.util.*;
import java.sql.*;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;

/** Class for changing the user's password.*/
public class ChangePasswordView extends Panel implements View {
    String resource;
    String username;
    String password;
    String question = null;
    String answer = null;
    
    transient TextField usernameF;
    transient TextField newPassword;
    transient TextField newPassword2;
    transient TextField questionF;
    transient TextField answerF;
    
    /** Method for creation of a new instance from the View class. The question and answer of the student is got from the database.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.resource = tic.resource;
        this.username = tic.username.toLowerCase();
        ResultSet rs;
        
        sql.init(Defaults.WEBCOMDATABASE);
        // Select question and answer to the student
        rs = sql.executeQuery("SELECT question,answer FROM users WHERE username='" + tic.username + "'");
        rs.next();
        question = rs.getString(1);
        answer = rs.getString(2);
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        ImageLoader jImage = new ImageLoader();
        Canvas canvas = new Canvas();
        Image icon;
        
        usernameF = new TextField(username);
        usernameF.setEditable(false);
        newPassword = new TextField(5);
        newPassword.setEchoChar('*');
        newPassword2 = new TextField(5);
        newPassword2.setEchoChar('*');
        questionF = new TextField(question);
        answerF = new TextField(answer);
        
        // Panel principal
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        // Panel for all of components
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        // Panel for group components
        Panel form = new Panel();
        form.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();;
        
        // Label username
        Label label = new Label("Username");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 1.0;
        constraints.weighty = 1.0;
        constraints.insets = new Insets(0,10,0,0);
        form.add(label, constraints);
        
        // Label New Password
        label = new Label("New Password       ");
        constraints.gridx = 0;
        constraints.gridy = 2;
        form.add(label, constraints);
        
        // Label Retype New Password
        label = new Label("Retype New Password");
        constraints.gridx = 1;
        constraints.gridy = 2;
        form.add(label, constraints);
        
        // Textfield username
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        form.add(usernameF, constraints);
        
        // Textfield new password
        constraints.gridx = 0;
        constraints.gridy = 3;
        form.add(newPassword, constraints);
        
        // Textfield new password2
        constraints.gridx = 1;
        constraints.gridy = 3;
        form.add(newPassword2, constraints);
        
        // Put the form in the center of groupForm Panel
        groupForm.add(form, BorderLayout.CENTER);
        
        // Create new instance of form
        form = new Panel();
        form.setLayout(new GridBagLayout());
        constraints = new GridBagConstraints();;
        
        // Image question
        icon = jImage.loadImage("question.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(35,35);
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        constraints.gridheight = 2;
        constraints.fill = GridBagConstraints.NONE;
        constraints.weightx = 0.3;
        constraints.weighty = 1;
        form.add(canvas, constraints);
        
        // Label Question
        label = new Label("Question to remember password");
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 3;
        constraints.gridheight = 1;
        constraints.weightx = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        form.add(label, constraints);
        
        // Label Answer
        label = new Label("Answer to the question");
        constraints.gridx = 1;
        constraints.gridy = 2;
        form.add(label, constraints);
        
        // Textfield question
        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        form.add(questionF, constraints);
        
        // Textfield answer
        constraints.gridx = 1;
        constraints.gridy = 3;
        form.add(answerF, constraints);
        
        // Put the form in the south of groupForm Panel
        groupForm.add(form,BorderLayout.SOUTH);
        
        // Image from top of tool
        icon = jImage.loadImage("password.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(430,45);
        canvas.setBackground(Color.lightGray);
        // Put the canvas in the north of groupForm Panel
        groupForm.add(canvas,BorderLayout.NORTH);
        
        // Put the groupForm in another panel
        principal.add(groupForm);
        return principal;
    }
    
    /** Method for validation of the graphic interface information.*/
    public boolean validateView() {
        ErrorWindow er;
        if (newPassword.getText().equals("")) {
            er = new ErrorWindow("Missign password.");
            er.show();
            return false;
        } else if (newPassword.getText().toLowerCase().indexOf("'") != -1) {
            er = new ErrorWindow("Invalid character in Password.");
            er.show();
            return false;
        } else if ((newPassword.getText().length() < 5) || (newPassword.getText().length() > 16)) {
            er = new ErrorWindow("Password should be bigger than 5 and smaller than 16 characters.");
            er.show();
            return false;
        } else if ((newPassword.getText().indexOf(' ') != -1) &&
        (newPassword.getText().indexOf(' ') != newPassword.getText().length())) {
            er = new ErrorWindow("Spaces are not allowed in Password.");
            er.show();
            return false;
        } else if (!newPassword.getText().equals(newPassword2.getText())) {
            er = new ErrorWindow("Two Passwords different.");
            er.show();
            return false;
        }
        if (questionF.getText().equals("") || answerF.getText().equals("")) {
            er = new ErrorWindow("You have to write a question and a answer.");
            er.show();
            return false;
        } else if ((questionF.getText().indexOf("'") != -1) || (answerF.getText().indexOf("'") != -1)){
            er = new ErrorWindow("Invalid Character in Question or Answer.");
            er.show();
            return false;
        }
        
        password = newPassword.getText();
        question = questionF.getText().toUpperCase();
        answer = answerF.getText().toUpperCase();
        return true;
    }
    
    /** Method for management of the database information.*/
    public Object updateView(SQL sql) throws Exception {
        sql.init(Defaults.WEBCOMDATABASE);
        sql.executeUpdate("UPDATE users SET password='" + password + "',question='" + question +
        "',answer='" + answer + "' WHERE username='" + username + "'");
        sql.close();
        return "Success";
    }
    
}


