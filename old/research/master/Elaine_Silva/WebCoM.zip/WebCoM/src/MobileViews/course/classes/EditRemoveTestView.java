/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import course.create.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class for edition or removing one test. */
public class EditRemoveTestView implements View, Serializable{
    transient TestPanel testsPanel;
    transient Panel p1;
    
    String resource;
    DataActivities dataActivities;
    int idClass;
    int idTest;
    int action;
    Ticket tic;
    
    /** Method for setting variables.*/
    public void setVariable(int idTest, int idClass, int action){
        this.idClass = idClass;
        this.idTest = idTest;
        this.action = action;
    }
    
    /** Method for creation of a new instance from the View class. The data about the selected test will be got. */
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.resource = tic.resource;
        this.tic = tic;
        dataActivities = new DataActivities();
        sql.init(this.resource);
        ResultSet rs = sql.executeQuery("SELECT expire FROM class WHERE id='" + idClass + "'");
        rs.next();
        dataActivities.expireClass = UtilFunctions.deconvertDate(rs.getString(1));
        dataActivities.idClass = idClass;
        
        rs = sql.executeQuery("SELECT date,weight FROM tests WHERE id='" + idTest + "' AND class='" + idClass + "'");
        rs.next();
        dataActivities.indexTests = 0;
        dataActivities.test[dataActivities.indexReports].id = idTest;
        dataActivities.test[dataActivities.indexReports].deliveryDate = UtilFunctions.deconvertDate(rs.getString(1));
        dataActivities.test[dataActivities.indexReports].weight = String.valueOf(rs.getInt(2));
        dataActivities.numberTests= 1;
        
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout());
        principal.setFont(new Font("Helvetica", Font.PLAIN, 12));
        
        testsPanel = new TestPanel();
        p1 = testsPanel.initView();
        testsPanel.atualizeView(dataActivities);
        principal.add(p1, BorderLayout.CENTER);
        
        if (action == 2) { // remove
            Label message = new Label("PRESS SEND BUTTON TO REMOVE ALL OF INFORMATION ABOUT THIS ACTIVITY.");
            message.setForeground(Color.red);
            message.setFont(new Font("Helvetica", Font.BOLD, 10));
            principal.add(message, BorderLayout.SOUTH);
        }
        return principal;
    }
    
    /** Method for validation of the graphic interface information. */
    public boolean validateView() {
        if (action == 1) { // edit
            ErrorWindow er = null;
            int errorView = testsPanel.validateView(dataActivities);
            if (errorView != 0) {
                if (errorView == 1)
                    er = new ErrorWindow("Invalid Information.");
                if (errorView == 2)
                    er = new ErrorWindow("The test date is after the class's expire date.");
                if (errorView == 3)
                    er = new ErrorWindow("The test delivery date should be orderer.");
                if (errorView == 4)
                    er = new ErrorWindow("The weight should be bigger than 0.");
                er.show();
                return false;
            }
            dataActivities = testsPanel.update(dataActivities);
            dataActivities.indexTests--; // it have to do the same position because there is only one test to edit
        }
        return true;
    }
    
    /** Method for management of the database information.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        if (action == 1) { // edit
            String instruction = null;
            sql.init(resource);
            // atualize the data about the test in the database
            instruction = new String("UPDATE tests SET date='" + UtilFunctions.convertDate(dataActivities.test[dataActivities.indexTests].deliveryDate) +
            "',weight='" + dataActivities.test[dataActivities.indexTests].weight +
            "' WHERE id='" + idTest + "' AND class='" + idClass + "'");
            sql.executeUpdate(instruction);
            sql.close();
        } else if (action == 2) { // remove
            sql.init(resource);
            // delete the test of the database
            sql.executeUpdate("DELETE FROM tests WHERE id='" + idTest + "' AND class='" + idClass + "'");
            sql.executeUpdate("DELETE FROM activities WHERE type='tests' AND id='" + idTest + "' AND class='" + idClass + "'");
            sql.close();
        }
        EditClassSelection editClassSelection = new EditClassSelection();
        editClassSelection.setVariable("Class "+ idClass);
        return editClassSelection.createView(tic,sql);
    }
}
