/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents;

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.applet.*;

import agents.*;
import agents.security.*;

/** Method for login into JSP page.*/
public class LoginJSP extends Frame implements ActionListener{
    protected String urlString = null;
    protected AppletContext appContext;
    
    TicketJavaInterface log;
    
    /** Method for creation of a new instance from this class.*/
    public LoginJSP() {};
    
    /** Method for creation of a new instance from this class. The url is the address of the JSP page.*/
    public LoginJSP(String host, String resource, String url, AppletContext appContext) {
        urlString = url;
        this.appContext = appContext;
        
        // Create a window to make login
        log = new TicketJavaInterface(host, resource);
        log.addActionListener(this);
        log.init();
    }
    
    /** Method for showing the login window.*/
    public void show() { log.show();}
    
    /** Method for controlling the events in the login window.*/
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        if (source == log) {
            try {
                urlString = urlString + "&key=" + cryptData(log.getUsername(),log.getPassword()) +
                "&userLogin=" + log.getUsername();
                URL url = new URL(urlString);
                appContext.showDocument(url,"jsp");
                log.setVisible(false);
            } catch (Exception er) {};
            return;
        }
    }
    
    /** Method for codifying the username and the date with the user's password.*/
    public String cryptData(String username, String password) {
        int counter;
        java.util.Calendar calend = java.util.Calendar.getInstance();
        java.util.Date date = new java.util.Date();
        calend.setTime(date);
        
        String[] information = new String[3];
        information[0] = username;
        information[1] = String.valueOf(calend.get(java.util.Calendar.DAY_OF_MONTH));
        information[2] = date.toString();
        
        String passwd = new String("");
        try {
            byte[] buffer = agents.security.ObjectOutputCrypt.writeObject(password, information);
            for (counter = 0; counter < buffer.length; counter++) {
                if (counter == 0)
                    passwd = passwd + (int) buffer[counter];
                else
                    passwd = passwd + "+" + (int) buffer[counter]; // "+" represent spaces " " to url
            }
            return passwd;
        } catch (Exception e) {return "ERROR - TRY AGAIN OR CONTACT THE SYSTEM ADMINISTRATOR";}
    }
    
    /** Method for verification of the user. If the date of the user's machine is wrong, he won't be able to log in.*/
    public int UserValid(String userName,String key, String basePassword) {
        int counter = 0;
        int spaces = 0;
        int indexBuffer = 0;
        int result = 0;
        String x = "";
        
        // Count the number of bytes of the message
        // The spaces appearing "+" in the URL
        while (counter < key.length()) {
            if (key.charAt(counter) == ' ')
                spaces++;
            counter++;
        }
        // Create one buffer with spaces+1 bytes
        byte[] buffer = new byte[spaces+1];
        
        counter = 0;
        while (counter <= key.length()) {
            // if the counter is the last character of the message, then record the byte of value x
            if (counter == key.length()) {
                int valueAux = Integer.parseInt(x);
                buffer[indexBuffer] = (byte) valueAux;
                indexBuffer++;
                counter++;
            } else {
                // if the character(in the index counter) is white, then record the byte of value x
                if (key.charAt(counter) == ' ') {
                    int ValueAux = Integer.parseInt(x);
                    x = new String("");
                    buffer[indexBuffer] = (byte) ValueAux;
                    indexBuffer++;
                    counter++;
                }
                // record the character (in the index counter) in the variable x
                x = x + key.charAt(counter);
                counter++;
            }
        }
        try {
            String[] Information = (String[]) ObjectInputCrypt.readObject(basePassword,buffer);
            
            if (Information[0].equals(userName)) {
                java.util.Calendar calend = java.util.Calendar.getInstance();
                java.util.Date date = new java.util.Date();
                calend.setTime(date);
                if ((Integer.parseInt(Information[1]) == calend.get(java.util.Calendar.DAY_OF_MONTH)) ||
                (Integer.parseInt(Information[1]) == (calend.get(java.util.Calendar.DAY_OF_MONTH)+1)) ||
                (Integer.parseInt(Information[1]) == (calend.get(java.util.Calendar.DAY_OF_MONTH)-1)))
                    result = 0; //usuario ok
                else
                    result = 1; //Autentication expired
            }
        } catch (Exception e) {return 2;};
        return result;
    }
}

