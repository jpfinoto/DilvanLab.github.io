/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.users;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import agents.util.CourseEmail;
import course.util.UtilFunctions;

/** Class for edition of administrator information.*/
public class EditAdminView extends Panel implements View {
    String firstName, lastName, password, NewPassword;
    String email;
    Ticket tic;
    
    public String username;
    
    transient TextField fAdmin,lAdmin,userName;
    transient TextField passwdAdmin,passwdAdmin2;
    transient TextField emailAdmin;
    
    /** Method for setting variable. Set the selected username.*/
    public void setUserSelected(String username) {
        this.username = username;
    }
    
    /** Method for creation of a new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        // test the student type (user of the login)
        if (!tic.type.equals("administrator")) throw new RuntimeException("You don't have permissions to access this tool.");
        sql.init(Defaults.WEBCOMDATABASE);
        
        // get the information about the selected username
        ResultSet rs = sql.executeQuery("SELECT first_name, last_name, password, email FROM users WHERE username='" + username + "'");
        rs.next();
        firstName = rs.getString(1);
        lastName = rs.getString(2);
        password = rs.getString(3);
        email = rs.getString(4);
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Image icon;
        Canvas canvas = new Canvas();
        
        fAdmin = new TextField(firstName);
        lAdmin = new TextField(lastName);
        userName = new TextField(username);
        passwdAdmin = new TextField(password);
        passwdAdmin2 = new TextField(password);
        emailAdmin = new TextField(email);
        
        setFont(new Font("Helvetica",Font.PLAIN,11));
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        // label username
        Label label = new Label("Username");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        
        // label first name
        constraints.gridx = 0;
        constraints.gridy = 2;
        label = new Label("First Name");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label last name
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.insets = new Insets(0,5,0,0);
        label = new Label("Last Name");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label password
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,0,0,5);
        label = new Label("Type Password");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label retype password
        constraints.gridx = 2;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,5,0,0);
        label = new Label("Retype Password");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label e-mail
        constraints.gridx = 0;
        constraints.gridy = 6;
        constraints.insets = new Insets(0,0,0,5);
        label = new Label("E-mail");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label
        label = new Label("          ");
        constraints.gridx = 1;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        label = new Label("          ");
        constraints.gridx = 3;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // field username
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        gridBag.setConstraints(userName,constraints);
        userName.setEditable(false);
        form.add(userName);
        
        // field first name Admin
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        constraints.insets = new Insets(0,0,0,5);
        gridBag.setConstraints(fAdmin,constraints);
        form.add(fAdmin);
        
        // field last name Admin
        constraints.gridx = 2;
        constraints.gridy = 3;
        constraints.insets = new Insets(0,5,0,0);
        gridBag.setConstraints(lAdmin,constraints);
        form.add(lAdmin);
        
        // field password
        constraints.gridx = 0;
        constraints.gridy = 5;
        constraints.insets = new Insets(0,0,0,5);
        passwdAdmin.setEchoChar('*');
        gridBag.setConstraints(passwdAdmin,constraints);
        form.add(passwdAdmin);
        
        // field retype password
        constraints.gridx = 2;
        constraints.gridy = 5;
        constraints.insets = new Insets(0,5,0,0);
        passwdAdmin2.setEchoChar('*');
        gridBag.setConstraints(passwdAdmin2,constraints);
        form.add(passwdAdmin2);
        
        // field email
        constraints.gridx = 0;
        constraints.gridy = 7;
        constraints.gridwidth = 4;
        constraints.insets = new Insets(0,0,0,5);
        gridBag.setConstraints(emailAdmin,constraints);
        form.add(emailAdmin);
        
        groupForm.add(form,BorderLayout.CENTER);
        
        ImageLoader jImage = new ImageLoader();
        icon = jImage.loadImage("administrator.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(430,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        ErrorWindow er;
        
        // test the first and last name fields. The username can't be changed.
        if ((!fAdmin.getText().equals("")) || (!lAdmin.getText().equals(""))) {
            if ((fAdmin.getText().indexOf("'") != -1) || (lAdmin.getText().indexOf("'") != -1)) {
                er = new ErrorWindow("Invalid character in First Name or Last Name.");
                er.show();
                return false;
            } else if ((fAdmin.getText().length() > 32) || (lAdmin.getText().length() > 32)) {
                er = new ErrorWindow("First Name and Last Name should be smaller than 32 characters.");
                er.show();
                return false;
            } else if ((fAdmin.getText().indexOf(' ') != -1) || (lAdmin.getText().indexOf(' ') != -1)){
                if ((fAdmin.getText().indexOf(' ') != fAdmin.getText().length()) ||
                (lAdmin.getText().indexOf(' ') != lAdmin.getText().length())){
                    er = new ErrorWindow("Spaces are not allowed in First an Last Name.");
                    er.show();
                    return false;
                }
            }
        }
        
        // Test the password field.
        if (passwdAdmin.getText().equals("")) {
            er = new ErrorWindow("Missign password.");
            er.show();
            return false;
        } else if (!passwdAdmin.getText().equals(password)) {
            if (passwdAdmin.getText().toLowerCase().indexOf("'") != -1) {
                er = new ErrorWindow("Invalid character in Password.");
                er.show();
                return false;
            } else if ((passwdAdmin.getText().length() < 5) || (passwdAdmin.getText().length() > 16)) {
                er = new ErrorWindow("Password should be bigger than 5 and smaller than 16 characters.");
                er.show();
                return false;
            } else if ((passwdAdmin.getText().indexOf(' ') != -1) &&
            (passwdAdmin.getText().indexOf(' ') != passwdAdmin.getText().length())) {
                er = new ErrorWindow("Spaces are not allowed in Password.");
                er.show();
                return false;
            } else if (!passwdAdmin.getText().equals(passwdAdmin2.getText())) {
                er = new ErrorWindow("Two Passwords different.");
                er.show();
                return false;
            }
        }
        
        // Test the email fields.
        if (emailAdmin.getText().indexOf('@') == -1) {
            er = new ErrorWindow("Wrong email format: name@site.");
            er.show();
            return false;
        }
        email = emailAdmin.getText();
        firstName = fAdmin.getText();
        lastName = lAdmin.getText();
        NewPassword = passwdAdmin.getText().toLowerCase();
        return true;
    }
    
    /** Method for management of the database information.*/
    public Object updateView(SQL sql) throws Exception {
        ResultSet rs;
        
        sql.init(Defaults.WEBCOMDATABASE);
        // Test if this email is already used
        rs = sql.executeQuery("SELECT username FROM users WHERE email='" + email + "'");
        if (rs.next())
            if (!rs.getString(1).equals(username)) throw new RuntimeException("This email already is used.");
        
        // Insert the Admin in the users base
        sql.executeUpdate("UPDATE users SET password='" + NewPassword + "', last_name='" + lastName +
        "', first_name='" + firstName + "', email='"+ email + "' WHERE username='" + username + "'");
        sql.close();
        
        if (!password.equals(NewPassword)) {
            // Send e-mail with alert
            try {
                CourseEmail courseEmail = new CourseEmail(email);
                courseEmail.envia(Defaults.FROM, Defaults.HOST, "Course Manager",
                "Message from Course Administrator: \n" + "Your information was changed to:\n" +
                " username = " + username +"\n" +
                " password = " + NewPassword +"\n" +
                " Please, change your password.");
            }catch (Exception e) {};
        }
        
        UserSelectionView userSelectionView = new UserSelectionView();
        return userSelectionView.createView(tic,sql);
    }
}
