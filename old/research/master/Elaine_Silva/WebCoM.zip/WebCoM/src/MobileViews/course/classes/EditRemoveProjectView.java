/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import course.create.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import agents.util.CourseEmail;
import course.util.UtilFunctions;

/** Class for edition or removing one assignment's project. */
public class EditRemoveProjectView implements View, Serializable{
    transient ProjectPanel projectPanel;
    transient Panel p1;
    
    String resource;
    String projectName;
    DataProject dataProject;
    int idClass;
    int idAssignment;
    int minStudentsGeneral = 1,maxStudentsGeneral = 1,maxGroupsGeneral = 1;
    int action;
    boolean thereAreGroups = false;
    
    Ticket tic;
    
    /** Method for setting variables. The data about the selected project is got.*/
    public void setVariable(int idClass, int idAssignment, String projectSelected, int action){
        boolean endToken = true;
        
        this.action = action;
        this.idClass = idClass;
        this.idAssignment = idAssignment;
        
        StringTokenizer stoken = new StringTokenizer(projectSelected, " ");
        String token;
        dataProject = new DataProject();
        while (endToken) {
            try {
                token = stoken.nextToken();
                if (token.equals("Project")) {
                    dataProject.name = stoken.nextToken();
                    projectName = dataProject.name;
                }
                if (token.equals("MaxGroup"))
                    dataProject.maxGroups = stoken.nextToken();
                if (token.equals("MaxStudents"))
                    dataProject.maxStudents = stoken.nextToken();
                if (token.equals("MinStudents"))
                    dataProject.minStudents = stoken.nextToken();
            } catch (NoSuchElementException e) {endToken = false;}
        }
    }
    
    /** Method for creation of new instance from the View class. The information, such as max groups, min and max students,
     * will be got to control the user's action. */
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.resource = tic.resource;
        this.tic = tic;
        boolean firstGroup = true;
        int countStudents;
        int countGroups;
        
        sql.init(resource);
        // get the name of the groups that are making this project
        ResultSet rs = sql.executeQuery("SELECT distinct groups.name FROM groups,activities WHERE " +
                                        "groups.name=activities.group_name AND groups.assignment='" + idAssignment +
                                        "' AND groups.project='" + dataProject.name + "' AND activities.class=" + idClass);
        if (action == 1) { // edit
            ResultSet rs1;
            for (countGroups=0;rs.next();countGroups++) {
                rs1 = sql.executeQuery("SELECT username FROM activities WHERE type='groups' AND id='" + idAssignment +
                "' AND class='" + idClass + "' AND group_name='" + rs.getString(1) + "'");
                for (countStudents = 0; rs1.next(); countStudents++);
                if ((firstGroup) && (countStudents > 0)){ // get the min and max students from the first group
                    minStudentsGeneral = countStudents;
                    maxStudentsGeneral = countStudents;
                    firstGroup = false;
                } else if (countStudents > 0) { // get the min and max students from all of the groups of this project
                    if (countStudents <= minStudentsGeneral)
                        minStudentsGeneral = countStudents;
                    if (countStudents >= maxStudentsGeneral)
                        maxStudentsGeneral = countStudents;
                }
            }
            maxGroupsGeneral = countGroups; // number of groups that is making this project
        } else { // remove
            if (rs.next())
                thereAreGroups = true; // there are groups making this project
        }
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout());
        principal.setFont(new Font("Helvetica", Font.PLAIN, 12));
        
        projectPanel = new ProjectPanel(idAssignment);
        p1 = projectPanel.initView();
        projectPanel.atualizeView(dataProject);
        principal.add(p1, BorderLayout.CENTER);
        if (action == 2) { // remove
            Panel panelMessage = new Panel();
            panelMessage.setLayout(new GridLayout(2,1));
            
            Label message = new Label("* PRESS SEND BUTTON TO REMOVE THIS PROJECT.");
            message.setForeground(Color.red);
            message.setFont(new Font("Helvetica", Font.BOLD, 10));
            panelMessage.add(message);
            // if there are groups making this project, present the message
            if (thereAreGroups) {
                message = new Label(" * ALL OF THE GROUPS TO THIS PROJECT WILL BE REMOVED TOO.");
                message.setForeground(Color.red);
                message.setFont(new Font("Helvetica", Font.BOLD, 10));
                panelMessage.add(message);
            }
            principal.add(panelMessage, BorderLayout.SOUTH);
        }
        
        return principal;
    }
    
    /** Method for validation of the graphic interface information.*/
    public boolean validateView() {
        ErrorWindow er = null;
        if (action == 1) { // edit
            int errorView = projectPanel.validateView();
            if (errorView != 0) {
                if (errorView == 1)
                    er = new ErrorWindow("Missing project name.");
                if (errorView == 2)
                    er = new ErrorWindow("Spaces are not allowed in the field Name.");
                if (errorView == 3)
                    er = new ErrorWindow("Values min and max have to be more than 0.");
                if (errorView == 4)
                    er = new ErrorWindow("MinStudents is bigger MaxStudents.");
                if (errorView == 5)
                    er = new ErrorWindow("Missing values.");
                er.show();
                return false;
            }
            
            dataProject = projectPanel.update(dataProject);
            if (Integer.parseInt(dataProject.maxGroups) < maxGroupsGeneral) {
                er = new ErrorWindow("The Max Groups value have to be bigger or equals than " + maxGroupsGeneral + ".");
                er.show();
                return false;
            }
            if (Integer.parseInt(dataProject.minStudents) > minStudentsGeneral) {
                er = new ErrorWindow("The Min Students value have to be smaller or equals than " + minStudentsGeneral + ".");
                er.show();
                return false;
            }
            if (Integer.parseInt(dataProject.maxStudents) < maxStudentsGeneral) {
                er = new ErrorWindow("The Max Students value have to be bigger or equals than " + maxStudentsGeneral + ".");
                er.show();
                return false;
            }
        }
        return true;
    }
    
    /** Method for management of the database information.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        String instruction = null;
        
        if (action == 1) { // edit
            sql.init(resource);
            // atualize the data about the project in the database
            sql.executeUpdate("UPDATE projects SET name='" + dataProject.name + "', max_groups='" + dataProject.maxGroups +
            "', min_users='" + dataProject.minStudents + "', max_users='" + dataProject.maxStudents +
            "' WHERE class='" + idClass + "' AND assignment='" + idAssignment + "' AND name='" + projectName + "'");
            sql.close();
        } else { // remove
            
            ResultSet rs, rs1;
            String courseDirectory, courseName;
            Vector students = new Vector();
            Vector groups = new Vector();
            
            // get the directory for this course
            sql.init(Defaults.WEBCOMDATABASE);
            rs = sql.executeQuery("SELECT course_name,directory FROM basic_info WHERE database_name='" + tic.resource + "'");
            rs.next();
            courseDirectory = rs.getString(2);
            courseName = rs.getString(1);
            sql.close();
            
            sql.init(tic.resource);
            // get the groups that is making this project
            rs = sql.executeQuery("SELECT name FROM groups WHERE assignment='" + idAssignment + "' AND project='" +
            dataProject.name + "'");
            for (;rs.next();) {
                // get all of the students from all of the groups to this project
                rs1 = sql.executeQuery("SELECT username FROM activities WHERE type='groups' AND id='" + idAssignment +
                "' AND group_name='" + rs.getString(1) + "' AND class='" + idClass + "'");
                for (;rs1.next();)
                    students.addElement(rs1.getString(1));
                
                // Delete all of the activities from all of the groups to this project
                sql.executeUpdate("DELETE FROM activities WHERE type='groups' AND id='" + idAssignment + "' AND group_name='" +
                rs.getString(1) + "' AND class='" + idClass + "'");
                
                // store all of the groups in a vector
                groups.addElement(rs.getString(1));
                
                // Delete all of the groups for this project
                sql.executeUpdate("DELETE FROM groups WHERE name='" + rs.getString(1) + "' AND assignment='" + idAssignment +
                "'");
                
            }
            // Delete this project
            sql.executeUpdate("DELETE FROM projects WHERE name='" + dataProject.name + "' AND assignment='" + idAssignment +
            "' AND class='" + idClass + "'");
            
            // Delete directory for all students of the groups
            for (int count=0; count < groups.size(); count++)
                UtilFunctions.deleteDirectoriesGroup(courseDirectory, idAssignment,(String) groups.elementAt(count), idClass);
            
            sql.close();
            
            sql.init(Defaults.WEBCOMDATABASE);
            // if the group have to be removed, then send email for all members
            if (students.size() > 0) {
                instruction = "SELECT email FROM users WHERE username='";
                for(int count=0;count<students.size();count++) {
                    if (count == students.size()-1)
                        instruction = instruction + students.elementAt(count) + "'";
                    else
                        instruction = instruction + students.elementAt(count) + "' AND username='";
                }
                rs = sql.executeQuery(instruction);
                for(;rs.next();) {
                    try {
                        CourseEmail courseEmail = new CourseEmail(rs.getString(1));
                        courseEmail.envia(Defaults.FROM, Defaults.HOST, "Course Manager",
                        "Message from Course Administrator: \n" +
                        "Your work group int the course " + courseName + " was removed in the assignment "
                        + idAssignment + ".\n" +
                        "The project you choose was removed. Please try to enter in another group or create a new group.");
                    }catch (Exception e) {};
                }
            }
        }
        EditClassSelection editClassSelection = new EditClassSelection();
        editClassSelection.setVariable("Class "+ idClass);
        return editClassSelection.createView(tic,sql);
    }
}
