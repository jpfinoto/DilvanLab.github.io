/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package ftpMail;

import java.util.*;
import java.io.*;
import agents.sql.*;
import agents.agent.Defaults;
import course.util.UtilFunctions;
import java.sql.ResultSet;

/** Class for analyzing the information of the email received.*/
public class Attributes {
    String course;
    String username;
    String activity;
    int id= -1; // number of the activity i.e. asignment 1
    String directory;
    String email;
    Date exp_date;
    int classUsername;
    String directoryCourse = null;
    
    /** Method to extracting and verifying the information from the email message.*/
    void init(StreamTokenizer inp) throws MailftpException {
        SQLDatabase sql;
        course= null;
        username= null;
        activity= null;
        id= -1;
        Date date = new Date();
        try {
            int type= inp.nextToken();
            String aux = "";
            boolean ok = true;
            while (type!=StreamTokenizer.TT_EOF) {
                if (type==StreamTokenizer.TT_WORD) {
                    if (inp.sval.equalsIgnoreCase("COURSENAME")) {
                        type = inp.nextToken();
                        while (ok && type!=StreamTokenizer.TT_EOF) {
                            if (type==StreamTokenizer.TT_WORD) {
                                if ((inp.sval.equalsIgnoreCase("USERNAME")) ||
                                (inp.sval.equalsIgnoreCase("ACTIVITY"))){
                                    ok = false;
                                    break;
                                } else
                                    aux = aux + inp.sval;
                            }
                            type = inp.nextToken();
                        }
                        course = aux;
                    }
                    if (inp.sval.equalsIgnoreCase("USERNAME")) {
                        type= inp.nextToken();
                        if (type!=StreamTokenizer.TT_WORD) return;
                        username= inp.sval.toLowerCase();
                    } else
                        if (inp.sval.equalsIgnoreCase("ACTIVITY")) {
                            type= inp.nextToken();
                            if (type!=StreamTokenizer.TT_WORD) return;
                            activity= inp.sval.toLowerCase();
                            id= Integer.parseInt(activity.substring(activity.length()-1));
                            activity= activity.substring(0, activity.length()-1);
                        }
                }
                type= inp.nextToken();
            } // end while
        } catch (Exception e) {
            throw new MailftpException("ERROR: " + e.toString());
        }
        try {
            sql = new SQLDatabase();
            sql.init(Defaults.WEBCOMDATABASE);
            ResultSet rs = sql.executeQuery("SELECT course_name, database_name, directory FROM basic_info");
            for(;rs.next();) {
                if (removeSpaces(rs.getString(1)).equalsIgnoreCase(course)) {
                    course = rs.getString(2);
                    directoryCourse = rs.getString(3);
                    break;
                }
            }
            if (directoryCourse.equals(null))
                throw new MailftpException("The course don't exist!");
            
            email= sql.getEmail(username);
            sql.close();
            
            sql.init(course);
            rs = sql.executeQuery("SELECT students.class,class.expire FROM students,class WHERE username='"
            + username + "' AND students.class=class.id");
            for (;rs.next();) {
                if (UtilFunctions.verifyDate(date,rs.getDate(2)) < 0)
                    throw new MailftpException("Your class is expired.");
                else
                    classUsername = rs.getInt(1);
            }
            if (classUsername== 0) throw new MailftpException("Student not registred in any class.");
            
            directory= sql.getDirectory(username, activity, id, date, directoryCourse, classUsername);
        } catch (Exception e) {
              throw new MailftpException("Problem with information. Please check it!");
        }
        exp_date= date;
        //	Verify expiration dates
        Date currentDate= new Date();
        if ((classUsername != 0) && (currentDate.after(exp_date)))
            throw new MailftpException("Update time expired for the directory.");
        
    }
    
    /** Method for removing the spaces from the course name.*/
    public String removeSpaces(String course) {
        String aux = "";
        for (int i=0; i < course.length(); i++) {
            if (course.charAt(i) != ' ')
                aux = aux + course.charAt(i);
        }
        return aux;
    }
}
