/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents.util;

import java.io.*;
import java.util.Vector;
import java.net.Socket;

/** Class for representation of a email message.*/
public class Email {
    
    public final static int portaSMTP = 25;
    protected String hostdest;
    protected String hostrem;
    protected String senderEmail;
    protected PrintWriter msgWriter;
    protected StringWriter msg = new StringWriter();
    protected Vector recipients = new Vector();
    protected String message = "";
    
    /** Method for creating a new instance of this class.*/
    public Email(String hostdest, String hostrem) {
        this.hostdest= hostdest;
        this.hostrem= hostrem;
        msgWriter= new PrintWriter(msg);
    }
    
    /** Method for adding a new recipient.*/
    public void addRecipient(String email) {
        recipients.addElement(email);
    }
    
    /** Method for returning the number of reports.*/
    public int recipientsNumber() {
        return recipients.size();
    }
    
    /** Method for setting the email sender.*/
    public void setSender(String email) {
        senderEmail= email;
    }
    
    /** Method for setting the email message.*/
    public void setMessage(String message) {
        this.message = message;
    }
    
    public PrintWriter body() { return msgWriter;}
    
    /** Method for sendding the email message.*/
    public void send() throws IOException {
        String          resposta;
        PrintStream     sai;
        DataInputStream ent;
        
        //  Conect to mailserver
        Socket socket = new Socket(hostdest,portaSMTP,true);
        sai = new PrintStream(socket.getOutputStream());
        ent = new DataInputStream(socket.getInputStream());
        
        sai.println("HELO " + hostrem);
        sai.flush();
        resposta = ent.readLine();
        
        sai.println("MAIL FROM:<" + senderEmail + ">");
        sai.flush();
        resposta = ent.readLine();
        
        //	Inform all recipients
        //
        if (recipients.size()==0) throw  new RuntimeException("No e-mail recipients");
        for (int aux1=0; aux1<recipients.size(); aux1++) {
            sai.println("RCPT TO:<" + recipients.elementAt(aux1) + ">");
            sai.flush();
            resposta = ent.readLine();
        }
        
        sai.println("DATA");
        sai.flush();
        resposta = ent.readLine();
        
        msgWriter.flush();
        sai.println(msg);
        sai.println(message);
        //	Ends message
        //
        sai.println(".");
        sai.flush();
        
        resposta = ent.readLine();
        
        socket.close();
        
    }
    
/*   public static void main(String args[]) {
 
      StringBuffer mensagem=new StringBuffer();
      PrintStream os = System.out;
      DataInputStream is = new DataInputStream(System.in);
 
      Email email= new Email();
 
      System.out.println("Envia um email.");
 
      try {
         //  Leitura do destinatario e rementente.
         //
         os.print("EMail destino: ");
         email.addRecipient(is.readLine());
         os.print("EMail remetente: ");
         email.setSender(is.readLine());
 
         String linha = "";
         mensagem = new StringBuffer("");
         os.println("Mensagem (. para terminar):");
         while (!linha.equals(".")) {
            linha = is.readLine();
            mensagem.append(linha);
            mensagem.append("\r\n");
         }
 
 
         email.body().println(mensagem);
         email.send();
 
      } catch(IOException iox) {
         System.out.println("Erro: Nao foi possivel enviar mensagem.");
         return;
      }
   }*/
    
}
