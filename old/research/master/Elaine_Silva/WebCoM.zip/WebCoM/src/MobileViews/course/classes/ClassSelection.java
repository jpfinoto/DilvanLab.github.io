/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import agents.security.Ticket;
import agents.agent.Defaults;

/** Class for management of students classes. */
public class ClassSelection implements View, Serializable, ItemListener {
    Ticket tic;
    String operationSelected = null;
    String classSelected = null;
    Vector listClass;
    
    transient Choice operations;
    transient Choice classSelection;
    
    /** Method for creation of new instance from the View class. */
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        sql.init(tic.resource);
        if (!tic.type.equals("administrator") &&
        !tic.type.equals("monitor")) throw new RuntimeException("You don't have permissions to access this tool.");
        
        listClass = new Vector();
        // Select all active classes
        ResultSet rs = sql.executeQuery("SELECT id, expire FROM class");
        for(;rs.next();)
            listClass.addElement("Class " + rs.getString(1));
        sql.close();
        
        return this;
    }
    
    /** Method for creation a graphic interface that allows to select a operation to be executed over one class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,0));
        
        Panel actionsPanel = new Panel();
        actionsPanel.setLayout(new FlowLayout());
        operations = new Choice();
        operations.addItem("Add");
        operations.addItem("Edit");
        operations.addItem("Remove");
        actionsPanel.add(operations);
        operations.addItemListener(this);
        
        Panel listActions = new Panel();
        listActions.setLayout(new FlowLayout());
        listActions.add(new Label("Select an operation: "));
        listActions.add(actionsPanel);
        
        Panel classPanel = new Panel();
        classPanel.setLayout(new FlowLayout());
        classPanel.add(new Label("Select an Class:"));
        
        classSelection = new Choice();
        for (int count = 0; count < listClass.size(); count++)
            classSelection.addItem((String) listClass.elementAt(count));
        
        classSelection.setEnabled(false);
        classPanel.add(classSelection);
        
        principal.add(listActions,BorderLayout.NORTH);
        principal.add(classPanel, BorderLayout.CENTER);
        
        return principal;
    }
    
    /** Method for showing menus when the operations list is changed.*/
    public void itemStateChanged(ItemEvent e) {
        Object source = e.getSource();
        int actionSelected = operations.getSelectedIndex();
        
        // Test the operation selected
        if (source == operations){
            if (((actionSelected == 1) || (actionSelected == 2)) && (classSelection.getSelectedItem() != null)) { // Edit or Remove
                classSelection.setEnabled(true);
            } else
                classSelection.setEnabled(false); // Add new class
        }
    }
    
    /** Method for validation and storing the selected operation and class selected.*/
    public boolean validateView() {
        operationSelected = operations.getSelectedItem();
        classSelected = classSelection.getSelectedItem();
        
        if ((operationSelected.equals("Edit") || (operationSelected.equals("Remove"))) && (classSelected == null)) {
            ErrorWindow er = new ErrorWindow("Don't have any class to edit and remove");
            er.show();
            return false;
        }
        return true;
    }
    
    /** Method that initializes the execution of the selected operation. */
    public synchronized Object updateView(SQL sql) throws Exception {
        // Add new classes
        if (operationSelected.equals("Add")) {
            ClassView classView = new ClassView();
            return classView.createView(tic,sql);
        } else if (operationSelected.equals("Edit")) { // Edit one class
            EditClassSelection editClassSelection = new EditClassSelection();
            editClassSelection.setVariable(classSelected);
            return editClassSelection.createView(tic, sql);
        } else if (operationSelected.equals("Remove")) { // Remove one class
            RemoveClassView removeClassView = new RemoveClassView();
            removeClassView.setVariable(classSelected);
            return removeClassView.createView(tic, sql);
        }
        return "";
    }
}
