/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import course.create.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class for creation of new management area.*/
public class NewCourseView implements View, Serializable, ActionListener {
    transient Label message;
    transient CoursePanel coursePanel;
    transient EndPanel endPanel;
    transient GradePanel gradesPanel;
    transient Button buttonNext, buttonBack;
    transient Panel p1,p2,p3,principal,steps, buttons;
    
    String resource;
    CardLayout card = new CardLayout();
    int controlInterface = 0;
    DataCourse dataCourse;
    boolean okViews = false;
    String separator;
    
    /** Method for creation of new instances from this class.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.resource = tic.resource;
        if (!tic.type.equals("administrator")) throw new RuntimeException("You don't have permissions to access this tool");
        dataCourse = new DataCourse(); // class to store the course basic information
        separator = new String(File.separator);
        return this;
    }
    
    /** Method for creation of graphic interface for this class.*/
    public Panel initView() {
        principal = new Panel();
        message = new Label();
        
        principal.setLayout(new BorderLayout(0,0));
        principal.setFont(new Font("Helvetica", Font.PLAIN, 12));
        
        buttonNext = new Button("  NEXT >> ");
        buttonNext.setBackground(Color.lightGray);
        buttonNext.addActionListener(this);
        
        buttonBack = new Button(" << BACK  ");
        buttonBack.setBackground(Color.lightGray);
        buttonBack.addActionListener(this);
        
        coursePanel = new CoursePanel(separator);
        p1 = coursePanel.initView();
        
        gradesPanel = new GradePanel();
        p2 = gradesPanel.initView();
        
        endPanel = new EndPanel();
        p3 = endPanel.initView();
        
        steps = new Panel();
        steps.setLayout(card);
        steps.add(p1,"Course");
        steps.add(p2,"Grade");
        steps.add(p3,"End");
        
        buttons = new Panel();
        buttons.setLayout(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        buttons.add(buttonBack);
        buttons.add(buttonNext);
        
        card.first(steps);
        buttonBack.setEnabled(false);
        principal.add(steps,BorderLayout.NORTH);
        principal.add(buttons, BorderLayout.CENTER);
        principal.add(message, BorderLayout.SOUTH);
        return principal;
    }
    
    /** Method for controling the users actions over graphic interface objects.*/
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        int errorView;
        ErrorWindow er = null;
        
        if (source == buttonNext) {
            if (controlInterface == 0) {
                errorView = coursePanel.validateView();
                if (errorView == 0) {
                    coursePanel.update(dataCourse);
                    controlInterface = 1;
                    buttonBack.setEnabled(true);
                } else {
                    if (errorView == 1)
                        er = new ErrorWindow("Error in the name for the course.");
                    if (errorView == 2)
                        er = new ErrorWindow("Error in the path for the course.");
                    if (errorView == 3)
                        er = new ErrorWindow("Error in the HTML path for the course.");
                    if (errorView == 4)
                        er = new ErrorWindow("Error in the database name for the course.");
                    if (errorView == 5)
                        er = new ErrorWindow("Invalid Date for the course.");
                    er.show();
                }
            } else if (controlInterface == 1) {
                errorView = gradesPanel.validateView();
                if (errorView == 0) {
                    gradesPanel.update(dataCourse);
                    okViews = true;
                    controlInterface = 2;
                } else {
                    if (errorView == 1)
                        er = new ErrorWindow("Invalid character in Average Value.");
                    if (errorView == 2)
                        er = new ErrorWindow("Value should be smaller than 10.0");
                    if (errorView == 3)
                        er = new ErrorWindow("Missign Grades.");
                    er.show();
                }
            }
            
            if (controlInterface == 0)
                card.show(steps,"Course");
            
            if (controlInterface == 1)
                card.show(steps,"Grade");
            
            if (controlInterface == 2) {
                card.show(steps,"End");
                buttonNext.setEnabled(false);
            }
            return;
        }
        if (source == buttonBack) {
            if (controlInterface == 2) {
                okViews = false;
                controlInterface = 1;
                buttonNext.setEnabled(true);
            } else if (controlInterface == 1) {
                controlInterface = 0;
                buttonBack.setEnabled(false);
            }
            
            if (controlInterface == 1)
                card.show(steps,"Grade");
            if (controlInterface == 0)
                card.show(steps,"Course");
            return;
        }
    }
    
    /** Method for validation of the graphic interface information.*/
    public boolean validateView() {
        ErrorWindow er;
        //Test if the user made all of the tasks
        if (!okViews) {
            er = new ErrorWindow("You have to end the configuration of the course properties");
            er.show();
            return false;
        }
        return true;
    }
    
    /**Method for storing information into the database and for creating directories to the students.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        String instruction = null;
        
        try {
            File directory = new File(dataCourse.course.path);
            if (directory.isDirectory()) {
                UtilFunctions.createDirectoryCourse(dataCourse.course.path);
            } else
                return "The path for the course is invalid.";
        } catch (Exception e) {
            return "Some error ocurred in the generation of directory /homework.";
        }
        
        try {
            sql.drop(dataCourse.databaseName);
        } catch (Exception e) {};
        sql.create(dataCourse.databaseName);
        sql.init(dataCourse.databaseName);
        
        // create tables
        sql.executeUpdate("CREATE TABLE activities (username CHAR(16),type CHAR(16),id INT,group_name CHAR(16),grade FLOAT,class INT)");
        sql.executeUpdate("CREATE TABLE tests (id INT,date DATE,weight INT, class INT)");
        sql.executeUpdate("CREATE TABLE reports (id INT,date DATE,weight INT, class INT)");
        sql.executeUpdate("CREATE TABLE assignments (id INT,date DATE,review_date DATE,weight INT,use_review CHAR(16),class INT)");
        sql.executeUpdate("CREATE TABLE groups (name CHAR(16),assignment INT,project CHAR(32),reviews CHAR(16),grade FLOAT,review_grade FLOAT,creation DATE)");
        sql.executeUpdate("CREATE TABLE projects (name CHAR(32),assignment INT,max_groups INT,min_users INT,max_users INT,class INT)");
        sql.executeUpdate("CREATE TABLE grade_step (name CHAR(16),limit_grade FLOAT)");
        sql.executeUpdate("CREATE TABLE class (id INT,expire DATE, weight_assignment INT, weight_report INT, weight_test INT,creation DATE)");
        sql.executeUpdate("CREATE TABLE students (username CHAR(16),id char(16),class INT)");
        sql.executeUpdate("CREATE TABLE monitors (username CHAR(16),directory CHAR(64),expire DATE)");
        sql.executeUpdate("CREATE TABLE candidates (accepted CHAR(1),info_public CHAR(1),last_name CHAR(32),first_name CHAR(32)," +
        "middle_names CHAR(32),address CHAR(64),zip_code CHAR(16),city CHAR(16),state CHAR(16)," +
        "country CHAR(16),phone CHAR(16),email CHAR(32),homepage CHAR(64),where_work CHAR(16)," +
        "work_name CHAR(32),work_address CHAR(64),school_level CHAR(16),english_level CHAR(16)," +
        "comp_level CHAR(16),java_level CHAR(8),java_use CHAR(16),study_time INT,username CHAR(16)," +
        "id CHAR(16), creation DATE)");
        sql.executeUpdate("CREATE TABLE news (subject CHAR(32),date DATE,time TIME,name CHAR(16),email CHAR(32),body TEXT)");
        
        if (dataCourse.course.useGradeStep) {
            for (int cont=0; cont < dataCourse.numberGradeSteps; cont++) {
                instruction = new String("INSERT INTO grade_step VALUES('" +
                dataCourse.grade[cont].nameGrade + "','" +
                dataCourse.grade[cont].limitGrade + "')");
                sql.executeUpdate(instruction);
            }
        }
        
        sql.close();
        
        // MySQL don't accept \ , only \\
        sql.init(Defaults.WEBCOMDATABASE);
        String pathAux = "";
        for (int i=0; i<dataCourse.course.path.length();i++) {
            if (dataCourse.course.path.charAt(i) == 92)
                pathAux+= "\\\\";
            else
                pathAux+=dataCourse.course.path.charAt(i);
            
        }
        if (dataCourse.course.useGradeStep) {
            instruction = new String("INSERT INTO basic_info VALUES ('" +
            dataCourse.databaseName + "','" +
            dataCourse.course.courseName + "','" +
            UtilFunctions.convertDate(dataCourse.course.beginDate) + "','" +
            pathAux + "','" +
            dataCourse.course.pathHTML + "','" +
            dataCourse.course.useGradeStep + "',0)");
        } else {
            instruction = new String("INSERT INTO basic_info VALUES ('" +
            dataCourse.databaseName + "','" +
            dataCourse.course.courseName + "','" +
            UtilFunctions.convertDate(dataCourse.course.beginDate) + "','" +
            pathAux + "','" +
            dataCourse.course.pathHTML + "','" +
            dataCourse.course.useGradeStep + "'," +
            dataCourse.course.average + ")");
        }
        sql.executeUpdate(instruction);
        sql.close();
        return "Success";
    }
}
