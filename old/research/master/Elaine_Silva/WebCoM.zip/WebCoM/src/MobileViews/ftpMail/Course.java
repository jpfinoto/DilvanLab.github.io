/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package ftpMail;

import java.util.*;
import java.io.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.event.*;
import javax.activation.*;
import javax.mail.search.*;

/** Class for management of the receiving of FTP emails.*/ 
public class Course implements Runnable {
    final static public String SUBJECT= "course"; // subject for the e-mails
    
    String host, username,password, dir;
    int interval;
    
    // flagDelete = true => delete e-mail after reading
    // flagDelete = false => don't delete e-mail after reading
    boolean flagDelete = false;
    
    /* Method for creating a new instance of the class */
    public Course(String host, String username, String password, int interval, String option) {
        this.interval = interval;  // minutes for execute the ftp mail daemon
        if (option.equals("-d"))
            flagDelete = true;
        this.host= host;
        this.username= username;
        this.password= password;
    }
    
    /* Method for executing the search for emails */
    public void run(){
        try {
            do {
                Properties props = System.getProperties();
                
                // Getting a section
                Session session = Session.getDefaultInstance(props, null);
                Store store = session.getStore("imap");
                
                // Conection
                store.connect(host, username, password);
                
                // Openning the folder (INBOX)
                Folder folder = store.getFolder("INBOX");
                folder.open(Folder.READ_WRITE);
                
                SubjectTerm subject= new SubjectTerm(SUBJECT);
                Message[] msgs = folder.search(subject);
                
                for(int i=0;i<msgs.length;i++) {
                    try {
                        if (msgs[i].getSubject().equalsIgnoreCase(SUBJECT)) {
                            getMessage(msgs[i]);
                            if(flagDelete) msgs[i].setFlag(Flags.Flag.DELETED, true);
                        }
                    }
                    catch (Exception e) {}
                }
                
                if(flagDelete) folder.expunge();
                folder.close(false);
                store.close();
                
                if(interval!=0) Thread.sleep(60000*interval);
                
            } while (interval!=0);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    /* Method for reading the email message.*/
    static void getMessage(Message msg) throws IOException, AddressException, MessagingException {
        
        CourseEmail email = new CourseEmail(msg.getFrom());
        Object o = msg.getContent();
        
        // String
        if (o instanceof String) {
            email.envia("ERROR: File not attached!");
            return;
        }
        
        //Extrai o arquivo atachado do e-mail
        Multipart mp = (Multipart)o;
        StringWriter attr = new StringWriter();
        getHeaderMessage(mp.getBodyPart(0), attr);
        email.setMsg2(attr.toString());
        Attributes a = new Attributes();
        try {
            a.init(new StreamTokenizer(new StringReader(attr.toString())));
        } catch (MailftpException e) {
            email.envia("ERROR: " + e.getMessage());
            return;
        }
        
        String auxfile;
        for (int i=1;i<mp.getCount();i++){
            auxfile= a.directory + File.separator + mp.getBodyPart(i).getFileName();
            try {
                partToFile(mp.getBodyPart(i),auxfile);
            } catch (IOException efile) {
                email.envia("ERROR: Can't write: "+ auxfile);
                return;
            }
        }
        String result= "Username: " + a.username + "   Activity: " + a.activity;
        email = new CourseEmail(a.email);
        email.setMsg2(attr.toString());
        email.envia("File(s) uploaded!\n" + result);
    }
    
    /* Method for getting the file for upload*/
    static void getHeaderMessage(Part p, Writer arq) throws IOException, MessagingException{
        InputStream is = p.getInputStream();
        int c;
        while ((c = is.read()) != -1)
            arq.write(c);
        arq.close();
    }
    
    /** Method for getting the file from the messagem and recording it into the correct directory.*/
    static void partToFile(Part p, String arq) throws IOException, MessagingException{
        Object content = p.getContent();
        if (content instanceof InputStream) {
            InputStream in = (InputStream) content;
            OutputStream out = new FileOutputStream(arq);
            int n;
            int count = 0;
            byte buffer[] = new byte[1024];
            while ((n = in.read(buffer)) > 0) {
                out.write(buffer);
                count = count + n;
            }
            in.close();
            out.close();
        }
    }
    
    /* main method */
    public static void main(String argv[]) {
        String ERROR=
        "Usage: java Curso [-d] [-c <interval>] <host> <username> <password>\n" +
        " [-d] - Delete e-mails after their analysis.\n" +
        " [-c <interval>] - Run forever, <interval>= minutes between checks.\n" +
        " <host> - host of the e-mail server\n" +
        " <username> - your username on the e-mail server\n" +
        " <password> -  respective password.\n\n";
        
        String HOW_TO_USE=
        "Some parameters are incorrect or are missing!\n"+
        "How to use: \n"+
        "#coursename\n "+
        "<the name of your course(OOP,MICRO,OS2,etc.)>\n"+
        "#username\n"+
        "<your username>\n"+
        "#activity\n"+
        "<Activity that you are uploading(assignment1, report3, review2, etc.)>";
        
        boolean flagDelete= false;
        String host, username, password;
        int interval =0;
        
        try {
            int n;
            for(n=0; n<argv.length; n++) {
                if (argv[n].equals("-d")) flagDelete= true;
                else
                    if (argv[n].equals("-c")) {
                        interval= ((new Integer(argv[n+1])).intValue());
                        n++;
                    }
                    else break;
            }
            host= argv[n];
            username= argv[n+1];
            password= argv[n+2];
        } catch (RuntimeException e) {
            System.out.println(ERROR);
            System.exit(1);
            return;
        }
        System.out.println("Flag= "+flagDelete);
        System.out.println("\nChecking for messages!");
        
        try {
            do {
                Properties props = System.getProperties();
                
                // Obtendo uma sess�o
                Session session = Session.getDefaultInstance(props, null);
                Store store = session.getStore("imap");
                
                // Conexao
                store.connect(host, username, password);
                
                // Abrindo o folder desejado (INBOX)
                Folder folder = store.getFolder("INBOX");
                if (folder == null || !folder.exists()) {
                    System.out.println("Invalid folder");
                    System.exit(1);
                }
                
                folder.open(Folder.READ_WRITE);
                
                String subject= SUBJECT;
                Message[] msgs = folder.search(new SubjectTerm(subject));
                System.out.println(msgs.length + " found with subject " + subject + "!");
                
                for(int i=0;i<msgs.length;i++) {
                    System.out.println("\nMessage "+(i+1));
                    try {
                        getMessage(msgs[i]);
                        if(flagDelete) msgs[i].setFlag(Flags.Flag.DELETED, true);
                    }
                    catch (Exception e) {
                        System.out.println(e);
                    }
                }
                
                if(flagDelete) folder.expunge();
                folder.close(false);
                store.close();
                
                if(interval!=0) Thread.sleep(60000*interval);
                
            } while (interval!=0);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}