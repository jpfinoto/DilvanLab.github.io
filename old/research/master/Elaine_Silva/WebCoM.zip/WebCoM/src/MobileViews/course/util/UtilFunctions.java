/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.util;

import java.util.*;
import java.sql.Date;
import java.io.*;

/** Class with util functions.*/
public class UtilFunctions {
    
    /** Method for validation of fields. All the characters of the string have to be into the characters list.*/
    public static boolean validateField(String field, String characters) {
        for (int count=0;count < field.length(); count++) {
            if (characters.indexOf(field.charAt(count)) == -1)
                return false;
        }
        return true;
    }
    
    /** Method for converting the date string in the database date format.*/
    public static String convertDate(String date) {
        StringTokenizer stoken = new StringTokenizer(date,"/");
        String token = null;
        String day = null;
        String month = null;
        String year = null;
        try {
            month = stoken.nextToken();
            day = stoken.nextToken();
            year = stoken.nextToken();
        } catch (NoSuchElementException e) {}
        return year + "-" + month + "-" + day;
    }
    
    /** Method for converting the database date format in the date string.*/
    public static String deconvertDate(String date) {
        StringTokenizer stoken = new StringTokenizer(date,"-");
        String token = null;
        String day = null;
        String month = null;
        String year = null;
        try {
            year = stoken.nextToken();
            month = stoken.nextToken();
            day = stoken.nextToken();
        } catch (NoSuchElementException e) {}
        return month + "/" + day + "/" + year;
    }
    
    /** Method for deleting directories when a group is removed.*/
    public static void deleteDirectoriesGroup(String directoryCourse, int assignmentSelected, String nameGroup, int classId) {
        
        File studentDirectory = new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator +
        "assignments" + File.separator + assignmentSelected + File.separator +
        nameGroup + File.separator);
        studentDirectory.renameTo(new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator +
        "trash" + File.separator + "assignment_" + assignmentSelected + "_" +
        nameGroup + File.separator));
        
        studentDirectory = new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "reviews" +
        File.separator + assignmentSelected + File.separator + nameGroup + File.separator);
        
        studentDirectory.renameTo(new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "trash" +
        File.separator + "review_" + assignmentSelected + "_" + nameGroup + File.separator));
    }
    
    /** Method for creation of directories when a group is created.*/
    public static void createDirectoriesGroup(String directoryCourse, int assignmentSelected, String nameGroup, int classId) {
        
        File dir = new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "assignments" + File.separator +
        assignmentSelected + File.separator + nameGroup);
        dir.mkdir();
        
        dir = new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "reviews" + File.separator +
        assignmentSelected + File.separator + nameGroup);
        dir.mkdir();
    }
    
    /** Method for deleting directories when a student is removed.*/
    public static void deleteDirectoriesStudent(String directoryCourse, int report, String username, int classId) {
        
        File studentDirectory = new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "reports" +
        File.separator + report + File.separator + username + File.separator);
        studentDirectory.renameTo(new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "trash" +
        File.separator + "report_" + report + "_" + username + File.separator));
    }
    
    /** Method for creation of directories when a student is created.*/
    public static void createDirectoriesStudent(String directoryCourse, int report, String username, int classId) {
        File dir = new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "reports" + File.separator +
        report + File.separator + username);
        dir.mkdir();
    }
    
    /** Method for verifying dates.*/
    public static int verifyDate(java.util.Date sysDate, java.sql.Date sqlDate) {
        // Getting Current System Date
        java.util.Calendar aux = Calendar.getInstance();
        
        java.util.Calendar systemDate = Calendar.getInstance();
        aux.setTime(sysDate);
        systemDate.set(aux.get(Calendar.YEAR), aux.get(Calendar.MONTH),aux.get(Calendar.DAY_OF_MONTH),0,0,0);
        
        // Initialising variables
        java.sql.Date baseDate = new java.sql.Date(new java.util.Date().getTime());
        baseDate = sqlDate;
        
        // Converting sql date to util date
        java.util.Date date = new java.util.Date(baseDate.getTime());
        
        // converting util to calendar
        java.util.Calendar databaseDate = Calendar.getInstance();
        aux.setTime(date);
        databaseDate.set(aux.get(Calendar.YEAR), aux.get(Calendar.MONTH),aux.get(Calendar.DAY_OF_MONTH),0,0,0);
        
        if (databaseDate.after(systemDate)) // sqlDate after sysDate
            return 1;
        else
            if (databaseDate.before(systemDate))// sqlDate before sysDate
                return -1;
            else // sqlDate equals sysDate
                return 0;
    }
    
    /** Method for creation of directories when a class is created.*/
    public static void createDirectoryClass(String directoryCourse, int numAssignments, int numReports, int classId) {
        
        //  /homework/<class>
        new File(directoryCourse + File.separator + "homework" + File.separator + classId).mkdir();
        
        //  /homework/<class>/assignments
        new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "assignments").mkdir();
        //  /homework/<class>/reviews
        new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "reviews").mkdir();
        for (int count = 1; count <= numAssignments; count++)
            createDirectoryAssignment(directoryCourse, count, classId);
        
        //  /homework/<class>/reports
        new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "reports").mkdir();
        for (int count = 1; count <= numReports; count++)
            createDirectoryReport(directoryCourse, count, classId);
        
        //  /homework/<class>/trash
        new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "trash").mkdir();
    }
    
    /** Method for creation of assignment directory.*/
    public static void createDirectoryAssignment(String directoryCourse, int idAssignment, int classId) {
        new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "assignments" + File.separator + idAssignment).mkdir();
        new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "reviews" + File.separator + idAssignment).mkdir();
    }
    
    /** Method for creation of report directory.*/
    public static void createDirectoryReport(String directoryCourse, int idReport, int classId) {
        new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "reports" + File.separator + idReport).mkdir();
    }
    
    /** Method for removing assignment directory.*/
    public static void deleteDirectoryAssignment(String directoryCourse, int idAssignment, int classId) {
        new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "assignments" + File.separator + idAssignment).delete();
        new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "reviews" + File.separator + idAssignment).delete();
    }
    
    /** Method for removing report directory.*/
    public static void deleteDirectoryReport(String directoryCourse, int idReport, int classId) {
        new File(directoryCourse + File.separator + "homework" + File.separator + classId + File.separator + "reports" + File.separator + idReport).delete();
    }
    
    /** Method for creation of course directory.*/
    public static void createDirectoryCourse(String directoryCourse) {
        new File(directoryCourse + File.separator + "homework").mkdir();
    }
    
    /** Method for removing Class directory when the class is removed.*/
    public static void deleteDirectoryClass(String directoryCourse, int classId) {
        //  /homework/<class>
        Calendar calendar = Calendar.getInstance();
        java.util.Date date = new java.util.Date();
        calendar.setTime(date);
        String id = calendar.get(calendar.DAY_OF_MONTH) + "_" + calendar.get(calendar.MONTH) + "_" + calendar.get(calendar.YEAR) + "_" +
        calendar.get(calendar.HOUR) + calendar.get(calendar.MINUTE) + calendar.get(calendar.SECOND);
        String deletedDirectoryClass = directoryCourse + File.separator + "homework" + File.separator + classId + "_Deleted_" + id;
        new File(directoryCourse + File.separator + "homework" + File.separator + classId).renameTo(new File(deletedDirectoryClass));
    }
    
}