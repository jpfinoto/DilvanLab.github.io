/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents;

import java.sql.*;
import java.util.*;
import java.io.IOException;

/** Interface for manipulation of database.*/
public interface SQL {
    
    /** Method for returning the amount 23h 59min 59s in miliseconds. It is used to control the validate of the ticket.*/
    public long MS_23H59M59S= ((23*60+59)*60+59)*1000;
    
    /** Method for deleting a database.*/
    public void drop(String database) throws IOException;
    
    /** Method for creating a database.*/
    public void create(String database) throws IOException;
    
    /** Method for connecting to one database.*/
    public void init(String resource) throws SQLException;
    
    /** Method for executing a query in a connected database.*/
    public ResultSet executeQuery(String query) throws SQLException;
    
    /** Method for executing a update in a connected database.*/
    public int executeUpdate(String query) throws SQLException;
    
    /** Method for closing the connect with the database.*/
    public void close() throws SQLException;
    
    /** Method for getting the password of the user from the database.*/
    public String getPassword(String username) throws SQLException;
    
    /** Method for getting the user directory for executing FTP.*/
    public String getDirectory(String username, String dir, java.util.Date exp_date, String directoryCourse, int classSelected) throws SQLException;
}
