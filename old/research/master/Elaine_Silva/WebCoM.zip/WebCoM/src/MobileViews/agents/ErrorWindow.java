/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents;

import java.awt.*;
import java.awt.event.*;

/** Class for presentation of error messages.*/
public class ErrorWindow extends Frame implements ActionListener {
    
    /** Method for creation of a new instance from this class.In the graphic interface are presented the message and a ok button.*/
    public ErrorWindow(String message) {
        ImageLoader jImage = new ImageLoader();
        Canvas canvas = new Canvas();
        Image icon;
        
        // Image warning
        icon = jImage.loadImage("warning.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(40,40);
        
        // Set layout, background and title to the frame
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.lightGray);
        setTitle("Error");
        
        // Panel principal
        Panel principal = new Panel();
        principal.setLayout(new GridLayout(0,1));
        
        // Panel for the error message
        Panel messagePanel = new Panel();
        messagePanel.setLayout(new FlowLayout());
        
        Label m= new Label("  " + message + "  ");
        m.setFont(new Font("Helvetica", Font.BOLD, 12));
        
        // add canvas and the error message in panel messagePanel
        messagePanel.add(canvas);
        messagePanel.add(m);
        
        // add panel in the panel principal
        principal.add(messagePanel);
        add("Center", principal);
        
        Button buttonOk = new Button("    OK    ");
        buttonOk.addActionListener(this);
        buttonOk.setBackground(Color.lightGray);
        
        principal = new Panel();
        principal.add(buttonOk);
        add("South", principal);
        
        // Listener to close window
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                setVisible(false);
            }
        });
        
        pack();
    }
    
    /** Method for closing the window when the ok button is pressed.*/
    public void actionPerformed(ActionEvent e) {
        setVisible(false);
    }
}



