/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.groups;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class for creation of students groups.*/
public class CreationGroupView implements View, Serializable, ActionListener {
    Vector projects;
    Vector members;
    String username;
    String resource;
    String project;
    String group = null;
    int min_students = 0;
    int max_students = 0;
    int countList = 0;
    int numberAssignment;
    public static int classGroup; // class of the group got from the GroupSelection class
    public static int assignmentSelected;
    
    transient Choice projectsList;
    transient TextField groupName;
    transient TextField newMember;
    transient java.awt.List membersList;
    transient Button add,remove;
    transient TextField assignmentID;
    
    /** Method for creation of a new instance from the View class. All the projects are got.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        ResultSet rs;
        ResultSet rs1;
        this.resource = tic.resource;
        this.username = tic.username.toLowerCase();
        int count;
        
        projects = new Vector();
        
        sql.init(resource);
        
        // Get the data and information to the each projects from the student class
        rs = sql.executeQuery("SELECT name,min_users,max_users FROM projects WHERE assignment='" + assignmentSelected +
        "' AND class='" + classGroup + "'");
        for (count = 0;rs.next();count++)
            projects.addElement(rs.getString(1) + "  Min_Students= " + rs.getString(2) + "  Max_Students= " + rs.getString(3));
        
        sql.close();
        numberAssignment=assignmentSelected;
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        ImageLoader jImage = new ImageLoader();
        Canvas canvas = new Canvas();
        Image icon;
        
        assignmentID = new TextField("Assignment " + numberAssignment);
        assignmentID.setForeground(Color.blue);
        assignmentID.setFont(new Font("Helvetica",Font.BOLD,12));
        assignmentID.setEditable(false);
        
        groupName = new TextField(5);
        newMember = new TextField(5);
        newMember.addActionListener(this);
        
        membersList = new java.awt.List(3,false);
        membersList.addItem(username);
        add = new Button("Add");
        add.addActionListener(this);
        remove = new Button("Remove");
        remove.addActionListener(this);
        
        projectsList = new Choice();
        for (int count = 0; count < projects.size();count++)
            projectsList.addItem((String) projects.elementAt(count));
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        //label Group for
        Label label = new Label("Group Creation for  ");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label Group Name
        label = new Label("Group Name");
        constraints.gridx = 0;
        constraints.gridy = 2;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label projects
        label = new Label("Project");
        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.insets = new Insets(0,10,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label New Student
        label = new Label("New Member");
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //label List of Members
        label = new Label("Members");
        constraints.gridx = 2;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,10,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        //Textfield assignmentID
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.insets = new Insets(0,0,0,0);
        gridBag.setConstraints(assignmentID,constraints);
        form.add(assignmentID);
        
        //Textfield groupName
        constraints.gridx = 0;
        constraints.gridy = 3;
        gridBag.setConstraints(groupName,constraints);
        form.add(groupName);
        
        //Textfield newMember
        constraints.gridx = 0;
        constraints.gridy = 5;
        gridBag.setConstraints(newMember,constraints);
        form.add(newMember);
        
        //Choice projectsList
        constraints.gridx = 1;
        constraints.gridy = 3;
        constraints.gridwidth = 3;
        constraints.insets = new Insets(0,10,0,0);
        gridBag.setConstraints(projectsList,constraints);
        form.add(projectsList);
        
        //Button add
        constraints.gridx = 1;
        constraints.gridy = 5;
        constraints.gridwidth = 1;
        gridBag.setConstraints(add,constraints);
        form.add(add);
        
        //Button remove
        constraints.gridx = 1;
        constraints.gridy = 6;
        gridBag.setConstraints(remove,constraints);
        form.add(remove);
        
        //List of Members
        constraints.gridx = 2;
        constraints.gridy = 5;
        constraints.gridwidth = 2;
        constraints.gridheight = 3;
        gridBag.setConstraints(membersList,constraints);
        form.add(membersList);
        
        groupForm.add(form,BorderLayout.CENTER);
        
        icon = jImage.loadImage("groups.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(430,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas, BorderLayout.NORTH);
        
        principal.add(groupForm);
        return principal;
    }
    /** Method for controlling the student action over the the graphic interface. This method control the members list.*/
    public void actionPerformed(ActionEvent ev){
        Object source = ev.getSource();
        if ((source == newMember) || (source == add)) {
            addItem(newMember.getText().toLowerCase());
        }
        if (source == remove) {
            // the student that is creating the group can't be removed
            if (membersList.getSelectedItem().equals(username)) {
                ErrorWindow errorWindow = new ErrorWindow("This user can't be removed because he is the group creator.");
                errorWindow.show();
            } else
                // get all members
                membersList.delItem(membersList.getSelectedIndex());
        }
        
    }
    /** Method for controlling the addition of names into the members list.*/
    void addItem(String item) {
        boolean error = false;
        int numberItens = membersList.getItemCount();
        ErrorWindow errorWindow;
        
        if (item.equals("")) {
            errorWindow = new ErrorWindow("Invalid Member.");
            errorWindow.show();
            error = true;
        } else if (item.indexOf(' ') != -1) {
            errorWindow = new ErrorWindow("Spaces not allowed in the member name.");
            errorWindow.show();
            error = true;
        }
        
        for (int c=0; c < numberItens; c++) {
            if(item.equals(membersList.getItem(c))) {
                errorWindow = new ErrorWindow("This user already is in the list.");
                errorWindow.show();
                error = true;
            }
        }
        
        if (!error) {
            membersList.addItem(item);
            newMember.setText("");
            newMember.requestFocus();
        }
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        ErrorWindow errorWindow;
        String token;
        StringTokenizer stoken;
        
        // Verify the name of the group
        if (groupName.getText().equals("")) {
            errorWindow = new ErrorWindow("Missing Group Name.");
            errorWindow.show();
            return false;
        } else if (groupName.getText().indexOf(' ') != -1){
            errorWindow = new ErrorWindow("Spaces are not allowed in Group Name.");
            errorWindow.show();
            return false;
        } else if (!UtilFunctions.validateField(groupName.getText(),"abcdefghijklmnopqrstuvxzwyABCDEFGHIJKLMNOPQRSTUVXZWV" +
        "1234567890-_")) {
            errorWindow = new ErrorWindow("Invalid Character in Group Name.");
            errorWindow.show();
            return false;
        } else if (groupName.getText().length() > 16) {
            errorWindow = new ErrorWindow("The Group Name should be smaller than 16 characters.");
            errorWindow.show();
            return false;
        }
        
        group = groupName.getText();
        
        // Verify the number of members of the project and of the list
        stoken = new StringTokenizer(projectsList.getSelectedItem(), " ");
        project = stoken.nextToken();
        try {
            token = stoken.nextToken();
            if (token.equals("Min_Students=")) {
                token = stoken.nextToken();
                min_students = Integer.parseInt(token);
            }
            token = stoken.nextToken();
            if (token.equals("Max_Students=")) {
                token = stoken.nextToken();
                max_students = Integer.parseInt(token);
            }
        } catch (NoSuchElementException e) {}
        countList = membersList.getItemCount();
        if ((countList > max_students) || (countList < min_students)) {
            errorWindow = new ErrorWindow("Incorrect number of members.");
            errorWindow.show();
            return false;
        }
        // create a vector with the members usernames.
        members = new Vector();
        for (int c=0;c<countList;c++)
            members.addElement(membersList.getItem(c));
        
        return true;
    }
    
    /** Method for management of database information.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        int numGroups;
        int id_class = 0;
        ResultSet rs;
        java.util.Date date = new java.util.Date();
        
        sql.init(resource);
        
        for (int count = 0;count < members.size();count++) {
            // Test if each username is a student of this course
            rs = sql.executeQuery("SELECT username FROM students WHERE class='" + classGroup + "' AND username='" +
            members.elementAt(count) + "'");
            if (!rs.next()) throw new RuntimeException("The name " + members.elementAt(count) + " is not a student of your class.");
            // Test if each username is not of another group
            rs = sql.executeQuery("SELECT username FROM activities WHERE type='groups' AND id='" + assignmentSelected +
            "' AND username='" + members.elementAt(count) + "' AND class=" + classGroup);
            if (rs.next()) throw new RuntimeException("The user " + members.elementAt(count) + " is registred in another group.");
            
        }
        //Test if the name of the group already exists
        rs = sql.executeQuery("SELECT username FROM activities WHERE group_name='" + group +
        "' and id='" + assignmentSelected + "'");
        if (rs.next()) throw new RuntimeException("This Group Name already exists.Choose another.");
        
        //  Test the number of projects already locked
        rs = sql.executeQuery("SELECT max_groups FROM projects WHERE assignment='" + assignmentSelected +
        "' AND name='" + project + "' AND class='" + classGroup + "'");
        rs.next();
        // get the max_groups to this project
        numGroups = rs.getInt(1);
        
        // get the number of groups to this project
        rs = sql.executeQuery("SELECT DISTINCT groups.name FROM groups,activities WHERE groups.project='" + project +
        "' AND activities.class='" + classGroup + "' AND groups.assignment='" + assignmentSelected +
        "' AND groups.name=activities.group_name");
        for(;rs.next();numGroups--);
        if (numGroups <= 0) throw new RuntimeException("Too many groups got this project already, choose another.");
        
        //Insert the values in DB if all is correct
        sql.executeUpdate("INSERT INTO groups VALUES ('" + group + "'," + assignmentSelected + ", '" +
        project + "', '', 0, 0, CURDATE())");
        
        for (int c = 0;c < members.size();c++)
            sql.executeUpdate("INSERT INTO activities VALUES ('" + members.elementAt(c) + "', 'groups'," +
            assignmentSelected + ", '" + group + "',0,'" + classGroup +"')");
        
        sql.close();
        sql.init(Defaults.WEBCOMDATABASE);
        //  Get base directory
        rs = sql.executeQuery("SELECT directory FROM basic_info WHERE database_name='" + resource + "'");
        rs.next();
        sql.close();
        //  Create directories
        UtilFunctions.createDirectoriesGroup(rs.getString(1), assignmentSelected, group, classGroup);
        return "Success";
    }
    
}
