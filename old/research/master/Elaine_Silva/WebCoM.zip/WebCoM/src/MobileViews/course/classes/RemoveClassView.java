/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.classes;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.*;
import agents.security.*;
import agents.agent.*;
import agents.util.*;
import course.create.*;
import course.util.UtilFunctions;

/** Class for removing one class. */
public class RemoveClassView implements View, Serializable {
    transient ClassPanel classPanel;
    transient Panel p1;
    
    String resource;
    int idClass;
    Ticket tic;
    DataActivities dataActivities = new DataActivities(); // class to store the course basic information
    
    /** Method for setting variables.*/
    public void setVariable(String classSelected) {
        StringTokenizer analex = new StringTokenizer(classSelected);
        String token = analex.nextToken();
        try {
            idClass = Integer.parseInt(analex.nextToken());
        } catch (Exception e) {}
    }
    
    /** Method for creation of new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.resource = tic.resource;
        this.tic = tic;
        // get date for class selected
        sql.init(resource);
        ResultSet rs = sql.executeQuery("SELECT expire FROM class WHERE id='" + idClass + "'");
        rs.next();
        dataActivities.expireClass=UtilFunctions.deconvertDate(rs.getString(1));
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,0));
        principal.setFont(new Font("Helvetica", Font.PLAIN, 12));
        
        classPanel = new ClassPanel(idClass,0,dataActivities);
        p1 = classPanel.initView();
        principal.add(p1, BorderLayout.CENTER);
        Label message = new Label("PRESS SEND BUTTON TO REMOVE ALL OF INFORMATION ABOUT THIS CLASS.");
        message.setForeground(Color.red);
        message.setFont(new Font("Helvetica", Font.BOLD, 10));
        principal.add(message, BorderLayout.SOUTH);
        return principal;
    }
    
    /** Method for validation of the graphic interface information. */
    public boolean validateView() {
        return true;
    }
    
    /** Method for management of the database information about one class.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        ResultSet rs, rs1;
        Vector students = new Vector();
        Vector studentsForRemove = new Vector();
        CourseEmail courseEmail;
        String directory, courseName;
        
        sql.init(resource);
        sql.executeUpdate("DELETE FROM tests WHERE class="+ idClass);
        sql.executeUpdate("DELETE FROM reports WHERE class="+ idClass);
        sql.executeUpdate("DELETE FROM assignments WHERE class="+ idClass);
        rs = sql.executeQuery("SELECT DISTINCT group_name FROM activities WHERE type='groups' AND class=" + idClass);
        for (;rs.next();)
            sql.executeUpdate("DELETE FROM groups WHERE name='"+ rs.getString(1) + "'");
        sql.executeUpdate("DELETE FROM activities WHERE class="+ idClass);
        sql.executeUpdate("DELETE FROM projects WHERE class="+ idClass);
        sql.executeUpdate("DELETE FROM class WHERE id="+ idClass);
        
        rs = sql.executeQuery("SELECT username FROM students WHERE class=" + idClass);
        for (;rs.next();) {
            // verify if the student is in another class
            rs1 = sql.executeQuery("SELECT COUNT(*) FROM students WHERE username='" + rs.getString(1) + "' AND class!=" + idClass);
            rs1.next();
            if (rs1.getInt(1) == 0) // the student is only in this class
                students.addElement(rs.getString(1));
        }
        sql.close();
        
        sql.init(Defaults.WEBCOMDATABASE);
        // get the root directory of this course
        rs = sql.executeQuery("SELECT directory, course_name FROM basic_info WHERE database_name='" + resource + "'");
        rs.next();
        directory = rs.getString(1);
        courseName = rs.getString(2);
        
        // Verify if the student is registred in another course
        rs = sql.executeQuery("SELECT database_name FROM basic_info WHERE database_name!='" + tic.resource + "'");
        sql.close();
            
        // Verify in each database
        for (; rs.next();) {
            sql.init(rs.getString(1));
            for (int i=0; i < students.size(); i++) {
                rs1 = sql.executeQuery("SELECT DISTINCT username FROM students WHERE username='" + students.elementAt(i) + "'");
                if (!rs1.next()) {
                    rs1 = sql.executeQuery("SELECT username FROM monitors WHERE username='" + students.elementAt(i) + "'");
                    if (!rs1.next())
                        studentsForRemove.addElement(students.elementAt(i));
                }
            }
            sql.close();
        }
        
        sql.init(Defaults.WEBCOMDATABASE);
        for (int i=0; i < studentsForRemove.size();i++) {
            rs = sql.executeQuery("SELECT email FROM users WHERE username='" + studentsForRemove.elementAt(i) + "'");
            rs.next();
            sql.executeUpdate("DELETE FROM users WHERE username='" + studentsForRemove.elementAt(i) + "'");
            try {
                courseEmail = new CourseEmail(rs.getString(1));
                courseEmail.envia(Defaults.FROM, Defaults.HOST, "Course Manager",
                "Message from Course Administrator: \n" +
                "Your class in the course " + courseName + " was removed.\n" +
                "For more information, contact the course administrator.\n");
            }catch (Exception e) {};
        }
        sql.close();

        sql.init(resource);
        sql.executeUpdate("DELETE FROM students WHERE class="+ idClass);        
        sql.close();
        
        // remove directories of activities
        try {
            UtilFunctions.deleteDirectoryClass(directory, idClass);
        } catch (Exception e) {return "Error deleting directory /homework/class. Directories not deleted.";};
        
        ClassSelection classSelection = new ClassSelection();
        return classSelection.createView(tic,sql);
    }
}
