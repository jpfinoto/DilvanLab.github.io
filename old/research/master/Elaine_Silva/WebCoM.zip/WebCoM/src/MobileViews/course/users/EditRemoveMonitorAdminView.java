/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.users;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;

/** Class for removing or edition monitor and administator users.*/
public class EditRemoveMonitorAdminView extends Panel implements View {
    String username;
    Ticket tic;
    
    public String userTypeSelected = null;
    public String operationSelected = null;
    
    Vector listUsers;
    transient java.awt.List user;
    
    /** Method for setting variable. It sets the user type (monitor, adminstator) and the operation (edit or remove).*/
    public void setVariable(String type, String operation) {
        this.userTypeSelected = type;
        this.operationSelected = operation;
    }
    
    /** Method for creation of a new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.tic = tic;
        ResultSet rs = null, rs1;
        listUsers = new Vector();
        // test the user type (user of the login)
        if (!tic.type.equals("administrator")) throw new RuntimeException("You don't have permissions to access this tool.");
        
        if (userTypeSelected.equals("monitor")) {
            sql.init(tic.resource);
            rs = sql.executeQuery("SELECT username FROM monitors ORDER BY username");
            sql.close();
        }
        
        sql.init(Defaults.WEBCOMDATABASE);
        if (userTypeSelected.equals("monitor")) {
            for (;rs.next();) {
                rs1 = sql.executeQuery("SELECT first_name, last_name FROM users WHERE username='" + rs.getString(1) + "'");
                if (rs1.next())
                    listUsers.addElement(rs.getString(1) + "  ->  " + rs1.getString(1) + " " + rs1.getString(2));
            }
        }
        else {
            rs = sql.executeQuery("SELECT username, first_name, last_name FROM users WHERE type='administrator' and username != 'root' ORDER BY username");
            if (rs.next())
                listUsers.addElement(rs.getString(1) + "  ->  " + rs.getString(2) + " " + rs.getString(3));
        }
        sql.close();
        
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Image icon;
        Canvas canvas = new Canvas();
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        user = new java.awt.List(10,false);
        for (int count = 0; count < listUsers.size(); count++)
            user.add((String) listUsers.elementAt(count));
        user.setBackground(Color.white);
        
        if (userTypeSelected.equals("monitor"))
            groupForm.add(new Label("Select one Monitor:"), BorderLayout.CENTER);
        else
            groupForm.add(new Label("Select one Administrator:"), BorderLayout.CENTER);
        
        groupForm.add(user, BorderLayout.SOUTH);
        
        ImageLoader jImage = new ImageLoader();
        if (userTypeSelected.equals("monitor"))
            icon = jImage.loadImage("monitor.gif");
        else
            icon = jImage.loadImage("administrator.gif");
        
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(380,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        String aux = user.getSelectedItem();  // selected user
        username = aux.substring(0,aux.indexOf(' '));
        return true;
    }
    
    /** Method that invoke the class for executing the operation selected. 
      * If the selected operation is edit, other class is invoked, else, 
      * it removes the monitor or the administrator managing the database information.*/
    public Object updateView(SQL sql) throws Exception {
        // operation : edit
        if (operationSelected.equals("edit")) {
            if (userTypeSelected.equals("monitor")) {
                EditMonitorView editMonitorView = new EditMonitorView();
                editMonitorView.setUserSelected(username);
                return editMonitorView.createView(tic,sql);
            } else { // administrator
                EditAdminView editAdminView = new EditAdminView();
                editAdminView.setUserSelected(username);
                return editAdminView.createView(tic,sql);
            }
        }
        // operation: remove
        if (operationSelected.equals("remove")) {
            boolean monitorOtherCourse = false;
            
            if (userTypeSelected.equals("monitor")) {
                sql.init(tic.resource);
                sql.executeUpdate("DELETE FROM monitors WHERE username='" + username + "'");
                sql.close();
                sql.init(Defaults.WEBCOMDATABASE);
                
                // Verify in others courses if the monitor is registred
                ResultSet rs = sql.executeQuery("SELECT database_name FROM basic_info WHERE database_name!='" + tic.resource + "'");
                sql.close();
                ResultSet rs1;
                if (rs.next()) {
                    do {
                        sql.init(rs.getString(1));
                        rs1 = sql.executeQuery("SELECT username FROM monitors WHERE username='" + username + "'");
                        if (rs1.next()) {
                            monitorOtherCourse = true;
                            for(;rs.next(););
                        }
                        rs1 = sql.executeQuery("SELECT username FROM students WHERE username='" + username + "'");
                        if (rs1.next()) {
                            monitorOtherCourse = true;
                            for(;rs.next(););
                        }
                        sql.close();
                    } while (rs.next());
                }
                
            }
            if (!monitorOtherCourse) {
                sql.init(Defaults.WEBCOMDATABASE);
                sql.executeUpdate("DELETE FROM users WHERE username='" + username + "'");
                sql.close();
            }
            UserSelectionView userSelectionView = new UserSelectionView();
            return userSelectionView.createView(tic,sql);
        }
        return "";
    }
}
