/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.users;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import agents.util.CourseEmail;
import course.util.UtilFunctions;

/** Class for edition of student user.*/
public class EditStudentView extends Panel implements View {
    String FirstName, LastName, Password, NewPassword;
    String email, emailOld;
    String classStudent;
    String idStudent;
    
    String idNumber;
    Ticket tic;
    
    public int classSelected;
    public String username;
    
    transient TextField fStudent,lStudent,userName;
    transient TextField passwdStudent,passwdStudent2;
    transient TextField emailStudent;
    transient TextField idNumberStudent;
    transient Choice listClassChoice;
    
    /** Method for setting variables. It sets the selected class and student username.*/
    public void setVariable(int classSelected, String username) {
        this.classSelected = classSelected;
        this.username = username;
    }
    
    /** Method for creation of a new instance from the View course. It returns a student list.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.tic = tic;
        ResultSet rs;
        
        sql.init(Defaults.WEBCOMDATABASE);
        rs = sql.executeQuery("SELECT first_name, last_name, password, email FROM users WHERE username='" +
        username + "'");
        rs.next();
        FirstName = rs.getString(1);
        LastName = rs.getString(2);
        Password = rs.getString(3);
        emailOld = rs.getString(4);
        sql.close();
        
        sql.init(tic.resource);
        rs = sql.executeQuery("SELECT id, class FROM students WHERE username='" + username + "'");
        rs.next();
        classStudent = "Class " + rs.getInt(2);
        // the id number is not needed
        try {
            idStudent = String.valueOf(rs.getInt(1));
        } catch (Exception e) {}
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Image icon;
        Canvas canvas = new Canvas();
        
        fStudent = new TextField(FirstName);
        lStudent = new TextField(LastName);
        userName = new TextField(username);
        passwdStudent = new TextField(Password);
        passwdStudent2 = new TextField(Password);
        emailStudent = new TextField(emailOld);
        idNumberStudent = new TextField(idStudent);
        
        listClassChoice = new Choice();
        listClassChoice.addItem(classStudent);
        listClassChoice.setEnabled(false);
        
        setFont(new Font("Helvetica",Font.PLAIN,11));
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        // label username
        Label label = new Label("Username");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        
        // label first name
        constraints.gridx = 0;
        constraints.gridy = 2;
        label = new Label("First Name");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label last name
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.insets = new Insets(0,5,0,0);
        label = new Label("Last Name");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label password
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,0,0,5);
        label = new Label("Type Password");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label retype password
        constraints.gridx = 2;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,5,0,0);
        label = new Label("Retype Password");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label e-mail
        constraints.gridx = 0;
        constraints.gridy = 6;
        constraints.insets = new Insets(0,0,0,5);
        label = new Label("E-mail");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label Id Number
        label = new Label("Id Number");
        constraints.gridx = 0;
        constraints.gridy = 8;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label class
        label = new Label("Class     ");
        constraints.gridx = 2;
        constraints.gridy = 8;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label
        label = new Label("          ");
        constraints.gridx = 1;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        label = new Label("          ");
        constraints.gridx = 3;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // field username
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        userName.setEditable(false);
        gridBag.setConstraints(userName,constraints);
        form.add(userName);
        
        // field first name Student
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        constraints.insets = new Insets(0,0,0,5);
        gridBag.setConstraints(fStudent,constraints);
        form.add(fStudent);
        
        // field last name Student
        constraints.gridx = 2;
        constraints.gridy = 3;
        constraints.insets = new Insets(0,5,0,0);
        gridBag.setConstraints(lStudent,constraints);
        form.add(lStudent);
        
        // field password
        constraints.gridx = 0;
        constraints.gridy = 5;
        constraints.insets = new Insets(0,0,0,5);
        passwdStudent.setEchoChar('*');
        gridBag.setConstraints(passwdStudent,constraints);
        form.add(passwdStudent);
        
        // field retype password
        constraints.gridx = 2;
        constraints.gridy = 5;
        constraints.insets = new Insets(0,5,0,0);
        passwdStudent2.setEchoChar('*');
        gridBag.setConstraints(passwdStudent2,constraints);
        form.add(passwdStudent2);
        
        // field email
        constraints.gridx = 0;
        constraints.gridy = 7;
        constraints.gridwidth = 4;
        constraints.insets = new Insets(0,0,0,5);
        gridBag.setConstraints(emailStudent,constraints);
        form.add(emailStudent);
        
        // field Id Number
        constraints.gridx = 0;
        constraints.gridy = 9;
        constraints.gridwidth = 2;
        gridBag.setConstraints(idNumberStudent,constraints);
        form.add(idNumberStudent);
        
        // field class
        constraints.gridx = 2;
        constraints.gridy = 9;
        constraints.gridwidth = 2;
        gridBag.setConstraints(listClassChoice,constraints);
        form.add(listClassChoice);
        
        groupForm.add(form,BorderLayout.CENTER);
        
        ImageLoader jImage = new ImageLoader();
        icon = jImage.loadImage("student.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(430,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        ErrorWindow er;
        // Test the first and last name fields. The username field can't be changed
        if ((!fStudent.getText().equals("")) || (!lStudent.getText().equals(""))) {
            if ((fStudent.getText().indexOf("'") != -1) || (lStudent.getText().indexOf("'") != -1)) {
                er = new ErrorWindow("Invalid character in First Name or Last Name");
                er.show();
                return false;
            } else if ((fStudent.getText().length() > 32) || (lStudent.getText().length() > 32)) {
                er = new ErrorWindow("First Name and Last Name should be smaller than 32 characters");
                er.show();
                return false;
            } else if ((fStudent.getText().indexOf(' ') != -1) || (lStudent.getText().indexOf(' ') != -1)){
                if ((fStudent.getText().indexOf(' ') != fStudent.getText().length()) ||
                (lStudent.getText().indexOf(' ') != lStudent.getText().length())){
                    er = new ErrorWindow("Spaces are not allowed in First an Last Name.");
                    er.show();
                    return false;
                }
            }
        }
        // Test the password field
        if (passwdStudent.getText().equals("")) {
            er = new ErrorWindow("Missign password.");
            er.show();
            return false;
        } else if (UtilFunctions.validateField(passwdStudent.getText().toLowerCase(),"'")) {
            er = new ErrorWindow("Invalid character in Password.");
            er.show();
            return false;
        } else if ((passwdStudent.getText().length() < 5) || (passwdStudent.getText().length() > 16)) {
            er = new ErrorWindow("Password should be bigger than 5 and smaller than 16 characters.");
            er.show();
            return false;
        } else if ((passwdStudent.getText().indexOf(' ') != -1) &&
        (passwdStudent.getText().indexOf(' ') != passwdStudent.getText().length())) {
            er = new ErrorWindow("Spaces are not allowed in Password.");
            er.show();
            return false;
        } else if (!passwdStudent.getText().equals(passwdStudent2.getText())) {
            er = new ErrorWindow("Two Passwords different.");
            er.show();
            return false;
        }
        
        // Test the email field
        if (emailStudent.getText().indexOf('@') == -1) {
            er = new ErrorWindow("Wrong email format: name@site.");
            er.show();
            return false;
        }
        
        // Test the id number field.
        if (!idNumberStudent.getText().equals("")) {
            if (!idNumberStudent.getText().equals(idStudent)) {
                if (!UtilFunctions.validateField(idNumberStudent.getText(),"0123456789")) {
                    er = new ErrorWindow("Invalid Charactere to Id Number.");
                    er.show();
                    return false;
                }
            }
            idNumber = idNumberStudent.getText();
        } else
            idNumber = "0";
        
        email = emailStudent.getText();
        FirstName = fStudent.getText();
        LastName = lStudent.getText();
        NewPassword = passwdStudent.getText().toLowerCase();
        
        return true;
    }
    
    /** Method for management of the database information.*/
    public Object updateView(SQL sql) throws Exception {
        ResultSet rs,rs1;
        String courseName;
        
        sql.init(Defaults.WEBCOMDATABASE);
        // Test if this email is already used
        rs = sql.executeQuery("SELECT username FROM users WHERE email='" + email + "'");
        if (rs.next())
            if (!rs.getString(1).equals(username)) throw new RuntimeException("This email already is used.");
        rs = sql.executeQuery("SELECT course_name FROM basic_info WHERE database_name='" + tic.resource + "'");
        rs.next();
        courseName = rs.getString(1);
        rs = sql.executeQuery("SELECT database_name FROM basic_info WHERE database_name!='" + tic.resource + "'");
        sql.close();
        
        // Search in candidates of another courses
        for (;rs.next();) {
            sql.init(rs.getString(1));
            rs1 = sql.executeQuery("SELECT username FROM candidates WHERE accepted='n' and email='" + email + "'");
            if (rs1.next()) {
                if (!rs1.getString(1).equals(username)) throw new RuntimeException("This username already is used.");
                for(;rs.next(););
            }
            sql.close();
        }
        
        sql.init(tic.resource);
        //Test if already exists this id Number
        rs = sql.executeQuery("SELECT username FROM students WHERE class='" + classSelected + "'AND id='" + idNumber + "'");
        if(rs.next())
            if (!rs.getString(1).equals(username)) throw new RuntimeException("This id number already is used.");
        
        // Update the student in the course base
        if (!idNumber.equals(idStudent))
            sql.executeUpdate("UPDATE students SET id='" + idNumber + "' WHERE username='" + username +
            "' and class='" + classSelected + "'");
        sql.close();
        
        sql.init(Defaults.WEBCOMDATABASE);
        // Insert the student in the users base
        sql.executeUpdate("UPDATE users SET password='" + NewPassword.toLowerCase() + "', last_name='" + LastName +
        "', first_name='" + FirstName + "', email='"+ email + "' WHERE username='" + username + "'");
        sql.close();
        
        // if the password was changed, send e-mail with alert
        if ((!Password.equals(NewPassword)) || (!idNumber.equals(idStudent))) {
            try {
                CourseEmail courseEmail = new CourseEmail(email);
                courseEmail.envia(Defaults.FROM, Defaults.HOST, "Course Manager",
                "Message from Course Administrator: \n" +
                "Your information was changed in the course " + courseName + " to:\n" +
                " username = " + username +"\n" +
                " password = " + NewPassword.toLowerCase() +"\n" +
                " Identification number = " + idNumber +"\n" +
                "Please, change your password.");
            }catch (Exception e) {}
        }
        
        UserSelectionView userSelectionView = new UserSelectionView();
        return userSelectionView.createView(tic,sql);
    }
}
