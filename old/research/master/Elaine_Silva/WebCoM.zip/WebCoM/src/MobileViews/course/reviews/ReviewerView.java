/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.reviews;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;

/** Class for allocation of reviewers of the groups.*/
public class ReviewerView extends Panel implements View {
    int idAssignmentSelected = 0, classSelected = 0;
    int countGroupInformation = 0;
    Vector groupInformation[] = new Vector[100];
    public static String ASSIGNMENT_ACCESS = "Assignment";
    Ticket tic;
    
    transient LineTableReview lines[];
    transient TextField classField,activityField;
    
    /** Method for setting variables. It sets the selected class and the selected assignment.*/
    public void setVariable(int classSelected, String assignmentSelected) {
        StringTokenizer analex = new StringTokenizer(assignmentSelected);
        String token = analex.nextToken();
        try {
            idAssignmentSelected = Integer.parseInt(analex.nextToken());
        } catch (Exception e) {}
        this.classSelected = classSelected;
        
    }
    
    /** Method for creation of a new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        ResultSet rs;
        this.tic = tic;
        
        sql.init(tic.resource);
        // get all of the groups to alocate review
        rs = sql.executeQuery("SELECT DISTINCT groups.name,groups.project, groups.reviews FROM groups,activities WHERE groups.assignment='" +
        idAssignmentSelected + "' AND activities.class='" + classSelected + "' AND groups.name=activities.group_name");
        for (;rs.next();countGroupInformation++) {
            groupInformation[countGroupInformation] = new Vector();
            groupInformation[countGroupInformation].addElement(rs.getString(1));
            groupInformation[countGroupInformation].addElement(rs.getString(2));
            groupInformation[countGroupInformation].addElement(rs.getString(3));
        }
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        ImageLoader jImage;
        Canvas canvas = new Canvas();
        Image icon;
        classField = new TextField("Class " + classSelected);
        activityField = new TextField(ASSIGNMENT_ACCESS + " " + idAssignmentSelected);
        
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,10));
        
        Panel top = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        top.setLayout(gridBag);
        
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        Label label = new Label("Class                   ");
        gridBag.setConstraints(label, constraints);
        top.add(label);
        
        label = new Label("Activity                 ");
        constraints.gridx = 1;
        constraints.gridy = 0;
        gridBag.setConstraints(label, constraints);
        top.add(label);
        
        constraints.gridx = 0;
        constraints.gridy = 1;
        classField.setFont(new Font("SansSerif", Font.BOLD, 14));
        classField.setForeground(Color.blue);
        classField.setEditable(false);
        gridBag.setConstraints(classField, constraints);
        top.add(classField);
        
        constraints.gridx = 1;
        constraints.gridy = 1;
        activityField.setFont(new Font("SansSerif", Font.BOLD, 14));
        activityField.setForeground(Color.blue);
        activityField.setEditable(false);
        gridBag.setConstraints(activityField, constraints);
        top.add(activityField);
        
        ScrollPane scrollPane = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);
        Panel titles = new Panel();
        titles.setLayout(new GridLayout(1,0));
        titles.add(new Label("Group"));
        titles.add(new Label("Assignment"));
        titles.add(new Label("Review"));
        titles.setBackground(new Color(220,220,220));
        
        Panel linesPane = new Panel();
        linesPane.setLayout(new GridLayout(0,1));
        linesPane.add(titles);
        
        lines = new LineTableReview[countGroupInformation];
        for (int count=0; count < countGroupInformation;count++) {
            lines[count] = new LineTableReview((String) groupInformation[count].elementAt(0),
            (String) groupInformation[count].elementAt(1),
            (String) groupInformation[count].elementAt(2));
            linesPane.add(lines[count].showLine());
        }
        scrollPane.add(linesPane);
        scrollPane.setSize(350,250);
        
        jImage = new ImageLoader();
        icon = jImage.loadImage("review.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(380,45);
        canvas.setBackground(Color.lightGray);
        
        principal.add(canvas,BorderLayout.NORTH);
        principal.add(top,BorderLayout.CENTER);
        principal.add(scrollPane,BorderLayout.SOUTH);
        return principal;
        
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        ErrorWindow errorWindow;
        
        // Test the reviewer group
        for (int count=0; count < countGroupInformation; count++) {
            if (!lines[count].review.getText().equals("")) {
                if (!validateGroup(lines[count].review.getText())) {
                    errorWindow = new ErrorWindow("Invalid Group: " + lines[count].review.getText() + ".");
                    errorWindow.show();
                    return false;
                }
            }
            groupInformation[count].setElementAt(lines[count].review.getText(),2);
        }
        return true;
    }
    
    /** Method for validation of the reviewer group. It tests if the reviewer group is into the groups vector.*/
    public boolean validateGroup(String group) {
        for (int count=0; count < countGroupInformation; count++)
            if (groupInformation[count].elementAt(0).equals(group))
                return true;
        return false;
    }
    
    /** Method for management of the database information.*/
    public Object updateView(SQL sql) throws Exception {
        sql.init(tic.resource);
        for (int count=0;count<countGroupInformation;count++)
            // set the reviewer groups for each group
            sql.executeUpdate("UPDATE groups set reviews='" + groupInformation[count].elementAt(2) +
            "' WHERE name='" + groupInformation[count].elementAt(0) + "' AND project='" +
            groupInformation[count].elementAt(1) + "'");
        
        sql.close();
        AssignmentReviewSelection assignmentReviewSelection = new AssignmentReviewSelection();
        assignmentReviewSelection.setVariable("Class " + classSelected);
        return assignmentReviewSelection.createView(tic,sql);
    }
    
}

/** Class for showing a table with all groups.*/
class LineTableReview extends Component{
    Label group, work;
    TextField review;
    Panel line;
    
    /** Method for creation of a new instance from this class. Each instance has group name, project name and the the reviewer group.*/
    public LineTableReview(String groupName, String workName, String groupReview) {
        line = new Panel();
        review = new TextField(groupReview);
        group = new Label(groupName);
        work = new Label(workName);
        line.setLayout(new GridLayout(1,0));
        line.add(group);
        line.add(work);
        line.add(review);
    }
    /** Method for showing each line of the table.*/
    public Panel showLine() {
        return line;
    }
}
