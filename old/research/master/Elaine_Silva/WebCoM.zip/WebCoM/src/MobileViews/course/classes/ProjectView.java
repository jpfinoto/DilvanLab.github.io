/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import course.create.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class for creation of new project for one assignment. */
public class ProjectView implements View, Serializable {
    transient ProjectPanel projectPanel;
    transient Panel p1;
    
    String resource;
    DataProject dataProject;
    int idClass;
    int idAssignment;
    Ticket tic;
    
    /** Method for setting variables.*/
    public void setVariable(int idClass, int idAssignment){
        boolean endToken = true;
        this.idClass = idClass;
        this.idAssignment = idAssignment;
    }
    
    /** Method for creation of new instance from the View class. */
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.resource = tic.resource;
        this.tic = tic;
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        projectPanel = new ProjectPanel(idAssignment);
        p1 = projectPanel.initView();
        principal.add(p1);
        return principal;
    }
    
    /** Method for validation of the graphic interface information. */
    public boolean validateView() {
        ErrorWindow er = null;
        int errorView = projectPanel.validateView();
        if (errorView != 0) {
            if (errorView == 1)
                er = new ErrorWindow("Missing project name.");
            if (errorView == 2)
                er = new ErrorWindow("Spaces are not allowed in the field Name.");
            if (errorView == 3)
                er = new ErrorWindow("Values min and max have to be more than 0.");
            if (errorView == 4)
                er = new ErrorWindow("MinStudents is bigger MaxStudents.");
            if (errorView == 5)
                er = new ErrorWindow("Missing values.");
            er.show();
            return false;
        }
        dataProject = new DataProject();
        dataProject = projectPanel.update(dataProject);
        return true;
    }
    
    /** Method for management of the database information.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        String instruction = null;
        
        sql.init(resource);
        // verify if there is other project with the same name
        ResultSet rs = sql.executeQuery("SELECT name FROM projects WHERE assignment='" + idAssignment + "' AND class='" + idClass + "'");
        for (;rs.next();)
            if (rs.getString(1).equals(dataProject.name)) throw new RuntimeException("Project name already used.");
        
        // insert the data about the new project in the database
        sql.executeUpdate("INSERT INTO projects VALUES('" + dataProject.name + "'," + idAssignment + ",'" + dataProject.maxGroups + "','" +
        dataProject.minStudents + "','" + dataProject.maxStudents + "'," + idClass + ")");
        sql.close();
        
        EditClassSelection editClassSelection = new EditClassSelection();
        editClassSelection.setVariable("Class "+ idClass);
        return editClassSelection.createView(tic,sql);
    }
}
