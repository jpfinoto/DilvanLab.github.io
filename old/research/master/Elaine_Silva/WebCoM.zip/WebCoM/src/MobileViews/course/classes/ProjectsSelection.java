/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import agents.security.Ticket;
import agents.agent.Defaults;

/** Class for selection of an action that will be executed with one assignment's project. */
public class ProjectsSelection implements View, Serializable, ItemListener {
    Ticket tic;
    int idClass;
    int operationSelected;
    int idAssignmentSelected;
    String projectSelected;
    Vector projects;
    
    transient Choice operations;
    transient Choice projectsSelection;
    transient Panel cardActivities;
    CardLayout card;
    
    /** Method for setting variables.*/
    public void setVariable(int idAssignmentSelected, int classSelected) {
        this.idAssignmentSelected = idAssignmentSelected;
        idClass = classSelected;
    }
    
    /** Method for creation of new instance from the View class. All projects from the selected assignment will be recovered. */
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        projects = new Vector();
        
        sql.init(tic.resource);
        // Select all projects from the selected assignment
        ResultSet rs = sql.executeQuery("SELECT name, max_groups, min_users, max_users FROM projects WHERE assignment='" +
        idAssignmentSelected + "' AND class='" + idClass + "' ORDER BY name");
        String project;
        for(;rs.next();) {
            project = "Project " + rs.getString(1) + " MaxGroup " + rs.getString(2) + " MinStudents " +
            rs.getString(3) + " MaxStudents " + rs.getString(4);
            projects.addElement(project);
        }
        sql.close();
        
        return this;
    }
    /** Method for creation of a graphic interface for this class. The user can to decide what type of operation he intend to do.
     * The operations are : add, edit or remove one project from the selected assignment. To edit or remove some project, the user
     * have to select it.
     */
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout(0,0));
        
        Panel actionsPanel = new Panel();
        actionsPanel.setLayout(new FlowLayout());
        operations = new Choice();
        operations.addItem("Add Project");
        operations.addItem("Edit Project");
        operations.addItem("Remove Project");
        actionsPanel.add(operations);
        operations.addItemListener(this);
        
        Panel listActions = new Panel();
        listActions.setLayout(new FlowLayout());
        listActions.add(new Label("Select one operation: "));
        listActions.add(actionsPanel);
        
        // Panel to edit or remove projects
        Panel projectsPanel = new Panel();
        projectsPanel.setLayout(new FlowLayout());
        projectsPanel.add(new Label("Select one project:"));
        
        projectsSelection = new Choice();
        for (int count = 0; count < projects.size(); count++)
            projectsSelection.addItem((String) projects.elementAt(count));
        projectsPanel.add(projectsSelection);
        
        card = new CardLayout();
        cardActivities = new Panel();
        cardActivities.setLayout(card);
        
        cardActivities.add(new Panel(),"nothing");
        cardActivities.add(projectsPanel, "projects");
        card.first(cardActivities);
        
        principal.add(listActions,BorderLayout.NORTH);
        principal.add(cardActivities, BorderLayout.CENTER);
        
        return principal;
    }
    
    /** Method for showing menus when the operations list is changed.*/
    public void itemStateChanged(ItemEvent e) {
        Object source = e.getSource();
        int actionSelected = operations.getSelectedIndex();
        
        // Test the operation selected
        if (source == operations){
            if ((actionSelected == 1) || (actionSelected == 2))
                card.show(cardActivities, "projects");
            else
                card.show(cardActivities,"nothing");
        }
    }
    
    /** Method for validation and storing of the selected operation and project. */
    public boolean validateView() {
        operationSelected = operations.getSelectedIndex();
        projectSelected = projectsSelection.getSelectedItem();
        
        if ((operationSelected == 2 || operationSelected==3) && (projectSelected == null)) {
            ErrorWindow er = new ErrorWindow("Don't have any project.");
            er.show();
            return false;
        }
        return true;
    }
    
    /** Method that invokes the class that implements the selected operation.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        if (operationSelected == 0) { // Add project
            ProjectView projectView = new ProjectView();
            projectView.setVariable(idClass,idAssignmentSelected);
            return projectView.createView(tic, sql);
            
        } else if (operationSelected==1) { // Edit project
            EditRemoveProjectView editRemoveProjectView = new EditRemoveProjectView();
            editRemoveProjectView.setVariable(idClass, idAssignmentSelected, projectSelected,1);
            return editRemoveProjectView.createView(tic, sql);
            
        } else if (operationSelected == 2) { // Remove project
            EditRemoveProjectView editRemoveProjectView = new EditRemoveProjectView();
            editRemoveProjectView.setVariable(idClass,idAssignmentSelected, projectSelected,2);
            return editRemoveProjectView.createView(tic, sql);
        }
        return "";
    }
    
}
