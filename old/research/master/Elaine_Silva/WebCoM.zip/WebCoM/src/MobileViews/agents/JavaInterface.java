/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents;

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

import agents.security.*;

/** Interface for providing comunication between the client and the servlet.*/
public abstract class JavaInterface extends Frame {
    ActionListener actionListener = null;
    protected String host;
    
    /** Method for creation of a new Instance from this class.*/
    public JavaInterface(String host) {
        this.host= host;
    }
    
    /** Method for initialization of the object.*/
    public abstract void init();
    
    /** Method for addition of a event listener in the objects.*/
    public void addActionListener(ActionListener l) {
        actionListener = AWTEventMulticaster.add(actionListener, l);
    }
    
    /** Method for removing a event listener from the objects.*/
    public void removeActionListener(ActionListener l) {
        actionListener = AWTEventMulticaster.remove(actionListener, l);
    }
    
    /** Method for execution of an action when a event ocurs.*/
    public void processAction(ActionEvent e) {
        // when event occurs which causes "action" semantic
        if (actionListener != null)
            actionListener.actionPerformed(e);
    }
    
    /** Method for sending request to the servlet Database on the server.*/
    protected Object sendRequest(String agent, Object message) throws Exception {
        String lixo= "http://" + host + ContactStudent.WEBMODULE_DIR + "/Database";
        System.out.println( "Host Name: "+ lixo);
        URL url = new URL(lixo);
        //URL url= new URL("http://localhost/manager_files/Database");
        
        URLConnection connection = url.openConnection();  // open the connection
        connection.setDoOutput(true);                     // set to send
        connection.setDoInput(true);                      // set to receive
        ObjectOutputStream out = new ObjectOutputStream(connection.getOutputStream());
        out.writeObject(agent);                           // write the agent to the servlet
        out.writeObject(message);                         // write the message to the servlet
        out.close();                                      // close the connection
        
        // Response from the server
        ObjectInputStream in = new ObjectInputStream(connection.getInputStream());
        Object resp= in.readObject();                     // receive stream of the server
        in.close();                                       // close the connecton
        
        if (resp instanceof Exception)
            throw (Exception) resp; // if there are errors, return error message
        return resp;                                           // else return stream.
    }
    
    /** Method for codifying the client message with the user's password. After that, it sends the request to the servlet.*/
    protected Object sendRequest(String agent, Message message, String passwd) throws Exception {
        message.encode(passwd); // codify the message with the user's password
        byte[] resp= (byte[]) sendRequest(agent, message); // send request to the server
        return ObjectInputCrypt.readObject(passwd, resp);  // decody the message with the users password and return to the client
    }
    
    /** Method that prepares the stream for communication.*/
    protected ObjectInput getStream(String agent, Message message, String passwd) throws Exception {
        message.encode(passwd);
        return getStream(agent, message);
    }
    
    /** Method that establishs the communication.*/
    protected ObjectInput getStream(String agent, Object message) throws Exception {
        URL url = new URL("http://" + host + ContactStudent.WEBMODULE_DIR + "/Database");
        
        URLConnection connection = url.openConnection();
        connection.setDoOutput(true);
        connection.setDoInput(true);
        
        ObjectOutputStream out = new ObjectOutputStream(connection.getOutputStream());
        out.writeObject(agent);
        out.writeObject(message);
        out.close();
        
        //	From the server
        return new ObjectInputStream(connection.getInputStream());
    }
    
    protected URLConnection getConnection() throws IOException {
        URL url = new URL("http://" + host + ContactStudent.WEBMODULE_DIR + "/Database");
        
        URLConnection connection = url.openConnection();
        connection.setDoOutput(true);
        connection.setDoInput(true);
        
        return connection;
    }
 
}
