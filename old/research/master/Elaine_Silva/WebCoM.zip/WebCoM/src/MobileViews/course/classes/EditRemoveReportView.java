/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/
 
package course.classes;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.View;
import agents.SQL;
import agents.ErrorWindow;
import course.create.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import course.util.UtilFunctions;

/** Class for edition or removing one report.*/
public class EditRemoveReportView implements View, Serializable{
    transient ReportPanel reportsPanel;
    transient Panel p1;
    
    String resource;
    DataActivities dataActivities;
    int idClass;
    int idReport;
    int action;
    Ticket tic;
    
    /** Method for setting variables.*/
    public void setVariable(int idReport, int idClass, int action){
        this.idClass = idClass;
        this.idReport = idReport;
        this.action = action;
    }
    
    /** Method for creation of new instance from the View class. The data about the selected project will be got.*/
    public Object createView(Ticket tic, SQL sql) throws SQLException, ClassNotFoundException {
        this.resource = tic.resource;
        this.tic = tic;
        dataActivities = new DataActivities();
        sql.init(this.resource);
        ResultSet rs = sql.executeQuery("SELECT expire FROM class WHERE id='" + idClass + "'");
        rs.next();
        dataActivities.expireClass = UtilFunctions.deconvertDate(rs.getString(1));
        dataActivities.idClass = idClass;
        
        rs = sql.executeQuery("SELECT date,weight FROM reports WHERE id='" + idReport + "' AND class='" + idClass + "'");
        rs.next();
        dataActivities.indexReports = 0;
        dataActivities.report[dataActivities.indexReports].id = idReport;
        dataActivities.report[dataActivities.indexReports].deliveryDate = UtilFunctions.deconvertDate(rs.getString(1));
        dataActivities.report[dataActivities.indexReports].weight = String.valueOf(rs.getInt(2));
        dataActivities.numberReports= 1;
        
        sql.close();
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Panel principal = new Panel();
        principal.setLayout(new BorderLayout());
        principal.setFont(new Font("Helvetica", Font.PLAIN, 12));
        
        reportsPanel = new ReportPanel();
        p1 = reportsPanel.initView();
        reportsPanel.atualizeView(dataActivities);
        principal.add(p1);
        if (action == 2) { // remove
            Label message = new Label("PRESS SEND BUTTON TO REMOVE ALL OF INFORMATION ABOUT THIS ACTIVITY.");
            message.setForeground(Color.red);
            message.setFont(new Font("Helvetica", Font.BOLD, 10));
            principal.add(message, BorderLayout.SOUTH);
        }
        
        return principal;
    }
    
    /** Method for validation of the graphic interface information.*/
    public boolean validateView() {
        if (action == 1) { // edit
            ErrorWindow er = null;
            int errorView = reportsPanel.validateView(dataActivities);
            if (errorView != 0) {
                if (errorView == 1)
                    er = new ErrorWindow("Invalid Information.");
                if (errorView == 2)
                    er = new ErrorWindow("The report date is after the class's expire date.");
                if (errorView == 3)
                    er = new ErrorWindow("The report delivery date should be orderer.");
                if (errorView == 4)
                    er = new ErrorWindow("The weight should be bigger than 0.");
                er.show();
                return false;
            }
            dataActivities = reportsPanel.update(dataActivities);
            dataActivities.indexReports--; // it have to do the same position because there is only one report to edit
        }
        return true;
    }
    
    /** Method for management of the database information.*/
    public synchronized Object updateView(SQL sql) throws Exception {
        if (action == 1) {
            // atualize the data about the report in the database
            String instruction = null;
            sql.init(resource);
            instruction = new String("UPDATE reports SET date='" + UtilFunctions.convertDate(dataActivities.report[dataActivities.indexReports].deliveryDate) +
            "', weight='" + dataActivities.report[dataActivities.indexReports].weight + "' WHERE id='" + idReport +
            "' AND class='" + idClass + "'");
            sql.executeUpdate(instruction);
            sql.close();
        } else if (action == 2) {
            // get the directory of this course
            sql.init(Defaults.WEBCOMDATABASE);
            ResultSet rs = sql.executeQuery("SELECT directory FROM basic_info WHERE database_name='" + resource + "'");
            rs.next();
            String directory = rs.getString(1);
            sql.close();
            // Create new directories in trash
            // Transfer the student's directories to the new directories in the trash
            String newReportTrash = directory + File.separator + "homework" + File.separator + "trash" + File.separator + "class_" + idClass + "_report_" + idReport;
            
            sql.init(resource);
            
            //Select all groups of this class to remove yours directories
            rs = sql.executeQuery("SELECT username FROM students WHERE class='" + idClass + "'");
            
            // Delete each directory from the students
            for (;rs.next();) {
                try {
                    UtilFunctions.deleteDirectoriesStudent(directory,idReport,rs.getString(1),idClass);
                } catch (Exception e) {return "Error deleting directory /homework/report. Directories not removed.";};
            }
            
            // if there's not other report, remove the report's directory
            rs = sql.executeQuery("SELECT id FROM reports WHERE id='" + idReport + "' AND class !='" + idClass + "'");
            if (!rs.next()) {
                try {
                    UtilFunctions.deleteDirectoryReport(directory,idReport,idClass);
                } catch (Exception e) {return "Error deleting directory /homework/report. Directories not removed.";};
            }
            
            sql.executeUpdate("DELETE FROM reports WHERE id='" + idReport + "' AND class='" + idClass + "'");
            sql.executeUpdate("DELETE FROM activities WHERE type='reports' AND id='" + idReport + "' AND class='" + idClass + "'");
            sql.close();
        }
        EditClassSelection editClassSelection = new EditClassSelection();
        editClassSelection.setVariable("Class "+ idClass);
        return editClassSelection.createView(tic,sql);
    }
}
