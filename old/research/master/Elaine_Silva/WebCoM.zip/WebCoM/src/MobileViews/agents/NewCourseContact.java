/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.lang.reflect.*;

/** Applet for creation of a new manament area for a new course.*/
public class NewCourseContact extends Applet implements ActionListener {
    JavaInterface newCourseI;
    String host, main_host;
    
    // Controls for chosing course
    private Dialog dframe;
    private Choice choice;
    
    private Button newCourse;
    private Color corback;
    
    /**
     * Initialize the graphic part of the Client.
     */
    public void init() {
        try {
            host = getCodeBase().getHost();
        } catch (Exception e) {
            host=main_host;
        }
        corback= Color.lightGray;
        setBackground(new Color(255, 204, 102));
        
        newCourse = new Button("New Course");
        newCourse.setBackground(corback);
        newCourse.addActionListener(this);
        
        setFont(new Font("Helvetica", Font.BOLD, 12));
        
        Panel p = new Panel();
        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        p.setLayout(grid);
        
        c.gridwidth = GridBagConstraints.REMAINDER; //end row
        c.insets = new Insets(1, 10, 1, 10);
        c.fill = GridBagConstraints.HORIZONTAL;
        grid.setConstraints(newCourse, c);
        p.add(newCourse);
        
        add(p);
        validate();
    }
    
    /**
     * Listenner of Events.
     */
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == newCourse) {
            if (newCourseI!=null) newCourseI.setVisible(false);
            newCourseI= new ViewInterface(host,"x", "UsersAgent", "course.NewCourseView");
            newCourseI.setBackground(corback);
            newCourseI.init();
            return;
        }
    }
}
