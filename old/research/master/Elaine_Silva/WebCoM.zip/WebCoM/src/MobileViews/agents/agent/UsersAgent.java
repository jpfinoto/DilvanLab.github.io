/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents.agent;

import java.awt.*;
import java.io.*;
import java.util.*;

import agents.*;
import agents.sql.*;
import agents.security.*;

/** Class for management of the client-server comunication process.*/
public class UsersAgent implements agents.query.ObjectStream {
    
    /** Method for receiving the request and sending the response to the database servlet.*/
    public void query(ObjectInput in, ObjectOutput out) throws Exception {
        Message msg= (Message) in.readObject();
        TicketAgent.decode(msg);
        ObjectOutputCrypt out2= new ObjectOutputCrypt(((Ticket)msg.ticket).password, out);
        out2.writeObject(query(msg));
    }
    
    /** Method for identifying and executing operation form the request.*/
    public Object query(Object msg1) throws Exception {
        Message msg= (Message) msg1;
        String queryType= (String) msg.body.elementAt(0);
        Ticket tic= (Ticket) msg.ticket;
        
        // execute the updateView method of the view
        if (queryType.equals("update")) {
            View view= (View) msg.body.elementAt(1);
            return view.updateView(new SQLDatabase());
        }
        
        // execute the createView method of the view
        View view= (View) Class.forName(queryType).newInstance();
        return view.createView(tic, new SQLDatabase());
    }
}

