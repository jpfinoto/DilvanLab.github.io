/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.users;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

import agents.*;
import agents.security.Ticket;
import agents.agent.Defaults;
import agents.util.CourseEmail;
import course.util.UtilFunctions;

/** Class for addition of administrator users.*/
public class AdminView extends Panel implements View {
    String username;
    String FirstName, LastName, Password;
    String email;
    Ticket tic;
    
    transient TextField fAdmin,lAdmin,userName;
    transient TextField passwdAdmin,passwdAdmin2;
    transient TextField emailAdmin;
    
    /** Method for creation of a new instance from the View class.*/
    public Object createView(Ticket tic, SQL sql) throws Exception {
        this.tic = tic;
        if (!tic.type.equals("administrator")) throw new RuntimeException("You don't have permissions to access this tool.");
        return this;
    }
    
    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        Image icon;
        Canvas canvas = new Canvas();
        
        fAdmin = new TextField(5);
        lAdmin = new TextField(5);
        userName = new TextField(5);
        passwdAdmin = new TextField(5);
        passwdAdmin2 = new TextField(5);
        emailAdmin = new TextField(5);
        
        setFont(new Font("Helvetica",Font.PLAIN,11));
        
        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());
        
        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
        
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);
        
        // label username
        Label label = new Label("Username");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.CENTER;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        
        // label first name
        constraints.gridx = 0;
        constraints.gridy = 2;
        label = new Label("First Name");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label last name
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.insets = new Insets(0,5,0,0);
        label = new Label("Last Name");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label password
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,0,0,5);
        label = new Label("Type Password");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label retype password
        constraints.gridx = 2;
        constraints.gridy = 4;
        constraints.insets = new Insets(0,5,0,0);
        label = new Label("Retype Password");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label e-mail
        constraints.gridx = 0;
        constraints.gridy = 6;
        constraints.insets = new Insets(0,0,0,5);
        label = new Label("E-mail");
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // label
        label = new Label("          ");
        constraints.gridx = 1;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        label = new Label("          ");
        constraints.gridx = 3;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);
        
        // field username
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        gridBag.setConstraints(userName,constraints);
        form.add(userName);
        
        // field first name Admin
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        constraints.insets = new Insets(0,0,0,5);
        gridBag.setConstraints(fAdmin,constraints);
        form.add(fAdmin);
        
        // field last name Admin
        constraints.gridx = 2;
        constraints.gridy = 3;
        constraints.insets = new Insets(0,5,0,0);
        gridBag.setConstraints(lAdmin,constraints);
        form.add(lAdmin);
        
        // field password
        constraints.gridx = 0;
        constraints.gridy = 5;
        constraints.insets = new Insets(0,0,0,5);
        passwdAdmin.setEchoChar('*');
        gridBag.setConstraints(passwdAdmin,constraints);
        form.add(passwdAdmin);
        
        // field retype password
        constraints.gridx = 2;
        constraints.gridy = 5;
        constraints.insets = new Insets(0,5,0,0);
        passwdAdmin2.setEchoChar('*');
        gridBag.setConstraints(passwdAdmin2,constraints);
        form.add(passwdAdmin2);
        
        // field email
        constraints.gridx = 0;
        constraints.gridy = 7;
        constraints.gridwidth = 4;
        constraints.insets = new Insets(0,0,0,5);
        gridBag.setConstraints(emailAdmin,constraints);
        form.add(emailAdmin);
        
        
        groupForm.add(form,BorderLayout.CENTER);
        
        ImageLoader jImage = new ImageLoader();
        icon = jImage.loadImage("administrator.gif");
        if (icon != null)
            canvas = new ImageCanvas(icon);
        canvas.setSize(380,45);
        canvas.setBackground(Color.lightGray);
        groupForm.add(canvas,BorderLayout.NORTH);
        
        principal.add(groupForm);
        
        return principal;
    }
    
    /** Method for validation of the graphic interface objects.*/
    public boolean validateView() {
        ErrorWindow er;
        
        // Verify the username field
        if (userName.getText().equals("")) {
            er = new ErrorWindow("Missing username.");
            er.show();
            return false;
        } else if (!UtilFunctions.validateField(userName.getText().toLowerCase(), "abcdefghijklmnopqrstuvxzwy0123456789-_")) {
            er = new ErrorWindow("Invalid character in Username.");
            er.show();
            return false;
        } else if ((userName.getText().length() < 5) || (userName.getText().length() > 16)){
            er = new ErrorWindow("Username should be bigger than 5 and smaller than 16 characters.");
            er.show();
            return false;
        } else if ((userName.getText().indexOf(' ') != -1) &&
        (userName.getText().indexOf(' ') != userName.getText().length())) {
            er = new ErrorWindow("Spaces are not allowed in Username.");
            er.show();
            return false;
        }
        
        // Verify the first and last name fields
        if ((!fAdmin.getText().equals("")) || (!lAdmin.getText().equals(""))) {
            if ((fAdmin.getText().indexOf("'") !=-1) || (lAdmin.getText().indexOf("'") != -1)) {
                er = new ErrorWindow("Invalid character in First Name or Last Name");
                er.show();
                return false;
            } else if ((fAdmin.getText().length() > 32) || (lAdmin.getText().length() > 32)) {
                er = new ErrorWindow("First Name and Last Name should be smaller than 32 characters");
                er.show();
                return false;
            } else if ((fAdmin.getText().indexOf(' ') != -1) || (lAdmin.getText().indexOf(' ') != -1)){
                if ((fAdmin.getText().indexOf(' ') != fAdmin.getText().length()) ||
                (lAdmin.getText().indexOf(' ') != lAdmin.getText().length())){
                    er = new ErrorWindow("Spaces are not allowed in First an Last Name.");
                    er.show();
                    return false;
                }
            }
        }
        // Verify the password field
        if (passwdAdmin.getText().equals("")) {
            er = new ErrorWindow("Missign password.");
            er.show();
            return false;
        } else if (passwdAdmin.getText().indexOf("'") != -1) {
            er = new ErrorWindow("Invalid character in Password.");
            er.show();
            return false;
        } else if ((passwdAdmin.getText().length() < 5) || (passwdAdmin.getText().length() > 16)) {
            er = new ErrorWindow("Password should be bigger than 5 and smaller than 16 characters.");
            er.show();
            return false;
        } else if ((passwdAdmin.getText().indexOf(' ') != -1) &&
        (passwdAdmin.getText().indexOf(' ') != passwdAdmin.getText().length())) {
            er = new ErrorWindow("Spaces are not allowed in Password.");
            er.show();
            return false;
        } else if (!passwdAdmin.getText().equals(passwdAdmin2.getText())) {
            er = new ErrorWindow("Two Passwords different.");
            er.show();
            return false;
        }
        // Verify the e-mail field
        if (emailAdmin.getText().indexOf('@') == -1) {
            er = new ErrorWindow("Wrong email format: name@site.");
            er.show();
            return false;
        }
        
        // store the information
        email = emailAdmin.getText();
        username = userName.getText().toLowerCase();
        FirstName = fAdmin.getText();
        LastName = lAdmin.getText();
        Password = passwdAdmin.getText().toLowerCase();
        
        return true;
    }
    
    /** Method for management of the database information.*/
    public Object updateView(SQL sql) throws Exception {
        ResultSet rs,rs1;
        String courseName;
        
        // Search username and e-mail in the course database
        sql.init(Defaults.WEBCOMDATABASE);
        
        rs= sql.executeQuery("SELECT username,email,type FROM users WHERE username='" + username+"' OR email='" + email + "'");
        if (rs.next()) {
            if ((!rs.getString(1).equals(username)) || (!rs.getString(2).equals(email)) ||
            (!rs.getString(3).equals("administrator"))) {
                if (rs.getString(1).equals(username)) throw new RuntimeException("This username already is used.");
                if (rs.getString(2).equals(email)) throw new RuntimeException("This e-mail already is used.");
            } else throw new RuntimeException("Administrator already registred.");
        }
        // get course and directory of the course
        rs = sql.executeQuery("SELECT course_name, directory FROM basic_info WHERE database_name='" + tic.resource + "'");
        rs.next();
        courseName = rs.getString(1);
        
        // get the database name of the other courses
        rs = sql.executeQuery("SELECT database_name FROM basic_info WHERE database_name!='" + tic.resource + "'");
        sql.close();
        
        // Search username and email in the candidates table of another courses
        for (;rs.next();) {
            sql.init(rs.getString(1));
            rs1 = sql.executeQuery("SELECT username,email FROM candidates WHERE accepted='n' and (username='" +
            username + "' OR email='" + email + "')");
            if (rs1.next()) {
                if (rs1.getString(1).equals(username)) throw new RuntimeException("This username already is used.");
                if (rs1.getString(2).equals(email)) throw new RuntimeException("This e-mail already is used.");
                for(;rs.next(););
            }
            sql.close();
        }
        
        sql.init(Defaults.WEBCOMDATABASE);
        // Insert the Admin in the users base
        sql.executeUpdate("INSERT INTO users VALUES('" + username + "','" + Password + "','administrator','" +
        LastName + "','" + FirstName + "','','"+ email + "','',CURDATE(),'','')");
        sql.close();
        
        // Send e-mail with alert
        try {
            CourseEmail courseEmail = new CourseEmail(email);
            courseEmail.envia(Defaults.FROM,Defaults.HOST,"Course Manager!",
            "Message from Course Administrator: \n" +
            "You was inserted in the course as administrator.\n" +
            "Your information are:\n" +
            " username = " + username +"\n" +
            " password = " + Password +"\n" +
            " Please, change your password.");
        }catch (Exception e) {};
        
        UserSelectionView userSelectionView = new UserSelectionView();
        return userSelectionView.createView(tic,sql);
    }
    
}
