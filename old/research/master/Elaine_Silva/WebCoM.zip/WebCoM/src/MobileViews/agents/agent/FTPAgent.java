/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents.agent;

import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;

import agents.*;
import agents.security.*;
import agents.sql.*;
import agents.util.*;
import course.util.UtilFunctions;

/** Class for management of file transfer - FTP tool. This is the server-side.*/
public class FTPAgent implements agents.query.ObjectStream {
    int classUsername = 0;
    String FILESEPARATOR = System.getProperty("file.separator");
    
    /** Method to receive the request and send the response to the database servlet.*/
    public void query(ObjectInput in, ObjectOutput out) throws Exception {
        String command, complemento;
        Message msg= (Message) in.readObject();
        TicketAgent.decode(msg);
        
        command= (String) msg.body.elementAt(0);
        
        // resquest to get log options
        if (command.equals("LOGOPTIONS")) {
            Execlogoptions(msg, out);
            return;
        }
        // request to get login
        if (command.equals("LOGIN")) {
            Execlogin(msg, out);
            return;
        }
        
        //  Test if the ticket has the HOMEDIR attached
        if (((Ticket) msg.ticket).note==null) throw new RuntimeException("Ilegal request.");
        
        // verify what is the requested command
        if (command.equals("NLST"))
            Execls(msg, out);
        else if (command.equals("CWD"))
            Execd(msg, out);
        else if (command.equals("PWD"))
            Execpwd(msg, out);
        else if (command.equals("RETR"))
            Execget(msg, out);
        else if (command.equals("STOR"))
            Execput(msg, out, in);
        else if (command.equals("DELE"))
            Execdele(msg, out);
        else if (command.equals("MKD"))
            Execmkd(msg, out);
        else if (command.equals("RMD"))
            Execrmd(msg, out);
        else throw new RuntimeException("FTPAgent: Unknown query");
    }
    
    public String comp(Message msg) {
        return (String) msg.body.elementAt(2);
    }
    
    public String reldir(Message msg) {
        String rdir= (String) msg.body.elementAt(1);
        //  Test if reldir tries to go up homedir
        StringTokenizer stoken= new StringTokenizer(rdir, "/");
        
        int ind=0;
        try {
            String token;
            while (ind>=0) {
                token= stoken.nextToken();
                if (token.equals(".."))
                    ind--;
                else if (!token.equals("."))
                    ind++;
            }
        } catch (NoSuchElementException e) {
            return rdir;
        } throw new RuntimeException("Reldir trying go up home dir.");
    }
    
    public String homedir(Message msg) {
        return (String) ((Ticket)msg.ticket).note;
    }
    
    /** Method for getting log options.*/
    public void Execlogoptions(Message msg, ObjectOutput out) throws Exception {
        Ticket ticket= (Ticket) msg.ticket;
        String[] options;
        
        //    Get Directory
        SQLDatabase sql= new SQLDatabase();
        sql.init(ticket.resource);
        if (ticket.type.equals("student")) {
            java.sql.ResultSet rs = sql.executeQuery(
                "SELECT students.class,class.expire FROM students,class WHERE username='" + ticket.username +
                "' AND students.class=class.id");
            java.util.Date date = new java.util.Date();
            for (;rs.next();) {
                if (UtilFunctions.verifyDate(date,rs.getDate(2)) < 0) 
                    throw new RuntimeException("Your class is expired.");
                else {
                    classUsername = rs.getInt(1);
                }
            } 
            if (classUsername== 0) throw new RuntimeException("Student not registred in any class.");
        } 
        
        try {
            options = sql.getLogOptions(classUsername);
        } catch(Exception e) {
            e.printStackTrace(System.out);
            throw new RuntimeException("Log options not available.");
        }
        
        //  Success
        ObjectOutputCrypt out2= new ObjectOutputCrypt(((Ticket)msg.ticket).password, out);
        out2.writeObject(options);
    }
    
    public void Execlogin(Message msg, ObjectOutput out) throws Exception {
        String directoryCourse;
        Date exp_date= new Date();
        Ticket ticket= (Ticket) msg.ticket;
        String directory;
        
        //    Get Directory
        SQLDatabase sql= new SQLDatabase();
        sql.init(Defaults.WEBCOMDATABASE);
        java.sql.ResultSet rs = sql.executeQuery("SELECT directory FROM basic_info WHERE database_name='" + ticket.resource + "'");
        rs.next();
        directoryCourse = rs.getString(1);
        sql.close();
        sql.init(ticket.resource);
        //  Get the database, accessType and subType fields
        String dir= (String) msg.body.elementAt(1);
        
        try {
            directory= sql.getDirectory(ticket.username, dir, exp_date, directoryCourse, classUsername);
        } catch(Exception e) {
            e.printStackTrace(System.out);
            throw new RuntimeException("Directory not available.");
        }
        
        //  Verify expiration dates
        Date currentDate= new Date();
        if (ticket.type.equals("student") && currentDate.after(exp_date))
            throw new RuntimeException("Update time expired for the directory");
        
        //  Test if directory exists
        File auxFile= new File(directory);
        if (!auxFile.isDirectory()) {
            if (!auxFile.mkdir()) throw new RuntimeException("Directory not accessible");
        }
        
        //  Success: update HOMEDIR & CURDIR
        ticket.note= directory;
        ObjectOutputCrypt out2= new ObjectOutputCrypt(((Ticket)msg.ticket).password, out);
        out2.writeObject(TicketAgent.encodeTicket(ticket));
    }
    
    public void Execls(Message msg, ObjectOutput out) throws IOException {
        File dir;
        String[] entries;
        SimpleFilter filtro;
        String complemento= comp(msg);
        filtro = new SimpleFilter(complemento);
        
        dir = new File(homedir(msg), reldir(msg));
        if (dir.canRead()) {
            entries = dir.list(filtro);
            out.write(entries.length);
            for(int i = 0; i < entries.length; i++)
                out.writeObject(entries[i]);
            out.writeObject("NLST successful");
        } else {
            out.write(0);
            out.writeObject("NLST unsuccessful - Permission denied");
        }
    }
    
    public void Execd(Message msg, ObjectOutput out)  throws IOException {
        String dirto;
        String complemento= comp(msg);
        
        //  Tests if reldir is valid
        String RELDIR= reldir(msg);
        
        if (complemento.startsWith("/"))
            dirto= complemento;
        else {
            if (RELDIR.endsWith("/"))
                dirto= RELDIR + complemento;
            else
                dirto= RELDIR + "/" + complemento;
        }
        
        //    Test if directory works
        msg.body.setElementAt(dirto, 1);
        try {
            reldir(msg);
        } catch (Exception e) {
            //  change it
            out.writeObject(RELDIR);
            out.writeObject("CWD unsuccessful");
            return;
        }
        
        File dir = new File(homedir(msg), dirto);
        if (dir.isDirectory()) {
            RELDIR = dirto;
            out.writeObject(RELDIR);
            out.writeObject("CWD successful " + RELDIR);
        } else {
            out.writeObject(RELDIR);
            out.writeObject("CWD unsuccessful");
        }
    }
    
    public void Execpwd(Message msg, ObjectOutput out) throws IOException {
        out.writeObject("PWD successful " + reldir(msg) + " is your current directory");
    }
    
    public void Execdele(Message msg, ObjectOutput out) throws IOException {
        File dir;
        File source_file;
        String source_name= comp(msg);
        
        dir = new File(homedir(msg), reldir(msg));
        source_file = new File(dir, source_name);
        
        if (!source_file.isFile() || !source_file.delete()) {
            out.writeObject("DELE command unsuccessful");
            return;
        }
        out.writeObject("DELE command successful");
    }
    
    public void Execmkd(Message msg, ObjectOutput out) throws IOException {
        File dir;
        File new_dir;
        String dir_name= comp(msg);
        
        dir = new File(homedir(msg), reldir(msg));
        new_dir = new File(dir, dir_name);
        
        if (!new_dir.mkdir()) {
            out.writeObject("MKD command unsuccessful");
            return;
        }
        out.writeObject("MKD command successful");
    }
    
    public void Execrmd(Message msg, ObjectOutput out) throws IOException {
        File dir;
        File old_dir;
        String dir_name= comp(msg);
        
        dir = new File(homedir(msg), reldir(msg));
        
        old_dir = new File(dir, dir_name);
        if (!old_dir.isDirectory() || !old_dir.delete()) {
            out.writeObject("RMD command unsuccessful");
            return;
        }
        out.writeObject("RMD command successful");
    }
    
    public void Execget(Message msg, ObjectOutput out) throws IOException {
        File dir;
        File source_file;
        FileInputStream source = null;
        byte[] buffer = new byte[4096];
        int bytes_read;
        long length;
        String source_name= comp(msg);
        
        dir = new File(homedir(msg), reldir(msg));
        
        source_file = new File(dir, source_name);
        
        // Verifica se o source_name existe, e' um arquivo e readable
        if (!source_file.exists() || !source_file.isFile() || !source_file.canRead()) {
            out.writeLong(-1);
        } else {
            source = new FileInputStream(source_file);
            length = source_file.length();
            out.writeLong(length);
            while(true) {
                bytes_read = source.read(buffer);
                if (bytes_read == -1) break;
                out.write(buffer, 0, bytes_read);
                out.flush();
            }
            source.close();
        }
    }
    
    public void Execput(Message msg, ObjectOutput out, ObjectInput sin) throws IOException, ClassNotFoundException {
        FileOutputStream destination = null;
        File dir = new File(homedir(msg), reldir(msg));
        String dest_name= comp(msg);
        
        long file_len, total_len;
        int read_len;
        byte[] buffer = new byte[4096];
        File destination_file = new File(dir, dest_name);
        
        try {
            // Caso destino exista e seja nao writeable ou nao arquivo, OU
            // caso o destino nao exista e nao possa ser criado gera uma
            // excecao FileCopyException
            if (destination_file.exists()) {
                if (destination_file.isFile()) {
                    if (!destination_file.canWrite())
                        throw new FileCopyException(" destination file is unwriteable: " + dest_name);
                } else
                    throw new FileCopyException("destination is not a file: " +  dest_name);
            } else {
                File parentdir = parent(destination_file);
                if (!parentdir.exists())
                    throw new FileCopyException("directory doesn't exist: " + dest_name);
                if (!parentdir.canWrite())
                    throw new FileCopyException("directory is unwriteable: " + dest_name);
            }
            
            // le o tamanho e, em seguida, o arquivo
            file_len = sin.readLong();
            if (file_len == -1) {
                sin.readObject();
            } else {
                destination = new FileOutputStream(destination_file);
                read_len = 0;
                total_len = 0;
                while (total_len < file_len) {
                    read_len = sin.read(buffer);
                    destination.write(buffer, 0, read_len);
                    total_len += read_len;
                }
                destination.close();
                out.writeObject("Transfer completed for " + dest_name + " (" + file_len + " bytes transfered).");
                
            }
        } catch (IOException e) {
            out.writeObject("NOT OK");
        }
    }
    
    // O metodo File.getParent retorna null se o arquivo e' especificado sem
    // diretorio ou esta no root dir; o metodo parent abaixo trata desses casos
    private static File parent(File f) {
        String dirname = f.getParent();
        if (dirname == null) {
            if (f.isAbsolute()) return new File(File.separator);
            else return new File(System.getProperty("user.dir"));
        }
        return new File(dirname);
    }
}