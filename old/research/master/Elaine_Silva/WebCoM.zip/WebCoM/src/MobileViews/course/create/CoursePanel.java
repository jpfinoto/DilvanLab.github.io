/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package course.create;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import agents.*;

/** Class with a graphic interface and some methods to manage inforamtion about the course.*/
public class CoursePanel extends Panel implements FocusListener {
    transient TextField courseName;   
    transient TextField beginTime;
    transient TextField path, studentDirectory, pathHTML;
    transient TextField databaseName;
    transient Image icon;
    String fileSeparator;

    /* Method for creation of new instance from this course.*/
    public CoursePanel (String separator) {
        fileSeparator = separator;
    }
    
    /** Method for atualizing the dataCourse object with the graphic interface information.*/
    public void update(DataCourse dataCourse) {
        dataCourse.course.courseName = courseName.getText();
	dataCourse.course.beginDate = beginTime.getText();
	dataCourse.course.path = path.getText();
	dataCourse.course.pathHTML = pathHTML.getText();
	dataCourse.databaseName = databaseName.getText();
    }
	 
    /** Method for validate the graphic interface objects.*/
    public int validateView() {
        if (courseName.getText().equals(""))
	    return 1;
	if ((path.getText().equals("")) || (path.getText().indexOf(' ') != -1))
	    return 2;
	if ((pathHTML.getText().equals("")) || (pathHTML.getText().indexOf(' ') != -1))
	    return 3;
	if ((databaseName.getText().equals("")) || (databaseName.getText().indexOf(' ') != -1))
	    return 4;
	try {
	    java.util.Date courseDate = new java.util.Date(beginTime.getText());
        } catch (Exception e) {return 5;}; 
	return 0;
    }

    /** Method for creation of a graphic interface for this class.*/
    public Panel initView() {
        ImageLoader jImage = new ImageLoader();
	Canvas canvas = new Canvas();
        courseName = new TextField(5);
        beginTime = new TextField("mm/dd/yyyy");
        path = new TextField("i.e.:/home/WWW/course or C:\\home\\WWW\\course");
        studentDirectory = new TextField(5);
	databaseName = new TextField(5);
	pathHTML = new TextField("i.e.: /course");
        path.addFocusListener(this);
	pathHTML.addFocusListener(this);

        setFont(new Font("Helvetica",Font.PLAIN,11));

        Panel principal = new Panel();
        principal.setLayout(new FlowLayout());

	Panel aux = new Panel();
	aux.setLayout(new BorderLayout(0,0));				                

        Panel groupForm = new Panel();
        groupForm.setLayout(new BorderLayout());
		  
        Panel form = new Panel();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        form.setLayout(gridBag);

	icon = jImage.loadImage("calendr1.gif");
	if (icon != null)
	    canvas = new ImageCanvas(icon);

        canvas.setSize(30,35);
        constraints.gridx = 3;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 2;
        constraints.weightx = 0.3;
        constraints.weighty = 1;
	constraints.insets = new Insets(0,15,0,0);
        gridBag.setConstraints(canvas,constraints);
        form.add(canvas);

        // label Course Name
        Label label = new Label("Course Name");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.gridheight = 1;
        constraints.weightx = 1;
        constraints.insets = new Insets(0,10,0,0);
        constraints.fill = GridBagConstraints.HORIZONTAL;
        gridBag.setConstraints(label,constraints);
        form.add(label);

        // label " "
        label = new Label("                                    ");
        constraints.gridx = 2;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        gridBag.setConstraints(label,constraints);
        form.add(label);

        // label Begin Date
        label = new Label("Start Date");
        constraints.gridx = 4;
        constraints.gridy = 0;
        gridBag.setConstraints(label,constraints);
        form.add(label);

        // field Course Name
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 3;
        gridBag.setConstraints(courseName,constraints);
        form.add(courseName);

        // Field Begin Date
        constraints.gridx = 4;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        gridBag.setConstraints(beginTime,constraints);
        form.add(beginTime);
	aux.add(form, BorderLayout.NORTH);

        form = new Panel();
        gridBag = new GridBagLayout();
        constraints = new GridBagConstraints();
        form.setLayout(gridBag);

	icon = jImage.loadImage("filemgr.gif");
	if (icon != null)
	    canvas = new ImageCanvas(icon);

	canvas.setSize(30,35);
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 2;
        constraints.weightx = 0.3;
        constraints.weighty = 1;
        gridBag.setConstraints(canvas,constraints);
        form.add(canvas);

        // Label path
        label = new Label("Absolute path for the HTML documents on the server disk");
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 4;
	constraints.gridheight = 1;
	constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(0,10,0,0);
        gridBag.setConstraints(label,constraints);
        form.add(label);

        // Field path
        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.gridwidth = 4;
        gridBag.setConstraints(path,constraints);
        form.add(path);
		  		  
	aux.add(form, BorderLayout.CENTER);
		  
        form = new Panel();
        gridBag = new GridBagLayout();
        constraints = new GridBagConstraints();
        form.setLayout(gridBag);

	// Label Path HTML
        label = new Label("Path used for the HTML documents URL");
	constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 4;
	constraints.gridheight = 1;
	constraints.weightx = 1;
	constraints.weighty = 1;
	constraints.fill = GridBagConstraints.HORIZONTAL;
	gridBag.setConstraints(label,constraints);
        form.add(label);

	// Label Student Directory
        label = new Label("Homework Directory");
        constraints.gridx = 0;
        constraints.gridy = 2;
        gridBag.setConstraints(label,constraints);
        form.add(label);
				  		  
	// Label database name
        label = new Label("Database Name");
        constraints.gridx = 0;
        constraints.gridy = 5;
        gridBag.setConstraints(label,constraints);
        form.add(label);
						  
        // Field path HTML
        constraints.gridx = 0;
        constraints.gridy = 1;
        gridBag.setConstraints(pathHTML,constraints);
        form.add(pathHTML);

        // Field homeword Diretory
        constraints.gridx = 0;
        constraints.gridy = 3;
        studentDirectory.setEditable(false);
        gridBag.setConstraints(studentDirectory,constraints);
        form.add(studentDirectory);
		  
        // Field database name
        constraints.gridx = 0;
        constraints.gridy = 6;
        gridBag.setConstraints(databaseName,constraints);
        form.add(databaseName);

        aux.add(form, BorderLayout.SOUTH);
	 
	groupForm.add(aux, BorderLayout.CENTER);
        icon = jImage.loadImage("course.gif");
	if (icon != null)
	    canvas = new ImageCanvas(icon);

        canvas.setSize(430,45);
	canvas.setBackground(Color.lightGray);
	groupForm.add(canvas,BorderLayout.NORTH);	  		  
        principal.add(groupForm);
        
	return principal;
    }

    /** Method for setting the fields HTML path and database name with the directory name of the course when the focus is 
     lost for the path field.*/
    public void focusLost(FocusEvent event) {
        Object source = event.getSource();
        String aux2 = null;
        if (source == path) {
            studentDirectory.setText(path.getText() + fileSeparator + "homework");
	    String aux = path.getText();
	    int index = aux.lastIndexOf(fileSeparator);
	    aux2 = aux.substring(index+1,aux.length());
	    pathHTML.setText("/" + aux2);
 	    databaseName.setText(aux2.substring(0,aux2.length()));
        }
	if (source == pathHTML) {
	    String aux = pathHTML.getText();
	    databaseName.setText(aux.substring(1,aux.length()));
	}
    }

    /** Method not implemented.*/
    public void focusGained(FocusEvent event) {
    }
}


