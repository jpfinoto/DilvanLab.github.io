/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents;

import java.util.*;
import java.io.*;
import agents.security.*;

/** Class that stores the information sent to the server and to the client.*/
public class Message implements Serializable {
    
    public Object ticket;              // ticket
    public Vector body= new Vector();  // body of the message
    
    /** Method for creation of a new instance from this class.*/
    public Message(){}
    
    /** Method for creation of a new instance from this class when threre is a ticket already.*/
    public Message(byte[] ticket) { this.ticket= ticket;}
    
    /** Method for decoding the message with the user's password. This password is into the ticket object.*/
    public void decode(String passwd)throws IOException, ClassNotFoundException {
        for (int aux1=0; aux1<body.size() ; aux1++) {
            body.setElementAt(ObjectInputCrypt.readObject(passwd, (byte[])body.elementAt(aux1)), aux1);
        }
    }
    
    /** Method for encoding the message with the user's password. This password is into the ticket object.*/
    public void encode(String passwd) throws IOException {
        for (int aux1=0; aux1<body.size() ; aux1++) {
            body.setElementAt(ObjectOutputCrypt.writeObject(passwd, body.elementAt(aux1)), aux1);
        }
    }
    
    /** Method for verifying if the ticket is enconded.*/
    public boolean isEncoded() {
        if (ticket==null) return false;
        if (ticket instanceof Ticket) return false;
        return true;
    }

    /** Method for verifying if the ticket was encoded.*/
    public boolean wasEncoded() {
        return !(ticket instanceof Ticket);
    }
}
