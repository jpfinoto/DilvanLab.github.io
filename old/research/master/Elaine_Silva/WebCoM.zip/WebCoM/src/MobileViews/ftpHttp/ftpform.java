/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package ftpHttp;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import java.net.*;
import javax.servlet.http.*;
import agents.security.*;
import agents.sql.*;
import agents.*;
import agents.agent.Defaults;

/** This class is used for the transfer of files from the student to his area in the server.*/
public class ftpform {
    File[] Arquivos, Diretorios;            // lista de arquivos e diretorios de um diretorio especifico
    static int ContadorArquivos = 0;
    static int ContadorDiretorios = 0;      // Contadores

    /* Method for getting the position in the string DiretorioSelecionado that indicates the 
     * path of the student.*/
    public int ObtemIndicePathUsuario(String Diretorio, String DiretorioSelecionado) {
        String PathUsuario;
        String SubTipo;
        StringTokenizer Analise = new StringTokenizer(DiretorioSelecionado);
        String TipoAcesso = Analise.nextToken();
        try {
            SubTipo = Analise.nextToken();
        } catch (NoSuchElementException e) { SubTipo = null;}
        if (SubTipo != null)
            PathUsuario = File.separator + TipoAcesso + "s" + File.separator + SubTipo + File.separator;
        else
            PathUsuario = File.separator + TipoAcesso + File.separator;
        String PathAux = PathUsuario.toLowerCase();
        int Indice = Diretorio.indexOf(PathAux);
        return Indice + PathUsuario.length();
    }
    
    /** Method for getting the files and directories from a especified directory.*/
    public void ObtemArquivosDiretorios(String Diretorio) {
        File currentDir = new File(Diretorio);               // Diretorio corrente
        String[] temporario = currentDir.list();            // Lista de arquivos e diretorios do diretorio corrente
        
        Arquivos = new File[temporario.length];              // Vetor de arquivos
        Diretorios = new File[temporario.length];            // Vetor de diretorios
        
        File[] temp = new File[temporario.length];
        for (int i=0;i<temp.length;i++)
            temp[i] = new File(Diretorio+File.separator+temporario[i]);  // Vetor temporario com o caminho de cada diretorio e arquivo
        
        ContadorArquivos = 0;
        ContadorDiretorios = 0;
        for(int i = 0; i < temp.length; i++) {
            if (temp[i].isFile()) {
                Arquivos[ContadorArquivos]=temp[i];
                ContadorArquivos++;
            } else {
                if (temp[i].isDirectory()) {
                    Diretorios[ContadorDiretorios]=temp[i];
                    ContadorDiretorios++;
                }
            }
        }
    }
    
    /* Method that returns the files from a directory.*/
    public File[] getArquivos() {
        return Arquivos;
    }
    
    /* Method that returns the directories from a directory.*/
    public File[] getDiretorios() {
        return Diretorios;
    }
    
    /* Method that returns the number of files from a directory.*/    
    public int getContadorArquivos() {
        return ContadorArquivos;
    }
    
    /* Method that returns the number of directories from a directory.*/    
    public int getContadorDiretorios() {
        return ContadorDiretorios;
    }
}







