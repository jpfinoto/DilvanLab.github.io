/******************************************************************************/
/* Mobile Views 1.0 - Mobile View System                                      */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

package agents.agent;

import java.util.Hashtable;
import java.util.Properties;
import java.io.*;

/** Class of information.*/
public class Defaults{

    // if the properties were configurated
    public static boolean PROPERTIES_OK = false;
    
    // General database
    public static String WEBCOMDATABASE = "";

    // Email host and Email sender
    public static String HOST = "";
    public static String FROM = "";
    public static String FROM_PASSWD = "";
    
    // Sql driver information
    public static String SQL_URL = "";
    public static String DRIVER_NAME = "";
    
    // FTP Mail Interval
    public static int FTPMAIL_INTERVAL = 0;
		
    // General password
    protected final static String PASSWD = "paswwhgtruytre";
	
    //	Validity time for tickets (in miliseconds)
    //	1000 - segundo 60 - minuto 60 - hora
    protected final static long TICKET_TIMEOUT = 1000 * 60 * 60 * 6;

    // Agents table
    static Hashtable agents;
    
    // Copyright information
    //public final static String COPYRIGHT = "WebCoM 2002 - by Dilvan Moreira & Elaine Silva";
    //public final static String VERSION = "1.0";

    /** Method for construction of the agents hastable.*/
    public final static Hashtable getAgents() {
        if (agents!=null) return agents;
        agents= new Hashtable();
        agents.put("TicketAgent", new TicketAgent());
        agents.put("UsersAgent", new UsersAgent());
        agents.put("FTPAgent", new FTPAgent());
        return agents;
    }

    /** Method for initialization of sql drivers.*/
    public final static void initSQLDrivers() throws ClassNotFoundException {        
        Class.forName(DRIVER_NAME);
    }

    /** Method for setting properties from properties file.
     * The properties file can be changed by the system administrator.
     */
    public final static void setPropertiesDefaults(InputStream in){
        try {
            
            Properties propertiesFile = new Properties();
            //InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("server.properties");
            if (in == null)
                System.out.println("ERRO");
            propertiesFile.load(in);

            //	Read the properties	 
            WEBCOMDATABASE = propertiesFile.getProperty("DATABASE_GENERAL");
            HOST = propertiesFile.getProperty("HOST_NAME");
            FROM = propertiesFile.getProperty("EMAIL");
            FROM_PASSWD = propertiesFile.getProperty("PASSWD_EMAIL");
            SQL_URL = propertiesFile.getProperty("SQL_URL");
            DRIVER_NAME = propertiesFile.getProperty("SQL_DRIVER");
            FTPMAIL_INTERVAL = Integer.parseInt(propertiesFile.getProperty("FTPMAIL_INTERVAL"));
            PROPERTIES_OK = true;
            if (FTPMAIL_INTERVAL != 0) {
                System.out.println("Starting FTP mail...");
                ftpMail.Course course = new ftpMail.Course(HOST, FROM.substring(0,FROM.indexOf('@')), FROM_PASSWD, FTPMAIL_INTERVAL, "-d");
                Thread t = new Thread(course);
                t.start();
            }
         } catch (Exception e) {
              System.out.println("Error getting properties file: " + e.toString());
         }
    }
}
