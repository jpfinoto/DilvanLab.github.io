/******************************************************************************/
/* WebCoM 1.0 - Web Course Manager                                            */
/*                                                                            */
/* Copyright (C) 2002 Elaine Quintino da Silva & Dilvan de Abreu Moreira.     */
/*                                                                            */
/* This library is free software; you can redistribute it and/or              */
/* modify it under the terms of the GNU Lesser General Public                 */
/* License as published by the Free Software Foundation; either               */
/* version 2.1 of the License, or (at your option) any later version.         */
/*                                                                            */
/* This library is distributed in the hope that it will be useful,            */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of             */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/* Lesser General Public License for more details.                            */
/*                                                                            */
/* You should have received a copy of the GNU Lesser General Public           */
/* License along with this library; if not, write to the Free Software        */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA  */
/*                                                                            */
/* Contact:                                                                   */
/*       Eletronic mail: elainesilva@zipmail.com or dilvan@computer.org       */
/*       Paper mail: Av. trabalahdor S�o Carlense, 400 Cx. Postal 668,        */
/*                   S�o Carlos,S�o Paulo                                     */
/*                   Brasil CEP 13560-970                                     */
/******************************************************************************/

import java.io.*;
import java.util.Hashtable;
import java.util.StringTokenizer;
import javax.servlet.*;
import javax.servlet.http.*;

/* Class for uploading files using http protocol */
public class UploadServlet extends HttpServlet {
    
    static final boolean DEBUG = false;
    static final boolean LOGGING = false;
    Hashtable table;
    PrintWriter log;
    
    protected void finalize() throws Throwable {
        closeLog();
    }
    
    public void doPost(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException {
        ServletOutputStream out = res.getOutputStream();
        //log = openLog("/tmp/upload.log");
        
        res.setContentType("text/html");
        int contentLength = req.getContentLength();
        
        out.println("<HTML><HEAD>");
        out.println("<TITLE>Upload Results</TITLE>");
        out.println("</HEAD>");
        out.println("<BASE HREF=\"../manager_files/\">");
        out.println("<BODY TEXT=\"#000000\" background=\"fundo2.gif\">");
        out.println("<FONT FACE=\"Arial, Helvetica, sans-serif\" SIZE=\"3\">");
        out.println("<B>Upload Results</B></FONT>");
        out.println("<HR><BR><CENTER><H3>");
        
        String contentType = req.getContentType();
        int ind = contentType.indexOf("boundary=");
        if(ind == -1) {
            out.println("IND is less than 0");
            return;
        }
        String boundary = contentType.substring(ind + 9);
        if(boundary == null) {
            out.println("boundary is null");
            return;
        }
        String boundaryString = "--" + boundary;
        ServletInputStream in = req.getInputStream();
        byte[] buffer = new byte[1024];
        table.clear();
        
        int result = readLine(in, buffer, 0, buffer.length);
        outer:
            while (true) {
                if(result <= 0) {
                    out.println("Error. Stream truncated");
                    break;
                }
                String line = new String(buffer, 0, result);
                
                if(!line.startsWith(boundaryString)) {
                    out.println("Error. MIME boundary missing.");
                    break;
                }
                result = readLine(in, buffer, 0, buffer.length);
                if(result <= 0){
                    if (DEBUG)
                        out.println("Error: boundary without contents.");
                    break;
                }
                
                line = new String(buffer, 0, result);
                StringTokenizer tokenizer = new StringTokenizer(line, ";\r\n");
                String token = tokenizer.nextToken();
                String upperToken = token.toUpperCase();
                if(!upperToken.startsWith("CONTENT-DISPOSITION")) {
                    out.println("Format error. Content-Disposition expected.");
                    break;
                }
                String disposition = upperToken.substring(21);
                if(!disposition.equals("FORM-DATA")) {
                    out.println("I don't know how to handle [" + disposition + "] disposition.");
                    break;
                }
                if(tokenizer.hasMoreElements()) {
                    token = tokenizer.nextToken();
                } else {
                    out.println("Format error. NAME expected.");
                    break;
                }
                int nameStart = token.indexOf("name=\"");
                int nameEnd = token.indexOf("\"", nameStart + 7);
                if(nameStart < 0 || nameEnd < 0) {
                    out.println("Format error. NAME expected.");
                    break;
                }
                String name = token.substring(nameStart + 6, nameEnd);
                if(tokenizer.hasMoreElements()) {
                    token = tokenizer.nextToken();
                    int tokenStart = token.indexOf("filename=\"");
                    int tokenEnd = token.indexOf("\"", tokenStart + 11);
                    if(tokenStart < 0 || tokenEnd < 0) {
                        out.println("Format error. FILENAME expected.");
                        break;
                    }
                    String filename = token.substring(tokenStart + 10, tokenEnd);
                    int lastindex = -1;
                    if((lastindex = filename.lastIndexOf('/')) < 0)
                        lastindex = filename.lastIndexOf('\\');
                    if(lastindex >= 0)
                        filename = filename.substring(lastindex + 1);
                    FileOutputStream f_out = null;
                    
                    String directory = getValue("DiretorioDestino");
                    try {
                        if(directory != null)
                            f_out = new FileOutputStream(directory + File.separator + filename);
                        else
                            out.println("Cannot open file " + directory + File.separator + filename);
                    }
                    catch(Exception exception) {
                        out.println("Cannot open file " + directory + File.separator + filename);
                        break;
                    }
                    appendValue(name, filename, true);
                    result = readLine(in, buffer, 0, buffer.length);
                    if(result <= 0) {
                        out.println("Error. Stream truncated 1");
                        break;
                    }
                    int size = 0;
                    try {
                        byte[] tmpbuffer = new byte[buffer.length];
                        int tmpbufferlen = 0;
                        boolean isFirst = true;
                        while((result = readLine(in, buffer, 0, buffer.length)) > 0)  {
                            if(isFirst && result == 2 && buffer[0] == '\r' && buffer[1] == '\n')
                                continue;
                            String tmp = new String(buffer, 0, result);
                            if (DEBUG)
                                out.println("read result:" + result + "(" + tmp + ")<BR>");
                            if(tmp.startsWith(boundaryString)) {
                                if (DEBUG)
                                    out.println("substract 2");
                                if(!isFirst) {
                                    size += tmpbufferlen - 2;
                                    f_out.write(tmpbuffer, 0, tmpbufferlen - 2);
                                }
                                continue outer;
                            }
                            else {
                                if(!isFirst) {
                                    size += tmpbufferlen;
                                    f_out.write(tmpbuffer, 0, tmpbufferlen);
                                }
                            }
                            System.arraycopy(buffer, 0, tmpbuffer, 0, result);
                            tmpbufferlen = result;
                            isFirst = false;
                        }
                    }
                    catch(IOException ioexception) {
                        if(log != null)
                            ioexception.printStackTrace(log);
                        out.println("IO Error while write to file:" + ioexception.toString());
                    }
                    catch(Exception exception2) {
                        if(log != null)
                            exception2.printStackTrace(log);
                        out.println("Error while write to file:" + exception2.toString());
                    }
                    finally {
                        if (DEBUG)
                            out.println("size:"+ size);
                        f_out.close();
                    }
                    result = readLine(in, buffer, 0, buffer.length);
                } else {
                    result = readLine(in, buffer, 0, buffer.length);
                    if(result <= 0) {
                        out.println("Error. Stream truncated 2");
                        break;
                    }
                    result = readLine(in, buffer, 0, buffer.length);
                    if(result <= 0) {
                        out.println("Error. Stream truncated 3");
                        break;
                    }
                    String value = new String(buffer, 0, result - 2);
                    appendValue(name, value, false);
                }
                result = readLine(in, buffer, 0, buffer.length); // exclude \r\n
            } // end while
            out.println("<BR><BR>End of the Upload. Refresh the directory!<BR><BR></H3>");
            out.println("<FORM><INPUT TYPE=button VALUE=\"    Exit    \" OnClick=\"window.close()\"></FORM>");
            out.println("</CENTER></BODY></HTML>");
            table.clear();
            
    }
    
    void appendValue(String name, String value, boolean isFile) {
        UploadData data = new UploadData(name, value, isFile);
        table.put(name, data);
    }
    
    String getValue(String name) {
        UploadData data = (UploadData)table.get(name);
        if(data == null)
            return null;
        else
            return data.value;
    }
    
    public String getServletInfo() {
        return "A servlet that uploads a file";
    }
    
    private PrintWriter openLog(String name) {
        return null;
    }
    
    private void closeLog() {
        if(log != null)
            log.close();
    }
    
    /** to fix JSDK 2.0's bug */
    int readLine(ServletInputStream in, byte[] b, int off, int len) throws IOException {
        if(len <= 0)
            return 0;
        int count = 0;
        int c;
        while((c = in.read()) != -1)  {
            b[off++] = (byte)c;
            count++;
            if(c == '\n' || count == len)
                break;
        }
        return count > 0 ? count: -1;
    }
    
    public UploadServlet() {
        table = new Hashtable();
    }
}

class UploadData {
    String name;
    String value;
    boolean isFile;
    
    UploadData(String s, String s1, boolean flag) {
        name = s;
        value = s1;
        isFile = flag;
    }
}
